function s=summaryData(r)
% Descriptive endpoint distributions from matched, contiguous ZOH windows.
fs=r.model.Fs; n=size(r.reference,1); K=size(r.samples,3);
L=min(n,max(1,round(r.cfg.summaryTerminalWindow_s*fs))); W=floor(n/L);
s=struct('windowSamples',L,'window_s',L/fs,'windowsPerRecord',W, ...
    'discardedSamplesPerRecord',n-W*L,'testV',zeros(W,3),'testP',zeros(W,3), ...
    'modelV',zeros(W*K,3),'modelP',zeros(W*K,3));
for w=1:W
    rows=(w-1)*L+(1:L);
    [v,p]=imupulse.integrate(r.reference(rows,:),fs);
    s.testV(w,:)=v(end,:); s.testP(w,:)=p(end,:);
    for k=1:K
        [v,p]=imupulse.integrate(r.samples(rows,:,k),fs);
        q=(k-1)*W+w; s.modelV(q,:)=v(end,:); s.modelP(q,:)=p(end,:);
    end
end
names={'X','Y','Z'}; rows={};
for j=find(r.model.selectedMask)
    for quantity={'Velocity','Position'}
        if strcmp(quantity{1},'Velocity')
            a=s.testV(:,j); b=s.modelV(:,j); unit='m/s';
        else
            a=s.testP(:,j); b=s.modelP(:,j); unit='m';
        end
        qa=imupulse.percentile(a,[5 50 95]); qb=imupulse.percentile(b,[5 50 95]);
        rows(end+1,:)={names{j},quantity{1},unit,L/fs,W,W*K,n-W*L, ...
            qa(1),qa(2),qa(3),qb(1),qb(2),qb(3)}; %#ok<AGROW>
    end
end
s.table=cell2table(rows,'VariableNames',{'Axis','Quantity','Unit','Window_s', ...
    'TestWindows','GeneratedWindows','DiscardedSamplesPerRecord', ...
    'TestP05','TestP50','TestP95','GeneratedP05','GeneratedP50','GeneratedP95'});
end
