function y=fromBins(F,bins)
% Efficient MATLAB reconstruction; C++ evaluates the equivalent sine sum.
n=numel(F); G=zeros(n,1); bins=bins(:);
G(bins+1)=F(bins+1);
paired=bins;
if mod(n,2)==0
    paired=paired(paired~=n/2);
    if any(bins==n/2), G(n/2+1)=real(G(n/2+1)); end
end
G(n-paired+1)=conj(F(paired+1));
y=real(ifft(G));
end
