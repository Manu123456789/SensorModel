// SINGLE-.CPP integration scaffold: replace only the EXAMPLE adapter bindings.
// Offline: Export_IMU_Pulse_To_CPP(PulseModel,'IMU_Pulse_Integration.cpp')
// This template refuses simulation until the MATLAB exporter supplies parameters.
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>

// ============================================================
// Types / model constants (file-local; no shared-memory defines)
// ============================================================
struct ImuPulseParameters {
    bool fitted;
    double Fs;
    double baseline_ug[3];
    double noise_factor[3][3];  // factor of STATIONARY quiet covariance C
    std::size_t event_count, sample_count;
    const double (*samples_ug)[3]; // all joint XYZ templates, stacked by ROW
    const std::size_t *offset, *length, *gap;
    const unsigned *event_class;   // X+,X-,Y+,Y-,Z+,Z- => 0..5
    double class_probability[6];
    double transition_probability[6][6];
    bool use_markov;
    std::size_t burn_in_samples;
    double gm_phi; // quiet[k] = phi*quiet[k-1] + sqrt(1-phi^2)*factor*N(0,I)
};
struct ImuPulseState {
    bool initialized, have_event, have_cache, spare_available, cached_is_pulse;
    std::uint32_t event_rng, gaussian_rng;
    double spare, cache_ug[3], gm_state_ug[3];
    std::size_t event, gap_remaining, pulse_row;
    unsigned previous_class;
    std::uint64_t cached_tick;
};

// BEGIN MATLAB MODEL CONSTANTS
// Dummy storage ONLY. fitted=false deliberately prevents accidental use.
static const double imu_template_samples[1][3] = {{0,0,0}};
static const std::size_t imu_event_offset[1]={0}, imu_event_length[1]={1}, imu_event_gap[1]={1};
static const unsigned imu_event_class[1]={0};
static const ImuPulseParameters imu_pulse_parameters = {
    false,100.0,{0,0,0},{{0,0,0},{0,0,0},{0,0,0}},1,1,
    imu_template_samples,imu_event_offset,imu_event_length,imu_event_gap,imu_event_class,
    {1,0,0,0,0,0},
    {{1,0,0,0,0,0},{1,0,0,0,0,0},{1,0,0,0,0,0},
     {1,0,0,0,0,0},{1,0,0,0,0,0},{1,0,0,0,0,0}},false,0,0
};
// END MATLAB MODEL CONSTANTS

// ============================================================
// Function prototypes
// ============================================================
static bool imu_pulse_validate(const ImuPulseParameters&);
static bool imu_pulse_reset(const ImuPulseParameters&,ImuPulseState&,std::uint32_t);
static bool imu_pulse_sample(const ImuPulseParameters&,ImuPulseState&,
                             std::uint64_t,double (&)[3]);
static void imu_pulse_raw_step(const ImuPulseParameters&,ImuPulseState&,double (&)[3]);
static double imu_pulse_uniform(std::uint32_t&);
static double imu_pulse_gaussian(ImuPulseState&);
static bool imu_rotation_valid(const double (&)[3][3]);

// ============================================================
// EXAMPLE input/output bindings: replace with YOUR sim variables.
// These are adapters to make the scaffold compile; no shared memory is required.
// All other_noise/other_bias values below must ALREADY be PLATFORM-frame [ug].
// ============================================================
struct ImuExampleInputs {
    bool reset_model=true;             // true ONCE per MC run/regime
    std::uint32_t run_seed=1234;
    std::uint64_t sensor_tick=0;        // 0,1,2,... at PulseModel.Fs
    double sensor_dt_s=0;              // set to 1/PulseModel.Fs
    bool inject_quiet_baseline=true;   // false if same baseline is added elsewhere
    double R_sensor_to_platform[3][3]={{1,0,0},{0,1,0},{0,0,1}};
    double other_noise_ug[3]={0,0,0};   // exclude the old white-noise source replaced here
    double other_bias_ug[3]={0,0,0};    // exclude duplicate test-derived mean/quiet baseline
};
enum class ImuExampleStatus { Ok,NotFitted,BadParameters,BadDt,BadRotation,BadClock };
struct ImuExampleOutputs {
    ImuExampleStatus status=ImuExampleStatus::NotFitted;
    double noise_ug[3]={0,0,0}, bias_ug[3]={0,0,0};
    double acceleration_error_ug[3]={0,0,0};
    double delta_velocity_error_ft_s[3]={0,0,0};
};
static ImuExampleInputs imu_input;
static ImuExampleOutputs imu_output;

// ============================================================
// YOUR FUNCTION SHAPE
// ============================================================
void IMU_error()
{
    // Persistent LOCAL generator memory; reset explicitly for each MC run.
    static ImuPulseState pulse_state = {};
    double model_noise_sensor_ug[3];
    double model_noise_platform_ug[3]={0,0,0};
    double model_bias_platform_ug[3]={0,0,0};
    double noise[3], bias[3];

    // ... your existing scale-factor, delay, misalignment calculations ...

    const ImuPulseParameters& p=imu_pulse_parameters;
    imu_output=ImuExampleOutputs{}; // On failure no stale output is marked valid.
    if (!p.fitted) { imu_output.status=ImuExampleStatus::NotFitted; return; }
    const double expected_dt=1.0/p.Fs;
    if (!std::isfinite(imu_input.sensor_dt_s) || imu_input.sensor_dt_s<=0 ||
        std::abs(imu_input.sensor_dt_s-expected_dt)>1e-8*expected_dt) {
        imu_output.status=ImuExampleStatus::BadDt; return;
    }
    if (!imu_rotation_valid(imu_input.R_sensor_to_platform)) {
        imu_output.status=ImuExampleStatus::BadRotation; return;
    }
    if (imu_input.reset_model || !pulse_state.initialized) {
        if (!imu_pulse_reset(p,pulse_state,imu_input.run_seed)) {
            imu_output.status=ImuExampleStatus::BadParameters; return;
        }
        imu_input.reset_model=false;
    }

    // Generate ONCE per XYZ sensor update, OUTSIDE the ii loop.
    // Pulse samples replace the Gaussian background during events, exactly as
    // in MATLAB. The output here excludes the constant quiet baseline.
    if (!imu_pulse_sample(p,pulse_state,imu_input.sensor_tick,model_noise_sensor_ug)) {
        imu_output.status=ImuExampleStatus::BadClock; return;
    }

    // SENSOR -> PLATFORM, with the same column-vector convention as MATLAB:
    // platform = R_sensor_to_platform * sensor. Do not transpose again.
    for (int ii=0; ii<3; ++ii) {
        for (int jj=0; jj<3; ++jj) {
            const double r=imu_input.R_sensor_to_platform[ii][jj];
            model_noise_platform_ug[ii]+=r*model_noise_sensor_ug[jj];
            if (imu_input.inject_quiet_baseline)
                model_bias_platform_ug[ii]+=r*p.baseline_ug[jj];
        }
    }

    // ========================================================
    // YOUR EXISTING FINAL XYZ LOOP: add the new components HERE.
    // Replace adapter sums with your actual existing sums.
    // ASSUMPTION: noise/bias are sampled errors [ug], not RMS parameters.
    // ========================================================
    for (int ii=0; ii<3; ++ii) {
        noise[ii] = imu_input.other_noise_ug[ii] + model_noise_platform_ug[ii];
        bias[ii]  = imu_input.other_bias_ug[ii]  + model_bias_platform_ug[ii];

        // Current sensor acceleration error [ug]. It includes the pulse mean;
        // do not zero-center these positive-biased pulses or add their mean twice.
        imu_output.noise_ug[ii]=noise[ii];
        imu_output.bias_ug[ii]=bias[ii];
        imu_output.acceleration_error_ug[ii]=noise[ii]+bias[ii];

        // ALTERNATIVE interface: a velocity-increment error [ft/s].
        // Apply this only if your internal accumulator consumes delta velocity.
        imu_output.delta_velocity_error_ft_s[ii]=
            (noise[ii]+bias[ii])*1e-6*9.80665/0.3048*imu_input.sensor_dt_s;

        // Connect ONE appropriate quantity to your existing internal update:
        // - acceleration interface: acceleration_error_ug[ii]
        // - delta-velocity interface: delta_velocity_error_ft_s[ii]
        // Your omitted update/units determine which applies. Do not inject both.
    }
    imu_output.status=ImuExampleStatus::Ok;
    return;
}

// ============================================================
// Helpers: keep below IMU_error() in the SAME .cpp file.
// ============================================================
static double imu_pulse_uniform(std::uint32_t& state)
{
    state ^= state<<13; state ^= state>>17; state ^= state<<5;
    return (static_cast<double>(state)+0.5)/4294967296.0; // strictly (0,1)
}
static double imu_pulse_gaussian(ImuPulseState& s)
{
    if (s.spare_available) { s.spare_available=false; return s.spare; }
    const double radius=std::sqrt(-2.0*std::log(imu_pulse_uniform(s.gaussian_rng)));
    const double angle=6.2831853071795864769*imu_pulse_uniform(s.gaussian_rng);
    s.spare=radius*std::sin(angle); s.spare_available=true;
    return radius*std::cos(angle);
}
static bool imu_pulse_validate(const ImuPulseParameters& p)
{
    if (!std::isfinite(p.gm_phi) || p.gm_phi<0 || p.gm_phi>=1) return false;
    if (!p.fitted || !std::isfinite(p.Fs) || p.Fs<=0 || p.event_count==0 ||
        p.sample_count==0 || !p.samples_ug || !p.offset || !p.length || !p.gap || !p.event_class)
        return false;
    std::size_t count[6]={0,0,0,0,0,0};
    for (std::size_t k=0;k<p.event_count;++k) {
        if (p.event_class[k]>=6 || p.length[k]==0 || p.offset[k]>=p.sample_count ||
            p.length[k]>p.sample_count-p.offset[k]) return false;
        ++count[p.event_class[k]];
    }
    for (std::size_t row=0;row<p.sample_count;++row)
        for (int j=0;j<3;++j) if (!std::isfinite(p.samples_ug[row][j])) return false;
    double sum=0;
    for (int j=0;j<6;++j) {
        if (!std::isfinite(p.class_probability[j]) || p.class_probability[j]<0 ||
            (p.class_probability[j]>0 && count[j]==0)) return false;
        sum+=p.class_probability[j];
        double row_sum=0;
        for (int k=0;k<6;++k) {
            const double q=p.transition_probability[j][k];
            if (!std::isfinite(q) || q<0 || (q>0 && count[k]==0)) return false;
            row_sum+=q;
        }
        if (std::abs(row_sum-1)>1e-8) return false;
    }
    if (std::abs(sum-1)>1e-8) return false;
    for (int i=0;i<3;++i) {
        if (!std::isfinite(p.baseline_ug[i])) return false;
        for (int j=0;j<3;++j) if (!std::isfinite(p.noise_factor[i][j])) return false;
    }
    return true;
}
static void imu_pulse_raw_step(const ImuPulseParameters& p,ImuPulseState& s,double (&out)[3])
{
    // Advance the latent quiet process EVERY sample, including event intervals.
    double gaussian[3]; for (int j=0;j<3;++j) gaussian[j]=imu_pulse_gaussian(s);
    const double innovation_scale=std::sqrt(1.0-p.gm_phi*p.gm_phi);
    for (int i=0;i<3;++i) {
        double excitation=0;
        for (int j=0;j<3;++j) excitation+=p.noise_factor[i][j]*gaussian[j];
        s.gm_state_ug[i]=p.gm_phi*s.gm_state_ug[i]+innovation_scale*excitation;
    }
    if (!s.have_event) {
        const double* probability=(s.previous_class<6 && p.use_markov) ?
            p.transition_probability[s.previous_class] : p.class_probability;
        double u=imu_pulse_uniform(s.event_rng),total=0; unsigned mark=0,last=0;
        for (unsigned j=0;j<6;++j) {
            if (probability[j]>0) last=j;
            total+=probability[j]; if (u<total) { mark=j; break; }
            mark=last;
        }
        std::size_t available=0;
        for (std::size_t k=0;k<p.event_count;++k) if (p.event_class[k]==mark) ++available;
        const std::size_t pick=static_cast<std::size_t>(imu_pulse_uniform(s.event_rng)*available);
        std::size_t seen=0;
        for (std::size_t k=0;k<p.event_count;++k) if (p.event_class[k]==mark) {
            if (seen++==pick) { s.event=k; break; }
        }
        s.gap_remaining=p.gap[s.event]; s.pulse_row=0; s.have_event=true;
    }
    s.cached_is_pulse=(s.gap_remaining==0);
    if (s.gap_remaining>0) {
        for (int i=0;i<3;++i) out[i]=s.gm_state_ug[i];
        --s.gap_remaining;
    } else {
        const std::size_t row=p.offset[s.event]+s.pulse_row;
        for (int i=0;i<3;++i) out[i]=p.samples_ug[row][i];
        if (++s.pulse_row==p.length[s.event]) {
            s.previous_class=p.event_class[s.event]; s.have_event=false;
        }
    }
}
static bool imu_pulse_reset(const ImuPulseParameters& p,ImuPulseState& s,std::uint32_t seed)
{
    s=ImuPulseState{};
    if (!imu_pulse_validate(p)) return false;
    s.event_rng=seed^0x9E3779B9u; if (!s.event_rng) s.event_rng=1;
    s.gaussian_rng=seed^0x85EBCA6Bu; if (!s.gaussian_rng) s.gaussian_rng=1;
    s.previous_class=6;
    // Stationary initialization avoids a variance ramp at startup.
    double initial[3]; for (int j=0;j<3;++j) initial[j]=imu_pulse_gaussian(s);
    for (int i=0;i<3;++i) for (int j=0;j<3;++j)
        s.gm_state_ug[i]+=p.noise_factor[i][j]*initial[j];
    double discard[3];
    for (std::size_t k=0;k<p.burn_in_samples;++k) imu_pulse_raw_step(p,s,discard);
    s.initialized=true; s.have_cache=false;
    return true;
}
static bool imu_pulse_sample(const ImuPulseParameters& p,ImuPulseState& s,
                             std::uint64_t tick,double (&out)[3])
{
    if (!s.initialized || (s.have_cache && tick<s.cached_tick)) return false;
    if (!s.have_cache) {
        imu_pulse_raw_step(p,s,s.cache_ug); s.cached_tick=0; s.have_cache=true;
    }
    while (s.cached_tick<tick) {
        imu_pulse_raw_step(p,s,s.cache_ug); ++s.cached_tick;
    }
    for (int j=0;j<3;++j) out[j]=s.cache_ug[j];
    return true;
}
static bool imu_rotation_valid(const double (&R)[3][3])
{
    for (int i=0;i<3;++i) for (int j=0;j<3;++j) {
        if (!std::isfinite(R[i][j])) return false;
        double dot=0; for (int k=0;k<3;++k) dot+=R[i][k]*R[j][k];
        if (std::abs(dot-(i==j ? 1.0 : 0.0))>1e-6) return false;
    }
    const double determinant=
        R[0][0]*(R[1][1]*R[2][2]-R[1][2]*R[2][1])-
        R[0][1]*(R[1][0]*R[2][2]-R[1][2]*R[2][0])+
        R[0][2]*(R[1][0]*R[2][1]-R[1][1]*R[2][0]);
    return std::abs(determinant-1.0)<=1e-6;
}
