function [C,T]=coefficients(m)
names={'X','Y','Z'}; a={}; b=cell(0,6);
for j=find(m.selectedMask)
    K=numel(m.toneFreq{j});
    a(end+1,:)={names{j},j-1,m.Fs,m.recordSamples,m.period_s,m.mean_ug(j), ...
        m.whiteSigma_ug(j),K,3*K+2,m.phaseMode}; %#ok<AGROW>
    for k=1:K
        b(end+1,:)={names{j},k-1,m.toneBin{j}(k),m.toneFreq{j}(k), ...
            m.toneAmp{j}(k),m.tonePhase{j}(k)}; %#ok<AGROW>
    end
end
C=cell2table(a,'VariableNames',{'SensorAxis','SensorAxis0','Fs_Hz','RecordSamples', ...
    'Period_s','MeanError_ug','WhiteSigma_ug','NumberOfTones','CoreCoefficientCount','PhaseMode'});
columns={'Axis','ToneIndex0','FFTBin0','Frequency_Hz','Amplitude_ug','Phase_rad'};
if isempty(b)
    % Keep numeric columns numeric even for the valid zero-tone comparison.
    T=table(cell(0,1),zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1), ...
        'VariableNames',columns);
else
    T=cell2table(b,'VariableNames',columns);
end
end
