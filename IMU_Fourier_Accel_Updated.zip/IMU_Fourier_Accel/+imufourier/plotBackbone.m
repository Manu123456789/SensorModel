function figs=plotBackbone(r)
% Validation layout retains the user's measured / tones / configured-model view.
figs=gobjects(0); names={'X','Y','Z'}; toneColor=[.49 .18 .56]; modelColor=[.8 .15 .15];
for j=find(r.model.selectedMask)
    f=figure('Name',['V_' names{j} '_Tone_Validation_Backbone'],'NumberTitle','off', ...
        'Visible',r.cfg.figureVisible,'Position',[50 50 1500 850]); figs(end+1)=f; %#ok<AGROW>
    t=tiledlayout(f,2,3,'TileSpacing','compact','Padding','compact');
    frequency=r.frequency_Hz; keep=frequency>0; Pr=r.referencePSD(:,j);
    Pt=r.tonePSD(:,j); Pm=mean(r.psd(:,j,:),3);
    ax=nexttile(t); loglog(ax,frequency(keep),max(Pr(keep),realmin),'k','DisplayName',r.referenceLabel); hold(ax,'on');
    loglog(ax,frequency(keep),max(Pt(keep),realmin),'Color',toneColor,'DisplayName','Aligned tones only');
    loglog(ax,frequency(keep),max(Pm(keep),realmin),'Color',modelColor,'DisplayName','Configured model mean');
    title(ax,'V1: PSD; linear powers averaged'); xlabel(ax,'Frequency [Hz]'); ylabel(ax,'PSD [ug^2/Hz]'); finish(ax);
    ax=nexttile(t); plot(ax,frequency,cumtrapz(frequency,Pr),'k','DisplayName',r.referenceLabel); hold(ax,'on');
    plot(ax,frequency,cumtrapz(frequency,Pt),'Color',toneColor,'DisplayName','Aligned tones only');
    plot(ax,frequency,cumtrapz(frequency,Pm),'Color',modelColor,'DisplayName','Configured model mean');
    title(ax,'V2: cumulative integrated PSD power'); xlabel(ax,'Frequency [Hz]'); ylabel(ax,'Cumulative power [ug^2]'); finish(ax);
    ax=nexttile(t); lag=(-r.lag:r.lag)'/r.model.Fs;
    plot(ax,lag,symmetrize(r.referenceACF(:,j)),'k','DisplayName',r.referenceLabel); hold(ax,'on');
    plot(ax,lag,symmetrize(r.toneACF(:,j)),'Color',toneColor,'DisplayName','Aligned tones only');
    plot(ax,lag,symmetrize(r.meanACF(:,j)),'Color',modelColor,'DisplayName','Mean covariance, normalized once');
    title(ax,'V3: original ensemble ACF procedure'); xlabel(ax,'Lag [s]'); ylabel(ax,'Normalized ACF'); finish(ax);
    ax=nexttile(t); loglog(ax,r.allanTau_s,max(sqrt(r.referenceAllanVariance(:,j)),realmin),'k','DisplayName',r.referenceLabel); hold(ax,'on');
    loglog(ax,r.allanTau_s,max(sqrt(r.toneAllanVariance(:,j)),realmin),'Color',toneColor,'DisplayName','Aligned tones only');
    deviation=sqrt(mean(r.allanVariance(:,j,:),3));
    loglog(ax,r.allanTau_s,max(deviation,realmin),'Color',modelColor,'DisplayName','sqrt(mean(Allan variance))');
    title(ax,'V4: Allan deviation; variance averaged first'); xlabel(ax,'Averaging time tau [s]'); ylabel(ax,'Allan deviation [ug]'); finish(ax);
    ax=nexttile(t); row=strcmp(r.metricNames,'Std_ug');
    bar(ax,[std(r.reference(:,j),1) std(r.toneOnly(:,j),1) sqrt(mean(r.metricValues(row,j,:).^2,'all'))]);
    set(ax,'XTickLabel',{'Measured','Tones','Model'}); title(ax,'V5: AC RMS; no time-history averaging'); ylabel(ax,'AC RMS [ug]'); grid(ax,'on');
    ax=nexttile(t); center=r.histCenters{j};
    plot(ax,center,r.histReference(:,j),'k','DisplayName',r.referenceLabel); hold(ax,'on');
    toneProb=histcounts(r.toneOnly(:,j),r.histEdges{j},'Normalization','probability');
    plot(ax,center,toneProb,'Color',toneColor,'DisplayName','Aligned tones only');
    plot(ax,center,mean(r.histogram(:,j,:),3),'Color',modelColor,'DisplayName','Model (equally weighted pooled runs)');
    title(ax,'V6: amplitude distributions'); xlabel(ax,'Error [ug]'); ylabel(ax,'Probability/bin'); finish(ax);
    title(t,sprintf('Sensor %s: added white sigma %.5g ug; %d distinct configured histories', ...
        names{j},r.model.whiteSigma_ug(j),r.distinctModelRuns));
end
end
function y=symmetrize(x)
y=[flipud(x(2:end));x];
end
function finish(ax)
legend(ax,'show','Location','best'); grid(ax,'on');
end
