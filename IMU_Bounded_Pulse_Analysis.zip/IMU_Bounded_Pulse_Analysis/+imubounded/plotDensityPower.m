function figs=plotDensityPower(r)
% Six extra tiles separate sign-law, pulse-density and spectral-power failures.
figs=gobjects(0); names={'X','Y','Z'}; red=[.8 .15 .15]; m=r.model;
for j=find(m.selectedMask)
    f=figure('Name',['G_' names{j} '_Signed_Density_and_Power'],'NumberTitle','off', ...
        'Visible',r.cfg.figureVisible,'Position',[50 50 1500 850]); figs(end+1)=f; %#ok<AGROW>
    t=tiledlayout(f,2,3,'TileSpacing','compact','Padding','compact');
    s=r.refEvents{j}; peaks=[];
    for k=1:numel(r.events), e=r.events{k}; peaks=[peaks;e{j}.peak_ug]; end %#ok<AGROW>
    ax=nexttile(t); drawCDF(ax,s.peak_ug(s.peak_ug>0),'k',r.referenceLabel); hold(ax,'on');
    drawCDF(ax,peaks(peaks>0),red,'Pooled generated'); title(ax,'G1: POSITIVE detected peak magnitude'); xlabel(ax,'Magnitude [ug]'); finishCDF(ax);
    ax=nexttile(t); drawCDF(ax,-s.peak_ug(s.peak_ug<0),'k',r.referenceLabel); hold(ax,'on');
    drawCDF(ax,-peaks(peaks<0),red,'Pooled generated'); title(ax,'G2: NEGATIVE detected peak magnitude'); xlabel(ax,'Absolute magnitude [ug]'); finishCDF(ax);
    ax=nexttile(t); compareBars(ax,r,j,{'PositiveRate_Hz','NegativeRate_Hz'});
    title(ax,'G3: signed COMPLETE-event density'); ylabel(ax,'Events / s');
    ax=nexttile(t); compareBars(ax,r,j,{'PositiveEventOccupancy','NegativeEventOccupancy'});
    title(ax,'G4: signed detected EVENT occupancy'); ylabel(ax,'Fraction of all samples');
    ax=nexttile(t); keep=r.frequency_Hz>0; average=mean(r.psd(:,j,:),3);
    ratio=10*log10(max(average,realmin))-10*log10(max(r.referencePSD(:,j),realmin));
    semilogx(ax,r.frequency_Hz(keep),ratio(keep),'Color',red); yline(ax,0,'k:');
    title(ax,'G5: model / measured Welch PSD ratio'); xlabel(ax,'Frequency [Hz]'); ylabel(ax,'Power ratio [dB]'); grid(ax,'on');
    ax=nexttile(t); row=find(strcmp(string(r.PowerSummary.Axis),names{j})); p=r.PowerSummary(row,:);
    bars=bar(ax,[p.MeasuredVariance_ug2 p.ModelMeanVariance_ug2; p.MeasuredWelchPower_ug2 p.ModelMeanWelchPower_ug2]);
    bars(1).FaceColor=[.1 .1 .1]; bars(2).FaceColor=red;
    set(ax,'XTickLabel',{'Time variance','Integrated Welch'}); ylabel(ax,'Power [ug^2]');
    legend(ax,r.referenceLabel,'Generated mean','Location','best'); title(ax,'G6: total power / variance consistency'); grid(ax,'on');
    title(t,sprintf('Sensor %s: separate signed laws and density | generated bound violations = %d',names{j},r.boundViolations(j)));
end
end
function compareBars(ax,r,j,fields)
measured=zeros(2,1); average=measured; low=measured; high=measured;
for k=1:2
    row=strcmp(r.metricNames,fields{k}); v=reshape(r.metricValues(row,j,:),[],1);
    measured(k)=r.referenceMetrics(row,j); average(k)=mean(v); q=imubounded.percentile(v,[5 95]); low(k)=q(1); high(k)=q(2);
end
b=bar(ax,[measured average]); b(1).FaceColor=[.1 .1 .1]; b(2).FaceColor=[.8 .15 .15]; hold(ax,'on');
locations=b(2).XEndPoints;
for k=1:2, plot(ax,[locations(k) locations(k)],[low(k) high(k)],'k-','HandleVisibility','off'); end
set(ax,'XTickLabel',{'Positive','Negative'}); legend(ax,r.referenceLabel,'Generated mean','Location','best'); grid(ax,'on');
end
function drawCDF(ax,x,color,label)
x=sort(x(isfinite(x)));
if isempty(x), plot(ax,NaN,NaN,'Color',color,'DisplayName',[label ': no events']);
else, stairs(ax,[x(1);x],[0;(1:numel(x))'/numel(x)],'Color',color,'LineWidth',1.3,'DisplayName',label); end
end
function finishCDF(ax)
ylabel(ax,'Cumulative probability'); ylim(ax,[0 1]); legend(ax,'show','Location','best'); grid(ax,'on');
end
