function [m,info]=fit(x,fs,selected,c)
% Twelve runtime scalars per axis. Bounds apply to COMPLETE generated error.
m=struct('Fs',fs,'selectedMask',selected,'shape',c.pulseShape, ...
    'baseline',zeros(1,3),'threshold',Inf(1,3),'release',Inf(1,3), ...
    'bgMu',zeros(1,3),'bgSigma',zeros(1,3),'lower',zeros(1,3),'upper',zeros(1,3), ...
    'meanGapSamples',NaN(1,3),'gapProbability',NaN(1,3),'negativeProbability',zeros(1,3), ...
    'logMu',zeros(3,2),'logSigma',zeros(3,2),'widthSamples',ones(3,2));
m.baseline(selected)=median(x(:,selected),1);
robust=1.4826*median(abs(x-m.baseline),1); robust=max(robust,eps(max(1,max(abs(x),[],1))));
m.threshold(selected)=c.detectSigma*robust(selected);
manual=selected & ~isnan(c.manualThreshold_ug); m.threshold(manual)=c.manualThreshold_ug(manual);
m.release(selected)=min(c.releaseSigma*robust(selected),.8*m.threshold(selected));
for iteration=1:10
    e=imubounded.detect(x,m); updated=m.baseline;
    for j=find(selected)
        quiet=~e.mask(:,j); assert(nnz(quiet)>=max(30,.1*size(x,1)),'Too little quiet data; inspect detection.');
        updated(j)=mean(x(quiet,j));
    end
    change=max(abs(updated(selected)-m.baseline(selected))./robust(selected)); m.baseline=updated;
    if change<1e-6, break; end
end
e=imubounded.detect(x,m);
info=struct('quietMask',~e.mask,'events',{imubounded.eventStats(x,m)},'amplitude',{cell(1,3)}, ...
    'observedMeanGap',NaN(1,3),'targetRate_Hz',zeros(1,3),'targetOccupancy',zeros(3,2), ...
    'signCounts',zeros(3,2),'projectionSignConflicts',zeros(1,3),'projectionOverCap',zeros(1,3), ...
    'gapWasLimited',false(1,3),'fitExitFlags',zeros(3,3));
for j=find(selected)
    quiet=info.quietMask(:,j); assert(nnz(quiet)>=max(30,.1*size(x,1)),'Too few final quiet samples.');
    m.lower(j)=min(x(:,j)); m.upper(j)=max(x(:,j));
    assert(m.lower(j)<m.upper(j),'A flat channel cannot identify a pulse model.');
    [m.bgMu(j),m.bgSigma(j),info.fitExitFlags(j,1)]=imubounded.fitBoundedNormal(x(quiet,j),m.lower(j),m.upper(j));
    s=info.events{j}; n=numel(s.peak_ug);
    info.targetOccupancy(j,:)=[s.positiveOccupancy s.negativeOccupancy];
    assert(n>=c.minEvents,'Too few complete events: inspect thresholds or extend row window.');
    classes=1+(s.peak_ug<0); amplitude=zeros(n,1); weights=ones(n,1);
    for k=1:n
        rows=s.start(k):s.stop(k); w=imubounded.shape(m.shape,numel(rows));
        estimate=sum(w.*(x(rows,j)-m.bgMu(j)))/sum(w.^2);
        info.projectionSignConflicts(j)=info.projectionSignConflicts(j)+(sign(estimate)~=sign(s.peak_ug(k)));
        amplitude(k)=abs(estimate);
        if strcmp(c.amplitudeWeight,'samples'), weights(k)=numel(rows); end
    end
    for signIndex=1:2
        which=classes==signIndex; info.signCounts(j,signIndex)=nnz(which);
        if ~any(which), continue; end
        m.widthSamples(j,signIndex)=max(1,round(mean(s.width_s(which))*fs));
        if signIndex==1, cap=m.upper(j)-m.bgMu(j); else, cap=m.bgMu(j)-m.lower(j); end
        assert(cap>0,'No amplitude support for an observed sign class.');
        a=amplitude(which); wgt=weights(which);
        assert(all(a>0 & isfinite(a)),'Zero/invalid pulse projection: inspect the chosen pulse shape.');
        info.projectionOverCap(j)=info.projectionOverCap(j)+nnz(a>cap);
        a=min(a,cap); % Projection support correction is reported; generated outputs are NOT clipped.
        [m.logMu(j,signIndex),m.logSigma(j,signIndex),info.fitExitFlags(j,signIndex+1)]= ...
            imubounded.fitBoundedLog(a,wgt,cap);
    end
    info.amplitude{j}=struct('magnitude_ug',amplitude,'class',classes,'weight',weights);
    m.negativeProbability(j)=mean(classes==2);
    info.targetRate_Hz(j)=nnz(e.start{j}>1)*fs/(size(x,1)-1);
    meanWidth=[1-m.negativeProbability(j) m.negativeProbability(j)]*m.widthSamples(j,:)';
    requestedGap=fs/info.targetRate_Hz(j)-meanWidth;
    info.gapWasLimited(j)=requestedGap<1;
    m.meanGapSamples(j)=max(1,requestedGap); m.gapProbability(j)=1/m.meanGapSamples(j);
    gaps=s.gap_s(isfinite(s.gap_s))*fs;
    if ~isempty(gaps), info.observedMeanGap(j)=mean(gaps); end
end
end
