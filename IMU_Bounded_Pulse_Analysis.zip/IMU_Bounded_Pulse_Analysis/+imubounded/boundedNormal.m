function x=boundedNormal(center,sigma,lo,hi,stream)
% Conditional normal rejection, not clipping random output samples.
originalSize=size(center); center=max(lo,min(hi,center(:))); % Center roundoff only.
if sigma==0, x=reshape(center,originalSize); return; end
x=center+sigma*randn(stream,size(center)); bad=~isfinite(x)|x<lo|x>hi;
while any(bad(:))
    x(bad)=center(bad)+sigma*randn(stream,nnz(bad),1);
    bad=~isfinite(x)|x<lo|x>hi;
end
x=reshape(x,originalSize);
end
