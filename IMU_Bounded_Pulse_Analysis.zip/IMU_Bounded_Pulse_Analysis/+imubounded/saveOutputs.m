function saveOutputs(r,folder)
if ~isfolder(folder), mkdir(folder); end
results=rmfield(r,'figures'); BoundedModel=r.model; %#ok<NASGU>
save(fullfile(folder,'Analysis.mat'),'results','BoundedModel','-v7.3');
for name={'Coefficients','DetectionSummary','ValidationSummary','SpectralSummary','TerminalWindows', ...
        'DensitySummary','PowerSummary','BoundsSummary','FitReview','PulseTypes','PulseKnots', ...
        'GapQuantiles','TailSummary','HistogramSummary','BlockSummary'}
    writetable(r.(name{1}),fullfile(folder,[name{1} '.csv']));
end
if r.cfg.writeHistoryCSVs
    writetable(r.Generated_sensor,fullfile(folder,'Generated_sensor_ug.csv'));
    writetable(r.Generated_PLT,fullfile(folder,'Generated_platform_ug.csv'));
end
provenance=struct('schemaVersion',3,'generator',r.model.mode,'blockSamples',r.model.blockSamples,'clock','(original_row-1)/sampleRate_Hz','selectedAxes',{r.input.selectedAxes}, ...
    'firstSourceRow',r.input.sourceRows(1),'lastSourceRow',r.input.sourceRows(end), ...
    'referenceMode',r.referenceMode,'isSynthetic',r.cfg.isSynthetic,'config',r.cfg);
fid=fopen(fullfile(folder,'Provenance.json'),'w'); assert(fid>=0);
cleanup=onCleanup(@()fclose(fid)); fprintf(fid,'%s',jsonencode(provenance)); clear cleanup;
if r.cfg.saveFigures
    for k=1:numel(r.figures)
        if ~isgraphics(r.figures(k)), continue; end
        path=fullfile(folder,r.figures(k).Name);
        exportgraphics(r.figures(k),[path '.png'],'Resolution',140); savefig(r.figures(k),[path '.fig']);
    end
end
fprintf('Saved coefficient table and diagnostics to %s\n',folder);
end
