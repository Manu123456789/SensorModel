function edges=histogramEdges(x,bins)
% Common finite edges with a tiny roundoff guard, useful for quantized IMU data.
% Equal values at an exact bin edge must not split because of FFT roundoff.
[~,edges]=histcounts(x,bins);
scale=max(1,max(abs(x(:)))); width=min(diff(edges));
guard=min(1e-6*width,1024*eps(scale));
edges(2:end-1)=edges(2:end-1)+guard;
end
