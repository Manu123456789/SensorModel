function figs=plotSummary(r)
% Six-panel presentation view. All comparisons use held-out measured samples.
figs=gobjects(0); names={'X','Y','Z'}; black=[.08 .08 .08]; red=[.8 .15 .15];
fs=r.model.Fs; s=r.summary; time=r.validationTime_s;
for j=find(r.model.selectedMask)
    f=figure('Name',['S_' names{j} '_Test_vs_Generated_Summary'], ...
        'NumberTitle','off','Visible',r.cfg.figureVisible,'Position',[50 50 1500 850]);
    figs(end+1)=f; t=tiledlayout(f,2,3,'TileSpacing','compact','Padding','compact'); %#ok<AGROW>
    test=r.reference(:,j); generated=r.samples(:,j,1);
    ax=nexttile(t); plot(ax,time,test,'Color',black,'DisplayName','Test (held-out)'); hold(ax,'on');
    plot(ax,time,generated,'Color',red,'DisplayName','Generated run 1');
    title(ax,'S1: complete acceleration history'); xlabel(ax,'Elapsed [s]'); ylabel(ax,'Error [ug]');
    legend(ax,'show','Location','best'); grid(ax,'on');

    ax=nexttile(t); lo=min([min(test) min(reshape(r.samples(:,j,:),[],1))]);
    hi=max([max(test) max(reshape(r.samples(:,j,:),[],1))]);
    if hi<=lo, hi=lo+max(1,abs(lo))*eps*10; end
    edges=linspace(lo,hi,r.cfg.histogramBins+1); centers=(edges(1:end-1)+edges(2:end))/2;
    density=zeros(numel(centers),size(r.samples,3));
    for k=1:size(r.samples,3)
        density(:,k)=histcounts(r.samples(:,j,k),edges,'Normalization','pdf')';
    end
    histogram(ax,test,edges,'Normalization','pdf','DisplayStyle','stairs', ...
        'EdgeColor',black,'LineWidth',1.3,'DisplayName','Test (held-out)'); hold(ax,'on');
    plot(ax,centers,mean(density,2),'Color',red,'LineWidth',1.3,'DisplayName','Generated ensemble mean');
    title(ax,'S2: amplitude probability density'); xlabel(ax,'Error [ug]'); ylabel(ax,'Density [1/ug]');
    legend(ax,'show','Location','best'); grid(ax,'on');

    ax=nexttile(t); limit=max(2,round(r.cfg.quietZoom_s*fs));
    a=longestQuiet(~r.refEvents.mask); b=longestQuiet(~r.events{1}.mask);
    count=min([limit numel(a) numel(b)]);
    if count>=2
        a=a(1:count); b=b(1:count); qtime=(0:count-1)'/fs;
        plot(ax,qtime,test(a),'Color',black,'DisplayName','Test quiet segment'); hold(ax,'on');
        plot(ax,qtime,generated(b),'Color',red,'DisplayName','Generated quiet segment');
        yline(ax,r.model.baseline(j),'k:','HandleVisibility','off');
        title(ax,sprintf('S3: quiet background only (%.3g s)',count/fs));
        xlabel(ax,'Elapsed within each quiet segment [s]'); ylabel(ax,'Error [ug]');
        legend(ax,'show','Location','best'); grid(ax,'on');
    else
        text(ax,.05,.5,'No shared quiet duration of at least 2 samples.','Units','normalized');
        title(ax,'S3: quiet background unavailable');
    end

    ax=nexttile(t); keep=r.frequency_Hz>0;
    loglog(ax,r.frequency_Hz(keep),max(r.referencePSD(keep,j),realmin), ...
        'Color',black,'LineWidth',1.2,'DisplayName','Test (held-out)'); hold(ax,'on');
    psdMean=mean(r.psd(:,j,:),3);
    loglog(ax,r.frequency_Hz(keep),max(psdMean(keep),realmin),'Color',red, ...
        'LineWidth',1.3,'DisplayName','Generated ensemble mean');
    title(ax,'S4: Welch PSD (record mean removed)'); xlabel(ax,'Frequency [Hz]'); ylabel(ax,'PSD [ug^2/Hz]');
    legend(ax,'show','Location','best'); grid(ax,'on');

    ax=nexttile(t); endpointCDF(ax,s.testV(:,j),s.modelV(:,j),black,red);
    title(ax,sprintf('S5: terminal velocity CDF, %.3g s windows',s.window_s)); xlabel(ax,'Final velocity error [m/s]');
    ax=nexttile(t); endpointCDF(ax,s.testP(:,j),s.modelP(:,j),black,red);
    title(ax,sprintf('S6: terminal position CDF, %.3g s windows',s.window_s)); xlabel(ax,'Final position error [m]');
    title(t,sprintf('Sensor %s: test versus generated | fitted on first %.0f%%, checked on remaining %.0f%%', ...
        names{j},100*r.cfg.fitFraction,100*(1-r.cfg.fitFraction)));
end
end
function rows=longestQuiet(quiet)
a=find(diff([false;quiet(:)])==1); b=find(diff([quiet(:);false])==-1);
if isempty(a), rows=[]; else, [~,q]=max(b-a+1); rows=(a(q):b(q))'; end
end
function endpointCDF(ax,test,generated,black,red)
drawCDF(ax,generated,red,sprintf('Generated windows (n=%d)',numel(generated))); hold(ax,'on');
if numel(test)>1
    drawCDF(ax,test,black,sprintf('Test windows (n=%d)',numel(test)));
else
    xline(ax,test,'--','Color',black,'DisplayName','Single test endpoint (no test CDF)');
end
ylabel(ax,'Cumulative probability'); ylim(ax,[0 1]); grid(ax,'on'); legend(ax,'show','Location','best');
end
function drawCDF(ax,x,color,label)
x=sort(x(:)); stairs(ax,[x(1);x],[0;(1:numel(x))'/numel(x)], ...
    'Color',color,'LineWidth',1.4,'DisplayName',label);
end
