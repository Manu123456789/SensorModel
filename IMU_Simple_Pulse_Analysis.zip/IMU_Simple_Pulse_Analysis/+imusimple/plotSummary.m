function figs=plotSummary(r)
% Clean six-panel comparison, one figure per selected sensor axis.
figs=gobjects(0); names={'X','Y','Z'}; red=[.8 .15 .15]; fs=r.model.Fs;
for j=find(r.model.selectedMask)
    f=figure('Name',['S_' names{j} '_Measured_vs_Generated_Summary'],'NumberTitle','off', ...
        'Visible',r.cfg.figureVisible,'Position',[50 50 1500 850]); figs(end+1)=f; %#ok<AGROW>
    t=tiledlayout(f,2,3,'TileSpacing','compact','Padding','compact');
    a=r.reference(:,j); b=r.exampleGenerated(:,j); time=r.validationTime_s;
    ax=nexttile(t); plot(ax,time,a,'k','DisplayName',r.referenceLabel); hold(ax,'on');
    plot(ax,time,b,'Color',red,'DisplayName','Generated run 1');
    title(ax,'S1: complete acceleration history'); xlabel(ax,'Elapsed [s]'); ylabel(ax,'Error [ug]'); legend(ax,'show'); grid(ax,'on');
    ax=nexttile(t); [~,edges]=histcounts([a;b],r.cfg.histogramBins);
    histogram(ax,a,edges,'Normalization','pdf','DisplayStyle','stairs','EdgeColor','k','DisplayName',r.referenceLabel); hold(ax,'on');
    histogram(ax,b,edges,'Normalization','pdf','DisplayStyle','stairs','EdgeColor',red,'DisplayName','Generated run 1');
    title(ax,'S2: amplitude probability density'); xlabel(ax,'Error [ug]'); ylabel(ax,'Density [1/ug]'); legend(ax,'show'); grid(ax,'on');
    ax=nexttile(t); ev=r.events{1}; qa=longestQuiet(~r.refEvents{j}.mask); qb=longestQuiet(~ev{j}.mask);
    count=min([max(2,round(r.cfg.quietZoom_s*fs)) numel(qa) numel(qb)]);
    if count>=2
        tt=(0:count-1)'/fs;
        plot(ax,tt,a(qa(1:count)),'k','DisplayName','Measured quiet segment'); hold(ax,'on');
        plot(ax,tt,b(qb(1:count)),'Color',red,'DisplayName','Generated quiet segment');
        yline(ax,r.model.baseline(j),'k:','HandleVisibility','off'); legend(ax,'show');
        title(ax,sprintf('S3: quiet background only, %.3g s',count/fs));
    else
        text(ax,.05,.5,'Not enough contiguous quiet samples.','Units','normalized'); title(ax,'S3: quiet close-up unavailable');
    end
    xlabel(ax,'Elapsed within each quiet segment [s]'); ylabel(ax,'Error [ug]'); grid(ax,'on');
    ax=nexttile(t); keep=r.frequency_Hz>0;
    loglog(ax,r.frequency_Hz(keep),max(r.referencePSD(keep,j),realmin),'k','DisplayName',r.referenceLabel); hold(ax,'on');
    average=mean(r.psd(:,j,:),3);
    loglog(ax,r.frequency_Hz(keep),max(average(keep),realmin),'Color',red,'DisplayName','Generated ensemble mean');
    title(ax,'S4: Welch PSD, record means removed'); xlabel(ax,'Frequency [Hz]'); ylabel(ax,'PSD [ug^2/Hz]'); legend(ax,'show'); grid(ax,'on');
    ax=nexttile(t); endpointCDF(ax,r.summary.testV(:,j),r.summary.modelV(:,j),r.referenceLabel);
    title(ax,sprintf('S5: terminal velocity CDF, %.3g s',r.summary.window_s)); xlabel(ax,'Final velocity error [m/s]');
    ax=nexttile(t); endpointCDF(ax,r.summary.testP(:,j),r.summary.modelP(:,j),r.referenceLabel);
    title(ax,sprintf('S6: terminal position CDF, %.3g s',r.summary.window_s)); xlabel(ax,'Final position error [m]');
    title(t,['Sensor ' names{j} ': ' r.referenceMode]);
end
end
function rows=longestQuiet(quiet)
a=find(diff([false;quiet(:)])==1); b=find(diff([quiet(:);false])==-1);
if isempty(a), rows=[]; else, [~,k]=max(b-a+1); rows=(a(k):b(k))'; end
end
function endpointCDF(ax,a,b,label)
b=sort(b(:)); stairs(ax,[b(1);b],[0;(1:numel(b))'/numel(b)],'Color',[.8 .15 .15], ...
    'LineWidth',1.3,'DisplayName',sprintf('Generated windows (n=%d)',numel(b))); hold(ax,'on');
if numel(a)>1
    a=sort(a(:)); stairs(ax,[a(1);a],[0;(1:numel(a))'/numel(a)],'k','LineWidth',1.3, ...
        'DisplayName',sprintf('%s windows (n=%d)',label,numel(a)));
else, xline(ax,a,'k--','DisplayName',[label ': single endpoint']); end
ylabel(ax,'Cumulative probability'); ylim(ax,[0 1]); legend(ax,'show','Location','best'); grid(ax,'on');
end
