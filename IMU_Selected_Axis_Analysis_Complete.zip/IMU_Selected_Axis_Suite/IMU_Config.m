%% MAIN CONFIG AND RUN SCRIPT: edit this file, then run it.
% Uses an already-imported workspace timetable. Acquisition rate defines all steps.
suiteRoot=fileparts(mfilename('fullpath')); addpath(suiteRoot);
cfg=struct;

%% 1. Workspace input and exact sensor-column mapping
cfg.workspaceVariable='YourIMUTimetable'; % EDIT to the variable already in workspace
cfg.columns.X='Your_X_Column';
cfg.columns.Y='Your_Y_Column';
cfg.columns.Z='Your_Z_Column';
cfg.selectedAxes={'Y'};                  % MODEL: {'X'}, {'Y'}, {'Z'}, {'X','Z'}, ...
cfg.histogramAxes={'X','Y','Z'};          % VISUALIZATION: independent of model axes

%% 2. Sampling, units, interval and known physical baseline
cfg.sampleRate_Hz=NaN;                   % EDIT actual acquisition rate, e.g. 1000
cfg.window_s=[0 120];                    % EDIT seconds since ORIGINAL row 1
cfg.inputMode='instantaneous_ft_s2';
% Other modes: instantaneous_cm_s2, instantaneous_ms2, instantaneous_ug,
% sample_sum_cm_s2 (unweighted sum), integral_cm_s (accumulated velocity).
cfg.baselineSensor_ms2=[NaN NaN NaN];     % EDIT true input for MODELED axes [m/s^2]
% Example ONLY for known zero-input / gravity-compensated Y: [NaN 0 NaN]
cfg.R_sensor_to_PLT=eye(3);              % platform_column = R * sensor_column
cfg.railLimitsInput=[-Inf Inf;-Inf Inf;-Inf Inf]; % ORIGINAL units, X/Y/Z rows
cfg.allowRailSamples=false;             % true models recorded clipped values only

%% 3. Quiet Gauss-Markov background + random spike events
cfg.gmPhiOverride=NaN;                   % NaN: fit; optional scalar 0<=phi<1
cfg.gmPhiMax=.999;                       % Stability cap for fitted quiet persistence
cfg.detectSigma=5; cfg.releaseSigma=2;
cfg.manualThreshold_ug=[NaN NaN NaN];    % Optional absolute thresholds, X/Y/Z
cfg.useEventMarkov=false;               % Optional sign/axis class transitions
cfg.markovPrior=1; cfg.fitFraction=.70;
cfg.nRealizations=50; cfg.seed=1234;

%% 4. Diagnostics and output (all editable options are here)
cfg.maxLag_s=2; cfg.quietMaxLag_s=.25; cfg.welchWindow_s=2;
cfg.histogramBins=60; cfg.block_s=10; cfg.zoom_s=5;
cfg.makePlots=true; cfg.saveFigures=true; cfg.figureVisible='on';
cfg.saveResults=true; cfg.exportCpp=true; cfg.writeHistoryCSVs=false;
cfg.outputFolder=fullfile(suiteRoot,'output_hardware');

%% 5. Optional self-contained example (no import needed)
cfg.useSyntheticExample=false;          % true to exercise this same pipeline
cfg.demoSampleRate_Hz=200; cfg.demoDuration_s=120;
cfg.isSynthetic=cfg.useSyntheticExample;

%% RUN (no edits needed below)
if cfg.useSyntheticExample
    [IMU_InputData,IMU_ExampleTruth]=Generate_Example_IMU(cfg.demoSampleRate_Hz,cfg.demoDuration_s);
    cfg.sampleRate_Hz=cfg.demoSampleRate_Hz;
    cfg.columns=struct('X','Example_X','Y','Example_Y','Z','Example_Z');
    cfg.baselineSensor_ms2=[0 0 0];
    cfg.outputFolder=fullfile(suiteRoot,'output_example');
else
    assert(isvarname(cfg.workspaceVariable),'Use a single workspace variable name.');
    assert(exist(cfg.workspaceVariable,'var')==1, ...
        ['Import your data first. Workspace variable not found: ' cfg.workspaceVariable]);
    IMU_InputData=eval(cfg.workspaceVariable); % MATLAB copy-on-write; no file reimport
end
IMU_Results=imupulse.analyze(IMU_InputData,cfg);
if cfg.saveResults, imupulse.saveOutputs(IMU_Results,cfg.outputFolder); end
