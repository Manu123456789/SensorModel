%% MAIN CONFIG. MATLAB R2021b, existing workspace table/timetable.
% Every user setting is here. Time = row index / Fs; no time field is read.
suiteRoot=fileparts(mfilename('fullpath')); addpath(suiteRoot); cfg=struct;
cfg.workspaceVariable='YourIMUTimetable';
cfg.columns=struct('X','Your_X_Column','Y','Your_Y_Column','Z','Your_Z_Column');
cfg.selectedAxes={'Y'};
cfg.histogramAxes={'X','Y','Z'}; % Use {'Y'} if only Y is available.
cfg.sampleRate_Hz=1000;
cfg.rowWindow=[1 Inf];          % Inclusive ORIGINAL ROWS, not seconds.
cfg.inputMode='instantaneous_ft_s2';
% Also: instantaneous_ms2, instantaneous_cm_s2, instantaneous_ug,
% delta_velocity_ft_s, delta_velocity_ms, delta_velocity_cm_s,
% sample_sum_cm_s2 (unweighted cumulative sum), integral_cm_s (velocity).
cfg.baselineSensor_ms2=[NaN 0 NaN]; % KNOWN true input; 0 if already an error.
cfg.R_sensor_to_PLT=eye(3);     % Your established frame_sens2plat_T values.

%% FOURIER MODEL: first run the exact full-record reference, then reduce K.
cfg.maxTones=Inf;              % Inf = all floor(Nfit/2) unique AC components.
% Finite example: 512. Zero is allowed for an offset-only comparison.
cfg.toneSelection='energy';    % 'energy' (largest contributions) or 'lowFrequency'.
cfg.ambientMode='none';        % 'none' or 'white' fitted ONLY from quiet residual.
% Full Fourier already includes the measured ambient noise. Default adds none.
cfg.phaseMode='aligned';       % 'aligned' or 'randomCircularShift'.
% A circular shift is ONE common integer sample shift for ALL tones/axes.
% Never randomize the individual phases: that destroys spike alignment.
cfg.fitFraction=1;             % Full record fit/check; .7 reserves final 30%.
cfg.sweepToneCounts=[8 16 32 64 128 256 512 1024 2048 Inf];
cfg.makeToneSweep=true;        % Adds aligned-fit error/peak/PSD/density vs K.

%% Detection is DIAGNOSTIC only; it does not drive a pulse generator.
cfg.detectSigma=5;
cfg.manualThreshold_ug=[NaN NaN NaN];
cfg.nRealizations=25; cfg.seed=1234;
% With aligned phases and zero added white noise, only ONE distinct model
% history exists; analysis automatically avoids recomputing identical runs.
cfg.histogramBins=60; cfg.zoom_s=2; cfg.quietZoom_s=.25;
cfg.allanPoints=35;             % Overlapping ADEV; variance averaged BEFORE sqrt.
cfg.maxLag_s=2; cfg.quietMaxLag_s=.25; cfg.welchWindow_s=2; cfg.block_s=10;
cfg.summaryTerminalWindow_s=5;
cfg.maxIntegrationPlotPoints=4000;
cfg.makePlots=true; cfg.figureVisible='on'; cfg.saveFigures=true;
cfg.saveResults=true; cfg.writeHistoryCSVs=false;
cfg.outputFolder=fullfile(suiteRoot,'output_hardware');
cfg.useSyntheticExample=false;
cfg.demoSampleRate_Hz=200; cfg.demoDuration_s=20;

%% RUN: model identification and outputs, no file import or C++ generator.
cfg.isSynthetic=cfg.useSyntheticExample;
if cfg.useSyntheticExample
    [IMU_InputData,IMU_ExampleTruth]=Generate_Example_IMU(cfg.demoSampleRate_Hz,cfg.demoDuration_s);
    cfg.sampleRate_Hz=cfg.demoSampleRate_Hz;
    cfg.columns=struct('X','Example_X','Y','Example_Y','Z','Example_Z');
    cfg.baselineSensor_ms2=[0 0 0]; cfg.inputMode='instantaneous_ug';
    cfg.outputFolder=fullfile(suiteRoot,'output_example');
else
    assert(isvarname(cfg.workspaceVariable),'Use one workspace variable name.');
    assert(exist(cfg.workspaceVariable,'var')==1,['Missing workspace input: ' cfg.workspaceVariable]);
    IMU_InputData=eval(cfg.workspaceVariable); % Copy-on-write, no large CSV reload.
end
IMU_Results=imufourier.analyze(IMU_InputData,cfg);
Coefficients=IMU_Results.Coefficients;
ToneCoefficients=IMU_Results.ToneCoefficients;
if cfg.saveResults, imufourier.saveOutputs(IMU_Results,cfg.outputFolder); end
