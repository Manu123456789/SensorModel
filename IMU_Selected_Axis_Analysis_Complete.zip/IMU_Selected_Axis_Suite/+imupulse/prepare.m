function d=prepare(T,c)
% Read only mapped channels and requested rows; acquisition rate is the sole clock.
assert(istimetable(T)||istable(T),'Input must be an imported timetable or table.');
labels={'X','Y','Z'}; names=["X","Y","Z"];
chosen=upper(string(c.selectedAxes)); chosen=chosen(:)';
visual=upper(string(c.histogramAxes)); visual=visual(:)';
assert(~isempty(chosen) && all(ismember(chosen,names)) && numel(unique(chosen))==numel(chosen));
assert(all(ismember(visual,names)) && numel(unique(visual))==numel(visual));
mask=ismember(names,chosen); histMask=ismember(names,visual); readMask=mask|histMask;
validateattributes(c.sampleRate_Hz,{'numeric'},{'scalar','real','finite','positive'});
fs=c.sampleRate_Hz; N=height(T); dt=1/fs;
assert(isequal(size(c.window_s),[1 2]) && c.window_s(1)<c.window_s(2));
% Assign original row k to (k-1)/Fs. Select rows before copying channel values.
lo=c.window_s(1)*fs; hi=c.window_s(2)*fs;
if isfinite(lo), lo=ceil(lo-32*eps(max(1,abs(lo)))); end
if isfinite(hi), hi=floor(hi+32*eps(max(1,abs(hi)))); end
first=max(1,lo+1); last=min(N,hi+1);
cumulative=ismember(c.inputMode,{'sample_sum_cm_s2','integral_cm_s'});
if cumulative, first=max(2,first+1); end % complete decoded interval inside window
assert(isfinite(first) && isfinite(last) && last-first+1>=512, ...
    'Choose an interval containing at least 512 reconstructed samples.');
sourceRows=(first:last)'; readRows=(first-double(cumulative):last)';
raw=zeros(numel(readRows),3); selectedNames=strings(0,1);
assert(isstruct(c.columns) && isscalar(c.columns),'Map names with cfg.columns.X/Y/Z.');
for j=find(readMask)
    axisName=labels{j}; assert(isfield(c.columns,axisName),['Map cfg.columns.' axisName]);
    name=string(c.columns.(axisName));
    assert(isscalar(name) && ~ismissing(name) && strlength(name)>0, ...
        ['Set cfg.columns.' axisName ' or remove that axis from histogramAxes/selectedAxes.']);
    name=char(name); assert(ismember(name,T.Properties.VariableNames),['Missing sensor column: ' name]);
    v=T{readRows,{name}}; % selected rows / one mapped channel, not the entire dataset
    assert(isnumeric(v) && isreal(v) && isvector(v) && numel(v)==numel(readRows), ...
        ['Channel must contain one numeric value per row: ' name]);
    raw(:,j)=double(v(:)); selectedNames(end+1,1)=string(name); %#ok<AGROW>
end
assert(numel(unique(selectedNames))==nnz(readMask),'Map each sensor axis to a distinct column.');
assert(isequal(size(c.baselineSensor_ms2),[1 3]) && ...
    all(isfinite(c.baselineSensor_ms2(mask))),'Supply known true baseline for MODELED axes [m/s^2].');
R=c.R_sensor_to_PLT;
assert(isequal(size(R),[3 3]) && isreal(R) && all(isfinite(R(:))) && ...
    norm(R*R'-eye(3),'fro')<1e-6 && abs(det(R)-1)<1e-6,'Use a proper sensor-to-platform rotation.');
assert(isequal(size(c.railLimitsInput),[3 2]) && all(c.railLimitsInput(:,1)<c.railLimitsInput(:,2)));
rail=any(raw(:,mask)<=c.railLimitsInput(mask,1)' | raw(:,mask)>=c.railLimitsInput(mask,2)',2);
switch c.inputMode
    case 'instantaneous_ft_s2', a=raw*.3048;
    case 'instantaneous_cm_s2', a=raw*.01;
    case 'instantaneous_ms2', a=raw;
    case 'instantaneous_ug', a=raw*(1e-6*9.80665);
    case {'sample_sum_cm_s2','integral_cm_s'}
        a=diff(raw,1,1)*.01; rail=rail(1:end-1)|rail(2:end);
        if strcmp(c.inputMode,'integral_cm_s'), a=a/dt; end
    otherwise, error('Unknown inputMode. See IMU_Config.m and README.');
end
assert(all(all(isfinite(a(:,mask)))),'Selected model channels need finite values throughout the interval.');
if any(rail)
    assert(c.allowRailSamples,'Configured rail reached: choose an interval or explicitly allow recorded clipping.');
    warning('Fitting recorded clipped readout, not unknown acceleration beyond its rail.');
end
y=zeros(size(a)); y(:,mask)=(a(:,mask)-c.baselineSensor_ms2(mask))*(1e6/9.80665);
histValues=NaN(size(a)); histValues(:,histMask)=a(:,histMask)/.3048;
d=struct('t',(sourceRows-1)/fs,'y',y,'Fs',fs,'dt',dt,'mask',mask,'rail',rail, ...
    'sourceRows',sourceRows,'histMask',histMask,'histValues_ft_s2',histValues);
d.selectedAxes=labels(mask); d.histogramAxes=labels(histMask);
end
