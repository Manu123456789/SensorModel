#ifndef IMU_SWITCH_MODEL_HPP
#define IMU_SWITCH_MODEL_HPP
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>

namespace imu_switch {
// All levels are SENSOR-frame acceleration errors in micro-g; times are seconds.
struct AxisParams {
    bool switching;
    double low_ug, high_ug;
    double low_s, high_s, phase_s;
    bool initial_high;
    double initial_remaining_s;
    const double* low_dwells_s;
    std::size_t low_count;
    const double* high_dwells_s;
    std::size_t high_count;
};
enum class Timing { Periodic, EmpiricalDwells };

class Model {
public:
    // Parameter/dwell arrays must outlive this object (generated arrays are static).
    Model(const AxisParams (&params)[3], Timing timing, std::uint32_t seed = 1)
        : timing_(timing), valid_(true) {
        for (int j = 0; j < 3; ++j) {
            p_[j] = params[j];
            valid_ = valid_ && std::isfinite(p_[j].low_ug) && std::isfinite(p_[j].high_ug);
            if (!p_[j].switching) continue;
            valid_ = valid_ && p_[j].high_ug > p_[j].low_ug &&
                positive(p_[j].low_s) && positive(p_[j].high_s) &&
                std::isfinite(p_[j].low_s + p_[j].high_s) &&
                std::isfinite(p_[j].phase_s) && positive(p_[j].initial_remaining_s);
            if (timing_ == Timing::EmpiricalDwells) {
                valid_ = valid_ && valid_dwells(p_[j].low_dwells_s,p_[j].low_count) &&
                    valid_dwells(p_[j].high_dwells_s,p_[j].high_count);
            }
        }
        reset(seed);
    }
    bool valid() const { return valid_; }
    // Call once at each Monte Carlo run / regime start; model time restarts at zero.
    void reset(std::uint32_t seed = 1) {
        last_time_ = -1.0;
        for (int j = 0; j < 3; ++j) {
            rng_[j] = seed ^ (0x9E3779B9u * static_cast<std::uint32_t>(j+1));
            if (rng_[j] == 0) rng_[j] = 1;
            high_[j] = p_[j].initial_high;
            next_switch_[j] = p_[j].initial_remaining_s;
        }
    }
    // Call on the SENSOR update clock, with elapsed time since the regime start.
    // Repeated timestamps are allowed. Backward/negative/nonfinite time returns false.
    bool sample(double elapsed_s, double sensor_error_ug[3]) {
        if (!valid_ || !std::isfinite(elapsed_s) || elapsed_s < 0 || elapsed_s < last_time_)
            return false;
        for (int j = 0; j < 3; ++j) {
            bool is_high = false;
            if (p_[j].switching && timing_ == Timing::Periodic) {
                const double period = p_[j].low_s + p_[j].high_s;
                double phase = std::fmod(elapsed_s + p_[j].phase_s,period);
                if (phase < 0) phase += period;
                // Roundoff at exact sensor-clock edges must not delay a transition.
                const double tol = tolerance(elapsed_s + p_[j].phase_s);
                if (period-phase <= tol) phase = 0;
                if (std::abs(phase-p_[j].high_s) <= tol) phase = p_[j].high_s;
                is_high = phase < p_[j].high_s;
            } else if (p_[j].switching) {
                while (elapsed_s >= next_switch_[j]-tolerance(next_switch_[j])) {
                    high_[j] = !high_[j];
                    const double* values = high_[j] ? p_[j].high_dwells_s : p_[j].low_dwells_s;
                    const std::size_t count = high_[j] ? p_[j].high_count : p_[j].low_count;
                    // One stream per axis: results do not depend on call cadence.
                    const std::size_t index = static_cast<std::size_t>(
                        (static_cast<double>(uniform_bits(j))/4294967296.0)*count);
                    const double next = next_switch_[j] + values[index];
                    if (!std::isfinite(next) || next <= next_switch_[j]) return false;
                    next_switch_[j] = next;
                }
                is_high = high_[j];
            }
            sensor_error_ug[j] = is_high ? p_[j].high_ug : p_[j].low_ug;
        }
        last_time_ = elapsed_s;
        return true;
    }
private:
    static double tolerance(double t) {
        return 32*std::numeric_limits<double>::epsilon()*std::fmax(1.0,std::abs(t));
    }
    static bool positive(double x) { return std::isfinite(x) && x > 0; }
    static bool valid_dwells(const double* d, std::size_t n) {
        if (!d || n == 0) return false;
        for (std::size_t k = 0; k < n; ++k) if (!positive(d[k])) return false;
        return true;
    }
    std::uint32_t uniform_bits(int j) {
        std::uint32_t x = rng_[j];
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        return rng_[j] = x;
    }
    AxisParams p_[3];
    Timing timing_;
    bool valid_, high_[3];
    std::uint32_t rng_[3];
    double next_switch_[3], last_time_;
};

// R is defined by column vectors: platform = R * sensor. Do not transpose again.
// Choose the output appropriate to your sim. Do not inject both outputs.
inline bool acceleration_step(Model& model, double elapsed_s, double dt_s,
    const double (&R)[3][3], double platform_error_ug[3], double delta_velocity_ft_s[3]) {
    if (!std::isfinite(dt_s) || dt_s <= 0) return false;
    double sensor_ug[3];
    if (!model.sample(elapsed_s,sensor_ug)) return false;
    for (int i = 0; i < 3; ++i) {
        platform_error_ug[i] = 0;
        for (int j = 0; j < 3; ++j) platform_error_ug[i] += R[i][j]*sensor_ug[j];
        // Left-endpoint / zero-order-hold integration for this sensor update.
        const double acceleration_ft_s2 = platform_error_ug[i]*1e-6*9.80665/0.3048;
        delta_velocity_ft_s[i] = acceleration_ft_s2*dt_s;
    }
    return true;
}
} // namespace imu_switch
#endif
