// Compile AFTER the MATLAB run. Relative include defaults to playground output.
// Hardware: supply -DIMU_MODEL_FILE='"../output_hardware/Candidate_IMU_Model.cpp"'
// Requires C++11 or later. Output is SENSOR-frame instantaneous error in micro-g.
#ifndef IMU_MODEL_FILE
#define IMU_MODEL_FILE "../output/Candidate_IMU_Model.cpp"
#endif
#include IMU_MODEL_FILE
#include <algorithm>
#include <cstdlib>
#include <iomanip>
#include <iostream>
int main(int argc,char** argv)
{
    if (argc!=3) {
        std::cerr<<"Usage: check_export sample_count seed > CPP_Trace.csv\n"; return 2;
    }
    const std::uint64_t n=std::strtoull(argv[1],nullptr,10);
    const std::uint32_t seed=static_cast<std::uint32_t>(std::strtoul(argv[2],nullptr,10));
    if (n==0) return 2;
    const ImuPulseParameters& p=imu_pulse_parameters;
    ImuPulseState state={};
    if (!imu_pulse_reset(p,state,seed)) { std::cerr<<"Invalid exported model\n"; return 1; }
    // Exercise IMU_error as well: bind a valid clock and identity transform.
    imu_input.sensor_dt_s=1.0/p.Fs; imu_input.run_seed=seed;
    std::cout<<"Time_s,ErrorX_ug,ErrorY_ug,ErrorZ_ug\n"<<std::setprecision(17);
    for (std::uint64_t tick=0;tick<n;++tick) {
        double x[3]; if (!imu_pulse_sample(p,state,tick,x)) return 1;
        imu_input.sensor_tick=tick; IMU_error();
        if (imu_output.status!=ImuExampleStatus::Ok) return 1;
        std::cout<<tick/p.Fs;
        for (int j=0;j<3;++j) {
            const double value=x[j]+p.baseline_ug[j];
            if (std::abs(value-imu_output.acceleration_error_ug[j])>1e-10*std::max(1.0,std::abs(value))) return 1;
            std::cout<<','<<value;
        }
        std::cout<<'\n';
    }
    return 0;
}
