function m=fit(x,fs,selected,c)
% Empirical joint-event / gap bootstrap plus fitted first-order Gauss-Markov quiet noise.
m.Fs=fs; m.selectedMask=selected; m.baseline=zeros(1,3);
m.baseline(selected)=median(x(:,selected),1);
s=1.4826*median(abs(x(:,selected)-m.baseline(selected)),1);
s=max(s,eps(max(1,max(abs(x(:,selected)),[],1))));
m.threshold=Inf(1,3); m.threshold(selected)=c.detectSigma*s;
v=c.manualThreshold_ug;
assert(isequal(size(v),[1 3]) && all(isnan(v) | (isfinite(v)&v>0)));
manual=selected & ~isnan(v); m.threshold(manual)=v(manual);
m.release=Inf(1,3); m.release(selected)=min(c.releaseSigma*s,.8*m.threshold(selected));
for iteration=1:10
    e=imupulse.detect(x,m); quiet=~e.mask;
    assert(nnz(quiet)>=max(30,.1*size(x,1)), ...
        'Too little quiet data. Inspect signal and thresholds; a pulse model may be unsuitable.');
    updated=mean(x(quiet,:),1);
    change=max(abs(updated(selected)-m.baseline(selected))./s);
    m.baseline=updated;
    if change<1e-6, break; end
end
e=imupulse.detect(x,m); m.quietMask=~e.mask;
assert(nnz(m.quietMask)>=max(30,.1*size(x,1)),'Too little final quiet data.');
m.covariance=cov(x(m.quietMask,:),1);
% Eigenfactor handles one selected axis and exactly zero inactive-axis variance.
[V,D]=eig((m.covariance+m.covariance')/2);
m.noiseFactor=V*diag(sqrt(max(diag(D),0)));
m.noiseFactor(~selected,:)=0; m.covariance(~selected,:)=0; m.covariance(:,~selected)=0;
m.baseline(~selected)=0;
% Fit one shared positive relaxation factor using ONLY consecutive quiet pairs.
% A shared phi keeps multi-axis stationary covariance positive semidefinite.
z=x-m.baseline; pair=find(m.quietMask(1:end-1)&m.quietMask(2:end));
assert(numel(pair)>=30,'Need >=30 consecutive quiet pairs to identify a Gauss-Markov background.');
variance=diag(m.covariance)'; usable=selected & variance>eps(max(1,max(variance)));
if any(usable)
    previous=z(pair,usable)./sqrt(variance(usable));
    current=z(pair+1,usable)./sqrt(variance(usable));
    m.gmPhiRaw=sum(previous(:).*current(:))/max(sum(previous(:).^2),eps);
else, m.gmPhiRaw=0; end
if isnan(c.gmPhiOverride), m.gmPhi=min(c.gmPhiMax,max(0,m.gmPhiRaw));
else, m.gmPhi=c.gmPhiOverride; end
m.gmPairCount=numel(pair); m.gmTau_s=0;
if m.gmPhi>0, m.gmTau_s=-1/(fs*log(m.gmPhi)); end
m.innovationCovariance=(1-m.gmPhi^2)*m.covariance;
m.templates={}; m.gapSamples=[]; m.classes=[]; starts=[]; stops=[];
for k=1:numel(e.start)
    a=e.start(k); b=e.stop(k);
    if a==1 || b==size(x,1), continue; end % censored boundary events
    previous=find(e.mask(1:a-1),1,'last');
    if isempty(previous), continue; end % first gap may be left-censored
    pulse=x(a:b,:)-m.baseline; pulse(:,~selected)=0;
    scaled=abs(pulse)./m.threshold;
    [~,idx]=max(scaled(:)); [row,axis]=ind2sub(size(pulse),idx);
    m.templates{end+1,1}=pulse; %#ok<AGROW>
    m.gapSamples(end+1,1)=a-previous-1; %#ok<AGROW>
    m.classes(end+1,1)=2*(axis-1)+1+(pulse(row,axis)<0); %#ok<AGROW>
    starts(end+1,1)=a; stops(end+1,1)=b; %#ok<AGROW>
end
assert(numel(m.templates)>=5, ...
    'Need >=5 eligible events to run; substantially more are needed for a convincing fit.');
m.classFrequency=accumarray(m.classes,1,[6 1])'; m.classFrequency=m.classFrequency/sum(m.classFrequency);
m.transitionCounts=zeros(6);
for k=2:numel(m.classes)
    m.transitionCounts(m.classes(k-1),m.classes(k))= ...
        m.transitionCounts(m.classes(k-1),m.classes(k))+1;
end
m.transitionProbability=(m.transitionCounts+c.markovPrior*m.classFrequency)./ ...
    (sum(m.transitionCounts,2)+c.markovPrior);
m.useEventMarkov=c.useEventMarkov;
m.trainingStart=starts; m.trainingStop=stops;
m.burnInSamples=10*max(m.gapSamples+cellfun(@(v)size(v,1),m.templates));
m.description='Selected axes: first-order Gauss-Markov quiet background / empirical spike replacement';
end
