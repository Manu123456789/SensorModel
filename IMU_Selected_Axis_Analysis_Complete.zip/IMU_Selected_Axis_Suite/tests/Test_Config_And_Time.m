function Test_Config_And_Time()
% Regression checks: arbitrary names, row-derived timing and optional timestamps.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(root);
n=2048; fs=200; value=sin((0:n-1)'/25)*.01;
T=table(value,'VariableNames',{'My Y acceleration (ft/s^2)'});
c=imupulse.defaults(); c.selectedAxes={'Y'};
c.columns=struct('Y','My Y acceleration (ft/s^2)'); % no X/Z keys needed
c.sampleRate_Hz=fs;
d=imupulse.prepare(T,c);
assert(isequal(d.t,(0:n-1)'/fs) && d.dt==1/fs && d.Fs==fs);
assert(isequal(d.sourceRows,(1:n)') && strcmp(d.timeSource,'row_count_and_rate'));
assert(all(all(d.y(:,[1 3])==0)));
assert(max(abs(d.y(:,2)-value*.3048*1e6/9.80665))<1e-8);
% Windowing uses times assigned to ORIGINAL table rows, without restarting clock.
c.window_s=[1 4]; window=imupulse.prepare(T,c);
assert(window.t(1)==1 && window.t(end)==4 && isequal(window.sourceRows,(201:801)'));
c.startTime_s=10; c.window_s=[11 14]; shifted=imupulse.prepare(T,c);
assert(shifted.t(1)==11 && shifted.t(end)==14 && isequal(shifted.sourceRows,(201:801)'));
% An unrelated 'Time' variable is ignored when timeColumn is empty.
c.window_s=[-Inf Inf]; c.startTime_s=0; T.Time=NaN(n,1);
ignored=imupulse.prepare(T,c); assert(isequal(ignored.t,d.t));
% An actual time column overrides configured rate / origin; it still checks gaps.
T.RecorderSeconds=7+(0:n-1)'/250;
c.timeColumn='RecorderSeconds'; c.sampleRate_Hz=1000; c.startTime_s=50;
stamped=imupulse.prepare(T,c);
assert(isequal(stamped.t,T.RecorderSeconds) && abs(stamped.Fs-250)<1e-8);
assert(strcmp(stamped.timeSource,'timestamp_column'));
bad=T; bad.RecorderSeconds(1000:end)=bad.RecorderSeconds(1000:end)+.1;
mustFail(@()imupulse.prepare(bad,c));
% Required timing and selected mapping cannot silently fall back to guesses.
c.timeColumn=''; c.startTime_s=0;
for rate=[NaN 0 -1 Inf]
    c.sampleRate_Hz=rate; mustFail(@()imupulse.prepare(T,c));
end
c.sampleRate_Hz=fs; c.columns.Y='MissingChannel'; mustFail(@()imupulse.prepare(T,c));
c.columns.Y=''; mustFail(@()imupulse.prepare(T,c));
% Cumulative decoder uses the same original-row clock and loses only first row.
c.columns.Y='My Y acceleration (ft/s^2)'; c.inputMode='sample_sum_cm_s2';
accum=T; accum.(c.columns.Y)=cumsum(value*30.48);
decoded=imupulse.prepare(accum,c);
assert(isequal(decoded.sourceRows,(2:n)') && decoded.t(1)==1/fs);
assert(max(abs(decoded.y(:,2)-d.y(2:end,2)))<1e-7);
c.inputMode='integral_cm_s'; accum.(c.columns.Y)=cumsum(value*30.48/fs);
decodedIntegral=imupulse.prepare(accum,c);
assert(max(abs(decodedIntegral.y(:,2)-d.y(2:end,2)))<1e-7);
fprintf('PASS: named columns, no time column, Fs/origin/window, actual timestamps, invalid config, accumulators.\n');
end
function mustFail(f)
failed=false; try, f(); catch, failed=true; end
assert(failed,'Invalid input unexpectedly accepted.');
end
