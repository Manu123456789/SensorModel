function [v,p]=windowEndpoints(x,fs,L)
% Nonoverlapping windows; reset v/p to zero each window; omit trailing partial.
W=floor(size(x,1)/L); v=zeros(W,3); p=v;
for w=1:W
    [a,b]=imufourier.integrate(x((w-1)*L+(1:L),:),fs);
    v(w,:)=a(end,:); p(w,:)=b(end,:);
end
end
