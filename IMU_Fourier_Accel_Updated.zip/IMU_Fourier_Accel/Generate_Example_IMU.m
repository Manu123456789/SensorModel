function [T,truth]=Generate_Example_IMU(fs,seconds)
% Deliberately irregular SINGLE-SAMPLE spikes plus a few three-sample peaks.
% Synthetic only; not the user's hardware record.
n=max(512,round(fs*seconds)); stream=RandStream('mt19937ar','Seed',417);
v=.4*randn(stream,n,3); v(:,2)=.3+.7*randn(stream,n,1);
cursor=15; starts=[];
while cursor<n-5
    height=25+180*rand(stream); if rand(stream)<.30, height=-height*.7; end
    if rand(stream)<.15, v(cursor:cursor+2,2)=height*[.25;1;.25];
    else, v(cursor,2)=height; end
    starts(end+1,1)=cursor; %#ok<AGROW>
    cursor=cursor+max(5,round(fs*(.025+.4*rand(stream))));
end
T=array2table(v,'VariableNames',{'Example_X','Example_Y','Example_Z'});
truth=struct('isSynthetic',true,'eventStart',starts,'Fs',fs,'description','One-sample impulses and short peaks');
end
