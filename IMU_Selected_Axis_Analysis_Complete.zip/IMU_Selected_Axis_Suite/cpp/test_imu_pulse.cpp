// Compile this test only; it includes the single-.cpp scaffold for helper access.
#include "IMU_Pulse_Integration_Template.cpp"
#include <cassert>
#include <iostream>

static bool close(double a,double b,double tol=1e-10) { return std::abs(a-b)<tol; }
static const double pulse[3][3]={{100,50,-25},{200,100,-50},{50,25,-12.5}};
static const std::size_t off[1]={0},len[1]={3},gap[1]={2};
static const unsigned cls[1]={0};
static ImuPulseParameters deterministic()
{
    ImuPulseParameters p=imu_pulse_parameters;
    p.fitted=true; p.Fs=100; p.event_count=1; p.sample_count=3;
    p.samples_ug=pulse; p.offset=off; p.length=len; p.gap=gap; p.event_class=cls;
    p.baseline_ug[0]=5; p.baseline_ug[1]=2; p.baseline_ug[2]=-1;
    p.burn_in_samples=0;
    return p;
}
int main()
{
    // Unexported template must not silently use fake sensor parameters.
    IMU_error(); assert(imu_output.status==ImuExampleStatus::NotFitted);
    ImuPulseParameters p=deterministic(); ImuPulseState s={}; double y[3];
    assert(imu_pulse_validate(p) && imu_pulse_reset(p,s,123));
    for (std::uint64_t tick=0;tick<20;++tick) {
        assert(imu_pulse_sample(p,s,tick,y));
        const unsigned phase=static_cast<unsigned>(tick%5);
        if (phase<2) for (int j=0;j<3;++j) assert(y[j]==0);
        else for (int j=0;j<3;++j) assert(y[j]==pulse[phase-2][j]);
        double duplicate[3]; assert(imu_pulse_sample(p,s,tick,duplicate));
        for (int j=0;j<3;++j) assert(duplicate[j]==y[j]);
    }
    assert(!imu_pulse_sample(p,s,0,y)); // reset required for a new run/clock

    // Gaussian variance/cross-axis covariance. Events MUST overwrite the noise.
    p.noise_factor[0][0]=2; p.noise_factor[1][0]=1; p.noise_factor[1][1]=3;
    p.noise_factor[2][1]=.5; p.noise_factor[2][2]=1;
    assert(imu_pulse_reset(p,s,987));
    double sum[3]={0,0,0},square[3][3]={{0,0,0},{0,0,0},{0,0,0}}; int quiet=0;
    for (std::uint64_t tick=0;tick<200000;++tick) {
        assert(imu_pulse_sample(p,s,tick,y));
        if (s.cached_is_pulse) {
            for (int j=0;j<3;++j) assert(y[j]==pulse[tick%5-2][j]);
        } else {
            ++quiet;
            for (int i=0;i<3;++i) { sum[i]+=y[i]; for (int j=0;j<3;++j) square[i][j]+=y[i]*y[j]; }
        }
    }
    const double covariance[3][3]={{4,2,0},{2,10,1.5},{0,1.5,1.25}};
    for (int i=0;i<3;++i) {
        assert(std::abs(sum[i]/quiet)<.05);
        for (int j=0;j<3;++j) {
            const double c=square[i][j]/quiet-(sum[i]/quiet)*(sum[j]/quiet);
            assert(std::abs(c-covariance[i][j])<.15);
        }
    }
    // Same seed/reset gives exactly the same process, independent of reads/skips.
    ImuPulseState dense={},sparse={}; assert(imu_pulse_reset(p,dense,123)); assert(imu_pulse_reset(p,sparse,123));
    for (std::uint64_t tick=0;tick<1000;++tick) {
        double a[3],b[3]; assert(imu_pulse_sample(p,dense,tick,a));
        if (tick%7==0) { assert(imu_pulse_sample(p,sparse,tick,b)); for (int j=0;j<3;++j) assert(a[j]==b[j]); }
    }

    // Deterministic alternating event classes, unequal widths/gaps, joint shape.
    static const double joint[5][3]={{10,20,30},{15,25,35},{-40,-50,-60},{-30,-20,-10},{-5,-10,-15}};
    static const std::size_t offsets[2]={0,2},lengths[2]={2,3},gaps[2]={1,2};
    static const unsigned classes[2]={0,1};
    ImuPulseParameters q=deterministic(); q.samples_ug=joint;q.sample_count=5;q.event_count=2;
    q.offset=offsets;q.length=lengths;q.gap=gaps;q.event_class=classes;q.use_markov=true;
    for (int row=0;row<6;++row) for (int col=0;col<6;++col) q.transition_probability[row][col]=0;
    for (int row=0;row<6;++row) q.transition_probability[row][row==0 ? 1 : 0]=1;
    assert(imu_pulse_reset(q,s,21));
    unsigned previous=6;int completed=0;
    for (std::uint64_t tick=0;tick<1000;++tick) {
        assert(imu_pulse_sample(q,s,tick,y));
        if (s.cached_is_pulse && !s.have_event) {
            if (previous<6) assert(s.previous_class!=previous);
            previous=s.previous_class; ++completed;
        }
    }
    assert(completed>200);
    // Empirical class frequencies AND uniform selection within a class.
    static const double population[4][3]={{100,1,0},{200,2,0},{300,3,0},{-100,-1,0}};
    static const std::size_t starts[4]={0,1,2,3},widths[4]={1,1,1,1},pauses[4]={1,1,1,1};
    static const unsigned marks[4]={0,0,0,1};
    ImuPulseParameters mix=deterministic();mix.event_count=4;mix.sample_count=4;
    mix.samples_ug=population;mix.offset=starts;mix.length=widths;mix.gap=pauses;mix.event_class=marks;
    mix.class_probability[0]=.75;mix.class_probability[1]=.25;mix.use_markov=false;
    for(int row=0;row<6;++row){mix.transition_probability[row][0]=.75;mix.transition_probability[row][1]=.25;}
    assert(imu_pulse_reset(mix,s,777));int histogram[4]={0,0,0,0};
    for(std::uint64_t tick=0;tick<200000;++tick){
        assert(imu_pulse_sample(mix,s,tick,y));
        if(s.cached_is_pulse)++histogram[s.event];
    }
    for(int k=0;k<4;++k)assert(std::abs(histogram[k]/100000.0-.25)<.01);
    q.transition_probability[0][5]=.01; assert(!imu_pulse_validate(q)); // absent class
    q=deterministic(); q.fitted=false; assert(!imu_pulse_reset(q,s,1));
    q=deterministic(); q.Fs=0; assert(!imu_pulse_validate(q));
    const double good[3][3]={{0,-1,0},{1,0,0},{0,0,1}},bad[3][3]={{2,0,0},{0,1,0},{0,0,1}};
    assert(imu_rotation_valid(good) && !imu_rotation_valid(bad));
    assert(close(100e-6*9.80665/0.3048*.01,.00003217404855643045));
    std::cout << "PASS: scheduling, joint shapes, Gaussian covariance, no double noise, reset/cache, Markov and units\n";
}
