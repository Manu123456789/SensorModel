function x=boundedNormalQuantile(q,mu,sigma,lo,hi)
if sigma==0, x=repmat(mu,size(q)); return; end
a=.5*erfc(-(lo-mu)/(sigma*sqrt(2))); b=.5*erfc(-(hi-mu)/(sigma*sqrt(2)));
x=mu+sigma*sqrt(2)*erfinv(2*(a+q*(b-a))-1);
x(q==0)=lo; x(q==1)=hi;
end
