%% Imported-table template: edit only this short script and defaults as needed.
suiteRoot=fileparts(mfilename('fullpath')); addpath(suiteRoot);
cfg=imupulse.defaults();
cfg.selectedAxes={'Y'};                 % One or more SENSOR axes
T=YourImportedTable;                    % EDIT, or readtable('Your_IMU.xlsx')
cfg.timeColumn='Time';                   % Numeric seconds
cfg.axisColumns={'ColumnX','ColumnY','ColumnZ'};
cfg.window_s=[0 120];                    % EDIT: one contiguous operating interval
cfg.baselineSensor_ms2=[NaN NaN NaN];     % EDIT known true input, incl. gravity
% Only selected axes require a finite known baseline. Example zero-input,
% gravity-compensated Y: cfg.baselineSensor_ms2=[NaN 0 NaN];
cfg.inputMode='instantaneous_ft_s2';
cfg.R_sensor_to_PLT=eye(3);              % Column convention: platform = R*sensor
cfg.isSynthetic=false;
% Optional selected-axis detection thresholds [ug], X/Y/Z order:
% cfg.manualThreshold_ug=[NaN 40 NaN]; cfg.detectSigma=5; cfg.releaseSigma=2;
% Known bounds in the ORIGINAL selected input column units:
% cfg.railLimitsInput=[-Inf Inf;-0.05 0.05;-Inf Inf];
% cfg.allowRailSamples=true; % explicit recorded-clipped-readout model only
results=imupulse.analyze(T,cfg);
imupulse.saveOutputs(results,fullfile(suiteRoot,'output_hardware'));

