// Exact selected-axis isolation and rotation checks; no fitted hardware data.
#include "IMU_Pulse_Integration_Template.cpp"
#include <cassert>
#include <iostream>
int main()
{
    static double rows[4][3];
    static const std::size_t offsets[2]={0,2},lengths[2]={2,2},gaps[2]={3,5};
    static unsigned classes[2];
    for (int selected=0;selected<3;++selected) {
        for (auto& row:rows) for (double& x:row) x=0;
        rows[0][selected]=100; rows[1][selected]=50;
        rows[2][selected]=-25; rows[3][selected]=-10;
        classes[0]=static_cast<unsigned>(2*selected); classes[1]=classes[0]+1;
        ImuPulseParameters p=imu_pulse_parameters;
        p.fitted=true; p.Fs=200; p.event_count=2; p.sample_count=4;
        p.samples_ug=rows; p.offset=offsets; p.length=lengths; p.gap=gaps; p.event_class=classes;
        p.burn_in_samples=100; p.baseline_ug[selected]=3;
        p.noise_factor[selected][selected]=2;
        for (int j=0;j<6;++j) {
            p.class_probability[j]=0;
            for (int k=0;k<6;++k) p.transition_probability[j][k]=0;
            p.transition_probability[j][2*selected]=.8;
            p.transition_probability[j][2*selected+1]=.2;
        }
        p.class_probability[2*selected]=.8; p.class_probability[2*selected+1]=.2;
        ImuPulseState s={}; assert(imu_pulse_reset(p,s,42));
        int positive=0,negative=0,quiet=0;
        for (std::uint64_t tick=0;tick<10000;++tick) {
            double out[3]; assert(imu_pulse_sample(p,s,tick,out));
            for (int j=0;j<3;++j) if (j!=selected) assert(out[j]==0 && p.baseline_ug[j]==0);
            if (s.cached_is_pulse) { if (out[selected]>0) ++positive; else ++negative; }
            else ++quiet;
        }
        assert(positive>0 && negative>0 && quiet>0);
    }
    // A single selected axis may contribute to every platform component.
    const double R[3][3]={{.36,.48,-.8},{-.8,.60,0},{.48,.64,.60}};
    assert(imu_rotation_valid(R));
    double platform[3]={0,0,0}; const double sensor[3]={0,100,0};
    for (int i=0;i<3;++i) for (int j=0;j<3;++j) platform[i]+=R[i][j]*sensor[j];
    assert(std::abs(platform[0]-48)<1e-12 && std::abs(platform[1]-60)<1e-12 && std::abs(platform[2]-64)<1e-12);
    const double reflection[3][3]={{-1,0,0},{0,1,0},{0,0,1}};
    assert(!imu_rotation_valid(reflection));
    std::cout<<"PASS: any single axis, exact inactive zeros, both signs, quiet samples, proper rotation\n";
}
