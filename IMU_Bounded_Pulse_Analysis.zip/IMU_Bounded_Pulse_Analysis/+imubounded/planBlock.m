function p=planBlock(m,j,stream)
% E events require E+1 quiet slots. Allocate exact integer quiet budget.
t=m.pulseTypes{j}; order=[];
for k=1:numel(t), order=[order repmat(k,1,t(k).count)]; end %#ok<AGROW>
order=shuffle(order,stream); E=numel(order); slots=E+1;
quiet=m.blockSamples-sum([t.count].*[t.width]); extra=quiet-slots;
assert(extra>=0,'Block has insufficient quiet separation.');
u=((0:slots-1)'+rand(stream,slots,1))/slots;
q=m.gapQuantiles{j}; weights=interp1(linspace(0,1,numel(q)),q,u,'linear');
weights=shuffle(weights,stream); if sum(weights)<=0, weights=ones(slots,1); end
cumulative=extra*cumsum(weights)/sum(weights); cumulative(end)=extra;
rounded=floor(cumulative+rand(stream)); gaps=1+diff([0;rounded]);
assert(all(gaps>=1) && sum(gaps)==quiet);
p=struct('order',order,'gaps',gaps,'blockSamples',m.blockSamples);
end
function x=shuffle(x,stream)
for k=numel(x):-1:2
    index=1+floor(rand(stream)*k); tmp=x(k); x(k)=x(index); x(index)=tmp;
end
end
