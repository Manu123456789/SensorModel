"""Developer checks; needs Python3 and g++, NOT MATLAB. Writes build files to scratch.
Usage: python3 tests/run_checks.py /path/to/scratch_build
The fixture below is SYNTHETIC and cannot calibrate a hardware model.
"""
import json
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parents[1]
build=Path(sys.argv[1]).resolve()
build.mkdir(parents=True,exist_ok=True)
source=(root/'IMU_Axis_Integration_Template.cpp').read_text()
begin='// BEGIN EXPORTED AXIS MODEL'
end='// END EXPORTED AXIS MODEL'
assert source.count(begin)==source.count(end)==1
fixture='''// BEGIN EXPORTED AXIS MODEL
// SYNTHETIC TEST DATA, not an actual MATLAB export or hardware calibration.
static const double imu_pulse_samples[3]={100,200,-50};
static const std::size_t imu_event_offset[2]={0,2}, imu_event_length[2]={2,1}, imu_event_gap[2]={2,3};
static const unsigned imu_event_sign[2]={0,1};
static const ImuAxisParameters imu_axis_parameters={
true,1,100,3,2,.9,2,3,imu_pulse_samples,
imu_event_offset,imu_event_length,imu_event_gap,imu_event_sign,
{.5,.5},{{.5,.5},{.5,.5}},false,50
};
// END EXPORTED AXIS MODEL'''
path=build/'Synthetic_Axis_Model.cpp'
path.write_text(source[:source.index(begin)]+fixture+source[source.index(end)+len(end):])
flags=['g++','-std=c++11','-O2','-Wall','-Wextra','-Werror','-pedantic']
binary=build/'test_axis_port'
subprocess.run(flags+[f'-DIMU_MODEL_FILE="{path}"',str(root/'tests/test_axis_port.cpp'),'-o',str(binary)],check=True)
test_output=subprocess.check_output([str(binary)],text=True)
print(test_output,end='')
trace=build/'trace_imu'
subprocess.run(flags+[f'-DIMU_MODEL_FILE="{path}"',str(root/'Trace_IMU_Axis_Model.cpp'),'-o',str(trace)],check=True)
text=subprocess.check_output([str(trace),'1000','1'],text=True)
rows=text.splitlines(); assert rows[0]=='Time_s,ErrorX_ug,ErrorY_ug,ErrorZ_ug' and len(rows)==1001
for k,line in enumerate(rows[1:]):
    t,x,y,z=map(float,line.split(',')); assert abs(t-k/100)<1e-12 and x==z==0
# Same host/event seeds must repeat; another seed must change the trace.
assert text==subprocess.check_output([str(trace),'1000','1'],text=True)
assert text!=subprocess.check_output([str(trace),'1000','2'],text=True)
(build/'CPP_Trace_Synthetic.csv').write_text(text)
report={'status':'PASS','scope':'C++ execution plus static exporter review; MATLAB not executed',
        'details':test_output.strip(),'trace_rows':1000,
        'checks':['strict C++11 compilation','deterministic event timing and sign transitions',
                  'background stationary variance and lag-one correlation','no extra background during events',
                  'tick cache and invalid-clock rejection','host RNG callback','burn-in phase preservation',
                  'selected sensor axis','frame rotation','unit conversion','retained unrelated errors',
                  'reproducible equal seeds and different unequal seeds']}
(build/'Port_Validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: trace columns, sample clock, inactive axes, repeated seeds.')
