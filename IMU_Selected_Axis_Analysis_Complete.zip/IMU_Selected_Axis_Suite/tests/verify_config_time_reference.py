"""Numerical clock/window/unit contract checks, NOT MATLAB execution.
Needs NumPy. Usage: python tests/verify_config_time_reference.py
"""
import json
from pathlib import Path
import numpy as np

root = Path(__file__).resolve().parents[1]
N, fs = 24000, 200
clock = np.arange(N) / fs
assert clock[0] == 0 and clock[-1] == 119.995
assert np.arange(2048)[1000] / 1000 == 1
reference = np.genfromtxt(root / 'data/Sample_IMU_ft_s2.csv', delimiter=',', names=True)
assert np.max(np.abs(clock - reference['Time'])) < 1e-12

# A time window is applied after constructing the original-record clock.
rows = np.arange(1, N + 1)
keep = (clock >= 10) & (clock <= 90)
assert rows[keep][0] == 2001 and rows[keep][-1] == 18001
assert len(rows[keep]) == 16001
shifted = 50 + clock
assert np.array_equal((shifted >= 60) & (shifted <= 140), keep)

# Different input names map to the same selected sensor component, not a position.
channels = {'An unrelated channel': np.full(N, np.nan),
            'My Y acceleration (ft/s^2)': reference['ColumnY']}
selected_ug = channels['My Y acceleration (ft/s^2)'] * .3048e6 / 9.80665
assert np.isfinite(selected_ug).all()
sensor = np.zeros((N, 3)); sensor[:, 1] = selected_ug
assert np.all(sensor[:, [0, 2]] == 0)
for cumulative, integral in [(False, False), (True, False), (True, True)]:
    if not cumulative:
        continue
    scale = fs if integral else 1
    C = np.cumsum(reference['ColumnY'] * 30.48 / scale)
    a_ms2 = np.diff(C) * .01
    if integral:
        a_ms2 /= np.diff(clock)
    assert np.max(np.abs(a_ms2 * 1e6 / 9.80665 - selected_ug[1:])) < 1e-7
    assert rows[1:][0] == 2 and clock[1:][0] == 1 / fs

report = {
    'scope': 'Python numerical reference for config/time contracts, NOT MATLAB execution',
    'status': 'PASS', 'N_rows': N, 'sampleRate_Hz': fs,
    'first_sample_s': float(clock[0]), 'last_sample_s': float(clock[-1]),
    'window_s': [10, 90], 'retained_original_rows_inclusive': [2001, 18001],
    'window_sample_count': int(keep.sum()),
    'checks': ['CSV timestamps vs row-derived clock', 'window retains original-row times',
               'time origin shift', 'named channel / inactive zeros',
               'unweighted cumulative sum decoding', 'integrated velocity decoding'],
    'MATLAB_regression_tests_executed': False,
}
(root / 'evidence/Config_Timing_Reference.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
