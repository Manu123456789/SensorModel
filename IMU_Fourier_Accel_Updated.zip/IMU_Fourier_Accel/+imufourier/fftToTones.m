function [frequency,amplitude,phase]=fftToTones(F,bins,fs)
% Bin labels are zero-based. sin(theta+phi) = cos(theta+phi-pi/2).
n=numel(F); bins=bins(:); C=F(bins+1)/n;
frequency=bins*fs/n; amplitude=2*abs(C); phase=angle(C)+pi/2;
if mod(n,2)==0
    nyquist=bins==n/2; value=real(C(nyquist));
    amplitude(nyquist)=abs(value); % Nyquist is not a conjugate pair: NO doubling.
    phase(nyquist)=pi/2; phase(nyquist & real(C)<0)=-pi/2;
end
phase=mod(phase+pi,2*pi)-pi;
end
