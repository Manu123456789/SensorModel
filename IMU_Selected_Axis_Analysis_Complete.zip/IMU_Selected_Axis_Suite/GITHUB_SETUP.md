# Put this source package in a Git repository

Extract the ZIP first. The project root is the folder containing `README.md`,
`IMU_Config.m`, `Generate_Example_IMU.m` and `+imupulse/`. Keep `+imupulse` exactly
as named: the plus sign defines a MATLAB package and must not be removed.

For an existing local checkout, copy this project folder's contents into your
checkout, preserving subfolders. Review `git status`, then stage and commit the
changes. Do not copy over the checkout's `.git` directory or force-push history.

For a new local repository, run from the extracted project root:

```sh
git init
git add .
git status
git commit -m "Add selected-axis IMU analysis suite"
```

After creating an empty remote repository and choosing its URL:

```sh
git branch -M main
git remote add origin YOUR_REPOSITORY_URL
git push -u origin main
```

If the remote already contains commits, clone it first and use the existing-
checkout workflow above. Authentication and repository access must be configured
on your machine. These instructions do not publish anything automatically.

The source package generates its optional synthetic timetable in memory.
`.gitignore` excludes generated output folders, MAT/FIG files, executables,
caches and local ZIPs. It does not exclude the supplied source data or evidence.
The scripts create output folders when needed; an initially empty output folder
does not need to be committed. Ignore rules do not untrack files already committed.

All supplied source files are compact. Record the exact upload error and
whether it occurred during browser upload, GitHub Desktop, or `git push` to
diagnose it. The current model includes a Gauss-Markov quiet process and spike events.
