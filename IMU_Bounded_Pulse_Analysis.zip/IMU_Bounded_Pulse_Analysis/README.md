# Bounded IMU pulse model: separate signed amplitudes and pulse density

This revision retains the small, self-contained pulse-generator architecture and
all diagnostic figure families. It addresses three specific shortcomings of the
previous shared-sign model:

1. Positive and negative pulses now have separate fitted magnitude laws AND
   separate fixed durations, so a short small negative event is not modeled like
   a large long positive event.
2. The COMPLETE generated sensor error, including background noise, stays within
   the minimum and maximum of the fitted measured error record. Samples are
   drawn from conditional distributions rather than clipped onto the endpoints.
3. Nominal onset density is tied to the observed start rate. A new G figure and
   tables distinguish event counts, occupied time, signed magnitude and PSD power.

The runtime model has **12 scalar values per selected axis**, plus sampling rate,
axis index and a rectangle/triangle flag. No measured waveform arrays or C++
exporter are included. The README contains a C++ implementation that uses the
coefficient table and your existing RNG. No MATLAB process is needed in the sim.

Requirements: MATLAB R2021b+ and Signal Processing Toolbox. Core `fminsearch`,
`erfc` and `erfinv` handle the small bounded fits; no Statistics/Optimization
Toolbox is needed. MATLAB was not available here; see VALIDATION.md for executed
numerical/C++ checks versus supplied unexecuted MATLAB tests.

## 1. Run it on your test data

Put this folder on your MATLAB path or open `IMU_Config.m` and run it. All user
settings are in that ONE script. Your dataset is already in the workspace:

```matlab
cfg.workspaceVariable = 'MyImportedTimetable';
cfg.columns.X = 'My_X_Channel';
cfg.columns.Y = 'My_Y_Channel';
cfg.columns.Z = 'My_Z_Channel';
cfg.selectedAxes = {'Y'};               % Fit/generate sensor axis 2 only
cfg.histogramAxes = {'X','Y','Z'};       % Observed XYZ histograms
cfg.sampleRate_Hz = 1000;               % Actual acquisition rate
cfg.rowWindow = [1000 2000];            % INCLUSIVE ORIGINAL ROWS
cfg.baselineSensor_ms2 = [NaN 0 NaN];   % Example: Y has known zero true input
```

Supply your actual physical baseline, not the example zero if there is known
motion or gravity on that axis. The code converts the readout to acceleration,
subtracts this known true input, and models the resulting ERROR. Its quiet
error offset is estimated separately and retained. It does not subtract the
full-signal mean or remove spikes as outliers.

Run the script after editing. Main outputs in your workspace are:

```matlab
IMU_Results       % Model, reference, generated example, diagnostics, summaries
Coefficients      % Small table to use in C++
```

The script uses your existing variable directly with MATLAB copy-on-write. No
CSV is reimported. It reads only mapped channels in the union of selectedAxes and
histogramAxes and only the requested rows. Unneeded channels need not be mapped
if they are absent from BOTH selections. Names containing spaces are supported.

### Timing is defined by row number, with no input clock lookup

Original row k corresponds to `(k - 1)/cfg.sampleRate_Hz`. The row window is
inclusive. At 1000 Hz, rows 1000:2000 produce 1001 samples from 0.999 to 1.999 s.
Most plots display elapsed time relative to the beginning of the selected window
or reference portion. Timetable acquisition metadata is ignored for the clock.
Uniform sampling is assumed; this cannot detect missed samples or acquisition
jitter from row number alone. No rows with invalid modeled samples are silently
removed, because doing so would break the assumed clock.

`rowWindow=[1 Inf]` uses the whole available record. At least 512 reconstructed
samples are required. Use a representative interval containing enough pulses.
The minimum of five complete events only permits calculation; it is not a
statistically justified minimum for tail or rate validation.

### Input modes and cumulative records

- `instantaneous_ft_s2` (default), `instantaneous_ms2`, `instantaneous_cm_s2`,
  `instantaneous_ug`: one acceleration value per row.
- `sample_sum_cm_s2`: your channel is an UNWEIGHTED running sum of cm/s^2
  samples; a first difference recovers acceleration. No division by dt here.
- `integral_cm_s`: your channel is accumulated velocity in cm/s; first difference
  divided by dt recovers acceleration.

For cumulative modes the prior row is read for the first requested difference.
The reconstructed sample is labeled with the current original row. If the
window starts at row 1, output begins at row 2 because a prior sample is absent.
Do not select a cumulative mode merely because your simulation later integrates
acceleration. Select it only when the INPUT channel itself is cumulative.

### Optional runnable example

Set `cfg.useSyntheticExample=true` in the same main script. It creates 120 s of
XYZ data in ft/s^2 at 200 Hz, with bounded white backgrounds and asymmetric signed
rectangle pulses (negative events are smaller and shorter). Change the demo duration/rate in the config if desired.
The example is generated under this simple model's assumptions, so a successful
example demonstrates the workflow, not applicability to arbitrary hardware.

### One or multiple axes

Default: `cfg.selectedAxes={'Y'}`. You can select X, Z or more than one axis.
Each selected axis gets its OWN 12 runtime values and is generated
independently. Unselected sensor outputs are exactly zero. This simple model
does not preserve cross-axis pulse coupling or background covariance; optional
Figure F exposes that limitation. Rotate the sensor vector afterward using
`cfg.R_sensor_to_PLT`. One sensor axis can contribute to multiple platform axes.

## 2. What is modeled, bounded, and fitted

### Complete-signal bounds

For a modeled sensor axis, let L and U be the minimum and maximum of the ERROR
samples used for fitting, after unit conversion and known-true-input subtraction.
For full-record fitting (the default), these are the extremes of your entire
selected row window. With an optional held-out suffix, bounds come from the FIT
portion only; reference samples outside that range are reported, not silently
used to update the model. These are empirical modeling limits for this record,
not established physical limits or a guarantee about unobserved sensor behavior.

Every output sample follows a normal proposal with a state-dependent center:

```text
quiet center       = quietLocation
positive center    = quietLocation + positiveAmplitude * shape[row]
negative center    = quietLocation - negativeMagnitude * shape[row]
output              = Normal(center, quietScale) conditioned on L <= output <= U
```

Proposals outside [L,U] are redrawn. This bounds the sum, not just the pulse.
There is no broad random-output clipping and no artificial accumulation of
clipped samples exactly at L/U. A genuinely zero-variance fitted class can still
produce a point mass, which is different from clipping. Roundoff guards keep
computed centers inside [L,U].

The underlying Gaussian noise draws remain independent. Conditioning near a
bound can shift the actual residual mean and variance from the proposal center
and scale; the complete model is therefore not an independent additive Gaussian
term at those edges. Quiet samples, with a fixed center and bounds, remain iid
under the model. The B plots compare against the conditional normal law.

Bounds are enforced on modeled SENSOR errors before frame rotation. A rotated
PLATFORM component does not generally have the same observed limits, and other
retained sim errors can change the final total. Unselected sensor contributions
remain exactly zero rather than being constrained to their unmodeled readouts.

### Separate positive and negative magnitude laws

The two event classes now have separate upper-truncated lognormal parameters:

```text
positive magnitude = exp(muPositive + sigmaPositive * fresh_normal())
                     conditioned on 0 < magnitude <= U - quietLocation
negative magnitude = exp(muNegative + sigmaNegative * fresh_normal())
                     conditioned on 0 < magnitude <= quietLocation - L
```

The sign is chosen once per event using NegativeEventProbability. An absent
negative class gives probability zero; it no longer borrows the positive
magnitude law. One observed event in a class gives a zero fitted log-spread
because no within-class event-to-event spread can be estimated from one event.
The class counts are printed in FitReview; tiny counts are weak evidence, not
permission to infer an unknown tail. Unused class parameters have finite zero
sentinels and an unused one-sample duration; their probability is zero.

Bounds enter the likelihood during fitting, rather than being added after the
old unbounded fit. The log-location is constrained below the logarithm of the
amplitude cap, so at least half the normal log-proposals lie below that cap.
The log-spread is constrained to 0..10 as a numerical guard. Quiet location is
constrained to [L,U] and its proposal scale to 0..(U-L). These constraints keep
rejection sampling practical and are documented model choices, not hardware laws.

### Pulse LEVEL fitting instead of noisy maxima

For each complete detected event we estimate the coefficient A of its chosen
ideal shape w using `A = sum(w*(samples - quietLocation)) / sum(w^2)`. For a
rectangle this is its background-adjusted mean level. For a triangle it is a
one-parameter least-squares shape projection. Runtime pulses still use simple
computed shapes; none of the event waveform samples is retained in the model.

Using noisy maxima as the level and THEN adding background noise can exaggerate
heights and energy. The projection avoids that particular double contribution.
D1/G1/G2 still check DETECTED PEAKS on generated versus measured signals; they
are not silently redefined as mean levels.

`cfg.amplitudeWeight='samples'` (default) weights each event's amplitude fit by
its observed duration. This prioritizes the distribution of occupied samples,
which is what the amplitude histogram counts. Set it to `'events'` to give each
event equal weight. This changes only offline estimation, not runtime coefficient
count. If width and amplitude are correlated in the real record, a fixed-width
per-sign model cannot perfectly preserve both event-weighted and sample-weighted
amplitude distributions; the option makes the chosen priority explicit.

FitReview reports shape-projection sign conflicts and projected magnitudes that
exceeded their permitted cap before support correction. These can indicate a
poor ideal-shape choice, biphasic events or classification problems. They are
not silently presented as successful unipolar-event fits. A zero or invalid
projection stops fitting and requests review. Truncating the lognormal law
cannot make an arbitrary measured histogram belong to that family.

### Separate durations and rate-based gap fitting

The positive and negative nominal widths are the respective mean complete-event
durations, rounded to samples. A single shorter negative width can correct
excess negative-bin occupancy without artificially deleting negative events.
There is still no variable-duration distribution within a sign class.

Let q be the fraction of complete detected events that are negative, W+ and W-
the fitted widths, and meanW = (1-q)*W+ + q*W-. Observable measured onsets exclude
an event already active at row 1, and include later onsets even if the record
ends before that event finishes. The target total onset rate is:

```text
targetRate = observable_onsets * Fs / (fit_sample_count - 1)
meanQuietGap_samples = Fs/targetRate - meanW
GapProbability = 1 / meanQuietGap_samples
```

The mean quiet gap is limited to at least one sample, with a MinimumGapLimited
flag if the requested rate is incompatible with rounded widths. Complete-gap
mean is also recorded for comparison, but no longer directly sets density.
This matches NOMINAL onset rate under the renewal model. Redetected generated
rate can differ because noise/thresholds trim, merge, fragment or miss events;
DensitySummary deliberately shows that discrepancy instead of promising exact
counts in every realization.

Quiet gaps remain geometric on 1,2,... and sign choices remain independent.
With cycle = meanQuietGap + meanW:

```text
nominal onset rate = Fs / cycle
positive occupancy = (1-q)*W+ / cycle
negative occupancy = q*W- / cycle
quiet occupancy = meanQuietGap / cycle
```

These formulas show why event probability alone does not determine histogram
occupancy. Long positive events and short negative events can have similar
counts but very different sample populations. Clustering, periodicity and
within-sign width variation remain limitations checked by the diagnostics.

### Shape and initialization

Rectangle is the default. A triangle uses
`min(row+1, width-row)/ceil(width/2)` for row 0..width-1. Both have unit peak and
positive finite support. Detected support is not a deconvolved physical width;
threshold trimming can still bias duration and shape estimates.

The scheduler starts at a stationary random phase for this ideal model. Pulse
occupancy is meanW/cycle. Conditional on starting inside a pulse, the negative
class probability is q*W-/meanW, NOT q, because longer events occupy more random
time samples. Choose a uniform row inside that class's width. Otherwise the
remaining quiet gap is geometric, using its memoryless property. New events
use the ordinary event-sign probability q. No burn-in or waveform catalog is
required. This is an initialization rule for the assumed model, not evidence
that the measured process is stationary.

## 3. Fitting and reference labels

`cfg.fitFraction=1` fits and compares the full selected record. Figures say
**Measured (fit/reference)**. A3 compares its measured first and second halves.
This is descriptive in-sample agreement, not independent validation. The optional
`.70` setting fits the first 70% and compares the final held-out 30%; bounds also
come from the first portion in that case. Contiguous portions are not necessarily
independent experimental runs.

Detection uses the same per-axis hysteresis and robust initial scale as before:
onset = 5*MAD-scale, release = 2*MAD-scale by default, with a manual onset
override in the config. Its quiet baseline is iteratively estimated as the
quiet SAMPLE mean. Keep that detector baseline distinct from the fitted
conditional-normal proposal LOCATION when bounds are near the quiet population.
The same detector baseline/thresholds are applied to measured and generated
records. Detector settings are diagnostic quantities, not extra C++ coefficients.

Quiet conditional-normal parameters and signed conditional lognormal parameters
are small constrained maximum-likelihood fits using core fminsearch. The signed
likelihood uses event projections with the configured weights. Fits condition
on the selected supports; detection censoring, imperfect shapes and threshold
selection are not magically removed by likelihood fitting. FitReview records
optimizer exit flags: a nonpositive active-class exit needs inspection. A zero
exit for an absent sign class means no fit was attempted.

## 4. Coefficients to put into your C++ code

`Coefficients` in the workspace and `Coefficients.csv` contain one row per selected
axis. The 12 runtime values are:

| Output column | C++ field | Meaning |
|---|---|---|
| QuietLocation_ug | b | Underlying bounded-normal proposal location |
| QuietScale_ug | sigma | Underlying proposal scale, not necessarily actual truncated std |
| LowerBound_ug | lo | Complete sensor-error lower limit |
| UpperBound_ug | hi | Complete sensor-error upper limit |
| PositiveLogMu | posMu | Positive magnitude log-location |
| PositiveLogSigma | posSigma | Positive magnitude log-spread |
| NegativeLogMu | negMu | Negative magnitude log-location |
| NegativeLogSigma | negSigma | Negative magnitude log-spread |
| NegativeEventProbability | q | Probability a NEW event is negative |
| PositiveWidth_samples | posWidth | Positive duration, in samples |
| NegativeWidth_samples | negWidth | Negative duration, in samples |
| GapProbability | gapP | Geometric quiet-gap parameter |

Metadata/derived columns include Fs, sensor index, pulse shape, mean gap,
durations in seconds and nominal rates/occupancies. They are not extra free
fitted parameters. Log parameters operate on numerical magnitudes in MICRO-G;
generate in micro-g first, then convert the complete output. There is no C++
source generator and no need to load CSV files inside the simulation.

## 5. Self-contained C++ implementation

The generator below is the manual implementation of these coefficients. Keep
its types/constants/prototypes/helpers in your existing .cpp. Your existing
callbacks supply fresh N(0,1) and uniform [0,1) values. Validate copied numbers
once: lo < hi, b inside bounds, nonnegative finite scales, sigma <= hi-lo,
0 < gapP <= 1, 0 <= q <= 1, positive integer widths, and enabled-sign log-location
<= log(its cap). The printed coefficient table satisfies those constraints.
No external process, MATLAB runtime or recorded waveform table is required.

<!-- BOUNDED_CPP_BEGIN -->
```cpp
#include <algorithm>
#include <cmath>
#include <cstddef>

struct BoundedParams {
    double b, sigma, lo, hi;
    double posMu, posSigma, negMu, negSigma;
    double q, gapP;
    std::size_t posWidth, negWidth;
    bool triangle;
};
struct BoundedState {
    bool initialized=false, active=false;
    std::size_t gapLeft=0, row=0, width=1;
    double amplitude=0;
};
using Draw = double (*)();

std::size_t drawGap(const BoundedParams& p, Draw uniform01)
{
    if (p.gapP >= 1) return 1;
    return 1 + static_cast<std::size_t>(
        std::floor(std::log1p(-uniform01())/std::log1p(-p.gapP)));
}
double boundedNoise(double center, const BoundedParams& p, Draw normal01)
{
    center = std::max(p.lo,std::min(p.hi,center)); // center roundoff guard only
    if (p.sigma == 0) return center;
    double x;
    do { x = center + p.sigma*normal01(); }
    while (!std::isfinite(x) || x < p.lo || x > p.hi);
    return x;
}
void loadPulse(const BoundedParams& p, BoundedState& s, bool negative, Draw normal01)
{
    s.width = negative ? p.negWidth : p.posWidth;
    s.row = 0; s.active = true;
    const double cap = negative ? p.b-p.lo : p.hi-p.b;
    const double mu = negative ? p.negMu : p.posMu;
    const double sigma = negative ? p.negSigma : p.posSigma;
    double a;
    if (sigma == 0) a = std::min(cap,std::exp(mu));
    else {
        do { a = std::exp(mu + sigma*normal01()); }
        while (!std::isfinite(a) || a <= 0 || a > cap);
    }
    s.amplitude = negative ? -a : a;
}
void resetBounded(const BoundedParams& p, BoundedState& s, Draw normal01, Draw uniform01)
{
    s = BoundedState{};
    const double meanWidth = (1-p.q)*p.posWidth + p.q*p.negWidth;
    const double duty = meanWidth/(1/p.gapP + meanWidth);
    if (uniform01() < duty) {
        const bool negative = uniform01() < p.q*p.negWidth/meanWidth;
        loadPulse(p,s,negative,normal01);
        s.row = static_cast<std::size_t>(uniform01()*s.width);
    } else s.gapLeft = drawGap(p,uniform01);
    s.initialized = true;
}
double sampleBounded(const BoundedParams& p, BoundedState& s, Draw normal01, Draw uniform01)
{
    if (!s.initialized) resetBounded(p,s,normal01,uniform01);
    if (!s.active) {
        if (s.gapLeft > 0) { --s.gapLeft; return boundedNoise(p.b,p,normal01); }
        loadPulse(p,s,uniform01() < p.q,normal01);
    }
    const double weight = p.triangle
        ? std::min(s.row+1,s.width-s.row)/std::ceil(s.width/2.0) : 1.0;
    const double center = p.b + s.amplitude*weight;
    if (++s.row == s.width) { s.active=false; s.gapLeft=drawGap(p,uniform01); }
    return boundedNoise(center,p,normal01);
}
```
<!-- BOUNDED_CPP_END -->

In your main error function, call sampleBounded ONCE per SENSOR update before
the XYZ loop. Put its value only on the exported SensorIndex0 component, rotate
using the same R as MATLAB, and convert micro-g to ft/s^2 with 9.80665e-6/0.3048.
For a delta-velocity interface multiply that acceleration by dt; for an
acceleration interface let your existing integrator do so. Inject only one.
The return already includes the quiet location and pulse contribution. Do not
add the same fitted quiet bias or old white-noise source again.

Do not difference successive instantaneous acceleration samples as in the
attached gyro example; that generates edge changes rather than acceleration or
its correct integral. Retain unrelated legacy cumulative-error terms in their
existing paths. Your actual receiving variable's units determine the binding.

Reset BoundedState and the relevant RNG streams once per Monte Carlo run. Keep
state persistent between samples. Solver substeps or repeated calls at one
sensor tick must not advance the scheduler; cache/hold between sensor ticks if
needed. Use one state per modeled axis/sensor instance. This compact snippet
assumes valid inputs and proper host callbacks; it does not implement your
scheduler, exception policy or thread synchronization.

The normal callback must genuinely supply fresh independent untruncated N(0,1)
draws. Verify what rn_norm_limits actually does rather than relying on its name.
Truncation here is applied by the model's own rejection rule. Uniform draws
select gaps, signs and initial phase. Different rejection counts advance shared
RNG streams differently; dedicated stream state can help isolate sources if
supported by your host. Mathematical sampling laws match MATLAB, but individual
samples need not match for an equal numeric seed.

The bounds are on the model-only selected SENSOR errors. Other retained error
sources and rotation can change the final platform totals. Do not claim a
platform bound merely because this scalar source is bounded.

## 6. Diagnostic figures: same families, at most six tiles

For one modeled axis the package opens S, G, H, A, B, C, D and E. H can show all
three observed axes even when only one is modeled. Optional F checks independence
when more than one axis is modeled. Figures save as PNG and editable FIG.
Units on selected-model plots are ERROR micro-g after known-input subtraction;
H shows observed acceleration in ft/s^2. Do not compare their offsets without
accounting for that distinction.

### Figure S: six-panel presentation summary

| Tile | What it shows | What agreement means / what to inspect |
|---|---|---|
| S1 | Full measured/reference and generated-run-1 histories on common axes | Compare signs, typical heights, event density and offset; independent event times need not align |
| S2 | Amplitude density for the reference and generated run 1 on identical finite bins | Compare central width, offset and tails; density times bin width integrates to one |
| S3 | Contiguous quiet close-ups from each record | See the background without spike-dominated vertical scaling |
| S4 | Mean-removed Welch PSD: reference and generated ensemble mean | Compare distribution of fluctuation power over frequency |
| S5 | Terminal velocity-error CDFs for equal-duration windows | Compare integrated acceleration area and run-to-run variation at this horizon |
| S6 | Terminal position-error CDFs for those windows | Compare consequences of amplitude and timing together |

S2 deliberately uses one generated realization for exact common-range density;
C3 provides the ensemble probability range. Histogram shape depends on bin width:
a narrow central peak plus a tail supports a different behavior population but
does not by itself show pulse timing or prove a physical fault.

S3 chooses the longest DETECTED quiet run separately from the reference and
generated run 1. It compares the beginning of each over a common duration capped
by quietZoom_s (default 0.5 s). It never concatenates disconnected samples or
clips spikes to manufacture a noise floor. Each segment has its own elapsed zero.
Their absolute positions in S1 differ. The dotted line is the fitted quiet mean.
This selected visual example can be affected by classification and segment
choice; B is the fuller assumption check. If either run lacks two contiguous
quiet samples, the panel explains that it is unavailable.

S4 removes each record's mean only for the spectrum. This does not remove mean
from generated output or integration. Mean generated PSD is the arithmetic mean
in LINEAR power, not a mean in dB. A consistently low measured PSD can mean that
the model produces too much fluctuation power in that reference interval;
compare Std_ug and event rates before changing coefficients.

S5/S6 split the reference and EACH generated record into nonoverlapping windows
of summaryTerminalWindow_s, rounded to whole samples and capped to the record.
Each window starts with zero velocity/position error. Incomplete trailing windows
are omitted. An empirical CDF at x gives the fraction of endpoints <=x. The
legend reports window counts. A single measured window is a vertical endpoint
marker, not a measured distribution. Neighboring windows can remain dependent;
pooled generated windows share fixed coefficients. These are descriptive CDFs,
NOT independent-trial confidence intervals or mission-horizon predictions.
Shorter windows give more endpoints at a shorter horizon; longer windows give
fewer examples of longer-horizon effects. Do not stitch reset windows together
as one physical trajectory. TerminalWindows.csv records the actual horizon,
counts, omitted samples and 5th/50th/95th percentiles.

### Figure A: input and detection, not a generated-data comparison

**A1 — measured signal and red events.** Gray is the entire measured error;
red redraws detected event samples. Small background noise can look flat when
large spikes set the vertical scale. It has not been removed. The split line
appears only if an actual held-out suffix is enabled. Check that red identifies
your intended events; otherwise later comparisons are based on poor labels.

**A2 — threshold zoom.** Black and red SHOULD overlap: they are the same
measurement with event labels, not test and model traces. Blue onset and green
release levels show hysteresis. Near-continuous red can indicate overly sensitive
thresholds or an unsuitable baseline/model family; missing excursions suggest
thresholds that are too high. Zoom duration is configurable.

**A3 — measured portion histograms.** With fitFraction=1, compare first versus
second half of the measured record. With a held-out split, compare fit versus
held-out. These curves compare measurement against measurement, not generation.
Agreement supports similar amplitude occupancy across portions, but not timing
or stationarity of every relevant property. Log probability displays tails;
zero-count bins are not visible on the log axis.

**A4 — block mean.** Means of nonoverlapping blocks reveal offset/regime changes.
Preferentially positive pulses can raise block means without quiet bias drift.
Check A5 alongside A4 to distinguish possible changes in event activity from a
change in background level.

**A5 — block event-start rate.** Counts starts per block divided by actual block
duration. Large differences can arise from finite counts or nonstationary
activity. Regular bursts/clusters matter because the generated gap process is
memoryless. Boundary blocks may include events whose starts/ends cross blocks.

**A6 — original row and elapsed time.** A straight line verifies the constructed
mapping under the configured acquisition rate. It is not measured timing-jitter
or missing-sample detection. Source rows retain original indices after selection.

### Figure B: WHITE background checks (changed from the old Gauss-Markov suite)

**B1 — quiet amplitude histogram / bounded-normal PDF.** Fit quiet samples are
shown after subtracting the detector quiet mean. The target is the fitted
CONDITIONAL normal, translated by that same detector mean. Its proposal location
and scale can differ from observed quiet mean/std when a bound is near the
population. Center, spread and tails all matter; symmetry alone is insufficient.
Zero fitted scale is explicitly labeled as a degenerate background.

**B2 — conditional-normal Q-Q.** Quantiles come from the bounded fitted law,
not an unbounded Gaussian reference. Near-diagonal agreement supports that
marginal model; curvature, skew or multiple populations indicate a limitation.
It is not a formal normality or significance test.

**B3 — quiet fit ACF and WHITE target.** White target equals one at lag zero and
zero at every nonzero lag. Original sample positions are preserved across pulse
gaps. Each lag averages only valid quiet pairs and is hidden if fewer than 30
pairs are available. Quiet samples are centered on their own quiet mean for ACF
only. A substantial smooth decay, oscillation or other repeatable structure
indicates that the white assumption misses time dependence. Small wiggles can
be finite-record variation; there are no formal significance bounds here.

**B4 — adjacent quiet samples.** Uses consecutive original samples that are both
quiet, with equal axis scaling and a display subset if needed. A round cloud
suggests weak lag-one correlation; a diagonal ellipse suggests persistence.
One round cloud does not establish independence at other lags or normality.
Compare B3/B6 before deciding white noise is adequate.

**B5 — standardized quiet residuals.** Plots `(quiet - proposalLocation) /
proposalScale` with the corresponding TRUNCATED standard-normal target. Near
bounds this is not an ordinary N(0,1) distribution, and it is not a Gauss-Markov
innovation. A zero scale is labeled unavailable. Check B3/B6 for time dependence;
a matching marginal histogram cannot establish whiteness.

**B6 — reference versus generated quiet ACF.** Compares reference quiet time
structure with the ensemble of redetected generated quiet portions. A meaningful
nonzero reference correlation absent from the white model is an unresolved
limitation. Pointwise ranges come from generated runs, not confidence limits for
the masked measured estimator. Reference quiet means are removed separately for
this ACF, so check amplitude plots for a baseline mismatch.

### Figure C: amplitude, spectrum and full-signal correlation

**C1/C2 — straight output histories.** Reference and generated run 1 use the
same vertical quantity but separate axes. Offsets, excursions and background
remain. Similar appearance is useful but cannot establish quantitative agreement.
Independent generated spike timestamps need not match measured timestamps.

**C3 — amplitude probability ensemble.** Black is the measured reference, red
the mean generated bin probability, shading the pointwise 5th-95th range. It
shows common occupancy and tails across full signals. The first and last bins
include underflow/overflow beyond the finite reference-bin span so total
probability is retained; their centers are display locations, not finite support
bounds. Check P001/P999/MaxAbs metrics for unseen extremes. This is probability
per bin, whereas S2 uses density for one realization. A histogram contains no
ordering information.

**C4 — Welch PSD ensemble.** Same window, overlap, NFFT and record length for
reference and model. Each record is demeaned; frequency zero is excluded on
log axes. The pointwise generated 5th-95th range is conditional on the fitted
numbers. It is neither a parameter interval nor a simultaneous spectral band.
A reference near the low edge everywhere may indicate excessive generated
fluctuation power, but one reference record can sit low by chance. Low-frequency
mismatch points toward timing/persistence/drift; a broad excess suggests total
variance or pulse energy/rate. A constant mean difference alone cannot explain
this mean-removed plot. Do not use arbitrary gain scaling to hide the cause.

**C5 — AC amplitude FFT.** One measured and one generated record, demeaned and
periodically Hann-windowed with coherent-gain normalization and a one-sided
amplitude convention. The exact spectrum will vary between stochastic runs.
Spectral lines can suggest periodic structure absent from memoryless gaps;
wide spectral content also follows from sharp finite pulses. FFT appearance
alone does not identify the physical source.

**C6 — full-signal ACF.** Biased autocorrelation normalized at zero lag, with each
record's mean removed. This checks timing-dependent behavior omitted by the
histogram, including pulse duration, repetition and clustering. Low variance can
make normalized correlation ill-defined; undefined values stay NaN, not zero.
Agreement does not establish higher-order temporal dependence.

### Figure D: event statistics and what the simple model may miss

The SAME detector and fitted thresholds process measured and generated signals.
Only complete detected events contribute to peak/width/area CDFs; censored gaps
are excluded individually. Generated CDFs pool events across runs, so records
with more events contribute more observations. They are not confidence bounds.

**D1 — signed peak CDF.** Tests sign balance and event magnitude distribution.
A systematic negative-side mismatch may expose an inadequate negative magnitude law or event labeling.
A few extreme events give weak tail evidence; compare event counts too.

**D2 — duration CDF.** This is a particularly important limitation check: generated
NOMINAL pulse width is FIXED WITHIN EACH SIGN CLASS. Redetected widths can still vary due to background
noise, threshold trimming or fragmentation, but the model cannot reproduce a
broad intrinsic within-sign width distribution by construction. A visible mismatch may be
acceptable only if the intended system outputs are insensitive to it.

**D3 — preceding quiet-gap CDF.** Checks the memoryless geometric gap assumption.
A narrow observed range suggests more regular timing; a strong long tail or
bursts can require a different gap distribution. We match the mean, not the
entire empirical gap distribution. Detector gaps and nominal generated gaps can
differ when weak events are missed or noise adds labels.

**D4 — event-start-interval CDF.** Includes the preceding pulse duration plus
quiet gap. Agreement asks whether recurrence time is adequate, not merely mean
rate. Unlike a periodic square wave, generated intervals are random.

**D5 — signed pulse-area CDF.** Integrates excursion ABOVE the fitted quiet
baseline. Pulse area affects velocity error. Rectangle versus triangle changes
area at the same peak/width. Closely matching D1 but missing D5 means amplitude
agreement is not enough for accumulation. Detector boundary trimming can matter.

**D6 — gap versus absolute peak.** The simple generator makes gap and amplitude
independent. A clear measured relationship will not be reproduced deliberately.
Scatter clouds need not align pointwise. Inspect trends, range, and the number
of measured events before claiming either dependence or independence.

Also check signed event COUNTS/RATES in ValidationSummary.csv. Similar event CDFs
do not guarantee the correct number of events. Five allowed fit events are far
from enough to establish rare negative-event or tail statistics.

### Figure E: does keeping pulses matter to integrated error?

All integrations use full-rate samples, zero initial errors, acceleration held
constant over each sample interval, and SI outputs:

```text
v_next = v + a*dt
p_next = p + v*dt + 0.5*a*dt^2
```

**E1 — velocity histories.** Compares reference, pulse-model ensemble, a constant
equal to the FULL fit-data mean, and white Gaussian noise matched to the full
fit mean/std. Pulse-model shading gives its pointwise 5th-95th range; the Gaussian
comparison uses a blue mean and dashed percentile curves. A constant mean can
match a total velocity increment over the same fitting record but loses
realization variability and local excursions.

**E2 — position histories.** Early acceleration contributes to position over
more remaining time, so equal total pulse area or equal mean need not give equal
position error. Compare mean trend, spread and extremes over the relevant
horizon, not only the final average. These are open-loop diagnostics, not your
complete estimator/controller.

**E3/E4 — whole-record terminal CDFs.** Each generated record gives one endpoint;
its ensemble makes a CDF. The reference gives ONE endpoint at that horizon and
is shown as a dashed vertical marker. The constant comparison is another marker.
A marker inside a generated range is not a formal statistical acceptance test.
Unlike S5/S6, these use the whole reference duration, without window resets.

Integration display curves store up to maxIntegrationPlotPoints boundaries,
including the final boundary. Calculations, maxima and terminal statistics use
ALL full-rate samples. Only plotted integration histories are thinned, never
the data fed to the generator, spectra, event statistics or integration itself.
The full ensemble of raw histories is not stored: one full generated example,
ensemble statistics, pooled event data and compact integration histories are
retained. This keeps memory lower for large imported records.

### H and optional F

H contains observed readout histograms for configured visualization axes,
independent of which sensor axes are modeled. It is not a goodness-of-fit panel.
Unmodeled raw axes can look nonzero in H while their generated model components
are exactly zero. F compares measured and generated selected-axis correlation
and the measured quiet correlation against independence. Coupling in the real
sensor is a limitation of independently generated selected axes.

### Figure G: new signed-density and spectral-power diagnosis

All six tiles stay within the same maximum tile count:

| Tile | Shows | Why it matters |
|---|---|---|
| G1 | Positive detected peak-magnitude CDF | Check the positive law separately |
| G2 | Absolute negative detected peak-magnitude CDF | Expose a negative-side mismatch hidden in the full signed CDF |
| G3 | Signed complete-event rates, measured versus generated | Check pulses per second rather than appearance alone |
| G4 | Signed detected event occupancy | Check time spent in each event sign, which influences histogram bins |
| G5 | 10*log10(model mean PSD / measured PSD) | Zero dB is agreement; 20 dB is 100x power, not an amplitude factor |
| G6 | Time-domain variance alongside integrated Welch power | Separate a total-energy discrepancy from a spectral-shape discrepancy |

G3/G4 bars show ensemble means with vertical pointwise 5th/95th intervals.
G4 includes detected segments touching record boundaries, classified by their
largest absolute signed excursion. D's complete-event CDFs exclude boundary
segments. NegativeSampleFractionBelowZero is also in ValidationSummary; it
includes ordinary background values below zero and is not the same as negative
PULSE occupancy. If events are biphasic, classifying a segment by one dominant
peak is only a summary of that event.

G6 integrates the FULL one-sided Welch array using frequency spacing times the
sum of its bins, including the unplotted DC/Nyquist bins. Records were demeaned
before Welch. Finite window/segment weighting means this need not equal
unweighted time variance exactly. PowerSummary records both values and their
ratios for reference and model. These estimates should still be broadly
consistent for a stationary representative record. A constant offset alone is
removed by the AC PSD; it cannot explain a broad PSD mismatch there.

A many-orders mismatch in G5 across most frequencies is not dismissed merely
because S/E endpoint CDFs agree. Integration can suppress high-frequency
fluctuations. Check total variance and units first; if power is similar but
G5 has structured differences, inspect width, pulse shape, gap timing, ACF and
quiet temporal dependence. Different fixed positive/negative widths can reduce
some artificial spectral notches but do not reproduce all real width variation.
No algorithm here promises a PSD match without examining the actual dataset.

## 7. How this responds to the reported real-data problems

The hardware observations below came from your description; the raw record
and actual diagnostic figures have not been numerically inspected here.

- Excess negative bins: separate negative magnitude and width replace the old
  shared-sign law. Complete-output bounds include the background. G2/G4 and
  negative event rates show whether the problem actually improved.
- Spike density: rate-based gap fitting targets observable onsets, while separate
  widths target occupied time. DensitySummary distinguishes nominal schedule
  rates from redetected rates; they are not automatically identical.
- Histogram: pulse LEVEL projection and optional sample weighting aim at occupied
  amplitude distribution rather than noisy maxima alone. The lognormal family
  and ideal shape may still be too restrictive for a multimodal class.
- Extreme amplitudes: BoundsSummary must show zero generated violations. It
  records reference values outside FIT bounds if held-out mode is used.
- PSD: G5/G6 and PowerSummary expose scale versus shape differences. Fitting signed
  levels/widths may improve power but is not a spectral optimizer.
- Endpoint CDFs: retained exactly as complementary checks, not a substitute for
  amplitude/timing/PSD evidence at other horizons or through a full controller.

The previous A/B explanations remain applicable with their updated conditional
normal reference: red-on-black A2 labels the same measurements, A1 can visually
compress the background, B4 round clouds suggest weak adjacent dependence, and
quiet ACF oscillations need assessment rather than automatic dismissal.

## 8. Saved outputs and the meaning of fit-review flags

The main script still uses your existing workspace input, one selectable sensor
axis by default, original-row timing, all-XYZ visualization as configured, the
same reference modes, and six tiles maximum per figure. No defaults file or
C++ exporter was introduced. Helpers live in +imubounded; keep its leading plus.

Saved tables:

- Coefficients.csv: 12 runtime scalars plus metadata and nominal rate/occupancy.
- DetectionSummary.csv: fit sample/event counts and detector thresholds.
- ValidationSummary.csv: amplitude, signed rate/occupancy, full-signal
  moments, integrated errors and generated ensemble ranges.
- SpectralSummary.csv: PSD log-ratio RMSE, full ACF RMSE and amplitude-bin distance.
- DensitySummary.csv: measured, generated and nominal signed rates/occupancies.
- PowerSummary.csv: variance, integrated Welch power and comparison ratios.
- BoundsSummary.csv: fit limits, reference/generated extremes and violation counts.
- FitReview.csv: signed class counts, shape sign conflicts, projected amplitudes
  above cap, gap lower-limit activation, optimizer exits, and target/nominal onset rate.
- TerminalWindows.csv: matched-window CDF horizon/counts/endpoint quantiles.

Analysis.mat saves `results` and `BoundedModel`. The model holds scalar
parameters, selected-axis metadata and detector settings; it has no recorded
waveform catalog. Full fit/reference arrays and diagnostic event summaries stay
in results for review, not in the C++ runtime parameters. Provenance.json records
config, reference mode, source rows and synthetic flag. PNG/FIG saving and optional
history CSVs work as before. Only one full generated realization is retained;
ensemble metrics/spectra and compact integration histories reduce memory use.

A nonpositive active fit exit, substantial shape conflicts, many cap-corrected
projections, very few sign-class events or incompatible rate/width flags need
inspection. These are not automatic release qualifications. Numeric agreement
flags in ValidationSummary remain descriptive conditional-ensemble checks.
Do not tune detection merely until plots agree; first ensure it labels the
behavior you actually intend to model.

## 9. Verification and primary references

See VALIDATION.md and evidence/Bounded_Validation.json. MATLAB tests are supplied
but were not executed here. The numerical reference and the exact manual C++
excerpt are executed on clearly synthetic cases, including asymmetric signs,
unequal durations, hard bounds and pulse occupancy.

The primary definitions behind the model are:

- MathWorks, [truncate](https://www.mathworks.com/help/stats/prob.normaldistribution.truncate.html):
  conditional distributions with zero support outside the truncation interval.
  This package uses its own rejection/likelihood calculations, not the toolbox object.
- NIST, [Lognormal Distribution](https://www.itl.nist.gov/div898/handbook/eda/section3/eda3669.htm):
  log-domain parameters. Our laws are additionally upper-truncated and constrained.
- MathWorks, [Geometric Distribution](https://www.mathworks.com/help/stats/geometric-distribution.html):
  its documented failures count starts at zero; our positive quiet count is one
  plus that value and has mean 1/p.
- MathWorks, [pwelch](https://www.mathworks.com/help/signal/ref/pwelch.html) and
  [Spectral Analysis](https://www.mathworks.com/help/signal/ug/spectral-analysis.html):
  PSD scaling, frequency-domain power, and correlation relationships. Generated
  percentile ranges are not analytical Welch confidence intervals.
- MathWorks, [periodogram](https://www.mathworks.com/help/signal/ref/periodogram.html):
  theoretical PSD integration/variance identity. Finite Welch estimates and
  nonstationary data do not make sample equality exact.
- NIST, [Median Absolute Deviation](https://www.itl.nist.gov/div898/software/dataplot/refman2/auxillar/mad.htm)
  and [Autocorrelation Plot](https://www.itl.nist.gov/div898/handbook/eda/section3/autocopl.htm):
  robust-scale and time-dependence diagnostics. Formal confidence bounds are not
  asserted for the masked quiet estimator.
- MathWorks, [Validating Models After Estimation](https://www.mathworks.com/help/ident/ug/validating-models-after-estimation.html):
  estimation versus validation data. Full-record mode is explicitly in-sample.

No reference establishes that this particular sensor must follow the selected
shape, duration, gap or magnitude law. The new version is a bounded empirical
approximation to your available record. Your colored-noise papers would become
relevant if quiet ACF/PSD requires background memory; this revision retains
white quiet proposals and does not add an AR model or a filter order.
