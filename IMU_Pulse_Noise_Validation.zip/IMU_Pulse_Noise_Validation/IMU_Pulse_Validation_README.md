# MATLAB pulse-plus-background model

Run `IMU_Pulse_Noise_Validation.m` as-is for its synthetic example. It requires
MATLAB R2021b and Signal Processing Toolbox for Welch PSD estimation. The
script contains its own helper functions and percentile calculations.

For your test data:

1. Run `IMU_Acceleration_Bias_Template.m` (included) using your instantaneous
   ft/s^2 columns, known baseline, selected interval, and frame matrix. It creates
   `Results_sensor` in micro-g without removing the measured overall mean.
2. Set `useDemo=false` in the new validation script. Keep both low and high states.
   Use a contiguous, uniformly sampled interval; do not compress excluded gaps.
3. Inspect the detector figure first. Red portions are detected event clusters;
   dashed lines are the positive/negative detection thresholds. Adjust
   `detectSigma`, `releaseSigma`, or `manualThreshold_ug` if the detector misses
   real pulses or treats ordinary noise as a pulse.
4. Inspect the validation figures and `ValidationSummary`, `SpectralSummary`,
   `EventTransitionComparison`. Increase `nRealizations` after checking the fit.

The default `fitFraction=1` compares with the same data used for identification.
This is an in-sample fit check, not independent evidence of prediction accuracy.
Use e.g. `.7` to identify on the prefix and compare with the remaining suffix,
provided both intervals represent the same operating regime and contain enough
events. No numerical data can be recovered from the supplied sketches.

## Model

- Identify a quiet baseline and full 3x3 quiet covariance; generate new correlated
  Gaussian white background samples. Quiet histogram and masked ACF plots check
  this assumption. Off-zero ACF structure or non-Gaussian quiet tails indicate
  that a different residual-noise model may be needed.
- Extract complete **joint XYZ event templates**, retaining shape, sign, peak,
  width and simultaneous effects across axes. A joint event is one continuous
  excursion until all axes return inside the release thresholds; multiple local
  maxima in one cluster are not counted as separate pulses.
- Resample each event together with its measured preceding quiet gap. Both
  record-edge pulses and left-censored initial gaps are excluded from the fit
  catalog. At least three eligible complete events and enough quiet data are
  required; substantially more data are preferable for estimating distributions.
- With `useEventMarkov=true`, choose the next event sign/dominant-axis class
  using fitted first-order transition probabilities. Classes are X+, X-, Y+, Y-,
  Z+, Z-. Smoothing toward observed class frequencies avoids traps from sparse
  transition counts. This does not reproduce higher-order event dependencies,
  slow regimes or correlations between successive quiet gaps.
- The event templates already contain event-time noise. Generated quiet noise is
  overwritten during events, avoiding double-counting it. This is a nonparametric
  recorded-shape bootstrap, not a separate fit of clean pulse shape plus noise.
  It cannot discover rare pulse shapes/amplitudes absent from the training record.

The low/high offset is retained. Means are removed only for AC PSD/ACF analysis;
histograms, generation and saved time histories retain the complete error.
Known true physical input (including gravity, if applicable) must be removed by
the processing baseline; commanded motion is not automatically a sensor error.
Flagged/clipped data model the recorded readout, not physical input beyond a rail.

## Comparisons

Figures show:

- pulse detection, and test versus one new XYZ time history;
- amplitude histograms, mean Welch PSD with 5-95% model ranges, and autocorrelation;
- single-record FFTs of the test and one generated realization;
- signed dominant peaks per joint event, event widths, quiet gaps, start intervals;
- quiet-data Gaussian fit and ACF, without concatenating separated quiet intervals;
- first-order joint-event class transition matrices, plus printed zero-lag XYZ correlations.

Positive/negative counts are per-axis threshold exceedances within each complete
joint event; a bipolar event can count as both signs. Compare rates/counts only
with identical detection rules and equal record durations. Counts vary between
runs, even when their distribution is appropriate. Waveform RMSE or raw pointwise
correlation against a randomized event sequence is not an appropriate goal.

Model percentile ranges condition on the fitted parameters and finite template
catalog. They do not include parameter uncertainty or prove the model correct.
The PSD compares the AC component; mean/std/total RMS are reported separately.
`BinnedAmplitudeTV` measures histogram discrepancy for the displayed bins and
depends on their choice; it is not an unbinned statistical test.

Workspace outputs include `PulseModel` (templates, gaps, covariance, transition
probabilities), `Generated_sensor`, `Generated_PLT`, and validation summaries.
Generated tables are full acceleration-error samples in micro-g, not constant
bias parameters. No simulator integration or C++ changes are made at this stage.

## Verification and preview

MATLAB/Octave was unavailable: the MATLAB script has been reviewed but not
executed here. The included PNG is a **synthetic Python numerical reference** of
the same modeling approach, not output fitted to your data or a MATLAB screenshot.
Numerical checks exercised signed event rates, joint templates, transition
probabilities, and covariance generation. In that example the reference record
contained 51 positive and 14 negative Y events; 60 model realizations averaged
50.97 and 14.5 events respectively. This illustrates the method, not its accuracy
on your sensor data.
