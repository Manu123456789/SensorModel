# Record-matched bounded IMU pulse model — revision 3

This revision addresses the reported sparse spike realizations, low pulse amplitudes,
and empty high-amplitude bins. It keeps a quiet-background-plus-pulses generator,
but replaces the independent geometric/lognormal draws with **counted compressed
measured pulse types**. Positive and negative events are fitted separately.

- Every complete fitted-length block has the same detected-segment count and sign
  counts as the fit record. Event order and spacing are randomized.
- The largest events of each sign have reserved types and counts in every complete
  block. They cannot disappear because a random amplitude draw missed the tail.
- Adaptive linear knots retain actual measured peak amplitudes and within-pulse
  shape, rather than estimating a rectangle's mean level. Pulse values already
  include their measured fine structure: no second Gaussian is added during pulses.
- Fresh bounded normal noise fills quiet intervals. Entire output stays within fit
  extrema. Quiet noise stays below the detector onset to prevent invented events.
- All S/H/A/B/C/D/E/F/G diagnostics remain; new R plots and tables expose **run 1**
  tail-bin occupancy, counts and compression error instead of hiding it in averages.

**Runtime coefficients have changed.** The old twelve-number/gap-probability C++
implementation does not implement this model. Copy four coefficient tables into
constants and use the updated C++ below. No MATLAB runtime, external process,
training record, file reader or C++ exporter is needed in the simulation.
The compact tables are derived from measured pulses; they are more coefficients
than twelve scalars. Their actual sizes appear in Coefficients.csv.

Requirements: MATLAB R2021b+ and Signal Processing Toolbox. MATLAB execution was
not available here. VALIDATION.md distinguishes executed independent numerical
and C++ checks from the supplied MATLAB tests. The actual hardware record was
not available for this revision; no hardware-fit improvement is claimed yet.

## 1. Run it on your test data

Put this folder on your MATLAB path or open `IMU_Config.m` and run it. All user
settings are in that ONE script. Your dataset is already in the workspace:

```matlab
cfg.workspaceVariable = 'MyImportedTimetable';
cfg.columns.X = 'My_X_Channel';
cfg.columns.Y = 'My_Y_Channel';
cfg.columns.Z = 'My_Z_Channel';
cfg.selectedAxes = {'Y'};               % Fit/generate sensor axis 2 only
cfg.histogramAxes = {'X','Y','Z'};       % Observed XYZ histograms
cfg.sampleRate_Hz = 1000;               % Actual acquisition rate
cfg.rowWindow = [1000 2000];            % INCLUSIVE ORIGINAL ROWS
cfg.baselineSensor_ms2 = [NaN 0 NaN];   % Example: Y has known zero true input
```

Supply your actual physical baseline, not the example zero if there is known
motion or gravity on that axis. The code converts the readout to acceleration,
subtracts this known true input, and models the resulting ERROR. Its quiet
error offset is estimated separately and retained. It does not subtract the
full-signal mean or remove spikes as outliers.

Run the script after editing. Main outputs in your workspace are:

```matlab
IMU_Results       % Model, reference, generated example, diagnostics, summaries
Coefficients      % Per-axis runtime metadata
PulseTypes        % Multiplicity and width of each pulse type
PulseKnots        % Zero-based sample rows and COMPLETE error values [ug]
GapQuantiles      % Compact extra-quiet-time distribution
```

The script uses your existing variable directly with MATLAB copy-on-write. No
CSV is reimported. It reads only mapped channels in the union of selectedAxes and
histogramAxes and only the requested rows. Unneeded channels need not be mapped
if they are absent from BOTH selections. Names containing spaces are supported.

### Timing is defined by row number, with no input clock lookup

Original row k corresponds to `(k - 1)/cfg.sampleRate_Hz`. The row window is
inclusive. At 1000 Hz, rows 1000:2000 produce 1001 samples from 0.999 to 1.999 s.
Most plots display elapsed time relative to the beginning of the selected window
or reference portion. Timetable acquisition metadata is ignored for the clock.
Uniform sampling is assumed; this cannot detect missed samples or acquisition
jitter from row number alone. No rows with invalid modeled samples are silently
removed, because doing so would break the assumed clock.

`rowWindow=[1 Inf]` uses the whole available record. At least 512 reconstructed
samples are required. Use a representative interval containing enough pulses.
The minimum of five detected segments only permits calculation; it is not a
statistically justified minimum for tail or rate validation.

### Input modes and cumulative records

- `instantaneous_ft_s2` (default), `instantaneous_ms2`, `instantaneous_cm_s2`,
  `instantaneous_ug`: one acceleration value per row.
- `sample_sum_cm_s2`: your channel is an UNWEIGHTED running sum of cm/s^2
  samples; a first difference recovers acceleration. No division by dt here.
- `integral_cm_s`: your channel is accumulated velocity in cm/s; first difference
  divided by dt recovers acceleration.

For cumulative modes the prior row is read for the first requested difference.
The reconstructed sample is labeled with the current original row. If the
window starts at row 1, output begins at row 2 because a prior sample is absent.
Do not select a cumulative mode merely because your simulation later integrates
acceleration. Select it only when the INPUT channel itself is cumulative.

### Optional runnable example

Set `cfg.useSyntheticExample=true` in the same main script. It creates 120 s of
XYZ data in ft/s^2 at 200 Hz, with white backgrounds, varied pulse widths and
asymmetric signed rectangle/triangle-like events. It is an independent synthetic
source, not a replay from the fitted model. It demonstrates the workflow and
does not establish hardware performance.

### One or multiple axes

Default: `cfg.selectedAxes={'Y'}`. You can select X, Z or more than one axis.
Each selected axis gets its OWN runtime tables and is generated
independently. Unselected sensor outputs are exactly zero. This simple model
does not preserve cross-axis pulse coupling or background covariance; optional
Figure F exposes that limitation. Rotate the sensor vector afterward using
`cfg.R_sensor_to_PLT`. One sensor axis can contribute to multiple platform axes.

## 2. What changed and why

### Why not simply increase GapProbability?

For the old model, p described the chance that a QUIET gap ends on the next quiet
sample; it was not the overall chance of a spike on any sample. The event rate
also depended on pulse duration. Even a correctly estimated mean rate permitted
sparse finite realizations. Increasing p by eye could conceal missed detector
labels, distort occupancy, and still fail to populate rare amplitude bins.

There is **no GapProbability in this revision**. Over one block of N fitted
samples, let E be the number of detected segments. The schedule contains exactly
E pulses, so its scheduled rate is E*Fs/N. Their signed multiplicities are fixed.
Every pulse is separated by at least one quiet sample, including both block ends.
The same detector processes reference and generated data. A1/A2 must still label
the intended spikes: undetected measured excursions will not become pulse types.

### Pulse compression and an adjustable coefficient budget

Detected events are sorted by absolute peak separately by dominant sign. The
largest protectedTailEvents (default 2) of each sign are kept individually with
count one. Any event containing a detected global minimum/maximum is also reserved, even
if its dominant sign differs. Remaining events are grouped by peak rank into
the remaining maxPulseTypesPerSign target budget (default 32 per sign). Each group retains an ACTUAL
representative event nearest the group's mean peak, width and area, with a
CountPerBlock equal to the group size. We do not average waveforms or shrink a
sharp peak into a rectangle level. A pulse's internal positive/negative structure
is retained even when its dominant sign defines its class.

Adaptive linear knots always retain first/last samples and both sample extrema.
Additional knots reduce waveform error toward knotTolerance_ug (default 1 ug),
subject to maxKnotsPerPulse (default 17). Extra knots are mandatory if needed to
preserve detector onset, sign at each sample, and continuous detection throughout
a pulse. The type target can also be exceeded when mandatory extrema consume the
budget and other events still need a representative. The knot budget is SOFT; FitReview reports budget/tolerance
limits. Integer knot rows are zero-based within each pulse. Their values are
COMPLETE sensor error values, not normalized weights or baseline-free amplitudes.
Linear interpolation between measured values does not overshoot the fitted range.

The typical number of runtime values per axis is approximately 9 axis values
(N, quiet location/scale, full, quiet and release bounds), plus two integers per type,
plus two values per knot, plus gapQuantileCount values. Fs and mapping are
additional simulation metadata. Sign and source-event labels are diagnostic
metadata, not required by the C++ generator. Inspect the actual type/knot counts;
there is no universal fixed parameter count for arbitrary waveform fidelity.

**For closer reproduction:** increase maxPulseTypesPerSign toward the number of
observed events of each sign. This reduces grouping errors in amplitude and
width. Increase maxKnotsPerPulse and lower knotTolerance_ug to retain waveform
texture. With one type per event and all its sample rows retained, pulse samples,
signed counts, occupied time and pulse-sample histogram are reproduced exactly
per complete block, while order/gaps and quiet noise change. This limit uses a
larger coefficient table. The defaults compress and can still miss individual
histogram bins. Reserved extreme peaks alone do NOT guarantee exact occupancy
of every high-amplitude bin; R1-R3, HistogramSummary and TailSummary expose that.

### Spacing and exact block length

The observed quiet gaps, including record edges, produce a short quantile table
of max(gap-1,0). Each block draws stratified values through this table, shuffles
them, and allocates the available quiet samples using cumulative randomized
rounding. The allocation sums EXACTLY to N minus the retained pulse widths.
Event order is independently shuffled. Gaps are not exponential/geometric,
independent, or memoryless: the fixed total and stratification couple them.
This preserves a spacing distribution approximately; it does not reproduce
measured temporal clustering or gap/amplitude dependence. Strong measured
clustering needs a further model change, visible in A5/C4/C6/D3/D4/D6.

Counts and protected tail representation are guaranteed only for COMPLETE
N-sample blocks, not arbitrary shorter windows or a trailing partial block.
The generator starts at a block boundary with a quiet slot, not in a stationary
random phase. It continues with fresh randomized blocks for longer simulations.
BlockSummary records the comparison horizon. A held-out suffix is often shorter
than N and therefore does not have the full-block count guarantee. A boundary
fragment in the fit record is reused as an observed segment and is explicitly
counted in FitReview; it does not reveal the missing physical pulse duration.
Choose row windows with quiet edges when possible. Complete-event CDFs omit
boundary events, so their measured counts can differ from the scheduled totals.

### Background, units, and amplitude limits

The detector's empirical quiet baseline is separate from the bounded normal's
proposal location and scale. Quiet draws are conditioned on the intersection of
the fit minimum/maximum and the interval strictly inside onset thresholds.
This prevents quiet samples from creating extra spikes. The FIRST sample of
EVERY quiet slot is drawn inside the release bounds, centered at the quiet
proposal location clamped into those release bounds. This ensures a pulse ends
where scheduled rather than extending into quiet noise. Interior quiet draws
use the onset bounds. Thus the complete-block quiet population is a mixture
of these two bounded normal laws; it is not one globally independent normal. The fitted normal is a
simple approximation to quiet samples, not exact replay of their histogram or
correlation. B1-B6 assess it. A zero fitted scale produces constant quiet error.

Pulse knots include the measured signal's small noise. No additional random
noise is added to those samples by this generator, avoiding both double noise
and inward bias from truncating a Gaussian centered near a hard pulse extreme.
Quiet intervals get fresh noise. Reused pulse texture is intentionally part of
the record-conditioned approximation; it is not new independent pulse noise.
Repeated extrema are retained waveform values, not clipping artifacts.

Full output is in micro-g and remains within FIT extrema. The quiet offset is
retained; no whole-signal mean subtraction is applied to output or integration.
Mean removal occurs only in the AC spectral/ACF diagnostics. An optional held-out
record can exceed the fit bounds; BoundsSummary reports that instead of silently
using the held-out extrema in fitting. Bounds apply to the selected SENSOR
component before rotation or addition of any other host simulation errors.

## 3. One dataset, intentional overfitting, and what the results mean

**This package is intentionally allowed to overfit your one measured record.**
Your objective is to regenerate closely similar IMU disturbances for simulation,
including the rare large positive/negative events that were actually observed.
That is a reasonable conditional scenario or stress-input objective. It is not
independent validation of a sensor population or a prediction of unseen behavior.

With fitFraction=1 (the default), the same record identifies the model and checks
its fit. Here 'fit' or 'training' means the samples used to estimate coefficients;
it does not imply a neural network. 'Reference' is the measured record shown
against generated output. 'Held out' means data excluded from fitting, enabled
by setting fitFraction below one (for example .70). A suffix of one recording
can still share operating conditions and temporal dependence with the fit part;
it is not a separate independent acquisition. The code labels each mode.

One record cannot establish the true maximum/minimum, rare-event probabilities,
long-term stationarity, environmental dependence or behavior on another device.
Treating its extrema as hard physical limits deliberately excludes unseen events
outside those limits. Repeated templates and fixed per-block counts also reduce
variability by construction. The simulation bands describe only randomized
order, spacing and quiet noise CONDITIONAL on this record and these coefficients.
They omit parameter uncertainty, missing event types and record-to-record change.
Narrow bands or excellent CDF/histogram agreement are not evidence that those
uncertainties are small. Do not interpret a match as a reliability guarantee.

In particular, fixed counts and fixed pulse areas within every full block make
whole-block terminal velocity less variable than a natural unconstrained random
pulse process; the remaining spread comes largely from quiet noise. Reordered
pulses still change position error because early pulses integrate for longer.
The imposed block horizon can affect low-frequency PSD and introduce artifacts.
Keep S/C/G/E checks, compare several horizons, and call this **record-conditioned
scenario generation** in a report. Matching terminal CDFs alone does not establish
PSD or closed-loop performance. If future measurements become available, use
them for an independent check and revise the coefficients/model as needed.

## 4. Coefficients and self-contained C++ implementation

Use these four CSV outputs for the selected axis. No runtime CSV reader is
needed: paste their numbers into constants in your existing source file.

| Table | Copy into C++ | Meaning |
|---|---|---|
| Coefficients | blockSamples,b,sigma,lo,hi,quietLo,quietHi,releaseLo,releaseHi | Block size and bounded quiet-noise law |
| PulseTypes | count,width | Multiplicity per complete block and pulse duration in samples |
| PulseKnots | row,value | Zero-based knot rows and full sensor error [ug], grouped by TypeIndex0 |
| GapQuantiles | ExtraQuietSamples | Values at equally spaced probabilities 0 through 1 |

Use Fs_Hz to call the model at the SAME sensor sample rate used in fitting.
The old positive/negative lognormal coefficients, fixed sign widths and gapP
are incompatible with this generator. Do not mix files from different runs.
Analysis.mat also contains the tables and BoundedModel; the runtime needs only
the four tables' numeric values and its RNG/state, not the measured history.

Call resetRecord once per simulation run after copying validated coefficients.
Call sampleRecord exactly once per SENSOR SAMPLE TICK. Cache the result if
other code reads the measurement more than once in that tick. Reset after any
coefficient change; do not change parameters under a live schedule. Uniform RNG
must supply fresh [0,1) values; the normal RNG must supply fresh N(0,1) values.
Your existing RNG buffers may be used, provided each callback consumes a new
appropriate value. If your existing rn_norm_limits routine limits/truncates its
normal variates, it is not automatically an N(0,1) callback; use a standard-normal
draw or deliberately revalidate the resulting noise law. C++11 is sufficient. The code uses std::vector allocation
at each block boundary; preallocate/adapt that planner if your host has hard
real-time allocation constraints. No external process is involved.

<!-- RECORD_CPP_BEGIN -->
```cpp
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <stdexcept>
#include <vector>

struct Knot { std::size_t row; double value; };
struct PulseType {
    std::size_t count, width;
    std::vector<Knot> knots;
};
struct RecordParams {
    std::size_t blockSamples;
    double b, sigma, lo, hi, quietLo, quietHi, releaseLo, releaseHi; // all acceleration in micro-g
    std::vector<PulseType> types;
    std::vector<double> gapQ; // equally spaced probabilities from 0 to 1
};
struct RecordState {
    bool initialized=false;
    std::vector<std::size_t> order, gaps;
    std::size_t event=0, pulseRow=0, gapLeft=0;
};
using Draw = double (*)();

double uniformDraw(Draw uniform01) {
    const double u=uniform01();
    if (!std::isfinite(u) || u<0 || u>=1) throw std::runtime_error("RNG must return [0,1)");
    return u;
}
template<class T>
void shuffleRecord(std::vector<T>& v, Draw uniform01) {
    for (std::size_t k=v.size(); k>1; --k) {
        const std::size_t i=static_cast<std::size_t>(uniformDraw(uniform01)*k);
        std::swap(v[k-1],v[i]);
    }
}
void validateRecord(const RecordParams& p) {
    if (p.blockSamples==0 || !std::isfinite(p.lo) || !std::isfinite(p.hi)
        || !(p.lo<p.hi) || !std::isfinite(p.b) || !std::isfinite(p.sigma)
        || p.sigma<0 || !std::isfinite(p.quietLo) || !std::isfinite(p.quietHi)
        || p.quietLo<p.lo || p.quietHi>p.hi || !(p.quietLo<p.quietHi)
        || p.b<p.quietLo || p.b>p.quietHi || !std::isfinite(p.releaseLo)
        || !std::isfinite(p.releaseHi) || p.releaseLo<p.quietLo || p.releaseHi>p.quietHi
        || !(p.releaseLo<p.releaseHi) || p.types.empty() || p.gapQ.size()<2)
        throw std::invalid_argument("Invalid record parameters");
    std::size_t active=0, events=0;
    for (const auto& t:p.types) {
        if (t.width==0 || t.count==0 || t.knots.empty()
            || t.count>(p.blockSamples-active)/t.width
            || t.count>p.blockSamples-events)
            throw std::invalid_argument("Invalid pulse count/width");
        active+=t.count*t.width; events+=t.count;
        if (t.knots.front().row!=0 || t.knots.back().row!=t.width-1)
            throw std::invalid_argument("Pulse endpoint knot missing");
        for (std::size_t k=0;k<t.knots.size();++k)
            if (!std::isfinite(t.knots[k].value) || t.knots[k].value<p.lo
                || t.knots[k].value>p.hi || t.knots[k].row>=t.width
                || (k>0 && t.knots[k].row<=t.knots[k-1].row))
                throw std::invalid_argument("Invalid pulse knots");
    }
    if (events>=p.blockSamples-active)
        throw std::invalid_argument("Need one quiet sample in every slot");
    for (std::size_t k=0;k<p.gapQ.size();++k)
        if (!std::isfinite(p.gapQ[k]) || p.gapQ[k]<0 || (k>0 && p.gapQ[k]<p.gapQ[k-1]))
            throw std::invalid_argument("Invalid gap quantiles");
}
double gapQuantile(const RecordParams& p, double u) {
    const double x=u*(p.gapQ.size()-1);
    const std::size_t a=std::min(static_cast<std::size_t>(x),p.gapQ.size()-2);
    return p.gapQ[a]+(x-a)*(p.gapQ[a+1]-p.gapQ[a]);
}
void planRecord(const RecordParams& p, RecordState& s, Draw uniform01) {
    s=RecordState{};
    std::size_t active=0;
    for (std::size_t k=0;k<p.types.size();++k) {
        s.order.insert(s.order.end(),p.types[k].count,k);
        active+=p.types[k].count*p.types[k].width;
    }
    shuffleRecord(s.order,uniform01);
    const std::size_t slots=s.order.size()+1;
    const std::size_t extra=p.blockSamples-active-slots;
    std::vector<double> weights(slots);
    double total=0;
    for (std::size_t k=0;k<slots;++k) {
        weights[k]=gapQuantile(p,(k+uniformDraw(uniform01))/slots);
        total+=weights[k];
    }
    shuffleRecord(weights,uniform01);
    if (total<=0) { std::fill(weights.begin(),weights.end(),1.0); total=double(slots); }
    const double offset=uniformDraw(uniform01);
    double cumulative=0;
    std::size_t previous=0;
    s.gaps.resize(slots);
    for (std::size_t k=0;k<slots;++k) {
        cumulative+=weights[k];
        std::size_t rounded=k+1==slots ? extra :
            static_cast<std::size_t>(std::floor(extra*(cumulative/total)+offset));
        rounded=std::max(previous,std::min(extra,rounded));
        s.gaps[k]=1+rounded-previous; previous=rounded;
    }
    s.gapLeft=s.gaps[0]; s.initialized=true;
}
double quietRecord(const RecordParams& p, bool firstInGap, Draw normal01) {
    const double lo=firstInGap ? p.releaseLo : p.quietLo;
    const double hi=firstInGap ? p.releaseHi : p.quietHi;
    const double center=std::max(lo,std::min(hi,p.b));
    if (p.sigma==0) return center;
    double x;
    do { x=center+p.sigma*normal01(); }
    while (!std::isfinite(x) || x<lo || x>hi);
    return x;
}
double pulseRecord(const PulseType& t, std::size_t row) {
    if (t.width==1) return t.knots.front().value;
    std::size_t k=1;
    while (k+1<t.knots.size() && t.knots[k].row<row) ++k;
    const auto& a=t.knots[k-1]; const auto& b=t.knots[k];
    const double u=double(row-a.row)/double(b.row-a.row);
    // Clamp to neighboring values only to suppress floating-point overshoot.
    return std::max(std::min(a.value,b.value),
        std::min(std::max(a.value,b.value),a.value+(b.value-a.value)*u));
}
void resetRecord(const RecordParams& p, RecordState& s, Draw uniform01) {
    validateRecord(p); planRecord(p,s,uniform01);
}
double sampleRecord(const RecordParams& p, RecordState& s, Draw normal01, Draw uniform01) {
    // Validate once before first use or after coefficients change.
    if (!s.initialized) planRecord(p,s,uniform01);
    if (s.gapLeft>0) {
        const bool firstInGap=s.gapLeft==s.gaps[s.event];
        --s.gapLeft;
        const double x=quietRecord(p,firstInGap,normal01);
        if (s.event==s.order.size() && s.gapLeft==0) s.initialized=false;
        return x;
    }
    const PulseType& t=p.types[s.order[s.event]];
    const double x=pulseRecord(t,s.pulseRow);
    if (++s.pulseRow==t.width) {
        s.pulseRow=0; ++s.event; s.gapLeft=s.gaps[s.event];
    }
    return x;
}
```
<!-- RECORD_CPP_END -->

Example coefficient layout below is illustrative, NOT fitted hardware numbers.
Replace it with your four tables. A width-one pulse has one knot at row zero.
Widths greater than one require sorted knots including rows zero and width-1.
CountPerBlock is an integer multiplicity, not a probability or cumulative CDF.

```cpp
RecordParams p;
p.blockSamples=1000;
p.b=0; p.sigma=1; p.lo=-40; p.hi=100;
p.quietLo=-4; p.quietHi=4; p.releaseLo=-2; p.releaseHi=2;
p.types={
    {3,3,{{0,20},{1,100},{2,20}}},
    {1,2,{{0,-40},{1,-15}}}
};
p.gapQ={0,20,70,140};
RecordState state;
resetRecord(p,state,freshUniform01);
// Once per sensor sample tick:
const double error_ug=sampleRecord(p,state,freshN01,freshUniform01);
const double error_ms2=error_ug*9.80665e-6;
```

At 1000 Hz this example contains exactly four pulses per complete one-second
block, including three positive 100-ug peaks and one negative -40-ug peak.
Shorter excerpts need not contain all four. Changing Fs without refitting changes
pulse durations and spectral behavior because the widths/gaps are sample counts.

For sensor axis 2, construct sensorError=[0,error_ms2,0], then rotate into the
platform frame using your established sensor-to-platform matrix convention.
If your host expects ft/s^2, divide error_ms2 by .3048. If it expects a delta
velocity contribution, multiply acceleration by dt; if it expects instantaneous
acceleration, use it directly. Do not blindly reuse the old gyro template's
current-minus-previous operation for this acceleration error. Add/replace at the
host measurement's correct units and stage. The model includes quiet offset and
pulse noise texture; remove the old modeled error contribution on that axis if
you are replacing it, to avoid double counting. Other intentional physical errors
remain a separate host modeling decision. Sensor-axis bounds do not guarantee
bounds after rotation or after other errors are added.

The MATLAB and C++ algorithms implement the same construction. RNG algorithms,
seeds and draw order can differ, so numerical sample-by-sample identity between
the two environments is not promised. MATLAB fills a block's quiet values before
overwriting pulses; C++ draws quiet noise as required. A fixed seed is repeatable
within an unchanged implementation with the same RNG and call sequence.

## 5. Diagnostic figures: same families, at most six tiles

For one modeled axis the package opens S, G, H, A, B, C, D and E. H can show all
three observed axes even when only one is modeled. Optional F checks independence
when more than one axis is modeled. Figures save as PNG and editable FIG.
Units on selected-model plots are ERROR micro-g after known-input subtraction;
H shows observed acceleration in ft/s^2. Do not compare their offsets without
accounting for that distinction.

### Figure S: six-panel presentation summary

| Tile | What it shows | What agreement means / what to inspect |
|---|---|---|
| S1 | Full measured/reference and generated-run-1 histories on common axes | Compare signs, typical heights, event density and offset; independent event times need not align |
| S2 | Amplitude density for the reference and generated run 1 on identical finite bins | Compare central width, offset and tails; density times bin width integrates to one |
| S3 | Contiguous quiet close-ups from each record | See the background without spike-dominated vertical scaling |
| S4 | Mean-removed Welch PSD: reference and generated ensemble mean | Compare distribution of fluctuation power over frequency |
| S5 | Terminal velocity-error CDFs for equal-duration windows | Compare integrated acceleration area and run-to-run variation at this horizon |
| S6 | Terminal position-error CDFs for those windows | Compare consequences of amplitude and timing together |

S2 deliberately uses one generated realization for exact common-range density;
C3 provides the ensemble probability range. Histogram shape depends on bin width:
a narrow central peak plus a tail supports a different behavior population but
does not by itself show pulse timing or prove a physical fault.

S3 chooses the longest DETECTED quiet run separately from the reference and
generated run 1. It compares the beginning of each over a common duration capped
by quietZoom_s (default 0.5 s). It never concatenates disconnected samples or
clips spikes to manufacture a noise floor. Each segment has its own elapsed zero.
Their absolute positions in S1 differ. The dotted line is the fitted quiet mean.
This selected visual example can be affected by classification and segment
choice; B is the fuller assumption check. If either run lacks two contiguous
quiet samples, the panel explains that it is unavailable.

S4 removes each record's mean only for the spectrum. This does not remove mean
from generated output or integration. Mean generated PSD is the arithmetic mean
in LINEAR power, not a mean in dB. A consistently low measured PSD can mean that
the model produces too much fluctuation power in that reference interval;
compare Std_ug and event rates before changing coefficients.

S5/S6 split the reference and EACH generated record into nonoverlapping windows
of summaryTerminalWindow_s, rounded to whole samples and capped to the record.
Each window starts with zero velocity/position error. Incomplete trailing windows
are omitted. An empirical CDF at x gives the fraction of endpoints <=x. The
legend reports window counts. A single measured window is a vertical endpoint
marker, not a measured distribution. Neighboring windows can remain dependent;
pooled generated windows share fixed coefficients. These are descriptive CDFs,
NOT independent-trial confidence intervals or mission-horizon predictions.
Shorter windows give more endpoints at a shorter horizon; longer windows give
fewer examples of longer-horizon effects. Do not stitch reset windows together
as one physical trajectory. TerminalWindows.csv records the actual horizon,
counts, omitted samples and 5th/50th/95th percentiles.

### Figure A: input and detection, not a generated-data comparison

**A1 — measured signal and red events.** Gray is the entire measured error;
red redraws detected event samples. Small background noise can look flat when
large spikes set the vertical scale. It has not been removed. The split line
appears only if an actual held-out suffix is enabled. Check that red identifies
your intended events; otherwise later comparisons are based on poor labels.

**A2 — threshold zoom.** Black and red SHOULD overlap: they are the same
measurement with event labels, not test and model traces. Blue onset and green
release levels show hysteresis. Near-continuous red can indicate overly sensitive
thresholds or an unsuitable baseline/model family; missing excursions suggest
thresholds that are too high. Zoom duration is configurable.

**A3 — measured portion histograms.** With fitFraction=1, compare first versus
second half of the measured record. With a held-out split, compare fit versus
held-out. These curves compare measurement against measurement, not generation.
Agreement supports similar amplitude occupancy across portions, but not timing
or stationarity of every relevant property. Log probability displays tails;
zero-count bins are not visible on the log axis.

**A4 — block mean.** Means of nonoverlapping blocks reveal offset/regime changes.
Preferentially positive pulses can raise block means without quiet bias drift.
Check A5 alongside A4 to distinguish possible changes in event activity from a
change in background level.

**A5 — block event-start rate.** Counts starts per block divided by actual block
duration. Large differences can arise from finite counts or nonstationary
activity. Regular bursts/clusters matter because the generated gaps are shuffled and block-conditioned. Boundary blocks may include events whose starts/ends cross blocks.

**A6 — original row and elapsed time.** A straight line verifies the constructed
mapping under the configured acquisition rate. It is not measured timing-jitter
or missing-sample detection. Source rows retain original indices after selection.

### Figure B: WHITE background checks (changed from the old Gauss-Markov suite)

**B1 — quiet amplitude histogram / bounded-mixture PDF.** Fit quiet samples are
shown after subtracting the detector quiet mean. The target is the complete-block quiet mixture of the interior bounded normal
and the release-conditioned first sample of each quiet slot, translated by that
same detector mean. The mixture weight is (events+1)/quiet samples. Its proposal location
and scale can differ from observed quiet mean/std when a bound is near the
population. Center, spread and tails all matter; symmetry alone is insufficient.
Zero fitted scale is explicitly labeled as a degenerate background.

**B2 — conditional-mixture Q-Q.** Quantiles come from the complete-block quiet mixture,
not an unbounded Gaussian reference. Near-diagonal agreement supports that
marginal model; curvature, skew or multiple populations indicate a limitation.
It is not a formal normality or significance test.

**B3 — quiet fit ACF and WHITE target.** The interior white-noise target equals one at lag zero and zero at every
nonzero lag. Release-conditioned boundary samples mean the generator is not
strictly identically distributed at every quiet position; use B6 for the actual
simulation comparison. Original sample positions are preserved across pulse
gaps. Each lag averages only valid quiet pairs and is hidden if fewer than 30
pairs are available. Quiet samples are centered on their own quiet mean for ACF
only. A substantial smooth decay, oscillation or other repeatable structure
indicates that the white assumption misses time dependence. Small wiggles can
be finite-record variation; there are no formal significance bounds here.

**B4 — adjacent quiet samples.** Uses consecutive original samples that are both
quiet, with equal axis scaling and a display subset if needed. A round cloud
suggests weak lag-one correlation; a diagonal ellipse suggests persistence.
One round cloud does not establish independence at other lags or normality.
Compare B3/B6 before deciding white noise is adequate.

**B5 — standardized quiet residuals.** Plots `(quiet - proposalLocation) /
proposalScale` with the corresponding standardized bounded-mixture target. Near
bounds this is not an ordinary N(0,1) distribution, and it is not a Gauss-Markov
innovation. A zero scale is labeled unavailable. Check B3/B6 for time dependence;
a matching marginal histogram cannot establish whiteness.

**B6 — reference versus generated quiet ACF.** Compares reference quiet time
structure with the ensemble of redetected generated quiet portions. A meaningful
nonzero reference correlation absent from the white model is an unresolved
limitation. Pointwise ranges come from generated runs, not confidence limits for
the masked measured estimator. Reference quiet means are removed separately for
this ACF, so check amplitude plots for a baseline mismatch.

### Figure C: amplitude, spectrum and full-signal correlation

**C1/C2 — straight output histories.** Reference and generated run 1 use the
same vertical quantity but separate axes. Offsets, excursions and background
remain. Similar appearance is useful but cannot establish quantitative agreement.
Independent generated spike timestamps need not match measured timestamps.

**C3 — amplitude probability ensemble.** Black is the measured reference, red
the mean generated bin probability, shading the pointwise 5th-95th range. It
shows common occupancy and tails across full signals. The first and last bins
include underflow/overflow beyond the finite reference-bin span so total
probability is retained; their centers are display locations, not finite support
bounds. Check P001/P999/MaxAbs metrics for unseen extremes. This is probability
per bin, whereas S2 uses density for one realization. A histogram contains no
ordering information.

**C4 — Welch PSD ensemble.** Same window, overlap, NFFT and record length for
reference and model. Each record is demeaned; frequency zero is excluded on
log axes. The pointwise generated 5th-95th range is conditional on the fitted
numbers. It is neither a parameter interval nor a simultaneous spectral band.
A reference near the low edge everywhere may indicate excessive generated
fluctuation power, but one reference record can sit low by chance. Low-frequency
mismatch points toward timing/persistence/drift; a broad excess suggests total
variance or pulse energy/rate. A constant mean difference alone cannot explain
this mean-removed plot. Do not use arbitrary gain scaling to hide the cause.

**C5 — AC amplitude FFT.** One measured and one generated record, demeaned and
periodically Hann-windowed with coherent-gain normalization and a one-sided
amplitude convention. The exact spectrum will vary between stochastic runs.
Spectral lines can suggest periodic structure absent from shuffled block-conditioned gaps;
wide spectral content also follows from sharp finite pulses. FFT appearance
alone does not identify the physical source.

**C6 — full-signal ACF.** Biased autocorrelation normalized at zero lag, with each
record's mean removed. This checks timing-dependent behavior omitted by the
histogram, including pulse duration, repetition and clustering. Low variance can
make normalized correlation ill-defined; undefined values stay NaN, not zero.
Agreement does not establish higher-order temporal dependence.

### Figure D: event statistics and what the simple model may miss

The SAME detector and fitted thresholds process measured and generated signals.
Only complete detected events contribute to peak/width/area CDFs; censored gaps
are excluded individually. Generated CDFs pool events across runs, so records
with more events contribute more observations. They are not confidence bounds.

**D1 — signed peak CDF.** Tests sign balance and event magnitude distribution.
A systematic negative-side mismatch may expose an inadequate negative magnitude law or event labeling.
A few extreme events give weak tail evidence; compare event counts too.

**D2 — duration CDF.** Types retain their representative measured event widths.
Grouping several widths into one type can change occupied time and duration
histograms; increase maxPulseTypesPerSign to reduce that approximation.

**D3 — preceding quiet-gap CDF.** Compares measured gaps with the shuffled
quantile-based allocation constrained to a fixed block total. This approximation
can differ from measured clustering or a detailed multimodal gap distribution.

**D4 — event-start-interval CDF.** Includes the preceding pulse duration plus
quiet gap. Agreement asks whether recurrence time is adequate, not merely mean
rate. Unlike a periodic square wave, generated intervals are random.

**D5 — signed pulse-area CDF.** Integrates excursion ABOVE the fitted quiet
baseline. Pulse area affects velocity error. Rectangle versus triangle changes
area at the same peak/width. Closely matching D1 but missing D5 means amplitude
agreement is not enough for accumulation. Detector boundary trimming can matter.

**D6 — gap versus absolute peak.** The generator shuffles gaps and pulse types separately; the fixed block
budget still induces dependence across events. A clear measured relationship will not be reproduced deliberately.
Scatter clouds need not align pointwise. Inspect trends, range, and the number
of measured events before claiming either dependence or independence.

Also check signed event COUNTS/RATES in ValidationSummary.csv. Similar event CDFs
do not guarantee the correct number of events. Five allowed fit events are far
from enough to establish rare negative-event or tail statistics.

### Figure E: does keeping pulses matter to integrated error?

All integrations use full-rate samples, zero initial errors, acceleration held
constant over each sample interval, and SI outputs:

```text
v_next = v + a*dt
p_next = p + v*dt + 0.5*a*dt^2
```

**E1 — velocity histories.** Compares reference, pulse-model ensemble, a constant
equal to the FULL fit-data mean, and white Gaussian noise matched to the full
fit mean/std. Pulse-model shading gives its pointwise 5th-95th range; the Gaussian
comparison uses a blue mean and dashed percentile curves. A constant mean can
match a total velocity increment over the same fitting record but loses
realization variability and local excursions.

**E2 — position histories.** Early acceleration contributes to position over
more remaining time, so equal total pulse area or equal mean need not give equal
position error. Compare mean trend, spread and extremes over the relevant
horizon, not only the final average. These are open-loop diagnostics, not your
complete estimator/controller.

**E3/E4 — whole-record terminal CDFs.** Each generated record gives one endpoint;
its ensemble makes a CDF. The reference gives ONE endpoint at that horizon and
is shown as a dashed vertical marker. The constant comparison is another marker.
A marker inside a generated range is not a formal statistical acceptance test.
Unlike S5/S6, these use the whole reference duration, without window resets.

Integration display curves store up to maxIntegrationPlotPoints boundaries,
including the final boundary. Calculations, maxima and terminal statistics use
ALL full-rate samples. Only plotted integration histories are thinned, never
the data fed to the generator, spectra, event statistics or integration itself.
The full ensemble of raw histories is not stored: one full generated example,
ensemble statistics, pooled event data and compact integration histories are
retained. This keeps memory lower for large imported records.

### H and optional F

H contains observed readout histograms for configured visualization axes,
independent of which sensor axes are modeled. It is not a goodness-of-fit panel.
Unmodeled raw axes can look nonzero in H while their generated model components
are exactly zero. F compares measured and generated selected-axis correlation
and the measured quiet correlation against independence. Coupling in the real
sensor is a limitation of independently generated selected axes.

### Figure G: new signed-density and spectral-power diagnosis

All six tiles stay within the same maximum tile count:

| Tile | Shows | Why it matters |
|---|---|---|
| G1 | Positive detected peak-magnitude CDF | Check the positive law separately |
| G2 | Absolute negative detected peak-magnitude CDF | Expose a negative-side mismatch hidden in the full signed CDF |
| G3 | Signed complete-event rates, measured versus generated | Check pulses per second rather than appearance alone |
| G4 | Signed detected event occupancy | Check time spent in each event sign, which influences histogram bins |
| G5 | 10*log10(model mean PSD / measured PSD) | Zero dB is agreement; 20 dB is 100x power, not an amplitude factor |
| G6 | Time-domain variance alongside integrated Welch power | Separate a total-energy discrepancy from a spectral-shape discrepancy |

G3/G4 bars show ensemble means with vertical pointwise 5th/95th intervals.
G4 includes detected segments touching record boundaries, classified by their
largest absolute signed excursion. D's complete-event CDFs exclude boundary
segments. NegativeSampleFractionBelowZero is also in ValidationSummary; it
includes ordinary background values below zero and is not the same as negative
PULSE occupancy. If events are biphasic, classifying a segment by one dominant
peak is only a summary of that event.

G6 integrates the FULL one-sided Welch array using frequency spacing times the
sum of its bins, including the unplotted DC/Nyquist bins. Records were demeaned
before Welch. Finite window/segment weighting means this need not equal
unweighted time variance exactly. PowerSummary records both values and their
ratios for reference and model. These estimates should still be broadly
consistent for a stationary representative record. A constant offset alone is
removed by the AC PSD; it cannot explain a broad PSD mismatch there.

A many-orders mismatch in G5 across most frequencies is not dismissed merely
because S/E endpoint CDFs agree. Integration can suppress high-frequency
fluctuations. Check total variance and units first; if power is similar but
G5 has structured differences, inspect width, pulse shape, gap timing, ACF and
quiet temporal dependence. Retained measured shapes and multiple widths help preserve pulse energy and
spectral texture, while compression and shuffled order can still change PSD.
No algorithm here promises a PSD match without examining the actual dataset.

### Figure R: first-realization reproduction checks (new)

R1 shows measured and generated run-1 sample counts per amplitude bin on a log
scale. R2 shows their signed difference on a LINEAR scale, so zero representation
is explicit even when log plots hide it. R3 compares counts above P90/P99 of the
positive/negative FIT EVENT-SAMPLE magnitudes. These are thresholds of pulse
samples, not event-peak probabilities. R4 compares signed complete-event counts
for one realization. R5 shows retained type widths/peaks, with point size related
to multiplicity. R6 zooms the amplitude histogram around quiet/onset levels.
All figures contain at most six data axes. R has no new automatic acceptance rule.

## 6. Outputs, fit review and what to adjust

All existing outputs are retained with updated coefficient semantics:

- Coefficients.csv, PulseTypes.csv, PulseKnots.csv, GapQuantiles.csv: the runtime data.
- DetectionSummary.csv: complete reference events and onset/release settings.
- FitReview.csv: all fitted signed segments, censored edge segments, retained types,
  knots, pulse-sample compression TV, maximum waveform error, knot-budget flags,
  measured/scheduled signed occupancy and background likelihood optimizer exit.
- HistogramSummary.csv: every bin's measured, run-1 and ensemble-mean sample counts,
  including a flag for a run-1 empty bin that had measured samples.
- TailSummary.csv: measured/run-1 high-excursion sample counts for both signs.
- BlockSummary.csv: fitted horizon, comparison length, complete/trailing blocks,
  scheduled counts and detected run-1 segments. Full-block guarantees apply to
  complete blocks even when a trailing partial block is also present.
- DensitySummary.csv and ValidationSummary.csv: measured and generated signed
  counts/rates/occupancy, means/spreads/extremes and integration metrics.
- SpectralSummary.csv and PowerSummary.csv: amplitude TV, ACF error, PSD log-ratio
  RMSE and variance/integrated Welch consistency. No gain is tuned to mask a mismatch.
- BoundsSummary.csv: fit/reference/generated extrema and violations.
- TerminalWindows.csv: reset-window integration CDF horizons/counts/quantiles.

Analysis.mat stores results and BoundedModel; Provenance.json records source rows,
config, reference mode and synthetic flag. PNG/FIG and optional history CSVs work
as before. One full generated realization is retained; ensemble metrics and
compact integration histories reduce memory. The source dataset remains in
results for analysis only, not in the C++ runtime constants.

Start with A1/A2 to verify labels. Missing intended spikes require reviewing a
physically sensible onset threshold (manualThreshold_ug), not inflating a random
probability. Next check BlockSummary and R4 for horizon/counts. If counts match
but R1/R3 or FitReview disagree, increase the pulse-type budget for peak/width
population matching, then the knot budget for within-pulse detail. Lowering knot
error alone cannot repair a poor representative type. If G5/G6 still disagree,
inspect temporal clustering, quiet correlation, shapes, units and power. Even a
nearly exact amplitude histogram cannot guarantee the correct PSD. Endpoint CDF
agreement remains a complementary check, not a reason to disregard that mismatch.

## 7. Commentary from your dataset review

You reported too few visible spikes, low generated pulse amplitudes, and empty
high-amplitude bins in a single realization. Earlier versions fitted a mean event
rate and an amplitude family but did not reserve finite-record tail events. Their
pulse-level projection could also understate a sharp measured peak. This revision
changes those mechanisms explicitly rather than only increasing a probability.

Your preference is to reproduce this one observed behavior consistently, even
with intentional overfitting, so the default fits and compares against the entire
selected measured record. This is conditional scenario construction. It does not
turn one recording into a representative population, and the limits described
in section 3 must accompany any claims based on it. The model remains a compact
coefficient-driven C++ generator; higher fidelity requires more retained types
and knots. That cost is visible rather than hidden in a training-record dependency.

The earlier plot explanations still apply: A2 red-on-black labels the same input;
background may be visually compressed in A1 but is shown in S3/B; a round B4 cloud
suggests weak adjacent correlation; symmetry in B1/B5 alone does not validate time
structure; small quiet ACF oscillations need context; C3 and D agreement are useful
but do not establish PSD or integrated behavior at every horizon. The hardware
record/figures were described by you and were not numerically examined here.

## 8. Verification and primary references

See VALIDATION.md and evidence/RecordMatch_Validation.json for the checks actually
executed. Run tests/Test_IMU_Bounded.m in MATLAB for the supplied integration checks.
The independent Python checks and the actual README C++ excerpt use synthetic data;
they establish implementation behavior, not a fit to your unavailable hardware data.

- MathWorks [interp1](https://www.mathworks.com/help/matlab/ref/double.interp1.html):
  piecewise linear sample interpolation.
- MathWorks [rng](https://www.mathworks.com/help/matlab/ref/rng.html): reproducible
  pseudorandom streams within a specified implementation and call sequence.
- MathWorks [pwelch](https://www.mathworks.com/help/signal/ref/pwelch.html) and
  [Spectral Analysis](https://www.mathworks.com/help/signal/ug/spectral-analysis.html):
  Welch power-density estimates and spectral interpretation.
- MathWorks [truncate](https://www.mathworks.com/help/stats/prob.normaldistribution.truncate.html):
  conditional-distribution support; this package implements bounded normal draws
  directly rather than requiring Statistics Toolbox objects.
