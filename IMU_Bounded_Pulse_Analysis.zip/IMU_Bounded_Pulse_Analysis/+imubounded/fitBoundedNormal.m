function [mu,sigma,exitflag]=fitBoundedNormal(x,lo,hi)
% Conditional normal MLE. Center stays within bounds; sigma <= range.
avg=mean(x); variance=var(x,1); range=hi-lo;
if variance==0, mu=avg; sigma=0; exitflag=1; return; end
floorSigma=max(realmin,range*1e-10);
start=[avg log(max(sqrt(variance),floorSigma*2))];
options=optimset('Display','off','MaxIter',400,'TolX',1e-8,'TolFun',1e-8);
[theta,~,exitflag]=fminsearch(@cost,start,options);
mu=max(lo,min(hi,theta(1))); sigma=min(range,max(floorSigma,exp(theta(2))));
    function value=cost(t)
        s=exp(t(2)); center=t(1);
        if ~isfinite(s) || ~isfinite(center) || center<lo || center>hi || s<floorSigma || s>range
            value=1e100; return;
        end
        a=(lo-center)/s; b=(hi-center)/s; Z=.5*erfc(-b/sqrt(2))-.5*erfc(-a/sqrt(2));
        value=numel(x)*(log(s)+.5*(variance+(avg-center)^2)/s^2+log(max(Z,realmin)));
    end
end
