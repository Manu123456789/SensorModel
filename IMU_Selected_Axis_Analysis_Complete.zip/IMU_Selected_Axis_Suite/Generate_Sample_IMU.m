function [SampleIMU,Truth,settings]=Generate_Sample_IMU(settings)
% Synthetic, gravity-compensated accelerometer readout in ft/s^2.
% Settings are illustrative, NOT fitted to your instrument.
if nargin==0, settings=struct; end
defaults=struct('Fs',200,'duration_s',120,'seed',42, ...
    'quietBias_ug',[3 -5 2],'quietSigma_ug',[5 7 4], ...
    'medianPeak_ug',350,'negativeProbability',.22, ...
    'minimumGap_s',.25,'medianExtraGap_s',.65, ...
    'gapLogSigma',.45,'widthRange_s',[.025 .15]);
names=fieldnames(defaults);
for k=1:numel(names)
    if ~isfield(settings,names{k}), settings.(names{k})=defaults.(names{k}); end
end
validateattributes(settings.Fs,{'numeric'},{'scalar','real','finite','positive'});
validateattributes(settings.duration_s,{'numeric'},{'scalar','real','finite','>=',10});
validateattributes(settings.seed,{'numeric'},{'scalar','integer','>=',0,'<=',2^32-1});
validateattributes(settings.quietBias_ug,{'numeric'},{'size',[1 3],'real','finite'});
validateattributes(settings.quietSigma_ug,{'numeric'},{'size',[1 3],'real','finite','positive'});
validateattributes(settings.medianPeak_ug,{'numeric'},{'scalar','real','finite','positive'});
validateattributes(settings.negativeProbability,{'numeric'},{'scalar','>=',0,'<=',1});
validateattributes(settings.minimumGap_s,{'numeric'},{'scalar','real','finite','nonnegative'});
validateattributes(settings.medianExtraGap_s,{'numeric'},{'scalar','real','finite','positive'});
validateattributes(settings.gapLogSigma,{'numeric'},{'scalar','real','finite','nonnegative'});
assert(isequal(size(settings.widthRange_s),[1 2]) && ...
    all(isfinite(settings.widthRange_s)) && settings.widthRange_s(1)>0 && ...
    settings.widthRange_s(2)>=settings.widthRange_s(1));
stream=RandStream('mt19937ar','Seed',settings.seed);
fs=settings.Fs; n=round(fs*settings.duration_s); t=(0:n-1)'/fs;
% Unit-diagonal correlation matrix: modest quiet cross-axis coupling.
C=[1 .20 .05;.20 1 -.10;.05 -.10 1];
factor=diag(settings.quietSigma_ug)*chol(C,'lower');
error_ug=randn(stream,n,3)*factor'+settings.quietBias_ug;
pulse_ug=zeros(n,3); eventID=zeros(n,1); logRows=zeros(0,8);
cursor=1; id=0;
while cursor<n
    gap=max(1,round(fs*(settings.minimumGap_s+settings.medianExtraGap_s* ...
        exp(settings.gapLogSigma*randn(stream,1,1)))));
    first=cursor+gap;
    width=max(3,round(fs*(settings.widthRange_s(1)+diff(settings.widthRange_s)*rand(stream,1,1))));
    last=first+width-1; if last>=n, break; end
    u=linspace(0,1,width)'; shapeID=1+floor(3*rand(stream,1,1));
    switch shapeID
        case 1, shape=exp(-5*u); % sharp onset, decaying tail
        case 2, shape=1-abs(2*u-1); % triangular event
        case 3 % short high plateau with sharp ramps
            shape=min(1,min(8*u,8*(1-u)));
    end
    % Y usually dominates; some independent X/Z events broaden the example.
    q=rand(stream,1,1);
    if q<.7, axis=2; direction=[.18 1 -.12];
    elseif q<.85, axis=1; direction=[1 .12 .08];
    else, axis=3; direction=[-.10 .15 1]; end
    peak=settings.medianPeak_ug*exp(.4*randn(stream,1,1));
    if rand(stream,1,1)<settings.negativeProbability, peak=-.55*peak; end
    id=id+1; pulse_ug(first:last,:)=peak*shape*direction;
    eventID(first:last)=id;
    logRows(id,:)=[id t(first) t(last) gap/fs width/fs axis peak shapeID];
    cursor=last+1;
end
error_ug=error_ug+pulse_ug;
acceleration_ft_s2=error_ug*(1e-6*9.80665/.3048);
SampleIMU=table(t,acceleration_ft_s2(:,1),acceleration_ft_s2(:,2), ...
    acceleration_ft_s2(:,3),'VariableNames',{'Time','ColumnX','ColumnY','ColumnZ'});
Truth=struct('Time_s',t,'Error_ug',error_ug,'Pulse_ug',pulse_ug, ...
    'EventID',eventID,'QuietCovariance_ug2',factor*factor', ...
    'KnownBaseline_ms2',[0 0 0],'Settings',settings);
Truth.Events=array2table(logRows,'VariableNames',{'EventID','Start_s','End_s', ...
    'PrecedingGap_s','Duration_s','DominantAxis','SignedScale_ug','ShapeID'});
end
