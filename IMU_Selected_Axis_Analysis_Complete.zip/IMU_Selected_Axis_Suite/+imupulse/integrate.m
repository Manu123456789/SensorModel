function [v,p,time]=integrate(x,fs)
% Piecewise-constant acceleration over n intervals, zero initial error.
% Input ug. Output m/s, m, and n+1 boundary times including initial zero.
a=x*(1e-6*9.80665); dt=1/fs;
v=[zeros(1,size(x,2));cumsum(a,1)*dt];
p=[zeros(1,size(x,2));cumsum(v(1:end-1,:)*dt+.5*a*dt^2,1)];
time=(0:size(x,1))'/fs;
end
