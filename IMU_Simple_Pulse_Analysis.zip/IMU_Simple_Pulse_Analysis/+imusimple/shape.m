function w=shape(kind,L)
% Peak-normalized discrete shape; no stored measured waveform.
if strcmp(kind,'rectangle'), w=ones(L,1);
else, w=min((1:L)',(L:-1:1)')/ceil(L/2); end
end
