function CPP_Comparison=Check_CPP_Output(cfg)
% After generating a C++ trace: CPP_Comparison=Check_CPP_Output(cfg)
suiteRoot=fileparts(mfilename('fullpath')); addpath(suiteRoot);
outputFolder=cfg.outputFolder;
loaded=load(fullfile(outputFolder,'Analysis.mat'),'results');
trace=readtable(fullfile(outputFolder,'CPP_Trace.csv'));
CPP_Comparison=imupulse.compareCpp(loaded.results,trace);
writetable(CPP_Comparison,fullfile(outputFolder,'CPP_Comparison.csv'));
disp(CPP_Comparison);
end
