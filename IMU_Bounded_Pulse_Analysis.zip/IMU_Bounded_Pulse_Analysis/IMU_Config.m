%% MAIN CONFIG: edit here, then run. Existing workspace table/timetable only.
suiteRoot=fileparts(mfilename('fullpath')); addpath(suiteRoot); cfg=struct;

%% Input, sensor mapping, and ROW window (inclusive original rows)
cfg.workspaceVariable='YourIMUTimetable';
cfg.columns=struct('X','Your_X_Column','Y','Your_Y_Column','Z','Your_Z_Column');
cfg.selectedAxes={'Y'};                 % Model one axis; optional {'X','Y','Z'}
cfg.histogramAxes={'X','Y','Z'};         % Display only; independent of model axes
cfg.sampleRate_Hz=1000;                 % EDIT actual acquisition rate
cfg.rowWindow=[1 Inf];                 % e.g. [1000 2000]; NOT seconds
cfg.inputMode='instantaneous_ft_s2';
% Also: instantaneous_ms2, instantaneous_cm_s2, instantaneous_ug,
% sample_sum_cm_s2 (unweighted sum), integral_cm_s (cumulative velocity).
cfg.baselineSensor_ms2=[NaN NaN NaN];    % Known TRUE input on modeled axes, e.g. [NaN 0 NaN]
cfg.R_sensor_to_PLT=eye(3);             % platform_column = R * sensor_column

%% Record matching: bounded quiet noise + compressed measured pulse types
cfg.maxPulseTypesPerSign=32;            % Raise toward observed event count for closer matching
cfg.protectedTailEvents=2;              % Keep largest events per sign as individual types
cfg.maxKnotsPerPulse=17;                % Soft budget; topology/extrema are mandatory
cfg.knotTolerance_ug=1;                 % Adaptive waveform approximation tolerance
cfg.gapQuantileCount=17;                % Compact spacing distribution, NOT geometric p
cfg.compressionTVWarning=.05;           % Review trigger; pulse-only binned TV, not acceptance
cfg.fitFraction=1.0;                    % 1: fit/check same record; .70: reserve last 30%
cfg.detectSigma=5; cfg.releaseSigma=2;
cfg.manualThreshold_ug=[NaN NaN NaN];   % Optional onset thresholds per sensor axis
cfg.minEvents=5;                       % Minimum to run; not an acceptance threshold
cfg.nRealizations=50; cfg.seed=1234;

%% Same diagnostic families, maximum SIX tiles per figure
cfg.histogramBins=60; cfg.zoom_s=5; cfg.quietZoom_s=.5;
cfg.maxLag_s=2; cfg.quietMaxLag_s=.25; cfg.welchWindow_s=2; cfg.block_s=10;
cfg.summaryTerminalWindow_s=5;          % Equal reset windows for summary CDFs
cfg.maxIntegrationPlotPoints=4000;      % Display storage only; integrate ALL samples
cfg.makePlots=true; cfg.figureVisible='on'; cfg.saveFigures=true;
cfg.saveResults=true; cfg.writeHistoryCSVs=false;
cfg.outputFolder=fullfile(suiteRoot,'output_recordmatched_hardware');

%% Optional reproducible synthetic example (no import required)
cfg.useSyntheticExample=false;         % Set true to try the complete workflow
cfg.demoSampleRate_Hz=200; cfg.demoDuration_s=120;

%% RUN (no edits below)
cfg.isSynthetic=cfg.useSyntheticExample;
if cfg.useSyntheticExample
    [IMU_InputData,IMU_ExampleTruth]=Generate_Example_IMU(cfg.demoSampleRate_Hz,cfg.demoDuration_s);
    cfg.sampleRate_Hz=cfg.demoSampleRate_Hz;
    cfg.columns=struct('X','Example_X','Y','Example_Y','Z','Example_Z');
    cfg.baselineSensor_ms2=[0 0 0]; cfg.outputFolder=fullfile(suiteRoot,'output_recordmatched_example');
else
    assert(isvarname(cfg.workspaceVariable),'Use one workspace variable name.');
    assert(exist(cfg.workspaceVariable,'var')==1,['Missing workspace input: ' cfg.workspaceVariable]);
    IMU_InputData=eval(cfg.workspaceVariable); % Copy-on-write; no file reimport
end
IMU_Results=imubounded.analyze(IMU_InputData,cfg);
Coefficients=IMU_Results.Coefficients;    % Axis metadata; use PulseTypes and PulseKnots too
PulseTypes=IMU_Results.PulseTypes; PulseKnots=IMU_Results.PulseKnots; GapQuantiles=IMU_Results.GapQuantiles;
if cfg.saveResults, imubounded.saveOutputs(IMU_Results,cfg.outputFolder); end
