"""Independent numerical checks of the new diagnostic estimators.

This executes Python, not MATLAB. MATLAB tests exercise the actual package.
"""
import json
from pathlib import Path

import numpy as np
from scipy import signal
from scipy.integrate import cumulative_trapezoid, trapezoid

ROOT = Path(__file__).resolve().parents[1]


def biased_covariance(x, lag):
    y = x - np.mean(x)
    c = signal.correlate(y, y, mode="full", method="fft") / len(y)
    return c[len(y) - 1:len(y) + lag]


def overlapping_allan_second_difference(x, factors):
    theta = np.cumsum(x - np.mean(x))
    n = len(x)
    result = []
    for m in factors:
        delta = theta[2*m:] - 2*theta[m:n-m] + theta[:n-2*m]
        result.append(np.dot(delta, delta) / (2*m*m*(n-2*m)))
    return np.array(result)


def main():
    rng = np.random.default_rng(61)
    n = 2048
    t = np.arange(n)
    signals = np.array([np.sin(2*np.pi*3*t/n), 8*np.cos(2*np.pi*9*t/n)])
    covariance = np.array([biased_covariance(x, 128) for x in signals])
    mean_covariance = covariance.mean(axis=0)
    rho = mean_covariance / mean_covariance[0]
    # Independent calculation from explicit pair products with biased /N divisor.
    expected = []
    for lag in range(129):
        values = [np.dot(x[:n-lag], x[lag:])/n for x in signals]
        expected.append(np.mean(values)/np.mean(signals**2))
    acf_error = float(np.max(np.abs(rho-expected)))
    assert acf_error < 1e-12
    separately_normalized = (covariance/covariance[:, :1]).mean(axis=0)
    difference = float(np.max(np.abs(rho-separately_normalized)))
    assert difference > .1

    x = 1.7 + rng.normal(size=4096)
    factors = np.array([1, 2, 7, 31, 300])
    avar = overlapping_allan_second_difference(x, factors)
    direct = []
    # Explicit adjacent block means use N-2m overlapping pairs, matching the
    # MathWorks inertial-sensor example and package's documented convention.
    for m in factors:
        differences = [x[i+m:i+2*m].mean()-x[i:i+m].mean()
                       for i in range(1, len(x)-2*m+1)]
        direct.append(np.mean(np.square(differences))/2)
    allan_error = float(np.max(np.abs(avar-direct)))
    assert allan_error < 1e-12
    assert np.max(np.abs(avar-overlapping_allan_second_difference(x+200, factors))) < 1e-12
    # Averaging Allan variances is a power operation: unequal-scale runs must
    # yield sqrt(mean(variance)), which differs from mean(deviation).
    ensemble = np.array([avar, 9*avar])
    adev = np.sqrt(ensemble.mean(axis=0))
    assert np.max(np.abs(adev-np.sqrt(5)*np.sqrt(avar))) < 1e-12
    assert np.max(np.abs(adev-np.sqrt(ensemble).mean(axis=0))) > .01

    psds = []
    for series in signals:
        frequency, power = signal.welch(series-series.mean(), fs=200, nperseg=256)
        psds.append(power)
    psds = np.array(psds)
    cumulative_mean = cumulative_trapezoid(psds.mean(axis=0), frequency, initial=0)
    individual = cumulative_trapezoid(psds, frequency, axis=1, initial=0)
    psd_error = float(np.max(np.abs(cumulative_mean-individual.mean(axis=0))))
    assert psd_error < 1e-12
    assert abs(cumulative_mean[-1]-trapezoid(psds.mean(axis=0), frequency)) < 1e-12
    assert np.all(np.diff(cumulative_mean) >= 0)

    report = {
        "scope": "Python estimator reference; not MATLAB execution",
        "ensemble_covariance_first_acf_max_error": acf_error,
        "difference_from_average_normalized_acf": difference,
        "overlapping_allan_vs_explicit_blocks_max_error": allan_error,
        "allan_constant_offset_invariance": "PASS",
        "allan_variance_averaged_before_sqrt": "PASS",
        "linear_psd_cumulative_ensemble_max_error_ug2": psd_error,
        "cumulative_endpoint_equals_integrated_psd": "PASS",
    }
    (ROOT/"evidence/Statistics_Validation.json").write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
