function [tail,histogramTable,blocks]=matchSummaries(r)
names={'X','Y','Z'}; t={}; h={}; b={}; m=r.model; n=size(r.reference,1);
for j=find(m.selectedMask)
    ref=r.reference(:,j); first=r.exampleGenerated(:,j);
    for s=1:2
        signValue=3-2*s; source=signValue*(r.train(:,j)-m.baseline(j));
        eventSamples=source(~r.fitInfo.quietMask(:,j) & source>0);
        if isempty(eventSamples), continue; end
        for q=[90 99]
            threshold=imubounded.percentile(eventSamples,q);
            observed=nnz(signValue*(ref-m.baseline(j))>=threshold);
            one=nnz(signValue*(first-m.baseline(j))>=threshold);
            labels={'Positive','Negative'};
            t(end+1,:)={names{j},labels{s},q,threshold,observed,one,one-observed}; %#ok<AGROW>
        end
    end
    one=histcounts(first,r.histEdges{j})';
    expected=r.histReference(:,j)*n;
    meanCount=mean(r.histogram(:,j,:),3)*n;
    for k=1:numel(one)
        h(end+1,:)={names{j},k,r.histCenters{j}(k),expected(k),one(k),meanCount(k), ...
            expected(k)>0&&one(k)==0}; %#ok<AGROW>
    end
    sourceCount=sum(r.fitInfo.signCounts(j,:)); oneStats=imubounded.detect(r.exampleGenerated,m);
    b(end+1,:)={names{j},m.blockSamples,n,floor(n/m.blockSamples),mod(n,m.blockSamples),sourceCount, ...
        numel(oneStats.start{j}),n==m.blockSamples,sourceCount*m.Fs/m.blockSamples}; %#ok<AGROW>
end
tail=cell2table(t,'VariableNames',{'Axis','Sign','FitPulseSamplePercentile','ExcursionThreshold_ug', ...
    'ReferenceSamples','Run1Samples','Run1MinusReference'});
histogramTable=cell2table(h,'VariableNames',{'Axis','Bin','Center_ug','ReferenceCount','Run1Count','ModelMeanCount','Run1EmptyObservedBin'});
blocks=cell2table(b,'VariableNames',{'Axis','FittedBlockSamples','ReferenceSamples','CompleteGeneratedBlocks', ...
    'PartialBlockSamples','ScheduledEventsPerBlock','Run1DetectedSegments','ExactlyOneCompleteBlock','ScheduledRate_Hz'});
end
