%% Synthetic example / identification checks. These are NOT your fitted parameters.
clear; rng(21);
t=(0:0.01:29.99)';
y=[randn(size(t)), ...
    1000*double(mod(t-0.3,2)<0.4)+2*randn(size(t)), ...
    -500+400*double(mod(t-0.7,3)<1)+2*randn(size(t))];
options=struct('MakePlots',true, ...
    'OutputDirectory',fullfile(fileparts(mfilename('fullpath')),'demo_output'));
[model,summary,details]=identify_imu_switch_model(t,y,options);
assert(~model(1).switching,'Quiet Gaussian axis must not be forced into two states.');
assert(model(2).switching && model(3).switching);
assert(abs(model(2).low_ug)<2 && abs(model(2).high_ug-1000)<2);
assert(abs(summary.NominalFrequency_Hz(2)-0.5)<0.02);
assert(abs(summary.NominalDuty(2)-0.2)<0.02);
assert(abs(model(3).low_ug+500)<2 && abs(model(3).high_ug+100)<2);
assert(summary.PlateauResidualRMS_ug(2)<5);
disp(summary);
% Removed rows / gaps must not silently become long fitted dwells.
badTime=t; badTime(1000:end)=badTime(1000:end)+1;
rejected=false;
try
    identify_imu_switch_model(badTime,y,struct('MakePlots',false));
catch
    rejected=true;
end
assert(rejected,'A gap in the data must be rejected.');
% Confirm first/last runs are marked censored (not exported as full dwell times).
runs=details.Runs{2}; assert(~runs.Complete(1) && ~runs.Complete(end));
fprintf('Synthetic identification checks passed. Demo exports are in demo_output.\n');
