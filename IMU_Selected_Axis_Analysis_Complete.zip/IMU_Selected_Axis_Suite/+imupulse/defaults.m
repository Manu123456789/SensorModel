function c=defaults()
% Algorithm defaults. Edit IMU_Config.m for your table and acquisition settings.
c.selectedAxes={'Y'};
c.columns=struct('X','ColumnX','Y','ColumnY','Z','ColumnZ');
c.sampleRate_Hz=NaN;                 % REQUIRED when timeColumn is empty
c.startTime_s=0;                     % Timestamp assigned to ORIGINAL table row 1
c.timeColumn='';                     % Empty: derive time from rows and sample rate
c.inputMode='instantaneous_ft_s2';
% Also: instantaneous_cm_s2, instantaneous_ms2, instantaneous_ug,
% sample_sum_cm_s2 (unweighted cumulative sum), integral_cm_s (velocity).
c.window_s=[-Inf Inf]; c.baselineSensor_ms2=[0 0 0];
c.R_sensor_to_PLT=eye(3);
c.railLimitsInput=[-Inf Inf;-Inf Inf;-Inf Inf]; c.allowRailSamples=false;
c.sampleIntervalTolerance=1e-4; % relative jitter check for actual timestamps only
c.fitFraction=.70; c.nRealizations=50; c.seed=1234;
c.detectSigma=5; c.releaseSigma=2; c.manualThreshold_ug=[NaN NaN NaN];
c.useEventMarkov=false; c.markovPrior=1;
c.maxLag_s=2; c.quietMaxLag_s=.25; c.welchWindow_s=2;
c.histogramBins=60; c.block_s=10; c.zoom_s=5;
c.makePlots=true; c.saveFigures=true; c.figureVisible='on';
c.isSynthetic=true; % Real-data template explicitly changes this to false
end
