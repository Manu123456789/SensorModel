%% Run AFTER generating CPP_Trace.csv with cpp/Check_Exported_Model.cpp.
suiteRoot=fileparts(mfilename('fullpath')); addpath(suiteRoot);
outputFolder=fullfile(suiteRoot,'output'); % EDIT output_hardware for your test
loaded=load(fullfile(outputFolder,'Analysis.mat'),'results');
trace=readtable(fullfile(outputFolder,'CPP_Trace.csv'));
CPP_Comparison=imupulse.compareCpp(loaded.results,trace);
writetable(CPP_Comparison,fullfile(outputFolder,'CPP_Comparison.csv'));
disp(CPP_Comparison);
