#include <cassert>
#include <iostream>
#include <random>
#include <vector>
#include <limits>
#ifndef IMU_MODEL_FILE
#define IMU_MODEL_FILE "../IMU_Axis_Integration_Template.cpp"
#endif
#include IMU_MODEL_FILE

struct Draws {
    unsigned calls=0;
    double value=1;
    std::mt19937 rng;
    std::normal_distribution<double> gaussian;
    explicit Draws(unsigned seed=1):rng(seed),gaussian(0,1) {}
};
static double constant_normal(void* p) { Draws& d=*static_cast<Draws*>(p); ++d.calls; return d.value; }
static double gaussian_normal(void* p) { Draws& d=*static_cast<Draws*>(p); ++d.calls; return d.gaussian(d.rng); }
static bool near(double x,double y,double tol=1e-12) { return std::abs(x-y)<tol; }
static ImuAxisParameters one_event()
{
    static const double pulse[]={10,20};
    static const std::size_t offset[]={0}, length[]={2}, gap[]={2};
    static const unsigned sign[]={0};
    ImuAxisParameters p={true,1,100,3,2,.5,1,2,pulse,offset,length,gap,sign,
                        {1,0},{{1,0},{1,0}},false,0};
    return p;
}
int main()
{
    ImuAxisParameters p=one_event(); ImuAxisState s; ImuAxisSample out; Draws d;
    assert(imu_axis_validate(p));
    assert(imu_axis_reset(p,s,42,constant_normal,&d));
    assert(d.calls==1 && near(s.quiet_ug,2));
    assert(imu_axis_sample(p,s,0,constant_normal,&d,out));
    assert(near(out.excursion_ug,1+std::sqrt(3.0)) && !out.is_pulse);
    assert(near(out.quiet_baseline_ug,3));
    const double first=out.excursion_ug; const unsigned used=d.calls;
    assert(imu_axis_sample(p,s,0,constant_normal,&d,out));
    assert(d.calls==used && near(first,out.excursion_ug));
    assert(!imu_axis_sample(p,s,2,constant_normal,&d,out) && d.calls==used); // skipped tick
    assert(imu_axis_sample(p,s,1,constant_normal,&d,out) && !out.is_pulse);
    const double latent=s.quiet_ug;
    assert(imu_axis_sample(p,s,2,constant_normal,&d,out) && out.is_pulse);
    assert(out.excursion_ug==10 && near(s.quiet_ug,.5*latent+std::sqrt(3.0)));
    assert(imu_axis_sample(p,s,3,constant_normal,&d,out) && out.excursion_ug==20);
    assert(imu_axis_sample(p,s,4,constant_normal,&d,out) && !out.is_pulse);
    assert(!imu_axis_sample(p,s,3,constant_normal,&d,out));
    p.burn_in_samples=3; assert(imu_axis_reset(p,s,42,constant_normal,&d));
    assert(imu_axis_sample(p,s,0,constant_normal,&d,out) && out.excursion_ug==20); // burn preserves phase

    ImuAxisParameters bad=p; bad.phi=1; assert(!imu_axis_validate(bad));
    bad=p; bad.sensor_axis=3; assert(!imu_axis_validate(bad));
    bad=p; bad.quiet_sigma_ug=-1; assert(!imu_axis_validate(bad));
    bad=p; bad.sign_probability[0]=.9; assert(!imu_axis_validate(bad));
    assert(!imu_axis_reset(p,s,42,nullptr,&d));
    p.burn_in_samples=0; d.value=std::numeric_limits<double>::quiet_NaN();
    assert(!imu_axis_reset(p,s,42,constant_normal,&d)); d.value=1;

    // Known stationary variance and lag-one correlation, no event in this interval.
    static const std::size_t long_gap[]={1000000}; p=one_event(); p.phi=.9; p.gap=long_gap;
    Draws stats(123); assert(imu_axis_reset(p,s,77,gaussian_normal,&stats));
    const int N=300000; double sum=0,sq=0,cross=0,previous=0;
    for (int k=0;k<N;++k) {
        assert(imu_axis_sample(p,s,static_cast<std::uint64_t>(k),gaussian_normal,&stats,out));
        assert(!out.is_pulse); const double x=out.excursion_ug;
        sum+=x; sq+=x*x; if(k) cross+=x*previous; previous=x;
    }
    const double mean=sum/N, variance=sq/N-mean*mean;
    const double rho=(cross/(N-1)-mean*mean)/variance;
    assert(std::abs(mean)<.07 && std::abs(variance-4)<.12 && std::abs(rho-.9)<.006);

    // Deterministic sign transitions: positive event then negative, then positive.
    static const double signed_pulses[]={12,-8};
    static const std::size_t offsets[]={0,1}, lengths[]={1,1}, gaps[]={0,0};
    static const unsigned signs[]={0,1};
    ImuAxisParameters alternating={true,1,100,0,0,0,2,2,signed_pulses,offsets,lengths,gaps,signs,
                                  {1,0},{{0,1},{1,0}},true,0};
    d.value=0; assert(imu_axis_reset(alternating,s,9,constant_normal,&d));
    for (int k=0;k<20;++k) {
        assert(imu_axis_sample(alternating,s,static_cast<std::uint64_t>(k),constant_normal,&d,out));
        assert(out.is_pulse && out.excursion_ug==(k%2 ? -8 : 12));
    }

    // Exercise the actual IMU_error adapter with exported-layout fixture constants.
    assert(imu_axis_parameters.fitted);
    imu_input=ImuHostInputs(); d.value=0;
    imu_input.normal_draw=constant_normal; imu_input.normal_context=&d;
    imu_input.sensor_dt_s=1/imu_axis_parameters.Fs;
    imu_input.other_noise_ft_s2[0]=.25; imu_input.other_bias_ft_s2[2]=-.125;
    IMU_error(); assert(imu_output.status==ImuPortStatus::Ok);
    assert(imu_output.model_only_sensor_ug[0]==0 && imu_output.model_only_sensor_ug[2]==0);
    const double y=imu_output.model_only_sensor_ug[1];
    const double scale=9.80665e-6/.3048;
    assert(near(imu_output.acceleration_error_ft_s2[0],.25));
    assert(near(imu_output.acceleration_error_ft_s2[1],y*scale));
    assert(near(imu_output.acceleration_error_ft_s2[2],-.125));
    assert(near(imu_output.delta_velocity_error_ft_s[1],y*scale/imu_axis_parameters.Fs));
    const unsigned cached_calls=d.calls; IMU_error(); assert(d.calls==cached_calls);

    // R maps sensor Y to platform -X; nonselected sensor errors stay zero.
    imu_input.R_sensor_to_platform[0][0]=0; imu_input.R_sensor_to_platform[0][1]=-1;
    imu_input.R_sensor_to_platform[1][0]=1; imu_input.R_sensor_to_platform[1][1]=0;
    IMU_error(); assert(imu_output.status==ImuPortStatus::Ok);
    assert(near(imu_output.model_only_platform_ft_s2[0],-y*scale));
    assert(imu_output.model_only_platform_ft_s2[1]==0 && imu_output.model_only_platform_ft_s2[2]==0);
    imu_input.include_quiet_baseline=false; IMU_error();
    assert(near(imu_output.model_only_sensor_ug[1],y-imu_axis_parameters.quiet_baseline_ug));
    imu_input.sensor_dt_s*=2; IMU_error(); assert(imu_output.status==ImuPortStatus::BadDt);
    std::cout<<"PASS: scheduling, Gaussian hook, GM variance/correlation, pulse replacement, cache, reset, sign transitions, axes, rotation, units.\n";
    std::cout<<"quiet variance="<<variance<<", lag1="<<rho<<"\n";
}
