function s=eventStats(x,m)
% Complete joint event records. NaN on an axis means that axis did not trigger.
e=imupulse.detect(x,m); valid=e.start>1 & e.stop<size(x,1);
a=e.start(valid); b=e.stop(valid); count=numel(a);
s=struct('start',a,'stop',b,'mask',e.mask,'width_s',(b-a+1)/m.Fs, ...
    'gap_s',NaN(count,1),'interval_s',NaN(count,1), ...
    'peak_ug',NaN(count,3),'area_ug_s',NaN(count,3));
for k=1:count
    z=x(a(k):b(k),:)-m.baseline;
    for j=find(m.selectedMask)
        [~,index]=max(abs(z(:,j))); peak=z(index,j);
        if abs(peak)>=m.threshold(j)
            s.peak_ug(k,j)=peak; s.area_ug_s(k,j)=sum(z(:,j))/m.Fs;
        end
    end
    previous=find(e.mask(1:a(k)-1),1,'last');
    if ~isempty(previous), s.gap_s(k)=(a(k)-previous-1)/m.Fs; end
    if k>1, s.interval_s(k)=(a(k)-a(k-1))/m.Fs; end
end
end
