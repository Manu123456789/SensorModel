function figs=plotSweep(r)
figs=gobjects(0); if isempty(r.ToneSweep), return; end
names={'X','Y','Z'}; m=r.model;
for j=find(m.selectedMask)
    S=r.ToneSweep(strcmp(string(r.ToneSweep.Axis),names{j}),:);
    f=figure('Name',['R_' names{j} '_Tone_Count_Sweep'],'NumberTitle','off', ...
        'Visible',r.cfg.figureVisible,'Position',[50 50 1500 850]); figs(end+1)=f; %#ok<AGROW>
    t=tiledlayout(f,2,3,'TileSpacing','compact','Padding','compact'); x=S.Tones;
    ax=nexttile(t); plot(ax,x,S.FitRMSE_ug,'o-'); title(ax,'R1: aligned fit RMSE'); ylabel(ax,'RMSE [ug]'); finish(ax);
    ax=nexttile(t); plot(ax,x,S.FitMaxError_ug,'o-'); title(ax,'R2: maximum point error'); ylabel(ax,'Max |error| [ug]'); finish(ax);
    ax=nexttile(t); plot(ax,x,[S.ReconstructedMin_ug S.ReconstructedMax_ug],'o-');
    yline(ax,m.lower(j),'k:'); yline(ax,m.upper(j),'k:'); title(ax,'R3: extrema; dotted = measured limits'); ylabel(ax,'Error [ug]'); finish(ax);
    ax=nexttile(t); plot(ax,x,S.PSD_RMSE_dB,'o-'); title(ax,'R4: Welch PSD error'); ylabel(ax,'Log-ratio RMSE [dB]'); finish(ax);
    ax=nexttile(t); plot(ax,x,S.AmplitudeTV,'o-'); title(ax,'R5: amplitude-bin difference'); ylabel(ax,'Total variation'); finish(ax);
    ax=nexttile(t); plot(ax,x,[S.PositiveEvents S.NegativeEvents],'o-');
    ref=r.fitInfo.events{j}; yline(ax,nnz(ref.peak_ug>0),'k:'); yline(ax,nnz(ref.peak_ug<0),'k:');
    legend(ax,'Positive','Negative'); title(ax,'R6: complete detected event counts'); ylabel(ax,'Events'); finish(ax);
    title(t,'FIT-record aligned sweep; no added white noise, no independent validation claim');
end
end
function finish(ax)
xlabel(ax,'Number of tones K'); grid(ax,'on');
end
