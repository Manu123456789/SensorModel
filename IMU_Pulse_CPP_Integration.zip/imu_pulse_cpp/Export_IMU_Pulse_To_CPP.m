function outputPath=Export_IMU_Pulse_To_CPP(PulseModel,outputPath)
% Export the PulseModel from IMU_Pulse_Noise_Validation.m to ONE complete .cpp.
% Example:
%   useDemo=false; run IMU_Pulse_Noise_Validation
%   Export_IMU_Pulse_To_CPP(PulseModel,'IMU_Pulse_Integration.cpp');
% Keep IMU_Pulse_Integration_Template.cpp beside this exporter.
% Confirm that your PulseModel is fitted to your real sensor data, not the demo.
if nargin<2, outputPath='IMU_Pulse_Integration.cpp'; end
fields={'Fs','baseline','noiseFactor','templates','gapSamples','classes', ...
    'classFrequency','transitionProbability','useEventMarkov'};
for k=1:numel(fields)
    assert(isfield(PulseModel,fields{k}),['Missing PulseModel.' fields{k}]);
end
p=PulseModel;
validateattributes(p.Fs,{'numeric'},{'scalar','real','finite','positive'});
assert(numel(p.baseline)==3 && isreal(p.baseline) && all(isfinite(p.baseline(:))));
assert(isequal(size(p.noiseFactor),[3 3]) && isreal(p.noiseFactor) && all(isfinite(p.noiseFactor(:))));
assert(iscell(p.templates) && ~isempty(p.templates),'No pulse templates.');
count=numel(p.templates); lengthSamples=zeros(count,1);
for k=1:count
    a=p.templates{k}; assert(isnumeric(a) && isreal(a) && size(a,2)==3 && ...
        size(a,1)>=1 && all(isfinite(a(:))),'Each template must be finite nonempty N-by-3.');
    lengthSamples(k)=size(a,1);
end
gap=p.gapSamples(:); classes=p.classes(:);
assert(numel(gap)==count && all(isfinite(gap)) && all(gap>=0 & gap==floor(gap)));
assert(numel(classes)==count && all(isfinite(classes)) && all(classes>=1 & classes<=6 & classes==floor(classes)));
frequency=reshape(p.classFrequency,1,[]); transition=p.transitionProbability;
assert(numel(frequency)==6 && all(isfinite(frequency)) && all(frequency>=0) && abs(sum(frequency)-1)<1e-8);
assert(isequal(size(transition),[6 6]) && all(isfinite(transition(:))) && ...
    all(transition(:)>=0) && all(abs(sum(transition,2)-1)<1e-8));
assert(isscalar(p.useEventMarkov) && (p.useEventMarkov==0 || p.useEventMarkov==1));
classCounts=accumarray(classes,1,[6 1]);
assert(all(frequency(classCounts==0)==0) && all(all(transition(:,classCounts==0)==0)), ...
    'A probability points to a class with no event templates.');
if isfield(p,'covariance')
    errorCov=norm(p.noiseFactor*p.noiseFactor'-p.covariance,'fro');
    assert(errorCov<=1e-8*max(1,norm(p.covariance,'fro')), ...
        'noiseFactor does not reproduce PulseModel.covariance.');
end
offset=[0;cumsum(lengthSamples(1:end-1))]; % C++ rows are ZERO-based
allSamples=vertcat(p.templates{:}); burn=10*max(gap+lengthSamples);
assert(burn<=flintmax && size(allSamples,1)<=flintmax,'Model is too large.');

lines={'// BEGIN MATLAB MODEL CONSTANTS'; ...
    '// Generated SENSOR-frame template deviations [ug], gaps [samples].'};
lines=[lines; matrixLines('imu_template_samples',allSamples)];
lines{end+1}=integerArray('std::size_t','imu_event_offset',offset);
lines{end+1}=integerArray('std::size_t','imu_event_length',lengthSamples);
lines{end+1}=integerArray('std::size_t','imu_event_gap',gap);
lines{end+1}=integerArray('unsigned','imu_event_class',classes-1);
lines{end+1}='static const ImuPulseParameters imu_pulse_parameters = {';
lines{end+1}=sprintf('    true, %.17g,',p.Fs);
lines{end+1}=['    {' realList(p.baseline) '},'];
lines{end+1}='    {';
for k=1:3, lines{end+1}=['        {' realList(p.noiseFactor(k,:)) '},']; end
lines{end+1}=sprintf('    }, %.0f, %.0f,',count,size(allSamples,1));
lines{end+1}='    imu_template_samples,imu_event_offset,imu_event_length,imu_event_gap,imu_event_class,';
lines{end+1}=['    {' realList(frequency) '},'];
lines{end+1}='    {';
for k=1:6, lines{end+1}=['        {' realList(transition(k,:)) '},']; end
if p.useEventMarkov, boolean='true'; else, boolean='false'; end
lines{end+1}=sprintf('    }, %s, %.0f',boolean,burn);
lines{end+1}='};'; lines{end+1}='// END MATLAB MODEL CONSTANTS';

templatePath=fullfile(fileparts(mfilename('fullpath')),'IMU_Pulse_Integration_Template.cpp');
assert(~strcmp(outputPath,templatePath) && ~strcmp(outputPath,'IMU_Pulse_Integration_Template.cpp'), ...
    'Write a new generated .cpp; preserve the exporter template.');
text=fileread(templatePath);
first=strfind(text,'// BEGIN MATLAB MODEL CONSTANTS'); last=strfind(text,'// END MATLAB MODEL CONSTANTS');
assert(numel(first)==1 && numel(last)==1 && first<last,'Template markers must each occur once.');
after=last+numel('// END MATLAB MODEL CONSTANTS');
text=[text(1:first-1) strjoin(lines,newline) text(after:end)];
fid=fopen(outputPath,'w'); assert(fid>=0,'Cannot write generated C++ file.');
cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
fprintf(fid,'%s',text);
fprintf('Wrote %s: %d joint templates, %d rows, Fs=%.9g Hz.\n', ...
    outputPath,count,size(allSamples,1),p.Fs);
fprintf('Adapt the EXAMPLE input/output bindings to your sim; all runtime code is in this .cpp.\n');
end
function lines=matrixLines(name,a)
lines=cell(size(a,1)+2,1); lines{1}=sprintf('static const double %s[%d][3] = {',name,size(a,1));
for k=1:size(a,1), lines{k+1}=['    {' realList(a(k,:)) '},']; end
lines{end}='};';
end
function text=integerArray(type,name,a)
text=sprintf('static const %s %s[%d] = {%s};',type,name,numel(a),sprintf('%.0f,',a));
end
function text=realList(a)
a=a(:); text=sprintf('%.17g',a(1));
if numel(a)>1, text=[text sprintf(', %.17g',a(2:end))]; end
end
