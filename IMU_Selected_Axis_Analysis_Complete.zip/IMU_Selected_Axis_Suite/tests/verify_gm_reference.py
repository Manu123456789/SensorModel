"""Optional developer check, NOT MATLAB execution. Needs NumPy/SciPy/matplotlib/g++.
Numerical reference for selected-axis event bootstrap and actual C++ helpers.
Writes only to a supplied scratch directory; does not edit user model outputs.
Usage: python tests/verify_gm_reference.py /path/to/scratch-checks
"""
import csv
import json
import subprocess
import sys
from pathlib import Path

import numpy as np
from scipy.signal import welch, lfilter

ROOT = Path(__file__).resolve().parents[1]
DEST = Path(sys.argv[1]).resolve()
DEST.mkdir(parents=True, exist_ok=True)
FS=200
def synthetic():
    rng=np.random.default_rng(42); n=24000; phi=.9
    C=np.diag([5,7,4])@np.array([[1,.2,.05],[.2,1,-.1],[.05,-.1,1]])@np.diag([5,7,4])
    L=np.linalg.cholesky(C); initial=rng.standard_normal(3)@L.T
    innovation=np.sqrt(1-phi**2)*(rng.standard_normal((n,3))@L.T)
    x=np.column_stack([lfilter([1],[1,-phi],innovation[:,j],zi=[phi*initial[j]])[0] for j in range(3)])
    x += [3,-5,2]; cursor=0
    while cursor<n:
        gap=max(1,round(FS*(.25+.65*np.exp(.45*rng.standard_normal()))))
        width=max(3,round(FS*(.025+.125*rng.random())))
        first=cursor+gap; last=first+width
        if last>=n: break
        u=np.linspace(0,1,width); kind=rng.integers(1,4)
        shape=np.exp(-5*u) if kind==1 else 1-abs(2*u-1) if kind==2 else np.minimum(1,np.minimum(8*u,8*(1-u)))
        q=rng.random(); direction=[.18,1,-.12] if q<.7 else [1,.12,.08] if q<.85 else [-.1,.15,1]
        peak=350*np.exp(.4*rng.standard_normal())
        if rng.random()<.22: peak *= -.55
        x[first:last] += peak*shape[:,None]*direction
        cursor=last
    return x
full=synthetic()


def detect(x, m):
    z = np.abs(x - m['baseline'])
    onset = np.any(z[:, m['mask']] >= m['threshold'][m['mask']], axis=1)
    released = np.all(z[:, m['mask']] <= m['release'][m['mask']], axis=1)
    active = False
    mask = np.zeros(len(x), bool)
    for k in range(len(x)):
        if not active and onset[k]:
            active = True
        if active and released[k]:
            active = False
        mask[k] = active
    a = np.flatnonzero(mask & ~np.r_[False, mask[:-1]])
    b = np.flatnonzero(mask & ~np.r_[mask[1:], False])
    return a, b, mask


def fit(x, selected):
    mask = np.zeros(3, bool)
    mask[selected] = True
    m = dict(mask=mask, baseline=np.median(x, axis=0))
    sigma = np.maximum(1.4826 * np.median(abs(x - m['baseline']), axis=0), 1e-12)
    m['threshold'] = np.where(mask, 5 * sigma, np.inf)
    m['release'] = np.where(mask, np.minimum(2 * sigma, .8 * m['threshold']), np.inf)
    for _ in range(10):
        a, b, event = detect(x, m)
        updated = x[~event].mean(axis=0)
        change = np.max(abs(updated[mask] - m['baseline'][mask]) / sigma[mask])
        m['baseline'] = updated
        if change < 1e-6:
            break
    a, b, event = detect(x, m)
    covariance = np.cov(x[~event].T, bias=True)
    d, V = np.linalg.eigh(covariance)
    m['factor'] = V @ np.diag(np.sqrt(np.maximum(d, 0)))
    m['factor'][~mask, :] = 0
    m['covariance'] = covariance
    m['quiet'] = ~event
    pair=np.flatnonzero((~event[:-1]) & (~event[1:]))
    variance=np.diag(covariance)
    usable=mask & (variance>1e-12)
    z=x-m['baseline']
    prev=z[pair][:,usable]/np.sqrt(variance[usable])
    curr=z[pair+1][:,usable]/np.sqrt(variance[usable])
    m['phi_raw']=np.sum(prev*curr)/max(np.sum(prev**2),1e-12)
    m['phi']=min(.999,max(0,m['phi_raw']))
    assert len(pair)>=30

    m['templates'], gaps, classes = [], [], []
    for first, last in zip(a, b):
        previous = np.flatnonzero(event[:first])
        if first == 0 or last == len(x) - 1 or not len(previous):
            continue
        p = x[first:last + 1] - m['baseline']
        p[:, ~mask] = 0
        # MATLAB max chooses the first column-major entry on a tie.
        scaled = abs(p) / m['threshold']
        row, axis = np.unravel_index(np.argmax(scaled.ravel(order='F')), p.shape, order='F')
        m['templates'].append(p)
        gaps.append(first - previous[-1] - 1)
        classes.append(2 * axis + int(p[row, axis] < 0))
    m['gap'] = np.array(gaps)
    m['classes'] = np.array(classes)
    counts = np.bincount(classes, minlength=6).astype(float)
    m['frequency'] = counts / counts.sum()
    m['transition'] = np.tile(m['frequency'], (6, 1))
    m['burn'] = 10 * max(g + len(p) for g, p in zip(gaps, m['templates']))
    return m


def generate(m, n, rng):
    initial=rng.standard_normal(3)@m['factor'].T
    innovation=np.sqrt(1-m['phi']**2)*(rng.standard_normal((n+m['burn'],3))@m['factor'].T)
    out=np.column_stack([lfilter([1],[1,-m['phi']],innovation[:,j],zi=[m['phi']*initial[j]])[0] for j in range(3)])
    out += m['baseline']
    cursor = 0
    while cursor < len(out):
        mark = rng.choice(6, p=m['frequency'])
        k = rng.choice(np.flatnonzero(m['classes'] == mark))
        p = m['templates'][k]
        cursor += m['gap'][k]
        last = min(len(out), cursor + len(p))
        if cursor < len(out):
            out[cursor:last] = p[:last - cursor] + m['baseline']
        cursor += len(p)
    return out[m['burn']:]


def stats(x, m, j):
    a, b, _ = detect(x, m)
    peaks = []
    for first, last in zip(a, b):
        if first == 0 or last == len(x) - 1:
            continue
        z = x[first:last + 1, j] - m['baseline'][j]
        peak = z[np.argmax(abs(z))]
        if abs(peak) >= m['threshold'][j]:
            peaks.append(peak)
    a_ms2 = x[:, j] * 9.80665e-6
    velocity = np.r_[0., np.cumsum(a_ms2) / FS]
    position = np.r_[0., np.cumsum(velocity[:-1] / FS + .5 * a_ms2 / FS**2)]
    return np.array([x[:, j].mean(), x[:, j].std(), np.sqrt(np.mean(x[:, j]**2)),
                     np.sum(np.array(peaks) > 0), np.sum(np.array(peaks) < 0),
                     velocity[-1], position[-1]])


def cpp_fixture(m, path):
    rows = np.concatenate(m['templates'])
    lengths = [len(p) for p in m['templates']]
    offsets = np.r_[0, np.cumsum(lengths)[:-1]]

    def real(a):
        return ','.join(f'{v:.17g}' for v in np.ravel(a))

    def ints(a):
        return ','.join(str(int(v)) for v in a)

    lines = ['// BEGIN MATLAB MODEL CONSTANTS', '// PYTHON REFERENCE FIXTURE, not MATLAB-export output.',
             f'static const double imu_template_samples[{len(rows)}][3]={{']
    lines += ['{' + real(row) + '},' for row in rows]
    lines += ['};']
    for name, values in [('offset', offsets), ('length', lengths), ('gap', m['gap'])]:
        lines.append(f'static const std::size_t imu_event_{name}[{len(lengths)}]={{{ints(values)}}};')
    lines.append(f'static const unsigned imu_event_class[{len(lengths)}]={{{ints(m["classes"])}}};')
    lines += ['static const ImuPulseParameters imu_pulse_parameters={',
              f'true,{FS:.17g},{{{real(m["baseline"])}}},',
              '{' + ','.join('{' + real(row) + '}' for row in m['factor']) + '},',
              f'{len(lengths)},{len(rows)},imu_template_samples,imu_event_offset,imu_event_length,imu_event_gap,imu_event_class,',
              '{' + real(m['frequency']) + '},',
              '{' + ','.join('{' + real(row) + '}' for row in m['transition']) + '},',
              f'false,{m["burn"]},{m["phi"]:.17g}', '};', '// END MATLAB MODEL CONSTANTS']
    source = (ROOT / 'cpp/IMU_Pulse_Integration_Template.cpp').read_text()
    first = source.index('// BEGIN MATLAB MODEL CONSTANTS')
    last = source.index('// END MATLAB MODEL CONSTANTS') + len('// END MATLAB MODEL CONSTANTS')
    path.write_text(source[:first] + '\n'.join(lines) + source[last:])


report = {'kind': 'Python numerical reference and C++ fixture, NOT MATLAB execution',
          'sample_count': len(full), 'Fs_Hz': FS, 'selected_axis_checks': {}}
for j in range(3):
    x = np.zeros_like(full)
    x[:, j] = full[:, j]
    m = fit(x[:16800], [j])
    sample = generate(m, 7200, np.random.default_rng(1))
    assert np.all(sample[:, ~m['mask']] == 0)
    assert np.all(m['factor'][~m['mask']] == 0)
    assert np.all(m['baseline'][~m['mask']] == 0)
    assert len(m['templates']) >= 5
    assert abs(m['phi']-.9)<.15
    report['selected_axis_checks']['XYZ'[j]] = {'eligible_events':len(m['templates']),'fitted_phi':m['phi']}

y = np.zeros_like(full)
y[:, 1] = full[:, 1]
train, ref = y[:16800], y[16800:]
m = fit(train, [1])
reference_stats = stats(ref, m, 1)
rng = np.random.default_rng(1234)
generated = [generate(m, len(ref), rng) for _ in range(50)]
model_stats = np.array([stats(x, m, 1) for x in generated])
fixture = DEST / 'Reference_Candidate.cpp'
cpp_fixture(m, fixture)
executable = DEST / 'check_reference_export'
subprocess.run(['g++', '-std=c++11', '-O2', '-Wall', '-Wextra', '-Werror', '-pedantic',
                f'-DIMU_MODEL_FILE="{fixture}"', str(ROOT / 'cpp/Check_Exported_Model.cpp'),
                '-o', str(executable)], check=True)
cpp_stats = []
for seed in range(30):
    output = subprocess.check_output([str(executable), str(len(ref)), str(seed)], text=True)
    records = list(csv.reader(output.splitlines()))
    trace = np.array(records[1:], dtype=float)
    assert len(trace) == len(ref) and np.all(trace[:, [1, 3]] == 0)
    assert np.max(abs(trace[:, 0] - np.arange(len(ref)) / FS)) < 1e-10
    cpp_stats.append(stats(trace[:, 1:], m, 1))
cpp_stats = np.array(cpp_stats)
# Ensemble-mean difference relative to Monte Carlo standard errors. Wide bound
# is a developer regression check, not hardware-model acceptance criterion.
se = np.sqrt(model_stats.var(axis=0, ddof=1) / len(model_stats) +
             cpp_stats.var(axis=0, ddof=1) / len(cpp_stats))
assert np.all(abs(model_stats.mean(axis=0) - cpp_stats.mean(axis=0)) < 5 * se + 1e-10)
report.update({'Y_quiet_fraction_train': float(m['quiet'].mean()),
               'Y_catalog_events': len(m['templates']), 'Y_fitted_phi':m['phi'],
               'Y_metric_names': ['Mean_ug', 'Std_ug', 'TotalRMS_ug', 'PositiveEvents',
                                  'NegativeEvents', 'FinalVelocity_ms', 'FinalPosition_m'],
               'Y_held_out': reference_stats.tolist(),
               'Python_model_50_run_mean': model_stats.mean(axis=0).tolist(),
               'CPP_30_run_mean': cpp_stats.mean(axis=0).tolist(),
               'CPP_vs_Python_mean_difference_in_MC_SE':
                   (abs(model_stats.mean(axis=0) - cpp_stats.mean(axis=0)) / np.maximum(se, 1e-12)).tolist(),
               'status': 'PASS developer reference checks; MATLAB runtime remains untested'})
(DEST / 'Reference_Validation.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))

# Six tiles: numerical-reference preview, explicitly not a MATLAB screenshot.
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig, ax = plt.subplots(2, 3, figsize=(14, 8), layout='constrained')
t = np.arange(len(ref)) / FS
ax[0, 0].plot(t, ref[:, 1], color='black', lw=.6)
ax[0, 0].set(title='Held-out synthetic Y', xlabel='Time [s]', ylabel='Error [µg]')
ax[0, 1].plot(t, generated[0][:, 1], color='firebrick', lw=.6)
ax[0, 1].set(title='New Y realization; X/Z exactly zero', xlabel='Time [s]', ylabel='Error [µg]')
edges = np.linspace(min(ref[:, 1]), max(ref[:, 1]), 60)
ax[0, 2].hist(ref[:, 1], edges, density=True, histtype='step', color='black', label='Held-out')
ax[0, 2].hist(generated[0][:, 1], edges, density=True, histtype='step', color='firebrick', label='One model run')
ax[0, 2].set(title='Amplitude density', xlabel='Error [µg]', ylabel='Density [1/µg]', yscale='log')
for x, color, label in [(ref, 'black', 'Held-out'), (generated[0], 'firebrick', 'One model run')]:
    f, p = welch(x[:, 1] - x[:, 1].mean(), fs=FS, window='hamming', nperseg=400,
                 noverlap=200, nfft=512, detrend=False)
    ax[1, 0].loglog(f[1:], p[1:], color=color, label=label)
    v = np.r_[0., np.cumsum(x[:, 1]) * 9.80665e-6 / FS]
    pos = np.r_[0., np.cumsum(v[:-1]/FS + .5*x[:, 1]*9.80665e-6/FS**2)]
    ax[1, 1].plot(np.arange(len(v))/FS, v, color=color)
    ax[1, 2].plot(np.arange(len(v))/FS, pos, color=color)
ax[1, 0].set(title='AC Welch PSD', xlabel='Frequency [Hz]', ylabel='PSD [µg²/Hz]')
ax[1, 1].set(title='Velocity error (ZOH integration)', xlabel='Time [s]', ylabel='Velocity error [m/s]')
ax[1, 2].set(title='Position error (ZOH integration)', xlabel='Time [s]', ylabel='Position error [m]')
for a in ax.flat:
    a.grid(alpha=.25)
ax[0, 2].legend(); ax[1, 0].legend()
fig.suptitle('SYNTHETIC GM + spikes, selected Y — Python reference, not hardware / MATLAB execution')
fig.savefig(DEST / 'Synthetic_Y_Preview.png', dpi=140)
plt.close(fig)
