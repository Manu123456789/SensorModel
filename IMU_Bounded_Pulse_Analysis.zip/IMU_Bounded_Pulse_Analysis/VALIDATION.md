# Verification status — bounded signed pulse model

This package keeps a small pulse-generator architecture while adding separate
positive/negative level distributions and durations, bounds on the COMPLETE
sensor-error sample, and rate-based quiet-gap estimation. It retains S,H,A,B,C,D,E
and adds six-tile G diagnostics for signed density and spectral power.

## Executed checks

`tests/verify_reference.py` independently implements the numerical model with
NumPy/SciPy, including constrained bounded likelihoods, conditional sampling,
shape projection, duration weighting, onset density and stationary initialization.
It fits an asymmetric synthetic 180-second 200-Hz XYZ record and checks:

- selected X/Y/Z separately, exact zero inactive components;
- separate larger/longer positive and smaller/shorter negative behavior;
- hard support of every generated sample, including background;
- positive/negative fit convergence on the synthetic example;
- nominal onset rate matching the measured onset target;
- background and lognormal fits on known strongly truncated populations;
- no clipping-induced samples exactly on bounds for nondegenerate noise;
- valid missing-sign and zero-background cases;
- mathematical calls/file references and six-tile summary guards;
- absence of a C++ exporter and waveform-catalog workflow.

The script extracts the ACTUAL C++ generator printed in README and compiles it
with C++11 and strict warnings. It executes deterministic pulse/triangle/sign
checks, then one million samples for complete bounds, separate signed occupancy,
onset rate and absence of endpoint-clipping atoms. An independent Python run
with the same parameter laws has compatible moments. Random seeds and samples
are not expected to match across implementations.

### Synthetic old-versus-new comparison

The synthetic reference deliberately has smaller and shorter negative events,
which the previous shared-sign model cannot represent well. Across 20 generated
records, the independent reference check reported:

| Quantity | Reference | Previous shared-sign model | New bounded signed model |
|---|---:|---:|---:|
| Negative detected-event occupancy | 0.9694% | 2.5164% | 0.9228% |
| Amplitude histogram total variation | — | 0.06094 | 0.01448 |
| PSD log-ratio RMSE | — | 7.120 dB | 0.331 dB |

The fit's nominal onset rates for X/Y/Z matched its respective targets of about
1.5000, 1.1667 and 1.7612 events/s. Fitted positive/negative widths were 14/5,
20/6 and 12/4 samples. Every generated sample remained inside its fitted axis
bounds. These numbers are SYNTHETIC evidence about the workflow, not your
hardware coefficients or proof that its PSD discrepancy has been solved.

Machine-readable details: `evidence/Bounded_Validation.json`.
`Bounded_Summary_Preview.png` and `Bounded_Density_Power_Preview.png` are clearly
labeled Python numerical illustrations, not MATLAB screenshots or hardware fits.

## MATLAB checks supplied, NOT executed here

MATLAB/Octave are unavailable in the authoring environment. The actual MATLAB
fit, plots and file-saving workflow were reviewed but not executed. Independent
Python checks do not prove MATLAB graphics/runtime compatibility.

On MATLAB R2021b+ with Signal Processing Toolbox:

```matlab
addpath('tests');
Test_IMU_Bounded
```

The supplied MATLAB test covers inclusive original-row windows, a configured Fs
independent of timetable metadata, custom column mapping, separate signed fits,
whole-output bounds, nominal rate matching, full-record/held-out modes, the new
summary tables, missing-negative/zero-noise cases, conditional sampling without
clipping, cumulative decoding, ZOH window integration, and hidden smoke checks
for the eight single-axis figure families with no more than six data axes each.

For a complete visual workflow, set `cfg.useSyntheticExample=true` in the main
IMU_Config.m and run it. Use your existing workspace record when false.

Optional developer check, with all build files placed in scratch:

```sh
python3 tests/verify_reference.py /tmp/imu_bounded_checks
```

## Remaining real-data and sim checks

No actual hardware samples or resulting figures were available for numerical
validation in this turn. Conditional normal/lognormal laws, fixed within-sign
durations, ideal shapes, geometric gaps, independent event signs and independent
selected axes remain assumptions. Bound estimates come from the fitting record
and do not establish physical limits or unseen failure behavior.

FitReview exposes sparse sign classes, shape sign conflicts, projected magnitudes
outside support, constrained gap activation and optimizer exits. A good synthetic
result does not justify ignoring those flags on hardware data. Rate matching is
nominal: the unchanged detector can miss or fragment generated events, so compare
both DensitySummary and the amplitude/event plots.

Endpoint CDFs are complementary evidence, not a substitute for matching amplitude
occupancy and relevant temporal power. Review PowerSummary/G5/G6 for broad PSD
scale discrepancies and B3/B6/C6/D for structural differences. Bounds apply to
selected SENSOR model components; rotation and other retained errors can change
platform totals. Your host RNG, tick rate, units and accumulator insertion point
must be verified in the actual C++ simulation.
