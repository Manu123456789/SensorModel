function y=period(m,j)
% Rebuild ONE period from runtime tone arrays only (no measured data needed).
n=m.recordSamples; F=zeros(n,1); bins=m.toneBin{j};
C=m.toneAmp{j}.*exp(1i*(m.tonePhase{j}-pi/2))*n/2;
paired=true(size(bins));
if mod(n,2)==0
    nyquist=bins==n/2; paired(nyquist)=false;
    % Derive the signed real Nyquist coefficient from the sine phase.
    C(nyquist)=n*m.toneAmp{j}(nyquist).*sin(m.tonePhase{j}(nyquist));
end
F(bins+1)=C;
F(n-bins(paired)+1)=conj(C(paired));
y=m.mean_ug(j)+real(ifft(F));
end
