function e=detect(x,m)
% Hysteresis: any selected axis starts; all selected axes must return to release.
n=size(x,1); active=false; mask=false(n,1); z=x-m.baseline;
for k=1:n
    if ~active && any(abs(z(k,m.selectedMask))>=m.threshold(m.selectedMask)), active=true; end
    if active && all(abs(z(k,m.selectedMask))<=m.release(m.selectedMask)), active=false; end
    mask(k)=active;
end
a=find(diff([false;mask])==1); b=find(diff([mask;false])==-1);
e=struct('start',a,'stop',b,'mask',mask);
end
