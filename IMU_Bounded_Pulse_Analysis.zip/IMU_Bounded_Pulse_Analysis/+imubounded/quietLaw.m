function y=quietLaw(m,j,kind,x)
% Marginal quiet law over COMPLETE blocks: one release-conditioned draw per gap.
types=m.pulseTypes{j}; slots=sum([types.count])+1;
quiet=m.blockSamples-sum([types.count].*[types.width]); weight=slots/quiet;
b=m.bgMu(j); s=m.bgSigma(j); rb=max(m.releaseLower(j),min(m.releaseUpper(j),b));
if strcmp(kind,'pdf')
    y=(1-weight)*imubounded.boundedNormalPDF(x,b,s,m.quietLower(j),m.quietUpper(j)) + ...
        weight*imubounded.boundedNormalPDF(x,rb,s,m.releaseLower(j),m.releaseUpper(j));
elseif strcmp(kind,'quantile')
    if s==0, y=repmat(b,size(x)); return; end
    low=repmat(m.quietLower(j),size(x)); high=repmat(m.quietUpper(j),size(x));
    for k=1:60
        mid=(low+high)/2;
        F=(1-weight)*cdf(mid,b,s,m.quietLower(j),m.quietUpper(j)) + ...
            weight*cdf(mid,rb,s,m.releaseLower(j),m.releaseUpper(j));
        less=F<x; low(less)=mid(less); high(~less)=mid(~less);
    end
    y=(low+high)/2;
else, error('Unknown quiet-law request.'); end
end
function F=cdf(x,b,s,lo,hi)
a=.5*erfc(-(lo-b)/s/sqrt(2)); z=.5*erfc(-(hi-b)/s/sqrt(2));
F=max(0,min(1,(.5*erfc(-(x-b)/s/sqrt(2))-a)/max(z-a,realmin)));
end
