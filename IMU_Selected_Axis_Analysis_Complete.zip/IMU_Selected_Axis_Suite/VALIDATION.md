# Summary-figure revision: verification status

This revision adds Figure S (six tiles), contiguous quiet-background close-ups,
matched-window terminal CDFs, SummaryTerminal.csv, and clearer fit-data labels.
The fitting and C++ generation algorithms are unchanged.

The MATLAB test now checks matched-window counts, exact inactive-axis zeros,
trailing-sample omission, per-window resets, early-versus-late pulse position
weighting, a single-window case, and a hidden six-axis summary-figure smoke test.
These MATLAB tests have NOT been executed here: MATLAB/Octave are unavailable.

A separate Python numerical check of windowed integration passed analytic
constant/pulse cases and matched-window pooling. This checks the mathematics,
not execution of MATLAB or MATLAB graphics. Original checks below are retained
as evidence for the prior model revision, not claimed as rerun for this edit.

# Verification coverage for the workspace / Gauss-Markov revision

## Executed numerical and C++ checks

- The numerical reference generates its synthetic XYZ record entirely in memory.
  Its true quiet correlation coefficient is 0.9, with a specified stationary
  cross-covariance and irregular signed pulses.
- X, Y and Z were fitted separately. Fitted coefficients were approximately
  0.9154, 0.9041 and 0.9000; eligible event catalogs contained 73, 70 and 72
  complete events. All inactive sensor outputs and quiet-factor rows were zero.
- For selected Y, the held-out record had 24 positive and 7 negative complete
  detected events. Fifty numerical-reference runs averaged 23.94 and 6.40.
  Thirty runs from the actual C++ runtime averaged 24.10 and 6.20. These finite
  synthetic counts demonstrate the workflow, not hardware calibration accuracy.
- The C++ statistical check compiled a populated reference fixture with the same
  constant layout as the MATLAB exporter, including gm_phi. The checker exercised
  both the low-level runtime and the example IMU_error() identity-frame binding.
  Differences in seven ensemble-mean statistics between 50 reference runs and
  30 C++ runs were all below 0.81 estimated Monte Carlo standard errors.
  This is a developer equivalence check, not a physical-model acceptance rule.
- The dedicated C++ Gauss-Markov test used 300,000 quiet samples at phi=0.9 and
  stationary variance 4. The measured variance was approximately 4.0071 and
  lag-one correlation 0.89978. It also checked persistence of the latent state
  through pulse intervals, exact inactive-axis zeros, no double-added background
  during pulse output, and invalid-coefficient rejection.
- The dedicated GM test passed strict C++11 warnings plus address and
  undefined-behavior instrumentation. Leak detection was disabled because the
  restricted execution environment cannot inspect the relevant process metadata.
- Existing C++ scheduling/covariance/no-double-noise/reset/cache/Markov/units
  tests and selected-axis/proper-rotation tests were recompiled and passed after
  adding the GM state. They use phi=0 to retain their original white limiting
  case, while the dedicated test covers nonzero persistence.
- Package-reference checks verify that every called imupulse function is
  included; the figure helper enforces a maximum of six tiles.

Machine-readable numerical results are in evidence/Reference_Validation.json.
The optional tests/verify_gm_reference.py reproduces this numerical-reference and
C++-fixture check with NumPy, SciPy, matplotlib and g++. These tools are not
required for the ordinary MATLAB analysis.

## MATLAB tests supplied, but not executed here

MATLAB and Octave are unavailable in the authoring environment. The MATLAB
implementation, plotting and exporter were reviewed but not run. Numerical
reference checks do not prove that MATLAB graphics or file output will execute
without a compatibility issue.

The supplied Test_IMU_Suite.m covers:
- timetable input and exact mapped channel names;
- a configured row clock that does not depend on timetable row labels;
- histogram channels independent from model selection;
- unchanged selected model input when unused visualization channels are altered;
- original-row window alignment;
- Gauss-Markov fits on each sensor axis and exactly zero inactive outputs;
- optional multi-axis model preparation;
- a table containing only the required channel when visualization is restricted;
- full analysis smoke checks, unit conversion and cumulative decoding;
- known constant-acceleration integration results.

Run in MATLAB:

```matlab
addpath('tests');
Test_IMU_Suite
```

For a full visual smoke test, set useSyntheticExample=true in IMU_Config.m and
run that main script. Inspect S, H and all five detailed selected-axis figure families.
For hardware, set the same script to false, supply your existing workspace
variable name, map the channels, and provide the actual rate/known true input.

## Remaining application-level verification

No numerical hardware record was supplied. The model's physical adequacy,
stationarity across operating conditions, clipping thresholds, quiet marginal
Gaussianity, exponential quiet correlation, event-tail support and sensor frame
definitions are not established by this example.

The complete generated signal is not wholly Gauss-Markov: it combines a
Gauss-Markov quiet process with separately scheduled empirical event waveforms.
The event catalog cannot extrapolate unseen extremes or longer unobserved gaps.
Conditional simulation bands hold fitted parameters fixed; they are not
parameter-confidence intervals or hardware qualification evidence.

Compile the actual MATLAB-exported candidate and compare C++ traces across
multiple seeds using Check_CPP_Output(cfg), as described in README. The authoring
fixture is deliberately distinguished from that actual exporter execution.
Test your real sensor scheduler, rotation, error insertion point and internal
accumulator with known constant/pulse inputs. The generalized adapter and
open-loop integration diagnostics do not validate an unseen navigation or
closed-loop controller implementation.
