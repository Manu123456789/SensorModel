function d=prepare(T,c)
% Convert only SELECTED axes, preserve time, and set unused model inputs to zero.
assert(istable(T),'Input must be a MATLAB table.');
chosen=upper(string(c.selectedAxes)); chosen=chosen(:)';
assert(~isempty(chosen) && numel(unique(chosen))==numel(chosen) && ...
    all(ismember(chosen,["X","Y","Z"])),'Choose unique axes X, Y and/or Z.');
mask=ismember(["X","Y","Z"],chosen);
assert(numel(c.axisColumns)==3 && ismember(c.timeColumn,T.Properties.VariableNames));
t=T.(c.timeColumn); assert(isnumeric(t) && isvector(t) && isreal(t)); t=double(t(:));
assert(numel(t)>=512 && all(isfinite(t)) && all(diff(t)>0), ...
    'Need >=512 finite, strictly increasing numeric time samples.');
raw=zeros(numel(t),3);
for j=find(mask)
    name=c.axisColumns{j}; assert(ismember(name,T.Properties.VariableNames), ...
        ['Missing selected column: ' name]);
    v=T.(name); assert(isnumeric(v) && isvector(v) && isreal(v) && numel(v)==numel(t));
    raw(:,j)=double(v(:));
end
assert(isequal(size(c.window_s),[1 2]) && c.window_s(1)<c.window_s(2));
assert(isequal(size(c.baselineSensor_ms2),[1 3]) && ...
    all(isfinite(c.baselineSensor_ms2(mask))),'Supply known true baseline for SELECTED axes.');
R=c.R_sensor_to_PLT;
assert(isequal(size(R),[3 3]) && isreal(R) && all(isfinite(R(:))) && ...
    norm(R*R'-eye(3),'fro')<1e-6 && abs(det(R)-1)<1e-6, ...
    'R must be a proper sensor-to-platform rotation (orthonormal, determinant +1).');
assert(isequal(size(c.railLimitsInput),[3 2]) && ...
    all(c.railLimitsInput(:,1)<c.railLimitsInput(:,2)));
rail=any(raw(:,mask)<=c.railLimitsInput(mask,1)' | ...
    raw(:,mask)>=c.railLimitsInput(mask,2)',2);
left=t; right=t;
switch c.inputMode
    case 'instantaneous_ft_s2', a=raw*.3048;
    case 'instantaneous_cm_s2', a=raw*.01;
    case 'instantaneous_ms2', a=raw;
    case 'instantaneous_ug', a=raw*(1e-6*9.80665);
    case {'sample_sum_cm_s2','integral_cm_s'}
        a=diff(raw,1,1)*.01; left=t(1:end-1); right=t(2:end);
        rail=rail(1:end-1)|rail(2:end);
        if strcmp(c.inputMode,'integral_cm_s'), a=a./diff(t); end
        t=right;
    otherwise, error('Unknown inputMode. See defaults and README.');
end
use=left>=c.window_s(1) & right<=c.window_s(2);
t=t(use); a=a(use,:); rail=rail(use);
assert(numel(t)>=512 && all(all(isfinite(a(:,mask)))), ...
    'Selected interval needs >=512 finite selected-axis samples; do not delete gap rows.');
dt=median(diff(t));
assert(all(abs(diff(t)-dt)<=c.sampleIntervalTolerance*dt+32*eps(max(abs(t)))), ...
    'Nonuniform sample times or a gap. Choose one contiguous native-rate interval.');
if any(rail)
    assert(c.allowRailSamples, ...
        'Rail samples present: choose another interval or explicitly set allowRailSamples=true.');
    warning('Model will describe recorded clipping, not unknown acceleration beyond the rail.');
end
y=zeros(size(a)); y(:,mask)=(a(:,mask)-c.baselineSensor_ms2(mask))*(1e6/9.80665);
labels={'X','Y','Z'};
d=struct('t',t,'y',y,'Fs',1/dt,'dt',dt,'mask',mask,'rail',rail);
d.selectedAxes=labels(mask);
end
