function [T,Truth]=Generate_Example_IMU(fs,duration_s)
% Independent synthetic source, NOT generated from the fitted compressed model.
validateattributes(fs,{'numeric'},{'scalar','real','finite','positive'});
validateattributes(duration_s,{'numeric'},{'scalar','real','finite','>=',10});
stream=RandStream('mt19937ar','Seed',42); n=round(fs*duration_s);
background=[3 -5 2]; sigma=[3 5 2]; x=background+randn(stream,n,3).*sigma;
for j=1:3
    cursor=max(2,round(.3*fs));
    while cursor<n-2
        negative=rand(stream)<.27; width=max(1,round(fs*(.025+.05*rand(stream))));
        count=min(width,n-cursor); amplitude=(60+180*rand(stream))*(1-.6*negative)*(1-2*negative);
        w=ones(count,1);
        if rand(stream)<.5, w=.3+.7*min((1:count)',(count:-1:1)')/ceil(count/2); end
        x(cursor:cursor+count-1,j)=background(j)+amplitude*w+sigma(j)*randn(stream,count,1);
        cursor=cursor+count+max(1,round(fs*(.15+1.2*rand(stream))));
    end
end
T=array2timetable(x*(9.80665e-6/.3048),'SampleRate',fs, ...
    'VariableNames',{'Example_X','Example_Y','Example_Z'});
Truth=struct('isSynthetic',true,'quietLocation',background,'quietSigma',sigma);
end
