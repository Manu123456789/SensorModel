"""Independent Python reference + execution of the actual README C++ snippet.
NOT MATLAB execution. Needs NumPy/SciPy/matplotlib/g++; use a scratch build dir.
"""
from pathlib import Path
import json, math, re, subprocess, sys
import numpy as np
from scipy.optimize import minimize
from scipy.special import ndtr
from scipy.signal import welch
ROOT=Path(__file__).resolve().parents[1]
BUILD=Path(sys.argv[1]).resolve(); BUILD.mkdir(parents=True,exist_ok=True)
FS=200

def shape(kind,L):
    return np.ones(L) if kind=='rectangle' else np.minimum(np.arange(1,L+1),np.arange(L,0,-1))/math.ceil(L/2)
def bounded_normal(center,sigma,lo,hi,rng):
    center=np.clip(np.asarray(center,dtype=float),lo,hi)
    if sigma==0:return center.copy()
    x=center+sigma*rng.standard_normal(center.shape); bad=(x<lo)|(x>hi)|~np.isfinite(x)
    while bad.any():
        x[bad]=center[bad]+sigma*rng.standard_normal(bad.sum());bad=(x<lo)|(x>hi)|~np.isfinite(x)
    return x
def amplitude(m,j,neg,rng):
    c=int(neg);cap=m['b'][j]-m['lo'][j] if neg else m['hi'][j]-m['b'][j]
    mu,sd=m['mu'][j,c],m['spread'][j,c]
    if sd==0:a=min(cap,np.exp(mu))
    else:
        a=np.inf
        while not np.isfinite(a) or a<=0 or a>cap:
            z=mu+sd*rng.standard_normal()
            if z<=np.log(cap):a=np.exp(z)
    return -a if neg else a

def generate(m,n,rng):
    x=np.zeros((n,3))
    for j in np.flatnonzero(m['mask']):
        b,sigma,lo,hi=m['b'][j],m['sigma'][j],m['lo'][j],m['hi'][j]
        x[:,j]=bounded_normal(np.full(n,b),sigma,lo,hi,rng)
        q=m['q'][j];mw=np.dot([1-q,q],m['L'][j]);cursor=0
        if rng.random()<mw/(m['gap'][j]+mw):
            neg=rng.random()<q*m['L'][j,1]/mw;L=int(m['L'][j,int(neg)])
            phase=int(rng.random()*L);count=min(n,L-phase);w=shape(m['shape'],L)
            center=b+amplitude(m,j,neg,rng)*w[phase:phase+count]
            x[:count,j]=bounded_normal(center,sigma,lo,hi,rng);cursor=count
        p=1/m['gap'][j]
        while cursor<n:
            G=1 if p>=1 else 1+int(np.floor(np.log1p(-rng.random())/np.log1p(-p)))
            cursor+=G
            if cursor>=n:break
            neg=rng.random()<q;L=int(m['L'][j,int(neg)]);count=min(L,n-cursor)
            center=b+amplitude(m,j,neg,rng)*shape(m['shape'],L)[:count]
            x[cursor:cursor+count,j]=bounded_normal(center,sigma,lo,hi,rng);cursor+=count
        assert np.all((x[:,j]>=lo)&(x[:,j]<=hi))
    return x

def detect(x,b,on,off):
    z=abs(x-b);active=False;mask=np.zeros(len(x),bool)
    for k in range(len(x)):
        if not active and z[k]>=on:active=True
        if active and z[k]<=off:active=False
        mask[k]=active
    a=np.flatnonzero(np.diff(np.r_[False,mask].astype(int))==1)
    z=np.flatnonzero(np.diff(np.r_[mask,False].astype(int))==-1)
    return mask,a,z

def events(x,b,on,off):
    mask,a,z=detect(x,b,on,off);out={k:[] for k in ['first','last','peak','width','gap','area','interval']}
    occ=np.zeros(2)
    for first,last in zip(a,z):
        v=x[first:last+1]-b;peak=v[np.argmax(abs(v))];occ[int(peak<0)]+=last-first+1
        if first==0 or last==len(x)-1:continue
        prev=z[z<first];out['first'].append(first);out['last'].append(last);out['peak'].append(peak)
        out['width'].append(last-first+1);out['area'].append(v.sum()/FS)
        out['gap'].append(first-prev[-1]-1 if len(prev) else np.nan)
    out={k:np.asarray(v) for k,v in out.items()}
    out['occupancy']=occ/len(x);out['onset_rate']=np.count_nonzero(a>0)*FS/(len(x)-1)
    out['mask']=mask;return out

def fit_normal(v,lo,hi):
    avg,var=v.mean(),v.var();R=hi-lo
    if var==0:return avg,0,True
    floor=max(np.finfo(float).tiny,R*1e-10)
    def cost(t):
        mu=t[0];s=np.exp(t[1])
        if not np.isfinite(s) or not lo<=mu<=hi or not floor<=s<=R:return 1e100
        Z=ndtr((hi-mu)/s)-ndtr((lo-mu)/s)
        return len(v)*(np.log(s)+.5*(var+(avg-mu)**2)/s**2+np.log(max(Z,1e-300)))
    result=minimize(cost,[avg,np.log(max(np.sqrt(var),2*floor))],method='Nelder-Mead',options={'maxiter':400,'xatol':1e-8,'fatol':1e-8})
    return result.x[0],np.exp(result.x[1]),result.success

def fit_log(a,weights,cap):
    z=np.log(a);w=weights/weights.sum();avg=np.dot(w,z);var=np.dot(w,(z-avg)**2);top=np.log(cap)
    if var<1e-14:return min(top,avg),0,True
    def cost(t):
        mu=t[0];s=np.exp(t[1])
        if not np.isfinite(s) or mu>top or not 1e-6<=s<=10:return 1e100
        return np.log(s)+.5*(var+(avg-mu)**2)/s**2+np.log(ndtr((top-mu)/s))
    result=minimize(cost,[min(top,avg),np.log(max(np.sqrt(var),2e-6))],method='Nelder-Mead',options={'maxiter':400,'xatol':1e-8,'fatol':1e-8})
    return min(top,result.x[0]),min(10,max(1e-6,np.exp(result.x[1]))),result.success

def fit(raw,j):
    x=raw[:,j];baseline=np.median(x);robust=max(1.4826*np.median(abs(x-baseline)),np.finfo(float).eps)
    on=5*robust;off=min(2*robust,.8*on)
    for _ in range(10):
        mask,_,_=detect(x,baseline,on,off);updated=x[~mask].mean();change=abs(updated-baseline)/robust;baseline=updated
        if change<1e-6:break
    mask,_,_=detect(x,baseline,on,off);e=events(x,baseline,on,off)
    m={k:np.zeros(3) for k in ['b','sigma','lo','hi','gap','q']}
    m.update(mask=np.arange(3)==j,shape='rectangle',mu=np.zeros((3,2)),spread=np.zeros((3,2)),L=np.ones((3,2)))
    m['lo'][j]=x.min();m['hi'][j]=x.max();m['b'][j],m['sigma'][j],bg_ok=fit_normal(x[~mask],x.min(),x.max())
    amps=[];classes=e['peak']<0
    for first,last in zip(e['first'],e['last']):
        w=shape(m['shape'],last-first+1);amps.append(abs(np.dot(w,x[first:last+1]-m['b'][j])/np.dot(w,w)))
    amps=np.array(amps);exits=[bool(bg_ok)]
    for c in range(2):
        which=classes==bool(c)
        if not which.any():exits.append(True);continue
        m['L'][j,c]=max(1,int(np.floor(e['width'][which].mean()+.5)))
        cap=m['hi'][j]-m['b'][j] if c==0 else m['b'][j]-m['lo'][j]
        mu,sd,ok=fit_log(np.minimum(amps[which],cap),e['width'][which].astype(float),cap)
        m['mu'][j,c]=mu;m['spread'][j,c]=sd;exits.append(bool(ok))
    m['q'][j]=classes.mean();mw=np.dot([1-m['q'][j],m['q'][j]],m['L'][j]);m['gap'][j]=max(1,FS/e['onset_rate']-mw)
    return m,baseline,on,off,e,exits

def legacy_generate(raw,j,b,on,off,n,rng):
    e=events(raw[:,j],b,on,off);quiet=~e['mask'];sigma=raw[quiet,j].std()
    logs=np.log(abs(e['peak']));mu=logs.mean();sd=logs.std();q=np.mean(e['peak']<0)
    G=np.nanmean(e['gap']);L=max(1,int(np.floor(e['width'].mean()+.5)));p=1/G
    x=b+sigma*rng.standard_normal(n);cursor=0
    def amp():
        a=np.exp(mu+sd*rng.standard_normal());return -a if rng.random()<q else a
    if rng.random()<L/(G+L):
        phase=int(rng.random()*L);count=min(n,L-phase);x[:count]+=amp();cursor=count
    while cursor<n:
        cursor+=1 if p>=1 else 1+int(np.floor(np.log1p(-rng.random())/np.log1p(-p)))
        if cursor>=n:break
        count=min(L,n-cursor);x[cursor:cursor+count]+=amp();cursor+=count
    return x

def endpoints(x,L):
    W=len(x)//L;a=x[:W*L].reshape(W,L,3)*9.80665e-6
    v=np.concatenate([np.zeros((W,1,3)),np.cumsum(a,axis=1)/FS],axis=1)
    p=np.cumsum(v[:,:-1]/FS+.5*a/FS**2,axis=1)
    return v[:,-1],p[:,-1]

truth={'mask':np.ones(3,bool),'shape':'rectangle','b':np.array([3.,-5,2]),'sigma':np.array([3.,5,2]),
       'lo':np.array([-90.,-120,-70]),'hi':np.array([250.,600,300]),'gap':FS*np.array([.6,.8,.5]),
       'L':np.rint(FS*np.array([[.07,.025],[.10,.03],[.06,.02]])),
       'mu':np.log([[130,35],[300,45],[150,25]]),'spread':np.array([[.25,.2],[.3,.25],[.2,.18]]),'q':np.array([.25,.3,.2])}
raw=generate(truth,FS*180,np.random.default_rng(42));fitted={};recovery={}
for j in range(3):
    m,b,on,off,e,exits=fit(raw,j);fitted[j]=(m,b,on,off,e)
    x=generate(m,50000,np.random.default_rng(123));assert np.all(x[:,np.arange(3)!=j]==0)
    assert abs(m['b'][j]-truth['b'][j])<1 and abs(m['sigma'][j]-truth['sigma'][j])<1
    assert m['L'][j,0]>m['L'][j,1] and m['mu'][j,0]>m['mu'][j,1]
    cycle=m['gap'][j]+np.dot([1-m['q'][j],m['q'][j]],m['L'][j]);assert abs(FS/cycle-e['onset_rate'])<1e-10
    recovery['XYZ'[j]]={'complete_positive':int(np.sum(e['peak']>0)),'complete_negative':int(np.sum(e['peak']<0)),
      'positive_width':int(m['L'][j,0]),'negative_width':int(m['L'][j,1]),'target_onset_rate_Hz':float(e['onset_rate']),
      'nominal_onset_rate_Hz':float(FS/cycle),'bound_violations':0,'optimizer_success':exits}
# Missing negative class / zero background is valid and does not invent negatives.
flat=np.zeros((6000,3))
for first in range(100,5700,400):flat[first:first+20,1]=100
one,*_=fit(flat,1);assert one['q'][1]==0 and one['sigma'][1]==0
assert np.all(generate(one,20000,np.random.default_rng(7))[:,1]>=0)
# Near-bound background: conditional mean, no samples clipped to the endpoints.
rng=np.random.default_rng(6);noise=bounded_normal(np.full(200000,.85),.5,-1,1,rng)
a=(-1-.85)/.5;z=(1-.85)/.5;Z=ndtr(z)-ndtr(a)
expected=.85+.5*(np.exp(-a*a/2)-np.exp(-z*z/2))/(np.sqrt(2*np.pi)*Z)
assert abs(noise.mean()-expected)<.003 and not np.any((noise==-1)|(noise==1))
# Old-versus-new comparison is on asymmetric SYNTHETIC data only.
j=1;m,b,on,off,reference_events=fitted[j];n=len(raw);K=20;rng=np.random.default_rng(1234)
new=[];old=[];new_events=[];old_events=[]
finite_edges=np.linspace(raw[:,j].min(),raw[:,j].max(),81);edges=finite_edges.copy();edges[[0,-1]]=[-np.inf,np.inf]
ref_prob=np.histogram(raw[:,j],edges)[0]/n
for k in range(K):
    x=generate(m,n,rng);y=legacy_generate(raw,j,b,on,off,n,np.random.default_rng(900+k))
    new.append(x);old.append(y);new_events.append(events(x[:,j],b,on,off));old_events.append(events(y,b,on,off))
new_prob=np.mean([np.histogram(x[:,j],edges)[0]/n for x in new],axis=0)
old_prob=np.mean([np.histogram(x,edges)[0]/n for x in old],axis=0)
new_tv=.5*np.abs(new_prob-ref_prob).sum();old_tv=.5*np.abs(old_prob-ref_prob).sum()
ref_occ=reference_events['occupancy'][1];new_occ=np.mean([e['occupancy'][1] for e in new_events]);old_occ=np.mean([e['occupancy'][1] for e in old_events])
assert new_tv<old_tv and abs(new_occ-ref_occ)<abs(old_occ-ref_occ)
assert all(np.all((x[:,j]>=m['lo'][j])&(x[:,j]<=m['hi'][j])) for x in new)
# Check truncated-fit likelihoods on strongly truncated known populations.
fit_mu,fit_sigma,_=fit_normal(noise,-1,1)
assert abs(fit_mu-.85)<.04 and abs(fit_sigma-.5)<.03
cap=100.; logs=[]
while len(logs)<30000:
 z=np.log(90.)+.5*rng.standard_normal(50000);logs.extend(z[z<=np.log(cap)].tolist())
logs=np.array(logs[:30000]); lm,ls,_=fit_log(np.exp(logs),np.ones(len(logs)),cap)
assert abs(lm-np.log(90.))<.08 and abs(ls-.5)<.04
# Record PSD and total-power diagnostics for the asymmetric synthetic comparison.
window=np.hamming(400)
freq,ref_psd=welch(raw[:,j]-raw[:,j].mean(),fs=FS,window=window,noverlap=200,nfft=512,detrend=False)
new_psd=np.mean([welch(z[:,j]-z[:,j].mean(),fs=FS,window=window,noverlap=200,nfft=512,detrend=False)[1] for z in new],axis=0)
old_psd=np.mean([welch(z-z.mean(),fs=FS,window=window,noverlap=200,nfft=512,detrend=False)[1] for z in old],axis=0)
new_psd_error=np.sqrt(np.mean((10*np.log10(new_psd[1:])-10*np.log10(ref_psd[1:]))**2))
old_psd_error=np.sqrt(np.mean((10*np.log10(old_psd[1:])-10*np.log10(ref_psd[1:]))**2))
assert new_psd_error<old_psd_error
# Package static checks and execution of the actual printed C++.
code='\n'.join(p.read_text() for p in ROOT.rglob('*.m'));called=set(re.findall(r'imubounded\.(\w+)\s*\(',code))
assert all((ROOT/'+imubounded'/f'{name}.m').exists() for name in called)
assert not list(ROOT.rglob('*.cpp')) and not list(ROOT.rglob('*Export*.m'))
for name in ['plotSummary.m','plotDensityPower.m']:assert (ROOT/'+imubounded'/name).read_text().count('ax=nexttile(t);')==6
readme=(ROOT/'README.md').read_text();block=readme.split('<!-- BOUNDED_CPP_BEGIN -->')[1].split('<!-- BOUNDED_CPP_END -->')[0]
cpp=block.split('```cpp\n')[1].split('```')[0]
harness=r'''
#include <cassert>
#include <iostream>
#include <iomanip>
#include <random>
static std::mt19937 ng(123),ug(456);
static std::normal_distribution<double> nd(0,1);
static std::uniform_real_distribution<double> ud(0,1);
double normalRng(){return nd(ng);}double uniformRng(){return ud(ug);}
double zeroNormal(){return 0;}double lateUniform(){return .999;}
int main(){
 BoundedParams p={0,0,-3,20,std::log(10.),0,std::log(2.),0,0,1,4,1,true};BoundedState s;
 const double expected[]={0,5,10,10,5,0};
 for(double e:expected)assert(std::abs(sampleBounded(p,s,zeroNormal,lateUniform)-e)<1e-12);
 p.q=1;s=BoundedState{};assert(sampleBounded(p,s,zeroNormal,lateUniform)==0);
 assert(std::abs(sampleBounded(p,s,zeroNormal,lateUniform)+2)<1e-12);
 p={2,3,-60,250,std::log(100.),.35,std::log(15.),.2,.25,.015,17,3,false};s=BoundedState{};
 resetBounded(p,s,normalRng,uniformRng);
 const int N=1000000;double pos=0,neg=0,starts=0,sum=0,sq=0,minimum=1e100,maximum=-1e100;
 for(int k=0;k<N;++k){
  const bool pulseNow=s.active||s.gapLeft==0;starts+=(!s.active&&s.gapLeft==0);
  const double x=sampleBounded(p,s,normalRng,uniformRng);
  if(pulseNow){if(s.amplitude<0)neg++;else pos++;}
  assert(x>=p.lo&&x<=p.hi&&std::isfinite(x));assert(x!=p.lo&&x!=p.hi);
  sum+=x;sq+=x*x;minimum=std::min(minimum,x);maximum=std::max(maximum,x);
 }
 const double cycle=1/p.gapP+(1-p.q)*p.posWidth+p.q*p.negWidth;
 assert(std::abs(pos/N-(1-p.q)*p.posWidth/cycle)<.004);
 assert(std::abs(neg/N-p.q*p.negWidth/cycle)<.002);
 assert(std::abs(starts/N-1/cycle)<.0004);
 BoundedParams initial=p;initial.sigma=0;initial.posMu=std::log(10.);initial.posSigma=0;initial.negMu=std::log(2.);initial.negSigma=0;
 double initPositive=0,initNegative=0;
 for(int k=0;k<50000;++k){BoundedState fresh;const double value=sampleBounded(initial,fresh,zeroNormal,uniformRng);initPositive+=(value>initial.b);initNegative+=(value<initial.b);}
 assert(std::abs(initPositive/50000-(1-p.q)*p.posWidth/cycle)<.006);
 assert(std::abs(initNegative/50000-p.q*p.negWidth/cycle)<.003);
 std::cout<<"PASS README C++: signed widths/laws, triangle, density, full bounds, no endpoint clipping.\n";
 std::cout<<std::setprecision(17)<<"{\"mean\":"<<sum/N<<",\"std\":"<<std::sqrt(sq/N-(sum/N)*(sum/N))
          <<",\"positive_occupancy\":"<<pos/N<<",\"negative_occupancy\":"<<neg/N
          <<",\"minimum\":"<<minimum<<",\"maximum\":"<<maximum<<"}\n";
}
'''
source=BUILD/'readme_bounded_check.cpp';source.write_text(cpp+harness);exe=BUILD/'readme_bounded_check'
subprocess.run(['g++','-std=c++11','-O2','-Wall','-Wextra','-Werror','-pedantic',str(source),'-o',str(exe)],check=True)
cpp_output=subprocess.check_output([str(exe)],text=True);cpp_stats=json.loads(cpp_output.splitlines()[-1]);print(cpp_output,end='')
cmp={k:np.zeros(3) for k in ['b','sigma','lo','hi','gap','q']};cmp.update(mask=np.array([False,True,False]),shape='rectangle',mu=np.zeros((3,2)),spread=np.zeros((3,2)),L=np.ones((3,2)))
cmp['b'][1]=2;cmp['sigma'][1]=3;cmp['lo'][1]=-60;cmp['hi'][1]=250;cmp['gap'][1]=1/.015;cmp['q'][1]=.25
cmp['mu'][1]=np.log([100,15]);cmp['spread'][1]=[.35,.2];cmp['L'][1]=[17,3]
large=generate(cmp,1000000,np.random.default_rng(789))[:,1]
assert abs(large.mean()-cpp_stats['mean'])<1 and abs(large.std()-cpp_stats['std'])/large.std()<.05
# Independent initial-time occupancy check: unequal widths must use length-biased signs.
initial={k:(v.copy() if isinstance(v,np.ndarray) else v) for k,v in cmp.items()}
initial['sigma'][1]=0;initial['mu'][1]=np.log([10,2]);initial['spread'][1]=0
phase_rng=np.random.default_rng(345)
first=np.array([generate(initial,1,phase_rng)[0,1] for _ in range(6000)])
cycle=initial['gap'][1]+np.dot([1-initial['q'][1],initial['q'][1]],initial['L'][1])
assert abs(np.mean(first>2)-.75*17/cycle)<.012 and abs(np.mean(first<2)-.25*3/cycle)<.006
report={'status':'PASS','scope':'Independent Python numerical reference and executed actual README C++; NOT MATLAB execution',
 'recovery':recovery,'synthetic_comparison':{'new_histogram_TV':float(new_tv),'old_histogram_TV':float(old_tv),
 'measured_negative_occupancy':float(ref_occ),'new_negative_occupancy':float(new_occ),'old_negative_occupancy':float(old_occ),'new_PSD_RMSE_dB':float(new_psd_error),'old_PSD_RMSE_dB':float(old_psd_error)},
 'cpp_stats':cpp_stats,'python_matching_mean':float(large.mean()),'python_matching_std':float(large.std()),
 'checks':['separate signed level laws/widths','bounded likelihood fits including strongly truncated cases','rate-based quiet gap','all generated samples in bounds',
 'no endpoint clipping atoms','rare/missing sign class','zero quiet scale','stationary duration-biased pulse initialization',
 'actual README C++ compiled and executed','Python/C++ statistical agreement','all package references resolve','six-tile summaries','no exporter']}
(BUILD/'Bounded_Validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
# Six-panel reference illustration, explicitly synthetic and not MATLAB graphics.
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axs=plt.subplots(2,3,figsize=(15,8.5),layout='constrained');time=np.arange(n)/FS;x=new[0][:,j]
axs[0,0].plot(time,raw[:,j],'k',lw=.5,label='Synthetic measured');axs[0,0].plot(time,x,color='firebrick',lw=.5,label='New generated')
axs[0,0].set(title='S1: bounded asymmetric pulse histories',xlabel='Elapsed [s]',ylabel='Error [µg]')
axs[0,1].hist(raw[:,j],finite_edges,density=True,histtype='step',color='k',label='Measured')
axs[0,1].hist(x,finite_edges,density=True,histtype='step',color='firebrick',label='New model')
axs[0,1].set(title='S2: amplitude density',xlabel='Error [µg]',ylabel='Density [1/µg]')
quietA=~reference_events['mask'];quietB=~new_events[0]['mask']
def longest(q):
 a=np.flatnonzero(np.diff(np.r_[False,q].astype(int))==1);b=np.flatnonzero(np.diff(np.r_[q,False].astype(int))==-1);k=np.argmax(b-a+1);return np.arange(a[k],b[k]+1)
qa,qb=longest(quietA),longest(quietB);count=min(100,len(qa),len(qb))
axs[0,2].plot(np.arange(count)/FS,raw[qa[:count],j],'k',lw=.7,label='Measured quiet')
axs[0,2].plot(np.arange(count)/FS,x[qb[:count]],color='firebrick',lw=.7,label='Generated quiet')
axs[0,2].set(title='S3: quiet background only',xlabel='Elapsed within segment [s]',ylabel='Error [µg]')
L=400
f,psd=welch(raw[:,j]-raw[:,j].mean(),fs=FS,window=np.hamming(L),noverlap=200,nfft=512,detrend=False)
new_psd=np.mean([welch(z[:,j]-z[:,j].mean(),fs=FS,window=np.hamming(L),noverlap=200,nfft=512,detrend=False)[1] for z in new],axis=0)
axs[1,0].loglog(f[1:],psd[1:],'k',label='Measured');axs[1,0].loglog(f[1:],new_psd[1:],color='firebrick',label='New ensemble mean')
axs[1,0].set(title='S4: AC Welch PSD',xlabel='Frequency [Hz]',ylabel='PSD [µg²/Hz]')
refV,refP=endpoints(raw,1000);modelEnd=[endpoints(z,1000) for z in new]
for ax,k,label,unit,ref in [(axs[1,1],0,'velocity','m/s',refV),(axs[1,2],1,'position','m',refP)]:
 for values,color,title in [(ref[:,j],'k','Measured windows'),(np.concatenate([z[k][:,j] for z in modelEnd]),'firebrick','Generated windows')]:
  values=np.sort(values);ax.step(np.r_[values[0],values],np.r_[0,np.arange(1,len(values)+1)/len(values)],where='post',color=color,label=title)
 ax.set(title=f'S{5 if k==0 else 6}: terminal {label} CDF, 5 s',xlabel=f'Error [{unit}]',ylabel='Cumulative probability',ylim=(0,1))
for ax in axs.flat:ax.grid(alpha=.2);ax.legend(fontsize=8)
fig.suptitle('SYNTHETIC bounded signed pulses — Python reference, NOT hardware / MATLAB execution',fontsize=12)
fig.savefig(BUILD/'Bounded_Summary_Preview.png',dpi=130);plt.close(fig)

# Focused density/power comparison preview, also synthetic only.
fig,axs=plt.subplots(2,3,figsize=(15,8.5),layout='constrained')
peaksNew=np.concatenate([e['peak'] for e in new_events]);peaksOld=np.concatenate([e['peak'] for e in old_events])
for ax,negative in [(axs[0,0],False),(axs[0,1],True)]:
 for a,color,label in [(reference_events['peak'],'k','Measured'),(peaksNew,'firebrick','New bounded'),(peaksOld,'steelblue','Previous shared')]:
  values=np.sort(-a[a<0] if negative else a[a>0])
  ax.step(np.r_[values[0],values],np.r_[0,np.arange(1,len(values)+1)/len(values)],where='post',color=color,label=label)
 ax.set(title='G2: negative peak magnitude' if negative else 'G1: positive peak magnitude',xlabel='Magnitude [µg]',ylabel='Cumulative probability',ylim=(0,1))
positions=np.arange(2);width=.25
for group,color,label,index in [(None,'black','Measured',-1),(new_events,'firebrick','New bounded',0),(old_events,'steelblue','Previous shared',1)]:
 if group is None:
  rates=np.array([np.sum(reference_events['peak']>0),np.sum(reference_events['peak']<0)])*FS/n;occ=reference_events['occupancy']
 else:
  rates=np.mean([[np.sum(e['peak']>0),np.sum(e['peak']<0)] for e in group],axis=0)*FS/n;occ=np.mean([e['occupancy'] for e in group],axis=0)
 axs[0,2].bar(positions+index*width,rates,width,color=color,label=label)
 axs[1,0].bar(positions+index*width,occ,width,color=color,label=label)
for ax,title,ylabel in [(axs[0,2],'G3: signed complete-event density','Events/s'),(axs[1,0],'G4: signed detected occupancy','Fraction of samples')]:
 ax.set(title=title,ylabel=ylabel,xticks=positions,xticklabels=['Positive','Negative'])
axs[1,1].semilogx(freq[1:],10*np.log10(new_psd[1:]/ref_psd[1:]),color='firebrick',label='New bounded')
axs[1,1].semilogx(freq[1:],10*np.log10(old_psd[1:]/ref_psd[1:]),color='steelblue',label='Previous shared');axs[1,1].axhline(0,color='k',ls=':')
axs[1,1].set(title='G5: PSD ratios relative to measured',xlabel='Frequency [Hz]',ylabel='Power ratio [dB]')
df=freq[1]-freq[0]
for index,(v,p,color,label) in enumerate([(raw[:,j].var(),ref_psd.sum()*df,'black','Measured'),(np.mean([z[:,j].var() for z in new]),new_psd.sum()*df,'firebrick','New bounded'),(np.mean([z.var() for z in old]),old_psd.sum()*df,'steelblue','Previous shared')]):
 axs[1,2].bar(positions+(index-1)*width,[v,p],width,color=color,label=label)
axs[1,2].set(title='G6: power / variance consistency',xticks=positions,xticklabels=['Time variance','Integrated Welch'],ylabel='Power [µg²]')
for ax in axs.flat:ax.grid(alpha=.2);ax.legend(fontsize=8)
fig.suptitle('ASYMMETRIC SYNTHETIC CHECK — smaller/shorter negatives; NOT a hardware result',fontsize=12)
fig.savefig(BUILD/'Bounded_Density_Power_Preview.png',dpi=130);plt.close(fig)
