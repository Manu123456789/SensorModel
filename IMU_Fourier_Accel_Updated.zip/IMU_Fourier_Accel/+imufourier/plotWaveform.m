function figs=plotWaveform(r)
% Aligned fit and circular boundary checks are separate from shifted ensembles.
figs=gobjects(0); names={'X','Y','Z'}; red=[.8 .15 .15]; m=r.model;
for j=find(m.selectedMask)
    f=figure('Name',['T_' names{j} '_Spike_and_Loop_Detail'],'NumberTitle','off', ...
        'Visible',r.cfg.figureVisible,'Position',[50 50 1500 850]); figs(end+1)=f; %#ok<AGROW>
    t=tiledlayout(f,2,3,'TileSpacing','compact','Padding','compact');
    a=r.train(:,j); b=r.fitInfo.fittedHistory(:,j); time=(0:numel(a)-1)'/m.Fs;
    ax=nexttile(t); plot(ax,time,a,'k','DisplayName','Fit record'); hold(ax,'on'); plot(ax,time,b,'Color',red,'DisplayName','Aligned Fourier fit');
    title(ax,'T1: aligned fitted history'); xlabel(ax,'Time [s]'); ylabel(ax,'Error [ug]'); legend(ax,'show'); grid(ax,'on');
    ax=nexttile(t); plot(ax,time,a-b); title(ax,'T2: aligned fit residual'); xlabel(ax,'Time [s]'); ylabel(ax,'Measured minus fit [ug]'); grid(ax,'on');
    [~,peak]=max(abs(a-m.baseline(j))); rows=max(1,peak-8):min(numel(a),peak+8);
    ax=nexttile(t); plot(ax,time(rows),a(rows),'ko-','DisplayName','Measured samples'); hold(ax,'on');
    plot(ax,time(rows),b(rows),'o-','Color',red,'DisplayName','Fourier samples');
    title(ax,'T3: largest spike, individual samples'); xlabel(ax,'Time [s]'); ylabel(ax,'Error [ug]'); legend(ax,'show'); grid(ax,'on');
    n=numel(a); L=min(12,n); rows=[n-L+1:n 1:L]; join=(-L:L-1)'/m.Fs;
    ax=nexttile(t); plot(ax,join,a(rows),'ko-','DisplayName','Measured circular join'); hold(ax,'on');
    plot(ax,join,b(rows),'o-','Color',red,'DisplayName','Fourier join'); xline(ax,0,'k:','HandleVisibility','off');
    title(ax,'T4: end-to-start seam, no smoothing'); xlabel(ax,'Time from restart [s]'); ylabel(ax,'Error [ug]'); legend(ax,'show'); grid(ax,'on');
    ax=nexttile(t); plot(ax,m.toneFreq{j},m.toneAmp{j},'.');
    title(ax,sprintf('T5: %d retained sinusoidal components',numel(m.toneFreq{j}))); xlabel(ax,'Frequency [Hz]'); ylabel(ax,'Amplitude [ug]'); grid(ax,'on');
    ax=nexttile(t); edges=imufourier.histogramEdges([r.reference(:,j);r.exampleGenerated(:,j)],r.cfg.histogramBins);
    histogram(ax,r.reference(:,j),edges,'Normalization','probability','DisplayStyle','stairs','DisplayName',r.referenceLabel); hold(ax,'on');
    histogram(ax,r.exampleGenerated(:,j),edges,'Normalization','probability','DisplayStyle','stairs','DisplayName','Run 1'); set(ax,'YScale','log');
    title(ax,'T6: first-history amplitude tail bins'); xlabel(ax,'Error [ug]'); ylabel(ax,'Probability/bin'); legend(ax,'show'); grid(ax,'on');
    title(t,'Full components match sampled points; reduced sums can ring and overshoot');
end
end
