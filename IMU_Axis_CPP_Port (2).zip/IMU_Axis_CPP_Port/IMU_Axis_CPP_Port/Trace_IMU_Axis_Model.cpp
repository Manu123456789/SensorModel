// OFFLINE CHECK ONLY: this program supplies its own Gaussian test source.
// Your SIM uses its existing rn_norm_limits through the callback instead.
// g++ -std=c++11 -O2 -DIMU_MODEL_FILE='"IMU_Axis_Model.cpp"' Trace_IMU_Axis_Model.cpp -o trace_imu
// ./trace_imu NUMBER_OF_SAMPLES SEED > CPP_Trace.csv
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <random>
#include <stdexcept>
#ifndef IMU_MODEL_FILE
#define IMU_MODEL_FILE "IMU_Axis_Model.cpp"
#endif
#include IMU_MODEL_FILE

struct OfflineNormal {
    std::mt19937 engine;
    std::normal_distribution<double> normal;
    explicit OfflineNormal(std::uint32_t seed):engine(seed),normal(0,1) {}
};
static double offline_normal(void* context)
{
    OfflineNormal& rng=*static_cast<OfflineNormal*>(context);
    return rng.normal(rng.engine);
}
int main(int argc,char** argv)
{
    if (argc!=3) { std::cerr<<"Usage: trace_imu sample_count seed\n"; return 2; }
    try {
        const std::uint64_t n=std::stoull(argv[1]);
        const std::uint32_t seed=static_cast<std::uint32_t>(std::stoul(argv[2]));
        if (!n) return 2;
        OfflineNormal gaussian(seed^0x85ebca6bu);
        imu_input.normal_draw=offline_normal; imu_input.normal_context=&gaussian;
        imu_input.sensor_dt_s=1/imu_axis_parameters.Fs;
        imu_input.event_seed=seed; imu_input.reset_model=true;
        std::cout<<std::setprecision(17)<<"Time_s,ErrorX_ug,ErrorY_ug,ErrorZ_ug\n";
        for (std::uint64_t k=0;k<n;++k) {
            imu_input.sensor_tick=k; IMU_error();
            if (imu_output.status!=ImuPortStatus::Ok) {
                std::cerr<<"Model not fitted, invalid parameters, or bad host binding.\n"; return 1;
            }
            std::cout<<static_cast<double>(k)/imu_axis_parameters.Fs;
            for (int j=0;j<3;++j) std::cout<<','<<imu_output.model_only_sensor_ug[j];
            std::cout<<'\n';
        }
    } catch (const std::exception& e) { std::cerr<<e.what()<<'\n'; return 2; }
}
