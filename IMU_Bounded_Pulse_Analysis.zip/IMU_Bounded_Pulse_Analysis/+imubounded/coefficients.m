function [axes,types,knots,gaps]=coefficients(m)
% Every runtime number is represented in these four tables; no source exporter.
names={'X','Y','Z'}; a={}; t={}; k={}; g={};
for j=find(m.selectedMask)
    p=m.pulseTypes{j}; E=sum([p.count]); active=sum([p.count].*[p.width]); K=sum(arrayfun(@(z)numel(z.knotRow),p));
    a(end+1,:)={names{j},j-1,m.Fs,m.blockSamples,m.blockSamples/m.Fs, ...
        m.bgMu(j),m.bgSigma(j),m.lower(j),m.upper(j),m.quietLower(j),m.quietUpper(j),m.releaseLower(j),m.releaseUpper(j), ...
        m.baseline(j),m.threshold(j),m.release(j),E,numel(p),K,numel(m.gapQuantiles{j}), ...
        E*m.Fs/m.blockSamples,active/m.blockSamples}; %#ok<AGROW>
    for i=1:numel(p)
        t(end+1,:)={names{j},i-1,p(i).count,p(i).width,p(i).sign,numel(p(i).knotRow),p(i).sourceEvent}; %#ok<AGROW>
        for h=1:numel(p(i).knotRow)
            k(end+1,:)={names{j},i-1,h-1,p(i).knotRow(h),p(i).knotValue(h)}; %#ok<AGROW>
        end
    end
    q=m.gapQuantiles{j};
    for i=1:numel(q), g(end+1,:)={names{j},i-1,(i-1)/(numel(q)-1),q(i)}; end %#ok<AGROW>
end
axes=cell2table(a,'VariableNames',{'SensorAxis','SensorIndex0','Fs_Hz','BlockSamples','Block_s', ...
    'QuietLocation_ug','QuietScale_ug','LowerBound_ug','UpperBound_ug','QuietLower_ug','QuietUpper_ug','ReleaseLower_ug','ReleaseUpper_ug', ...
    'DetectorBaseline_ug','Onset_ug','Release_ug','EventsPerBlock','PulseTypeCount','TotalKnotCount','GapQuantileCount', ...
    'ScheduledRate_Hz','ScheduledEventOccupancy'});
types=cell2table(t,'VariableNames',{'Axis','TypeIndex0','CountPerBlock','Width_samples','Sign','KnotCount','SourceEventIndex1'});
knots=cell2table(k,'VariableNames',{'Axis','TypeIndex0','KnotIndex0','Row0','Value_ug'});
gaps=cell2table(g,'VariableNames',{'Axis','QuantileIndex0','Probability','ExtraQuietSamples'});
end
