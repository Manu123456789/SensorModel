function A=boundedAmplitude(m,j,signIndex,stream)
if signIndex==1, cap=m.upper(j)-m.bgMu(j); else, cap=m.bgMu(j)-m.lower(j); end
mu=m.logMu(j,signIndex); sigma=m.logSigma(j,signIndex);
if sigma==0, A=min(cap,exp(mu));
else
    A=Inf;
    while ~isfinite(A) || A<=0 || A>cap
        logA=mu+sigma*randn(stream);
        if logA<=log(cap), A=exp(logA); end
    end
end
if signIndex==2, A=-A; end
end
