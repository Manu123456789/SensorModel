%% Run this script first. MATLAB R2021b+ and Signal Processing Toolbox.
suiteRoot=fileparts(mfilename('fullpath')); addpath(suiteRoot);
cfg=imupulse.defaults();
cfg.selectedAxes={'Y'};                 % {'X'}, {'Y'}, {'Z'}, or {'X','Y','Z'}
cfg.nRealizations=50;                    % Start here; use 200+ for final comparisons
cfg.fitFraction=.70;                     % Fit prefix, validate separate suffix
cfg.isSynthetic=true;
regenerate=false;                        % true enables the adjustable generator
if regenerate
    [T,Truth]=Generate_Sample_IMU(struct('Fs',200,'duration_s',120,'seed',42));
else
    T=readtable(fullfile(suiteRoot,'data','Sample_IMU_ft_s2.csv'));
end
results=imupulse.analyze(T,cfg);
imupulse.saveOutputs(results,fullfile(suiteRoot,'output'));

