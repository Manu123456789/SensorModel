function [rho,count]=maskedACF(x,quiet,lag)
% Center on each quiet subset's mean; preserve original indices and lag gaps.
rho=NaN(lag+1,1); count=zeros(lag+1,1);
if nnz(quiet)<2, return; end
z=(x-mean(x(quiet))).*quiet;
num=xcorr(z,lag,'none'); pairs=xcorr(double(quiet),lag,'none');
num=num(lag+1:end); count=max(0,round(pairs(lag+1:end)));
covariance=num./max(count,1);
if covariance(1)>0, rho=covariance/covariance(1); end
rho(count<30)=NaN;
end
