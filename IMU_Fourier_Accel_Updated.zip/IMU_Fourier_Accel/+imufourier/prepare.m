function d=prepare(T,c)
% Input row number and configured Fs are the ONLY clock. Read mapped rows only.
assert(istable(T)||istimetable(T),'Use the existing workspace table/timetable.');
names={'X','Y','Z'}; chosen=upper(string(c.selectedAxes)); visual=upper(string(c.histogramAxes));
assert(~isempty(chosen) && all(ismember(chosen,names)) && numel(unique(chosen))==numel(chosen));
assert(all(ismember(visual,names)) && numel(unique(visual))==numel(visual));
mask=ismember(names,chosen); histMask=ismember(names,visual); readMask=mask|histMask;
validateattributes(c.sampleRate_Hz,{'numeric'},{'scalar','real','finite','positive'});
w=c.rowWindow; assert(isnumeric(w) && isreal(w) && isequal(size(w),[1 2]) && ...
    isfinite(w(1)) && w(1)>=1 && w(1)==floor(w(1)) && w(2)>=w(1) && ...
    ((isfinite(w(2)) && w(2)==floor(w(2))) || w(2)==Inf),'rowWindow must be [first last], inclusive integer rows.');
first=w(1); last=min(w(2),height(T));
cumulative=ismember(c.inputMode,{'sample_sum_cm_s2','integral_cm_s'});
if cumulative, first=max(2,first); end
assert(last-first+1>=512,'Choose at least 512 reconstructed samples.');
sourceRows=(first:last)'; readRows=(first-double(cumulative):last)';
raw=zeros(numel(readRows),3); mapped={};
for j=find(readMask)
    name=char(string(c.columns.(names{j})));
    assert(~isempty(name) && ismember(name,T.Properties.VariableNames),['Missing mapped column for ' names{j} ': ' name]);
    v=T{readRows,{name}}; assert(isnumeric(v) && isreal(v) && isvector(v) && numel(v)==numel(readRows));
    raw(:,j)=double(v(:)); mapped{end+1}=name; %#ok<AGROW>
end
assert(numel(unique(mapped))==nnz(readMask),'Map each read sensor axis to a different column.');
switch c.inputMode
    case 'instantaneous_ft_s2', a=raw*.3048;
    case 'instantaneous_ms2', a=raw;
    case 'instantaneous_cm_s2', a=raw*.01;
    case 'instantaneous_ug', a=raw*9.80665e-6;
    case 'delta_velocity_ft_s', a=raw*.3048*c.sampleRate_Hz;
    case 'delta_velocity_ms', a=raw*c.sampleRate_Hz;
    case 'delta_velocity_cm_s', a=raw*.01*c.sampleRate_Hz;
    case 'sample_sum_cm_s2', a=diff(raw)*.01;
    case 'integral_cm_s', a=diff(raw)*.01*c.sampleRate_Hz;
    otherwise, error('Unknown inputMode. See README.');
end
assert(all(all(isfinite(a(:,mask)))),'Modeled channels must contain finite values; rows are not dropped.');
assert(isequal(size(c.baselineSensor_ms2),[1 3]) && all(isfinite(c.baselineSensor_ms2(mask))), ...
    'Specify the known TRUE physical input on modeled axes in baselineSensor_ms2.');
R=c.R_sensor_to_PLT; assert(isequal(size(R),[3 3]) && isreal(R) && all(isfinite(R(:))) && ...
    norm(R*R'-eye(3),'fro')<1e-6 && abs(det(R)-1)<1e-6,'Use a proper sensor-to-platform rotation.');
y=zeros(size(a)); y(:,mask)=(a(:,mask)-c.baselineSensor_ms2(mask))/9.80665e-6;
h=NaN(size(a)); h(:,histMask)=a(:,histMask)/.3048;
d=struct('y',y,'Fs',c.sampleRate_Hz,'t',(sourceRows-1)/c.sampleRate_Hz, ...
    'sourceRows',sourceRows,'mask',mask,'histMask',histMask,'histValues_ft_s2',h, ...
    'selectedAxes',{names(mask)},'histogramAxes',{names(histMask)});
end
