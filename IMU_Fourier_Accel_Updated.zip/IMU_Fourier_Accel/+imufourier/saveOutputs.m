function saveOutputs(r,folder)
if ~isfolder(folder), mkdir(folder); end
IMU_Results=rmfield(r,'figures'); FourierModel=r.model; %#ok<NASGU>
save(fullfile(folder,'IMU_Results.mat'),'IMU_Results','FourierModel','-v7.3');
for name={'Coefficients','ToneCoefficients','DetectionSummary','ValidationSummary', ...
        'SpectralSummary','TerminalWindows','DensitySummary','PowerSummary','BoundsSummary', ...
        'FitReview','TailSummary','HistogramSummary','ToneSweep','CumulativePower','AllanSummary','ToneValidation'}
    if width(r.(name{1}))>0, writetable(r.(name{1}),fullfile(folder,[name{1} '.csv'])); end
end
if r.cfg.writeHistoryCSVs
    writetable(r.Generated_sensor,fullfile(folder,'Generated_sensor_ug.csv'));
    writetable(r.Generated_PLT,fullfile(folder,'Generated_platform_ug.csv'));
end
fid=fopen(fullfile(folder,'Provenance.json'),'w'); assert(fid>=0); cleanup=onCleanup(@()fclose(fid));
fprintf(fid,'%s',jsonencode(struct('schemaVersion',1,'model',r.model.mode,'config',r.cfg, ...
    'referenceMode',r.referenceMode,'distinctModelRuns',r.distinctModelRuns,'phaseOffsetsSamples',r.phaseOffsets, ...
    'sourceRows',[r.input.sourceRows(1) r.input.sourceRows(end)]))); clear cleanup;
if r.cfg.saveFigures
    for k=1:numel(r.figures)
        path=fullfile(folder,r.figures(k).Name);
        exportgraphics(r.figures(k),[path '.png'],'Resolution',140); savefig(r.figures(k),[path '.fig']);
    end
end
fprintf('Saved Fourier coefficients, model and diagnostics to %s\n',folder);
end
