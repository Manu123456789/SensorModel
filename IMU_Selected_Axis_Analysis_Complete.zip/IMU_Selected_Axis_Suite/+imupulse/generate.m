function x=generate(m,n,stream)
% Same event-selection and row-overwrite semantics as the exported C++ model.
burn=m.burnInSamples; total=n+burn;
% Stationary initial latent state, then exact discrete OU/AR(1) recursion.
initial=randn(stream,1,3)*m.noiseFactor';
innovation=sqrt(1-m.gmPhi^2)*(randn(stream,total,3)*m.noiseFactor');
x=zeros(total,3);
for j=find(m.selectedMask)
    x(:,j)=filter(1,[1 -m.gmPhi],innovation(:,j),m.gmPhi*initial(j));
end
x=x+m.baseline;
cursor=1; previous=0;
while cursor<=total
    if previous==0 || ~m.useEventMarkov, probability=m.classFrequency;
    else, probability=m.transitionProbability(previous,:); end
    mark=find(rand(stream,1,1)<cumsum(probability),1);
    if isempty(mark), mark=find(probability>0,1,'last'); end
    pool=find(m.classes==mark); index=pool(1+floor(rand(stream,1,1)*numel(pool)));
    pulse=m.templates{index}; cursor=cursor+m.gapSamples(index);
    last=min(total,cursor+size(pulse,1)-1);
    if cursor<=total, x(cursor:last,:)=pulse(1:last-cursor+1,:)+m.baseline; end
    cursor=cursor+size(pulse,1); previous=mark;
end
x=x(burn+1:end,:); x(:,~m.selectedMask)=0;
end
