%% Run IMU_Acceleration_Bias_Template.m first to create Results_sensor.
% Keep this script and identify_imu_switch_model.m in the same folder/on path.
% Use SENSOR-frame errors; fitting rotated PLT axes and rotating again is wrong.
assert(exist('Results_sensor','var')==1,'Run the accelerometer processing script first.');
t = Results_sensor.Time_s;
error_sensor_ug = [Results_sensor.ErrorX_ug Results_sensor.ErrorY_ug Results_sensor.ErrorZ_ug];

options = struct;
options.ConfirmSamples = 1;         % Increase ONLY if rapid threshold chatter is noise
options.MinSeparationSigma = 4;     % Screening heuristic; inspect the fitted plots
options.MinSeparation_ug = 0;       % Optional minimum meaningful level difference
options.MinCompleteRuns = 2;       % At least 2 complete high + 2 complete low dwells
options.ManualLevels_ug = nan(3,2); % Optional approximate [low high] for each axis
options.MakePlots = true;
options.OutputDirectory = fileparts(mfilename('fullpath'));

% A flagged channel may be clipped. The fit reproduces the recorded readout;
% it cannot recover the unknown physical input beyond the sensor rail.
if ismember('LimitFlag',Results_sensor.Properties.VariableNames) && any(Results_sensor.LimitFlag)
    warning('Selected data contain limit flags; inspect the recorded levels before fitting.');
end
[switchModel,SwitchSummary,SwitchDetails] = identify_imu_switch_model(t,error_sensor_ug,options);
disp(SwitchSummary);
fprintf('Generated imu_switch_params.h, imu_switch_summary.csv, and imu_switch_fit.mat.\n');
fprintf('Copy imu_switch_params.h and imu_switch_model.hpp into your C++ project.\n');
