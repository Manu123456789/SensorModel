function [rows,values,y,error,limited]=compressPulse(x,baseline,onset,release,maxKnots,tolerance)
% Adaptive linear knots at integer rows. Mandatory extrema/topology override budget.
x=x(:); n=numel(x); [~,peak]=max(abs(x-baseline)); [~,low]=min(x); [~,high]=max(x);
rows=unique([1;n;peak;low;high]);
while true
    if n==1, y=x; else, y=interp1(rows,x(rows),(1:n)','linear'); end
    broken=abs(y-baseline)<=release | sign(y-baseline)~=sign(x-baseline);
    broken(1)=broken(1) | abs(y(1)-baseline)<onset;
    [error,worst]=max(abs(y-x));
    if any(broken)
        candidates=find(broken); [~,p]=max(abs(y(candidates)-x(candidates))); add=candidates(p);
    elseif error>tolerance && numel(rows)<maxKnots, add=worst;
    else, break;
    end
    assert(~ismember(add,rows),'Could not preserve pulse detection topology.');
    rows=sort([rows;add]);
end
values=x(rows); limited=numel(rows)>maxKnots || error>tolerance;
rows=rows-1; % ZERO-based exported integer sample rows.
end
