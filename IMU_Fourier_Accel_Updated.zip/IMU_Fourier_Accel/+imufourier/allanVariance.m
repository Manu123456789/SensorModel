function avar=allanVariance(x,m)
% Overlapping Allan variance, using the MathWorks N-2m second-difference formula.
% No Sensor Fusion Toolbox required. Rows=time, columns=channels; x is a rate.
% https://www.mathworks.com/help/fusion/ug/inertial-sensor-noise-analysis-using-allan-variance.html
% Subtracting a constant mean improves numerical conditioning; it does NOT
% remove the error mean from the actual generated signal or its integration.
if isvector(x), x=x(:); end
n=size(x,1); m=m(:);
assert(all(m>=1 & m==floor(m) & m<(n-1)/2),'Invalid Allan averaging factors.');
theta=cumsum(x-mean(x,1),1); avar=zeros(numel(m),size(x,2));
for k=1:numel(m)
    q=m(k);
    d=theta(1+2*q:n,:)-2*theta(1+q:n-q,:)+theta(1:n-2*q,:);
    avar(k,:)=sum(d.^2,1)/(2*q^2*(n-2*q));
end
end
