# Simple IMU pulse model: a few coefficients, the same diagnostic figures

This package estimates a small model from your existing workspace table or
timetable. It generates a selected accelerometer axis using white Gaussian
background noise plus randomly timed signed pulses. **There is no recorded
waveform catalog, C++ exporter, runtime CSV loader, or dependency on MATLAB
inside your C++ simulation.** Copy the coefficient values described below into
your existing C++ file.

Requirements: MATLAB R2021b+ and Signal Processing Toolbox (`pwelch`, `xcorr`).
No Statistics Toolbox is required. MATLAB/Octave were unavailable during
preparation; see `VALIDATION.md` for exactly what was and was not executed.

## 1. Run it on your test data

Put this folder on your MATLAB path or open `IMU_Config.m` and run it. All user
settings are in that ONE script. Your dataset is already in the workspace:

```matlab
cfg.workspaceVariable = 'MyImportedTimetable';
cfg.columns.X = 'My_X_Channel';
cfg.columns.Y = 'My_Y_Channel';
cfg.columns.Z = 'My_Z_Channel';
cfg.selectedAxes = {'Y'};               % Fit/generate sensor axis 2 only
cfg.histogramAxes = {'X','Y','Z'};       % Observed XYZ histograms
cfg.sampleRate_Hz = 1000;               % Actual acquisition rate
cfg.rowWindow = [1000 2000];            % INCLUSIVE ORIGINAL ROWS
cfg.baselineSensor_ms2 = [NaN 0 NaN];   % Example: Y has known zero true input
```

Supply your actual physical baseline, not the example zero if there is known
motion or gravity on that axis. The code converts the readout to acceleration,
subtracts this known true input, and models the resulting ERROR. Its quiet
error offset is estimated separately and retained. It does not subtract the
full-signal mean or remove spikes as outliers.

Run the script after editing. Main outputs in your workspace are:

```matlab
IMU_Results       % Model, reference, generated example, diagnostics, summaries
Coefficients      % Small table to use in C++
```

The script uses your existing variable directly with MATLAB copy-on-write. No
CSV is reimported. It reads only mapped channels in the union of selectedAxes and
histogramAxes and only the requested rows. Unneeded channels need not be mapped
if they are absent from BOTH selections. Names containing spaces are supported.

### Timing is defined by row number, with no input clock lookup

Original row k corresponds to `(k - 1)/cfg.sampleRate_Hz`. The row window is
inclusive. At 1000 Hz, rows 1000:2000 produce 1001 samples from 0.999 to 1.999 s.
Most plots display elapsed time relative to the beginning of the selected window
or reference portion. Timetable acquisition metadata is ignored for the clock.
Uniform sampling is assumed; this cannot detect missed samples or acquisition
jitter from row number alone. No rows with invalid modeled samples are silently
removed, because doing so would break the assumed clock.

`rowWindow=[1 Inf]` uses the whole available record. At least 512 reconstructed
samples are required. Use a representative interval containing enough pulses.
The minimum of five complete events only permits calculation; it is not a
statistically justified minimum for tail or rate validation.

### Input modes and cumulative records

- `instantaneous_ft_s2` (default), `instantaneous_ms2`, `instantaneous_cm_s2`,
  `instantaneous_ug`: one acceleration value per row.
- `sample_sum_cm_s2`: your channel is an UNWEIGHTED running sum of cm/s^2
  samples; a first difference recovers acceleration. No division by dt here.
- `integral_cm_s`: your channel is accumulated velocity in cm/s; first difference
  divided by dt recovers acceleration.

For cumulative modes the prior row is read for the first requested difference.
The reconstructed sample is labeled with the current original row. If the
window starts at row 1, output begins at row 2 because a prior sample is absent.
Do not select a cumulative mode merely because your simulation later integrates
acceleration. Select it only when the INPUT channel itself is cumulative.

### Optional runnable example

Set `cfg.useSyntheticExample=true` in the same main script. It creates 120 s of
XYZ data in ft/s^2 at 200 Hz, with independent white backgrounds and signed
rectangle pulses. Change the demo duration/rate in the config if desired.
The example is generated under this simple model's assumptions, so a successful
example demonstrates the workflow, not applicability to arbitrary hardware.

### One or multiple axes

Default: `cfg.selectedAxes={'Y'}`. You can select X, Z or more than one axis.
Each selected axis gets its OWN seven fitted numbers and is generated
independently. Unselected sensor outputs are exactly zero. This simple model
does not preserve cross-axis pulse coupling or background covariance; optional
Figure F exposes that limitation. Rotate the sensor vector afterward using
`cfg.R_sensor_to_PLT`. One sensor axis can contribute to multiple platform axes.

## 2. The model, and why it is smaller

For one selected sensor axis, all amplitudes below are expressed in micro-g:

```text
error[k] = quiet_mean + quiet_sigma * N(0,1) + pulse[k]
```

The background is white and remains present DURING pulses. The pulse has a
simple ideal shape and a random signed amplitude. It no longer reuses measured
samples. This is a deliberate change from the previous waveform-replacement
model, whose measured event templates already contained within-event texture.
Here the ideal pulse contains no such texture, so the Gaussian term is additive
throughout.

The seven independent fitted quantities are:

| Quantity | Meaning | Estimation |
|---|---|---|
| Quiet mean | Signed background offset | Mean of samples outside detected events |
| Quiet sigma | Background standard deviation | Population standard deviation of those quiet samples |
| Mean quiet gap | Mean samples between events | Mean of complete observed preceding quiet gaps |
| Log-peak mean | Center of positive pulse magnitudes in log units | Mean of ln(abs(detected signed peak)/1 micro-g) |
| Log-peak std | Spread of log magnitudes | Population std of the same logarithms |
| Negative probability | Fraction of negative events | Fraction of complete event peaks below zero |
| Fixed width | One duration for all generated pulses | Mean detected width, rounded to whole samples |

The background takes two numbers; there is no AR/ARMA/Gauss-Markov fit. If the
quiet ACF shows material memory, the white assumption is a limitation to review.
There is no automatic high-order fit hidden in the helpers.

### Positive magnitude, then a random sign

A pulse amplitude is drawn once per event:

```text
magnitude = exp(LogPeakMean + LogPeakStd * fresh_normal())   [micro-g]
sign      = -1 with probability NegativeProbability, else +1
amplitude = sign * magnitude
```

The lognormal distribution provides positive, variable magnitudes with two
parameters, without clipping Gaussian draws at zero. It is an engineering
starting assumption, NOT a finding that your hardware's peaks must be lognormal.
The sign is independent of magnitude. The same magnitude distribution is used
for both signs. If negative events have systematically smaller magnitudes, D1
can reveal that deficiency; this seven-parameter model does not hide separate
positive/negative amplitude fits.

The logarithm is taken on numeric magnitudes expressed in MICRO-G. Generate in
micro-g and convert the final signal to your sim's units. Do not multiply a
logarithmic coefficient by the acceleration conversion factor.

Peak estimates come from noisy, threshold-detected excursions. Detection misses
small events and measurement noise can inflate maxima. The estimates are simple
summary estimates; they are not a likelihood fit correcting for all detection
censoring or recovering a uniquely identifiable hidden physical process.

### Quiet gaps, duration, and event rate

Let G be the number of quiet samples BEFORE the next pulse. We use a geometric
distribution with support `1,2,3,...`, with:

```text
GapProbability = 1 / MeanQuietGap_samples
P(G=g) = (1-GapProbability)^(g-1) * GapProbability
```

A drawn gap is followed by one fixed-width pulse, then a new gap is drawn. Pulses
do not overlap, and at least one quiet sample separates generated events. Mean
event-start rate is `Fs / (MeanQuietGap_samples + PulseWidth_samples)`, NOT
`Fs*GapProbability` over the complete record, because pulse time also occupies
the record. Counts fluctuate between generated realizations.

This is memoryless quiet-gap timing. It does not preserve near-periodic timing,
clustering, sign sequences or a gap/amplitude relationship. If D3/D4/D6 show
those features, this simple model may be inadequate even if its histogram fits.

`PulseShape='rectangle'` is the default. A triangle is the only alternative:

```text
rectangle: shape[row] = 1
triangle:  shape[row] = min(row+1, L-row) / ceil(L/2)     row = 0 ... L-1
```

Both have unit peak, fixed support L, and no waveform arrays in a C++
implementation. The triangle has less area than a rectangle of the same peak
and width. For L=4 its weights are [0.5, 1, 1, 0.5]. Very short triangles have
few distinct levels and can look rectangular.

**Width here is fitted from detector support.** It is not a deconvolved physical
pulse duration. In particular, a threshold detector can trim triangle tails or
fragment low-amplitude events. Changing shape does not automatically correct
that bias. D2/D5 must be rechecked; exact distribution agreement is not promised.

### Initialization without burn-in or a waveform catalog

The code starts at a random stationary phase for this ideal renewal model.
With mean gap E[G] and fixed pulse length L, pulse occupancy is
`D=L/(E[G]+L)`. At initialization, start inside a pulse with probability D and
choose its row uniformly from 0 ... L-1; otherwise start quiet with a geometric
remaining gap. The geometric quiet distribution is memoryless, so this residual
quiet-gap rule is consistent with stationary sampling. Draw a fresh amplitude
if initialization lands inside a pulse.

This removes the need for a long discarded startup run. It follows from this
model's fixed width, memoryless gaps and independence assumptions; it is not a
statement that the real hardware process is stationary. Partial events at record
boundaries are excluded from complete-event comparisons.

## 3. Fitting, measured reference, and optional held-out data

By default `cfg.fitFraction=1.0`. The FULL selected record estimates the seven
numbers and is also the measured reference. Plots say **Measured
(fit/reference)**. This is an in-sample descriptive check, not evidence of
independent prediction. A3 compares the first and second halves of measured data
as a stability check; neither half is called held out in this mode.

For the previous validation arrangement, set `cfg.fitFraction=.70`. The first
70% fits the parameters; the final 30% is kept out of parameter estimation and
is labeled **Measured (held-out)** in comparisons. A3 then compares fit and
held-out portions. Contiguous portions are not automatically independent
experiments; consider separate measured runs for a final validation check.

The event detector uses per-axis hysteresis around an iteratively estimated quiet
baseline. Onset defaults to five robust scale units; release is two scale units,
limited below onset. The initial robust scale is `1.4826 * median absolute
deviation`. You can override the onset for a particular axis with
`manualThreshold_ug`. The final quiet mean/std use non-event samples. Thresholds
are fitted on the fit portion only, then reused on the reference and generated
signals. No separate detector is tuned to make generated events look better.

The fit requires complete pulses and observed quiet gaps. Boundary pulses and
left-censored initial gaps are excluded from the relevant statistics. Weak
pulses, saturated samples, changing baseline, sustained switching, or poor
threshold choices can all affect interpretation. Inspect A before interpreting
any apparent goodness in C/D/E/S. Configured true-input subtraction does not
remove unknown real motion or gravity changes; those can be mistaken for error.

## 4. Coefficient output: what to copy into C++

`Coefficients` in the workspace and `Coefficients.csv` in the output directory
have one row per modeled sensor axis.

| Column | Use |
|---|---|
| SensorAxis / SensorIndex0 | X/Y/Z; zero-based C++ axis index |
| Fs_Hz | Required discrete sensor update rate |
| QuietMean_ug | `b` in the C++ parameters below |
| QuietSigma_ug | `sigma` |
| MeanQuietGap_samples / MeanQuietGap_s | Interpretable mean quiet gap |
| GapProbability | `gapP` (derived from that mean) |
| LogPeakMean | `logMu` |
| LogPeakStd | `logSigma` |
| NegativeProbability | `negativeP` |
| PulseWidth_samples / PulseWidth_s | `width` and its duration |
| PulseShape | `triangle=false` for rectangle; true for triangle |
| ExpectedEventRate_Hz | Nominal model rate before redetection/boundary exclusions |
| ExpectedMean_ug / ExpectedStd_ug | Analytic full-model moments, useful for checks |
| ExpectedDutyFraction | Nominal fraction of time inside pulse support |

Seven quantities are independent; the table deliberately includes convenient
derived values and metadata too. C++ needs GapProbability rather than both gap
columns. The expected moments are not additional adjustable parameters. They
are derived from the lognormal moments and uniform pulse phase:

```text
EA  = exp(logMu + 0.5*logSigma^2)
EA2 = exp(2*logMu + 2*logSigma^2)
pulseMean = D*(1-2*negativeP)*EA*mean(shape)
mean = b + pulseMean
variance = sigma^2 + D*EA2*mean(shape^2) - pulseMean^2
```

There is NO automatic source exporter. Open the coefficient table and type its
values into your existing C++ constants. Keep sufficient digits; CSV records the
calculated values for review. You do not need the table file inside the sim.

## 5. Minimal C++ implementation using the coefficients

The following generator needs seven values, a shape flag, a little persistent
state, and your existing RNG callbacks. It returns instantaneous acceleration
error in micro-g. The normal callback must return a FRESH untruncated N(0,1)
value each call; the uniform callback must return a FRESH value in [0,1).
It uses standard C++ math only and calls no external process.

<!-- SIMPLE_CPP_BEGIN -->
```cpp
#include <algorithm>
#include <cmath>
#include <cstddef>

struct SimpleParams {
    double b, sigma, gapP, logMu, logSigma, negativeP;
    std::size_t width;
    bool triangle;
};
struct SimpleState {
    bool initialized=false, active=false;
    std::size_t gapLeft=0, row=0;
    double amplitude=0;
};
using Draw = double (*)();

std::size_t drawGap(const SimpleParams& p, Draw uniform01)
{
    if (p.gapP >= 1.0) return 1;
    return 1 + static_cast<std::size_t>(
        std::floor(std::log1p(-uniform01()) / std::log1p(-p.gapP)));
}
double drawAmplitude(const SimpleParams& p, Draw normal01, Draw uniform01)
{
    double a = std::exp(p.logMu + p.logSigma*normal01());
    return uniform01() < p.negativeP ? -a : a;
}
void resetSimple(const SimpleParams& p, SimpleState& s,
                 Draw normal01, Draw uniform01)
{
    s = SimpleState{};
    const double duty = p.width / (1.0/p.gapP + p.width);
    s.active = uniform01() < duty;
    if (s.active) {
        s.row = static_cast<std::size_t>(uniform01()*p.width);
        s.amplitude = drawAmplitude(p,normal01,uniform01);
    } else s.gapLeft = drawGap(p,uniform01);
    s.initialized = true;
}
double sampleSimple(const SimpleParams& p, SimpleState& s,
                    Draw normal01, Draw uniform01)
{
    if (!s.initialized) resetSimple(p,s,normal01,uniform01);
    double value = p.b + p.sigma*normal01();
    if (!s.active) {
        if (s.gapLeft > 0) { --s.gapLeft; return value; }
        s.active = true; s.row = 0;
        s.amplitude = drawAmplitude(p,normal01,uniform01);
    }
    const double shape = p.triangle
        ? std::min(s.row+1,p.width-s.row) / std::ceil(p.width/2.0)
        : 1.0;
    value += s.amplitude*shape;
    if (++s.row == p.width) {
        s.active = false; s.gapLeft = drawGap(p,uniform01);
    }
    return value;
}
```
<!-- SIMPLE_CPP_END -->

Validate the copied parameters once: all numeric values finite, sigma/logSigma
nonnegative, `0<gapP<=1`, `0<=negativeP<=1`, and width a positive integer.
Extreme log-amplitude spreads can overflow `exp`; do not silently clip the output
and then claim equivalence to the fitted model. These compact helpers assume
validated coefficients, independent valid callbacks, and one call per sensor
update. They do not implement a clock cache or host error-handling policy.

For physical sensor axis 2, the final integration resembles:

```cpp
// File constants: populate p from the selected Coefficients.csv row.
// Helpers above live in this same .cpp, below prototypes if desired.
// normalFromSim() and uniformFromSim() are your existing RNG adapters.
static SimpleState modelState;

// Once per SENSOR update, before the final XYZ loop:
double model_sensor_ug[3] = {0.0, 0.0, 0.0};
model_sensor_ug[1] = sampleSimple(p,modelState,normalFromSim,uniformFromSim);

// Rotate sensor -> platform using the SAME R as MATLAB.
for (int ii=0; ii<3; ++ii) {
    double model_platform_ug = 0.0;
    for (int jj=0; jj<3; ++jj)
        model_platform_ug += R_sensor_to_platform[ii][jj]*model_sensor_ug[jj];

    const double model_accel_ft_s2 = model_platform_ug * 9.80665e-6 / 0.3048;
    // Add model_accel_ft_s2 at an ACCELERATION-error interface.
    // OR add model_accel_ft_s2*sensor_dt_s to a DELTA-VELOCITY interface.
}
```

Set the index from SensorIndex0, not always 1 if a different sensor was fitted.
Use a proper rotation with `platform=R*sensor`. A matrix named sens2plat or its
transpose is correct only if its physical convention equals the MATLAB R.
One selected sensor component need not remain one selected platform component.

The returned sample already contains b AND the positive/negative pulse mean.
Do not add the same fitted quiet baseline or full-signal mean again. Remove the
old Gaussian component only for the modeled source, while retaining unrelated
errors. If your code's `noise[]` holds an RMS setting rather than a sampled
error, add this sample AFTER that RMS-to-noise calculation, not into the RMS.

Your attached gyro example differences current and previous noise. Do NOT
apply that operation to this instantaneous accelerometer error: it would create
edge differences, not the fitted acceleration or its integral. Add acceleration
before integration, or multiply by dt for the corresponding velocity increment.
Inject only one interface. Retain unrelated legacy cumulative-error paths where
they belong. The omitted host update/units determine the correct binding.

Use the fitted Fs; changing only the sim dt changes pulse widths and rates.
No extra sqrt(Fs) or 1/sqrt(dt) scaling is needed for QuietSigma_ug at the fitted
rate. A noise-density specification would be a different quantity.

Reuse your `rn_norm_limits` routine through normalFromSim if its samples really
satisfy N(0,1). Its name alone does not establish absence of clipping/truncation.
Each callback invocation must draw anew; pulse amplitudes and background need
independent normal draws. A separate uniform draw selects gaps, signs and phase.
Keep RNG seeds/state persistent, not re-seeded per sample. Reset modelState and
the appropriate RNG streams once per Monte Carlo run. Shared host RNG streams
will advance differently after adding these calls; separate stream state may
help isolate components if your host supports it.

Call the generator ONCE per discrete sensor tick, outside the XYZ loop. Solver
substeps and repeated calls at the same tick must not advance it again. Hold the
cached output between sensor ticks if your sim calls the function more often.
One state instance is required per modeled axis/sensor instance; independent
axes require independent draws. For exact run repeatability, reset both state
and RNG streams. MATLAB and C++ need statistical agreement, not matching samples
for the same numeric seed.

## 6. Diagnostic figures: same families, at most six tiles

For one modeled axis the package opens S, H, A, B, C, D and E. H can show all
three observed axes even when only one is modeled. Optional F checks independence
when more than one axis is modeled. Figures save as PNG and editable FIG.
Units on selected-model plots are ERROR micro-g after known-input subtraction;
H shows observed acceleration in ft/s^2. Do not compare their offsets without
accounting for that distinction.

### Figure S: six-panel presentation summary

| Tile | What it shows | What agreement means / what to inspect |
|---|---|---|
| S1 | Full measured/reference and generated-run-1 histories on common axes | Compare signs, typical heights, event density and offset; independent event times need not align |
| S2 | Amplitude density for the reference and generated run 1 on identical finite bins | Compare central width, offset and tails; density times bin width integrates to one |
| S3 | Contiguous quiet close-ups from each record | See the background without spike-dominated vertical scaling |
| S4 | Mean-removed Welch PSD: reference and generated ensemble mean | Compare distribution of fluctuation power over frequency |
| S5 | Terminal velocity-error CDFs for equal-duration windows | Compare integrated acceleration area and run-to-run variation at this horizon |
| S6 | Terminal position-error CDFs for those windows | Compare consequences of amplitude and timing together |

S2 deliberately uses one generated realization for exact common-range density;
C3 provides the ensemble probability range. Histogram shape depends on bin width:
a narrow central peak plus a tail supports a different behavior population but
does not by itself show pulse timing or prove a physical fault.

S3 chooses the longest DETECTED quiet run separately from the reference and
generated run 1. It compares the beginning of each over a common duration capped
by quietZoom_s (default 0.5 s). It never concatenates disconnected samples or
clips spikes to manufacture a noise floor. Each segment has its own elapsed zero.
Their absolute positions in S1 differ. The dotted line is the fitted quiet mean.
This selected visual example can be affected by classification and segment
choice; B is the fuller assumption check. If either run lacks two contiguous
quiet samples, the panel explains that it is unavailable.

S4 removes each record's mean only for the spectrum. This does not remove mean
from generated output or integration. Mean generated PSD is the arithmetic mean
in LINEAR power, not a mean in dB. A consistently low measured PSD can mean that
the model produces too much fluctuation power in that reference interval;
compare Std_ug and event rates before changing coefficients.

S5/S6 split the reference and EACH generated record into nonoverlapping windows
of summaryTerminalWindow_s, rounded to whole samples and capped to the record.
Each window starts with zero velocity/position error. Incomplete trailing windows
are omitted. An empirical CDF at x gives the fraction of endpoints <=x. The
legend reports window counts. A single measured window is a vertical endpoint
marker, not a measured distribution. Neighboring windows can remain dependent;
pooled generated windows share fixed coefficients. These are descriptive CDFs,
NOT independent-trial confidence intervals or mission-horizon predictions.
Shorter windows give more endpoints at a shorter horizon; longer windows give
fewer examples of longer-horizon effects. Do not stitch reset windows together
as one physical trajectory. TerminalWindows.csv records the actual horizon,
counts, omitted samples and 5th/50th/95th percentiles.

### Figure A: input and detection, not a generated-data comparison

**A1 — measured signal and red events.** Gray is the entire measured error;
red redraws detected event samples. Small background noise can look flat when
large spikes set the vertical scale. It has not been removed. The split line
appears only if an actual held-out suffix is enabled. Check that red identifies
your intended events; otherwise later comparisons are based on poor labels.

**A2 — threshold zoom.** Black and red SHOULD overlap: they are the same
measurement with event labels, not test and model traces. Blue onset and green
release levels show hysteresis. Near-continuous red can indicate overly sensitive
thresholds or an unsuitable baseline/model family; missing excursions suggest
thresholds that are too high. Zoom duration is configurable.

**A3 — measured portion histograms.** With fitFraction=1, compare first versus
second half of the measured record. With a held-out split, compare fit versus
held-out. These curves compare measurement against measurement, not generation.
Agreement supports similar amplitude occupancy across portions, but not timing
or stationarity of every relevant property. Log probability displays tails;
zero-count bins are not visible on the log axis.

**A4 — block mean.** Means of nonoverlapping blocks reveal offset/regime changes.
Preferentially positive pulses can raise block means without quiet bias drift.
Check A5 alongside A4 to distinguish possible changes in event activity from a
change in background level.

**A5 — block event-start rate.** Counts starts per block divided by actual block
duration. Large differences can arise from finite counts or nonstationary
activity. Regular bursts/clusters matter because the generated gap process is
memoryless. Boundary blocks may include events whose starts/ends cross blocks.

**A6 — original row and elapsed time.** A straight line verifies the constructed
mapping under the configured acquisition rate. It is not measured timing-jitter
or missing-sample detection. Source rows retain original indices after selection.

### Figure B: WHITE background checks (changed from the old Gauss-Markov suite)

**B1 — quiet amplitude histogram / Gaussian PDF.** Uses fit samples outside
detected events after subtracting the fitted quiet baseline. It supports a
Gaussian marginal if center, spread and tails match; symmetry alone is not
sufficient. Quiet classification is estimated, not ground truth. Near-zero
quiet variance is a degenerate case, not evidence for a Gaussian bell shape.

**B2 — Gaussian Q-Q.** Compares measured quiet quantiles with Gaussian quantiles.
A near-diagonal trend supports the assumed marginal. Tail curvature, asymmetry
or separated populations can reveal heavy tails, skewness, state switching or
missed pulses. No normality significance test is claimed.

**B3 — quiet fit ACF and WHITE target.** White target equals one at lag zero and
zero at every nonzero lag. Original sample positions are preserved across pulse
gaps. Each lag averages only valid quiet pairs and is hidden if fewer than 30
pairs are available. Quiet samples are centered on their own quiet mean for ACF
only. A substantial smooth decay, oscillation or other repeatable structure
indicates that the white assumption misses time dependence. Small wiggles can
be finite-record variation; there are no formal significance bounds here.

**B4 — adjacent quiet samples.** Uses consecutive original samples that are both
quiet, with equal axis scaling and a display subset if needed. A round cloud
suggests weak lag-one correlation; a diagonal ellipse suggests persistence.
One round cloud does not establish independence at other lags or normality.
Compare B3/B6 before deciding white noise is adequate.

**B5 — standardized quiet residuals.** Plots `(quiet-baseline)/sigma` against a
standard normal PDF. There is NO fitted AR predictor and these are not the old
Gauss-Markov innovations. Center near zero, width near one and suitable tails
support the amplitude scaling. B5 is intentionally the familiar Gaussian-scale
view; temporal whiteness must be checked separately.

**B6 — reference versus generated quiet ACF.** Compares reference quiet time
structure with the ensemble of redetected generated quiet portions. A meaningful
nonzero reference correlation absent from the white model is an unresolved
limitation. Pointwise ranges come from generated runs, not confidence limits for
the masked measured estimator. Reference quiet means are removed separately for
this ACF, so check amplitude plots for a baseline mismatch.

### Figure C: amplitude, spectrum and full-signal correlation

**C1/C2 — straight output histories.** Reference and generated run 1 use the
same vertical quantity but separate axes. Offsets, excursions and background
remain. Similar appearance is useful but cannot establish quantitative agreement.
Independent generated spike timestamps need not match measured timestamps.

**C3 — amplitude probability ensemble.** Black is the measured reference, red
the mean generated bin probability, shading the pointwise 5th-95th range. It
shows common occupancy and tails across full signals. The first and last bins
include underflow/overflow beyond the finite reference-bin span so total
probability is retained; their centers are display locations, not finite support
bounds. Check P001/P999/MaxAbs metrics for unseen extremes. This is probability
per bin, whereas S2 uses density for one realization. A histogram contains no
ordering information.

**C4 — Welch PSD ensemble.** Same window, overlap, NFFT and record length for
reference and model. Each record is demeaned; frequency zero is excluded on
log axes. The pointwise generated 5th-95th range is conditional on the fitted
numbers. It is neither a parameter interval nor a simultaneous spectral band.
A reference near the low edge everywhere may indicate excessive generated
fluctuation power, but one reference record can sit low by chance. Low-frequency
mismatch points toward timing/persistence/drift; a broad excess suggests total
variance or pulse energy/rate. A constant mean difference alone cannot explain
this mean-removed plot. Do not use arbitrary gain scaling to hide the cause.

**C5 — AC amplitude FFT.** One measured and one generated record, demeaned and
periodically Hann-windowed with coherent-gain normalization and a one-sided
amplitude convention. The exact spectrum will vary between stochastic runs.
Spectral lines can suggest periodic structure absent from memoryless gaps;
wide spectral content also follows from sharp finite pulses. FFT appearance
alone does not identify the physical source.

**C6 — full-signal ACF.** Biased autocorrelation normalized at zero lag, with each
record's mean removed. This checks timing-dependent behavior omitted by the
histogram, including pulse duration, repetition and clustering. Low variance can
make normalized correlation ill-defined; undefined values stay NaN, not zero.
Agreement does not establish higher-order temporal dependence.

### Figure D: event statistics and what the simple model may miss

The SAME detector and fitted thresholds process measured and generated signals.
Only complete detected events contribute to peak/width/area CDFs; censored gaps
are excluded individually. Generated CDFs pool events across runs, so records
with more events contribute more observations. They are not confidence bounds.

**D1 — signed peak CDF.** Tests sign balance and event magnitude distribution.
A systematic negative-side mismatch may expose the shared magnitude assumption.
A few extreme events give weak tail evidence; compare event counts too.

**D2 — duration CDF.** This is a particularly important limitation check: generated
NOMINAL pulse width is FIXED. Redetected widths can still vary due to background
noise, threshold trimming or fragmentation, but the model cannot reproduce a
broad intrinsic width distribution by construction. A visible mismatch may be
acceptable only if the intended system outputs are insensitive to it.

**D3 — preceding quiet-gap CDF.** Checks the memoryless geometric gap assumption.
A narrow observed range suggests more regular timing; a strong long tail or
bursts can require a different gap distribution. We match the mean, not the
entire empirical gap distribution. Detector gaps and nominal generated gaps can
differ when weak events are missed or noise adds labels.

**D4 — event-start-interval CDF.** Includes the preceding pulse duration plus
quiet gap. Agreement asks whether recurrence time is adequate, not merely mean
rate. Unlike a periodic square wave, generated intervals are random.

**D5 — signed pulse-area CDF.** Integrates excursion ABOVE the fitted quiet
baseline. Pulse area affects velocity error. Rectangle versus triangle changes
area at the same peak/width. Closely matching D1 but missing D5 means amplitude
agreement is not enough for accumulation. Detector boundary trimming can matter.

**D6 — gap versus absolute peak.** The simple generator makes gap and amplitude
independent. A clear measured relationship will not be reproduced deliberately.
Scatter clouds need not align pointwise. Inspect trends, range, and the number
of measured events before claiming either dependence or independence.

Also check signed event COUNTS/RATES in ValidationSummary.csv. Similar event CDFs
do not guarantee the correct number of events. Five allowed fit events are far
from enough to establish rare negative-event or tail statistics.

### Figure E: does keeping pulses matter to integrated error?

All integrations use full-rate samples, zero initial errors, acceleration held
constant over each sample interval, and SI outputs:

```text
v_next = v + a*dt
p_next = p + v*dt + 0.5*a*dt^2
```

**E1 — velocity histories.** Compares reference, pulse-model ensemble, a constant
equal to the FULL fit-data mean, and white Gaussian noise matched to the full
fit mean/std. Pulse-model shading gives its pointwise 5th-95th range; the Gaussian
comparison uses a blue mean and dashed percentile curves. A constant mean can
match a total velocity increment over the same fitting record but loses
realization variability and local excursions.

**E2 — position histories.** Early acceleration contributes to position over
more remaining time, so equal total pulse area or equal mean need not give equal
position error. Compare mean trend, spread and extremes over the relevant
horizon, not only the final average. These are open-loop diagnostics, not your
complete estimator/controller.

**E3/E4 — whole-record terminal CDFs.** Each generated record gives one endpoint;
its ensemble makes a CDF. The reference gives ONE endpoint at that horizon and
is shown as a dashed vertical marker. The constant comparison is another marker.
A marker inside a generated range is not a formal statistical acceptance test.
Unlike S5/S6, these use the whole reference duration, without window resets.

Integration display curves store up to maxIntegrationPlotPoints boundaries,
including the final boundary. Calculations, maxima and terminal statistics use
ALL full-rate samples. Only plotted integration histories are thinned, never
the data fed to the generator, spectra, event statistics or integration itself.
The full ensemble of raw histories is not stored: one full generated example,
ensemble statistics, pooled event data and compact integration histories are
retained. This keeps memory lower for large imported records.

### H and optional F

H contains observed readout histograms for configured visualization axes,
independent of which sensor axes are modeled. It is not a goodness-of-fit panel.
Unmodeled raw axes can look nonzero in H while their generated model components
are exactly zero. F compares measured and generated selected-axis correlation
and the measured quiet correlation against independence. Coupling in the real
sensor is a limitation of independently generated selected axes.

## 7. Practical reading of the earlier dataset observations

The following observations came from your report of the earlier suite; the raw
hardware record and resulting plots were not independently inspected here. They
are retained as review context, not as numerical validation of this NEW model.

| Your earlier observation | What to check in this simpler package |
|---|---|
| A1 mostly showed red spikes, little background | Background remains in gray but scale compresses it; S3 isolates a contiguous quiet view |
| A2 red lay on black | Expected: red labels the same measured samples, not a second generated trace |
| Fit and held-out histograms agreed | A3 supports amplitude consistency, not generated accuracy; defaults now label measured halves rather than inventing a held-out set |
| B3 decayed rapidly with small late oscillations | Rapid loss of memory supports trying white noise; nontrivial short-lag decay or repeatable oscillations are still mismatches to a white target |
| B4 was one round cloud | Consistent with weak adjacent-sample dependence; not proof of whiteness at all lags |
| B1/B5 looked symmetric and Gaussian | Encouraging marginal behavior; B5 now standardizes quiet residuals, not Gauss-Markov innovations |
| C3 was useful for model goodness | Still compares generated full-signal probabilities with the measured reference |
| Reference C4 lay near the low edge of model PSD | Recheck variance, pulse energy and rate; do not assume simplification has fixed it |
| D1-D6 agreed in the catalog model | This agreement must be established again: fixed width, ideal shape and memoryless gaps may lose some of it |

A smaller coefficient set is valuable only if it is adequate for your intended
system outputs. The code does not promise the same detailed fidelity as an
empirical catalog. Your current priorities are visual plausibility, amplitude
statistics, event counts/areas/timing, and velocity/position consequences. If
those are satisfactory, retain the simple model. If one fails materially, first
identify that failure, then add only the relevant parameter or structure.

## 8. Saved results and files

When saveResults=true the output directory contains:

- Coefficients.csv: the small runtime parameter table and useful derived moments.
- DetectionSummary.csv: complete fit-event counts, sign counts, quiet samples and thresholds.
- ValidationSummary.csv: measured metrics and generated ensemble mean/5th/95th values.
- SpectralSummary.csv: log-ratio PSD RMSE, ACF RMSE and binned total variation.
- TerminalWindows.csv: window-horizon endpoint comparison.
- Analysis.mat: results and SimpleModel. The model contains scalar coefficients,
  axis metadata and detector settings; no recorded event waveform arrays.
- Provenance.json: settings, source rows, reference mode and synthetic flag.
- PNG/FIG files when saveFigures=true. History CSVs are optional, off by default.

InsideModelRange in the validation table is a descriptive flag for one metric,
not a multivariate acceptance test. PSD/ACF/histogram error values have no
universal good-enough threshold. Use relevant engineering tolerances, data
coverage and system-level impact. Detector settings are diagnostic tools, not
extra values the C++ generator needs.

File layout: IMU_Config.m is the only user entry script, Generate_Example_IMU.m
is the optional demo, and +imusimple holds reusable helpers. Do not rename the
package folder or remove its leading plus. There are NO C++ source exporters
or generated-code files in this package; C++ guidance is contained in Section 5.

## 9. Evidence and references

The distribution choices below are a deliberately small engineering model.
References establish the mathematics, not that this sensor follows those laws.

- NIST, [Lognormal Distribution](https://www.itl.nist.gov/div898/handbook/eda/section3/eda3669.htm):
  log-domain parameter meaning and estimates. We apply that assumption to noisy
  detected magnitudes; detection truncation is not automatically corrected.
- MathWorks, [Geometric Distribution](https://www.mathworks.com/help/stats/geometric-distribution.html):
  the documented distribution counts failures starting at ZERO. Our quiet count
  is one plus that quantity, so its mean is 1/p rather than (1-p)/p. The package
  uses the inverse formula directly and requires no Statistics Toolbox.
- Brémaud, Massoulié and Ridolfi (2005), [Power spectra of random spike fields and related processes](https://doi.org/10.1239/aap/1134587756):
  general random-event/shot-noise spectral framework. Our nonoverlapping renewal
  pulses are not asserted to be Poisson events or a diagnosed hardware mechanism.
- MathWorks, [pwelch](https://www.mathworks.com/help/signal/ref/pwelch.html): Welch
  averaging and analytical PSD interval definitions. Our ensemble percentile
  bands are different from its optional analytical confidence limits.
- NIST, [Median Absolute Deviation](https://www.itl.nist.gov/div898/software/dataplot/refman2/auxillar/mad.htm):
  robust-scale definition. It does not justify every chosen detection multiplier.
- NIST, [Autocorrelation Plot](https://www.itl.nist.gov/div898/handbook/eda/section3/autocopl.htm):
  time-dependence diagnostics; formal complete-series confidence limits are not
  claimed for our masked quiet estimator.
- MathWorks, [Validating Models After Estimation](https://www.mathworks.com/help/ident/ug/validating-models-after-estimation.html):
  estimation and validation-data distinction. Full-record fitting is the simple
  default, and is explicitly labeled in-sample.

Your Kasdin colored-noise paper is relevant if background correlation later
requires a filter. No such colored-noise method is implemented or needed for
this WHITE starting model. No paper PDFs or real measurement files are bundled.
