%% Edit IMU_Config.m, then set your imported table on the line below and run.
suiteRoot=fileparts(mfilename('fullpath')); addpath(suiteRoot);
cfg=IMU_Config();
T=YourImportedTable; % EDIT; or readtable('Your_IMU.xlsx','VariableNamingRule','preserve')
results=imupulse.analyze(T,cfg);
imupulse.saveOutputs(results,fullfile(suiteRoot,'output_hardware'));
