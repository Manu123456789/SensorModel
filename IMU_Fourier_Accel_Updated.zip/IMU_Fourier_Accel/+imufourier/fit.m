function [m,info]=fit(x,fs,mask,c)
% A real finite record is represented by DC plus positive-frequency pairs.
% No windowing/zero padding: these coefficients reconstruct ORIGINAL samples.
n=size(x,1); available=floor(n/2);
m=struct('mode','phase_preserved_fourier','Fs',fs,'recordSamples',n, ...
    'period_s',n/fs,'selectedMask',mask,'phaseMode',c.phaseMode, ...
    'ambientMode',c.ambientMode,'mean_ug',zeros(1,3),'whiteSigma_ug',zeros(1,3), ...
    'toneBin',{cell(1,3)},'toneFreq',{cell(1,3)},'toneAmp',{cell(1,3)}, ...
    'tonePhase',{cell(1,3)},'baseline',zeros(1,3),'threshold',zeros(1,3), ...
    'release',zeros(1,3),'lower',zeros(1,3),'upper',zeros(1,3));
info=struct('quietMask',false(size(x)),'events',{cell(1,3)}, ...
    'fullFFT',{cell(1,3)},'rankedBins',{cell(1,3)},'residual',zeros(size(x)), ...
    'fittedHistory',zeros(size(x)),'fullReconRMSE',zeros(1,3), ...
    'availableTones',available,'quietResidualRMS',zeros(1,3),'quietResidualMean',zeros(1,3), ...
    'spikeResidualRMS',zeros(1,3),'retainedEnergy',zeros(1,3));
for j=find(mask)
    v=x(:,j); m.mean_ug(j)=mean(v); center=median(v);
    robustSigma=1.4826*median(abs(v-center));
    onset=max(c.detectSigma*robustSigma,32*eps(max(1,max(abs(v)))));
    if isfinite(c.manualThreshold_ug(j)), onset=c.manualThreshold_ug(j); end
    m.baseline(j)=center; m.threshold(j)=onset; m.release(j)=onset;
    m.lower(j)=min(v); m.upper(j)=max(v);
    F=fft(v-m.mean_ug(j)); bins=(1:available)';
    energy=2*abs(F(bins+1)/n).^2;
    if mod(n,2)==0, energy(end)=abs(real(F(n/2+1))/n)^2; end
    if strcmp(c.toneSelection,'energy')
        [~,order]=sort(energy,'descend'); ranked=bins(order);
    else, ranked=bins; end
    K=min(available,c.maxTones); chosen=sort(ranked(1:K));
    [frequency,amplitude,phase]=imufourier.fftToTones(F,chosen,fs);
    m.toneBin{j}=chosen; m.toneFreq{j}=frequency;
    m.toneAmp{j}=amplitude; m.tonePhase{j}=phase;
    info.fullFFT{j}=F; info.rankedBins{j}=ranked;
    info.fittedHistory(:,j)=m.mean_ug(j)+imufourier.fromBins(F,chosen);
    info.residual(:,j)=v-info.fittedHistory(:,j);
    exact=m.mean_ug(j)+imufourier.fromBins(F,bins);
    info.fullReconRMSE(j)=sqrt(mean((v-exact).^2));
    info.retainedEnergy(j)=sum(energy(chosen))/max(sum(energy),realmin);
    info.quietMask(:,j)=abs(v-center)<onset;
    q=info.residual(info.quietMask(:,j),j);
    if ~isempty(q)
        info.quietResidualRMS(j)=sqrt(mean(q.^2)); info.quietResidualMean(j)=mean(q);
    end
    spike=info.residual(~info.quietMask(:,j),j);
    if ~isempty(spike), info.spikeResidualRMS(j)=sqrt(mean(spike.^2)); end
    if strcmp(c.ambientMode,'white')
        assert(numel(q)>=30,'Need at least 30 quiet residual samples to fit ambient white noise.');
        % Keep global fitted mean ONCE. Do not add residual mean as another bias.
        m.whiteSigma_ug(j)=std(q,1);
        % Suppress only numerical roundoff, not meaningful residual variance.
        if m.whiteSigma_ug(j)<100*eps(max(1,max(abs(v)))), m.whiteSigma_ug(j)=0; end
    end
end
info.events=imufourier.eventStats(x,m);
end
