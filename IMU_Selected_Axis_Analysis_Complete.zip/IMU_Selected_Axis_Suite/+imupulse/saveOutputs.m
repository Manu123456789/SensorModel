function saveOutputs(r,outputFolder)
% Save one complete analysis plus tables, plots, metadata and C++ candidate.
if ~isfolder(outputFolder), mkdir(outputFolder); end
PulseModel=r.model; %#ok<NASGU>
results=rmfield(r,'figures'); %#ok<NASGU>
save(fullfile(outputFolder,'Analysis.mat'),'results','PulseModel','-v7.3');
names={'ValidationSummary','SpectralSummary','Summary_PLT','Readiness', ...
    'Generated_sensor','Generated_PLT','History_sensor'};
for k=1:numel(names), writetable(r.(names{k}),fullfile(outputFolder,[names{k} '.csv'])); end
history=r.Generated_sensor;
history{:,2:4}=history{:,2:4}*(1e-6*9.80665/.3048);
history.Properties.VariableNames={'Time','ErrorX_ft_s2','ErrorY_ft_s2','ErrorZ_ft_s2'};
writetable(history,fullfile(outputFolder,'Generated_sensor_ft_s2.csv'));
m=r.model; lengths=cellfun(@(v)size(v,1),m.templates);
peaks=zeros(numel(lengths),3); areas=peaks;
for k=1:numel(lengths)
    pulse=m.templates{k}; areas(k,:)=sum(pulse,1)/m.Fs;
    for j=1:3, [~,where]=max(abs(pulse(:,j))); peaks(k,j)=pulse(where,j); end
end
catalog=table((1:numel(lengths))',m.trainingStart,m.trainingStop,lengths, ...
    m.gapSamples,m.classes,peaks(:,1),peaks(:,2),peaks(:,3),areas(:,1),areas(:,2),areas(:,3), ...
    'VariableNames',{'Event','TrainingStartIndex','TrainingStopIndex','LengthSamples', ...
    'PrecedingGapSamples','Class_Xpos_Xneg_Ypos_Yneg_Zpos_Zneg', ...
    'PeakX_ug','PeakY_ug','PeakZ_ug','AreaX_ug_s','AreaY_ug_s','AreaZ_ug_s'});
writetable(catalog,fullfile(outputFolder,'Training_Event_Catalog.csv'));
meta=struct('selectedSensorAxes',{r.input.selectedAxes},'sampleRate_Hz',m.Fs, ...
    'isSynthetic',r.cfg.isSynthetic,'status','Candidate: human review and system validation required', ...
    'R_sensor_to_PLT',r.cfg.R_sensor_to_PLT,'config',r.cfg);
fid=fopen(fullfile(outputFolder,'Provenance.json'),'w'); assert(fid>=0);
cleanup=onCleanup(@()fclose(fid)); fprintf(fid,'%s',jsonencode(meta)); clear cleanup;
suiteRoot=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(suiteRoot,'cpp'));
Export_IMU_Pulse_To_CPP(m,fullfile(outputFolder,'Candidate_IMU_Model.cpp'));
if r.cfg.saveFigures
    for k=1:numel(r.figures)
        fig=r.figures(k); if ~isgraphics(fig), continue; end
        path=fullfile(outputFolder,fig.Name);
        exportgraphics(fig,[path '.png'],'Resolution',140); savefig(fig,[path '.fig']);
    end
end
fprintf('Saved candidate analysis and diagnostics: %s\n',outputFolder);
fprintf('Read README sections on each figure and C++ readiness before porting.\n');
end
