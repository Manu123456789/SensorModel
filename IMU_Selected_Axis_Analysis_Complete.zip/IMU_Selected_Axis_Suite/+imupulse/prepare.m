function d=prepare(T,c)
% Convert only SELECTED axes, preserve time, and set unused model inputs to zero.
assert(istable(T),'Input must be a MATLAB table.');
chosen=upper(string(c.selectedAxes)); chosen=chosen(:)';
assert(~isempty(chosen) && numel(unique(chosen))==numel(chosen) && ...
    all(ismember(chosen,["X","Y","Z"])),'Choose unique axes X, Y and/or Z.');
mask=ismember(["X","Y","Z"],chosen);
labels={'X','Y','Z'}; N=height(T);
assert(N>=512,'Need at least 512 table rows.');
assert(isstruct(c.columns) && isscalar(c.columns),'Use cfg.columns.X / Y / Z to map column names.');
timeName=string(c.timeColumn);
assert(isscalar(timeName) && ~ismissing(timeName),'timeColumn must be one name, or empty.');
inferred=strlength(timeName)==0;
if inferred
    validateattributes(c.sampleRate_Hz,{'numeric'},{'scalar','real','finite','positive'}, ...
        'imupulse.prepare','cfg.sampleRate_Hz');
    validateattributes(c.startTime_s,{'numeric'},{'scalar','real','finite'});
    t=c.startTime_s+(0:N-1)'/c.sampleRate_Hz;
    timeSource='row_count_and_rate';
else
    assert(ismember(char(timeName),T.Properties.VariableNames), ...
        ['Missing timestamp column: ' char(timeName)]);
    t=T.(char(timeName));
    assert(isnumeric(t) && isvector(t) && isreal(t),'Timestamps must be numeric seconds.');
    t=double(t(:)); timeSource='timestamp_column';
end
assert(numel(t)==N && all(isfinite(t)) && all(diff(t)>0), ...
    'Need finite, strictly increasing sample times; check sample rate and time offset.');
sourceRows=(1:N)'; raw=zeros(N,3); selectedNames=strings(0,1);
for j=find(mask)
    axis=labels{j};
    assert(isfield(c.columns,axis),['Set cfg.columns.' axis ' to your table column name.']);
    name=string(c.columns.(axis));
    assert(isscalar(name) && ~ismissing(name) && strlength(name)>0, ...
        ['Set cfg.columns.' axis ' to your selected table column name.']);
    name=char(name); assert(ismember(name,T.Properties.VariableNames), ...
        ['Missing selected column: ' name]);
    selectedNames(end+1,1)=string(name); %#ok<AGROW>
    v=T.(name); assert(isnumeric(v) && isvector(v) && isreal(v) && numel(v)==N, ...
        ['Selected column must be a numeric N-by-1 channel: ' name]);
    raw(:,j)=double(v(:));
end
assert(numel(unique(selectedNames))==nnz(mask),'Selected axes must map to distinct table columns.');
assert(isequal(size(c.window_s),[1 2]) && c.window_s(1)<c.window_s(2));
assert(isequal(size(c.baselineSensor_ms2),[1 3]) && ...
    all(isfinite(c.baselineSensor_ms2(mask))),'Supply known true baseline for SELECTED axes.');
R=c.R_sensor_to_PLT;
assert(isequal(size(R),[3 3]) && isreal(R) && all(isfinite(R(:))) && ...
    norm(R*R'-eye(3),'fro')<1e-6 && abs(det(R)-1)<1e-6, ...
    'R must be a proper sensor-to-platform rotation (orthonormal, determinant +1).');
assert(isequal(size(c.railLimitsInput),[3 2]) && ...
    all(c.railLimitsInput(:,1)<c.railLimitsInput(:,2)));
rail=any(raw(:,mask)<=c.railLimitsInput(mask,1)' | ...
    raw(:,mask)>=c.railLimitsInput(mask,2)',2);
left=t; right=t;
switch c.inputMode
    case 'instantaneous_ft_s2', a=raw*.3048;
    case 'instantaneous_cm_s2', a=raw*.01;
    case 'instantaneous_ms2', a=raw;
    case 'instantaneous_ug', a=raw*(1e-6*9.80665);
    case {'sample_sum_cm_s2','integral_cm_s'}
        a=diff(raw,1,1)*.01; left=t(1:end-1); right=t(2:end);
        rail=rail(1:end-1)|rail(2:end);
        if strcmp(c.inputMode,'integral_cm_s'), a=a./diff(t); end
        t=right; sourceRows=sourceRows(2:end);
    otherwise, error('Unknown inputMode. See defaults and README.');
end
use=left>=c.window_s(1) & right<=c.window_s(2);
t=t(use); a=a(use,:); rail=rail(use); sourceRows=sourceRows(use);
assert(numel(t)>=512 && all(all(isfinite(a(:,mask)))), ...
    'Selected interval needs >=512 finite selected-axis samples; do not delete gap rows.');
if inferred, fs=c.sampleRate_Hz; dt=1/fs; else, dt=median(diff(t)); fs=1/dt; end
assert(all(abs(diff(t)-dt)<=c.sampleIntervalTolerance*dt+32*eps(max(abs(t)))), ...
    'Nonuniform sample times or a gap. Choose one contiguous native-rate interval.');
if any(rail)
    assert(c.allowRailSamples, ...
        'Rail samples present: choose another interval or explicitly set allowRailSamples=true.');
    warning('Model will describe recorded clipping, not unknown acceleration beyond the rail.');
end
y=zeros(size(a)); y(:,mask)=(a(:,mask)-c.baselineSensor_ms2(mask))*(1e6/9.80665);
d=struct('t',t,'y',y,'Fs',fs,'dt',dt,'mask',mask,'rail',rail);
d.selectedAxes=labels(mask);
d.timeSource=timeSource; d.sourceRows=sourceRows;
end
