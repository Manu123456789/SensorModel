function rho=normalizeACF(covariance)
% Normalize ONCE at lag zero. Columns are sensor axes, rows are nonnegative lags.
rho=NaN(size(covariance));
for j=1:size(covariance,2)
    if isfinite(covariance(1,j)) && covariance(1,j)>0
        rho(:,j)=covariance(:,j)/covariance(1,j);
    end
end
end
