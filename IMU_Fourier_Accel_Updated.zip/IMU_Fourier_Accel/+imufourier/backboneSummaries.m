function [curves,allan,stats]=backboneSummaries(r)
% Measured / aligned tone-only / configured ensemble; means removed for AC metrics.
names={'X','Y','Z'}; rows={}; arows={}; srows={}; f=r.frequency_Hz;
Pmodel=mean(r.psd,3); ACFmodel=r.meanACF;
for j=find(r.model.selectedMask)
    Pt=r.tonePSD(:,j); Pr=r.referencePSD(:,j); Pm=Pmodel(:,j);
    Cr=cumtrapz(f,Pr); Ct=cumtrapz(f,Pt); Cm=cumtrapz(f,Pm);
    for k=1:numel(f)
        rows(end+1,:)={names{j},f(k),Cr(k),Ct(k),Cm(k)}; %#ok<AGROW>
    end
    for k=1:numel(r.allanTau_s)
        arows(end+1,:)={names{j},r.allanM(k),r.allanTau_s(k), ...
            sqrt(r.referenceAllanVariance(k,j)),sqrt(r.toneAllanVariance(k,j)), ...
            sqrt(mean(r.allanVariance(k,j,:),3))}; %#ok<AGROW>
    end
    ref=r.reference(:,j); tone=r.toneOnly(:,j);
    refRms=std(ref,1); toneRms=std(tone,1);
    stdRow=strcmp(r.metricNames,'Std_ug'); modelRms=sqrt(mean(r.metricValues(stdRow,j,:).^2,'all'));
    srows(end+1,:)={names{j},'AC_RMS_ug',refRms,toneRms,modelRms}; %#ok<AGROW>
    srows(end+1,:)={names{j},'IntegratedPSD_ug2',Cr(end),Ct(end),Cm(end)}; %#ok<AGROW>
    logRef=10*log10(max(Pr,realmin));
    srows(end+1,:)={names{j},'PSD_RMSE_dB',0, ...
        sqrt(mean((10*log10(max(Pt,realmin))-logRef).^2)), ...
        sqrt(mean((10*log10(max(Pm,realmin))-logRef).^2))}; %#ok<AGROW>
    denom=norm(Pr);
    srows(end+1,:)={names{j},'PSD_RelativeL2_pct',0, ...
        100*norm(Pt-Pr)/max(denom,realmin),100*norm(Pm-Pr)/max(denom,realmin)}; %#ok<AGROW>
    srows(end+1,:)={names{j},'ACF_RMSE',0, ...
        sqrt(mean((r.toneACF(:,j)-r.referenceACF(:,j)).^2)), ...
        sqrt(mean((ACFmodel(:,j)-r.referenceACF(:,j)).^2))}; %#ok<AGROW>
    ar=sqrt(r.referenceAllanVariance(:,j)); at=sqrt(r.toneAllanVariance(:,j));
    am=sqrt(mean(r.allanVariance(:,j,:),3)); goodT=ar>0&at>0; goodM=ar>0&am>0;
    srows(end+1,:)={names{j},'Allan_RMSE_dB',0, ...
        sqrt(mean((20*log10(at(goodT))-20*log10(ar(goodT))).^2)), ...
        sqrt(mean((20*log10(am(goodM))-20*log10(ar(goodM))).^2))}; %#ok<AGROW>
end
curves=cell2table(rows,'VariableNames',{'Axis','Frequency_Hz','MeasuredPower_ug2','ToneOnlyPower_ug2','ModelMeanPower_ug2'});
allan=cell2table(arows,'VariableNames',{'Axis','AveragingSamples','Tau_s','MeasuredADEV_ug','ToneOnlyADEV_ug','ModelADEV_ug'});
stats=cell2table(srows,'VariableNames',{'Axis','Metric','Measured','ToneOnly','ConfiguredModel'});
end
