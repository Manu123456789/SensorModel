function e=detect(x,m)
% Independent per-axis hysteresis. Quiet is not created by stitching samples.
e=struct('mask',false(size(x)),'start',{cell(1,3)},'stop',{cell(1,3)});
for j=find(m.selectedMask)
    z=abs(x(:,j)-m.baseline(j)); active=false;
    for k=1:size(x,1)
        if ~active && z(k)>=m.threshold(j), active=true; end
        if active && z(k)<=m.release(j), active=false; end
        e.mask(k,j)=active;
    end
    e.start{j}=find(diff([false;e.mask(:,j)])==1);
    e.stop{j}=find(diff([e.mask(:,j);false])==-1);
end
end
