function [x,ledger]=generate(m,n,stream)
% Exact type counts per COMPLETE block; fresh quiet noise, event order and gaps.
x=zeros(n,3); ledger=cell(1,3);
for j=find(m.selectedMask)
    types=m.pulseTypes{j}; cursor=1; blocks={};
    while cursor<=n
        plan=imubounded.planBlock(m,j,stream); used=min(m.blockSamples,n-cursor+1);
        y=imubounded.boundedNormal(repmat(m.bgMu(j),used,1),m.bgSigma(j), ...
            m.quietLower(j),m.quietUpper(j),stream);
        % First sample of every quiet slot must release the previous pulse.
        quietRow=1;
        for h=1:numel(plan.gaps)
            if quietRow<=used
                y(quietRow)=imubounded.boundedNormal(m.bgMu(j),m.bgSigma(j), ...
                    m.releaseLower(j),m.releaseUpper(j),stream);
            end
            quietRow=quietRow+plan.gaps(h);
            if h<=numel(plan.order), quietRow=quietRow+types(plan.order(h)).width; end
        end
        row=1;
        for k=1:numel(plan.order)
            row=row+plan.gaps(k); t=types(plan.order(k));
            if row>used, break; end
            count=min(t.width,used-row+1);
            if t.width==1, z=t.knotValue;
            else, z=interp1(t.knotRow,t.knotValue,(0:count-1)','linear'); end
            y(row:row+count-1)=z; row=row+t.width;
        end
        x(cursor:cursor+used-1,j)=y; blocks{end+1}=plan; %#ok<AGROW>
        cursor=cursor+used;
    end
    ledger{j}=blocks;
    assert(all(isfinite(x(:,j))) && all(x(:,j)>=m.lower(j)&x(:,j)<=m.upper(j)), ...
        'Generated sample violated fit support.');
end
end
