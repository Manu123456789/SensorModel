function [T,H]=tailSummaries(r)
names={'X','Y','Z'}; rows={}; histrows={};
for j=find(r.model.selectedMask)
    a=r.reference(:,j); b=r.exampleGenerated(:,j); q=imufourier.percentile(a,[1 99]);
    rows(end+1,:)={names{j},q(1),q(2),mean(a<=q(1)),mean(b<=q(1)), ...
        mean(a>=q(2)),mean(b>=q(2)),min(a),min(b),max(a),max(b)}; %#ok<AGROW>
    for k=1:r.cfg.histogramBins
        values=reshape(r.histogram(k,j,:),[],1);
        histrows(end+1,:)={names{j},k,r.histCenters{j}(k),r.histReference(k,j), ...
            r.histogram(k,j,1),mean(values),nnz(values==0)/numel(values)}; %#ok<AGROW>
    end
end
T=cell2table(rows,'VariableNames',{'Axis','LowerTailThreshold_ug','UpperTailThreshold_ug', ...
    'MeasuredLowerFraction','Run1LowerFraction','MeasuredUpperFraction','Run1UpperFraction', ...
    'MeasuredMin_ug','Run1Min_ug','MeasuredMax_ug','Run1Max_ug'});
H=cell2table(histrows,'VariableNames',{'Axis','Bin','Center_ug','MeasuredProbability', ...
    'Run1Probability','EnsembleMeanProbability','FractionOfRunsWithEmptyBin'});
end
