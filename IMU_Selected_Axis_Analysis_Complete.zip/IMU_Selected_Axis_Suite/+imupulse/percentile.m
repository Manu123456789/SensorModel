function q=percentile(x,p)
% Linear interpolation on sorted finite values; no Statistics Toolbox required.
x=sort(x(isfinite(x))); p=double(p);
if isempty(x), q=NaN(size(p)); return; end
index=1+(numel(x)-1)*p(:)/100; lo=floor(index); hi=ceil(index);
q=x(lo).*(1-(index-lo))+x(hi).*(index-lo);
q=reshape(q,size(p));
end
