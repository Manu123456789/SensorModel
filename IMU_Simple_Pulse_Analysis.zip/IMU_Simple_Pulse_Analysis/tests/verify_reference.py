"""Optional numerical/reference check, NOT MATLAB execution.
Needs NumPy, SciPy, matplotlib and g++. No raw hardware data are used.
Run: python3 tests/verify_reference.py /path/to/scratch_build
"""
from pathlib import Path
import json
import math
import re
import subprocess
import sys
import numpy as np
from scipy.signal import welch

ROOT=Path(__file__).resolve().parents[1]
BUILD=Path(sys.argv[1]).resolve()
BUILD.mkdir(parents=True,exist_ok=True)
FS=200

def shape(kind,L):
    return np.ones(L) if kind=='rectangle' else np.minimum(np.arange(1,L+1),np.arange(L,0,-1))/math.ceil(L/2)

def generate(m,n,rng):
    x=np.zeros((n,3))
    for j in np.flatnonzero(m['mask']):
        x[:,j]=m['b'][j]+m['sigma'][j]*rng.standard_normal(n)
        L=int(m['L'][j]); w=shape(m['shape'],L); cursor=0
        def amplitude():
            a=np.exp(m['mu'][j]+m['spread'][j]*rng.standard_normal())
            return -a if rng.random()<m['negative'][j] else a
        if rng.random()<L/(L+m['gap'][j]):
            phase=int(rng.random()*L); count=min(n,L-phase)
            x[:count,j]+=amplitude()*w[phase:phase+count]; cursor=count
        p=1/m['gap'][j]
        while cursor<n:
            gap=1 if p>=1 else 1+int(np.floor(np.log1p(-rng.random())/np.log1p(-p)))
            cursor+=gap
            if cursor>=n: break
            count=min(L,n-cursor); x[cursor:cursor+count,j]+=amplitude()*w[:count]; cursor+=count
    return x

def detect(x,b,on,off):
    z=np.abs(x-b); active=False; mask=np.zeros(len(x),bool)
    for k in range(len(x)):
        if not active and z[k]>=on: active=True
        if active and z[k]<=off: active=False
        mask[k]=active
    a=np.flatnonzero(np.diff(np.r_[False,mask].astype(int))==1)
    b=np.flatnonzero(np.diff(np.r_[mask,False].astype(int))==-1)
    return mask,a,b

def fit(y,j):
    x=y[:,j]; b=np.median(x); robust=max(1.4826*np.median(abs(x-b)),np.finfo(float).eps)
    on=5*robust; off=min(2*robust,.8*on)
    for _ in range(10):
        mask,_,_=detect(x,b,on,off); new=x[~mask].mean(); change=abs(new-b)/robust; b=new
        if change<1e-6: break
    mask,a,z=detect(x,b,on,off); peaks=[]; lengths=[]; gaps=[]
    for first,last in zip(a,z):
        if first==0 or last==len(x)-1: continue
        e=x[first:last+1]-b; peaks.append(e[np.argmax(abs(e))]); lengths.append(last-first+1)
        prev=z[z<first]
        if len(prev): gaps.append(first-prev[-1]-1)
    logs=np.log(np.abs(peaks)); m={k:np.zeros(3) for k in ['b','sigma','gap','mu','spread','negative','L']}
    m.update(mask=np.arange(3)==j,shape='rectangle')
    m['b'][j]=b; m['sigma'][j]=np.std(x[~mask]); m['gap'][j]=np.mean(gaps)
    m['mu'][j]=logs.mean(); m['spread'][j]=logs.std(); m['negative'][j]=np.mean(np.array(peaks)<0)
    m['L'][j]=max(1,int(np.floor(np.mean(lengths)+.5)))
    return m,mask,on,off,len(peaks)

def moments(m,j):
    w=shape(m['shape'],int(m['L'][j])); duty=m['L'][j]/(m['L'][j]+m['gap'][j])
    ea=np.exp(m['mu'][j]+.5*m['spread'][j]**2); ea2=np.exp(2*m['mu'][j]+2*m['spread'][j]**2)
    pm=duty*(1-2*m['negative'][j])*ea*w.mean()
    return m['b'][j]+pm,np.sqrt(m['sigma'][j]**2+duty*ea2*np.mean(w*w)-pm*pm)

def endpoints(x,fs,L):
    W=len(x)//L; a=x[:W*L].reshape(W,L,3)*9.80665e-6
    v=np.concatenate([np.zeros((W,1,3)),np.cumsum(a,axis=1)/fs],axis=1)
    p=np.cumsum(v[:,:-1]/fs+.5*a/fs**2,axis=1)
    return v[:,-1],p[:,-1]

truth={'mask':np.ones(3,bool),'shape':'rectangle','b':np.array([3.,-5,2]),'sigma':np.array([3.,5,2]),
       'gap':FS*np.array([.8,1,.65]),'L':np.rint(FS*np.array([.06,.08,.05])),
       'mu':np.log([150,350,180]),'spread':np.array([.25,.3,.2]),'negative':np.array([.2,.25,.1])}
raw=generate(truth,FS*180,np.random.default_rng(42)); fitted={}; recovery={}
for j in range(3):
    m,quiet,on,off,count=fit(raw,j); fitted[j]=(m,quiet,on,off)
    sample=generate(m,12000,np.random.default_rng(123))
    assert np.all(sample[:,np.arange(3)!=j]==0)
    assert abs(m['b'][j]-truth['b'][j])<1 and abs(m['sigma'][j]-truth['sigma'][j])<.5
    assert abs(m['L'][j]-truth['L'][j])<=1 and abs(m['negative'][j]-truth['negative'][j])<.15
    assert abs(m['mu'][j]-truth['mu'][j])<.15 and abs(m['spread'][j]-truth['spread'][j])<.15
    recovery['XYZ'[j]]={'quiet_mean_ug':float(m['b'][j]),'quiet_sigma_ug':float(m['sigma'][j]),
                        'mean_gap_samples':float(m['gap'][j]),'width_samples':int(m['L'][j]),
                        'negative_probability':float(m['negative'][j]),'complete_fit_events':count}
# Analytical moments and stationary phase occupancy across many short records.
m=fitted[1][0]; theory_mean,theory_std=moments(m,1)
large=generate(m,1000000,np.random.default_rng(987))[:,1]
assert abs(large.mean()-theory_mean)<max(1,.08*abs(theory_mean))
assert abs(large.std()-theory_std)/theory_std<.05
first=np.array([generate(m,1,np.random.default_rng(k))[0,1] for k in range(10000)])
assert abs(first.mean()-theory_mean)<3
for L in range(1,12):
    w=shape('triangle',L); assert w.max()==1 and np.all(w>0) and np.array_equal(w,w[::-1])
x=np.zeros((23,3)); x[[0,19],1]=1; v,p=endpoints(x,10,10)
assert v.shape==(2,3) and abs(v[0,1]-v[1,1])<1e-15 and p[0,1]>p[1,1]
assert abs(p[0,1]-.95*9.80665e-7)<1e-15
# Package references and layout guards.
called=set()
for f in ROOT.rglob('*.m'): called.update(re.findall(r'imusimple\.(\w+)\s*\(',f.read_text()))
assert all((ROOT/'+imusimple'/f'{name}.m').exists() for name in called)
assert not list(ROOT.rglob('*.cpp')) and not list(ROOT.rglob('*Export*.m'))
assert 'rowWindow' in (ROOT/'IMU_Config.m').read_text() and 'window_s=' not in (ROOT/'IMU_Config.m').read_text()
assert 'assert(rows*cols<=6)' in (ROOT/'+imusimple/plotDiagnostics.m').read_text()
assert (ROOT/'+imusimple/plotSummary.m').read_text().count('ax=nexttile(t);')==6
# Compile the actual C++ generator printed in README, rather than a separate implementation.
readme=(ROOT/'README.md').read_text(); block=readme.split('<!-- SIMPLE_CPP_BEGIN -->')[1].split('<!-- SIMPLE_CPP_END -->')[0]
cpp=block.split('```cpp\n')[1].split('```')[0]
harness=r'''
#include <cassert>
#include <iostream>
#include <random>
static std::mt19937 ng(123), ug(456);
static std::normal_distribution<double> nd(0,1);
static std::uniform_real_distribution<double> ud(0,1);
double normalRng(){return nd(ng);} double uniformRng(){return ud(ug);}
double zeroNormal(){return 0;} double lateUniform(){return .999;}
int main(){
 SimpleParams p={3,0,1,std::log(10.),0,0,2,false}; SimpleState s;
 assert(sampleSimple(p,s,zeroNormal,lateUniform)==3);
 assert(std::abs(sampleSimple(p,s,zeroNormal,lateUniform)-13)<1e-12);
 assert(std::abs(sampleSimple(p,s,zeroNormal,lateUniform)-13)<1e-12);
 assert(sampleSimple(p,s,zeroNormal,lateUniform)==3);
 p.width=4;p.triangle=true;s=SimpleState{};
 const double expected[]={3,8,13,13,8,3};
 for(double e:expected) assert(std::abs(sampleSimple(p,s,zeroNormal,lateUniform)-e)<1e-12);
 p={2,3,.02,std::log(40.),.25,.2,8,false};s=SimpleState{};
 const int N=1000000;double sum=0,sq=0,pulse=0,starts=0;
 resetSimple(p,s,normalRng,uniformRng);
 for(int k=0;k<N;++k){
   pulse+=(s.active||s.gapLeft==0); starts+=(!s.active&&s.gapLeft==0);
   const double x=sampleSimple(p,s,normalRng,uniformRng);sum+=x;sq+=x*x;
 }
 const double d=p.width/(1/p.gapP+p.width),ea=std::exp(p.logMu+.5*p.logSigma*p.logSigma);
 const double ea2=std::exp(2*p.logMu+2*p.logSigma*p.logSigma),pm=d*(1-2*p.negativeP)*ea;
 const double mean=p.b+pm,var=p.sigma*p.sigma+d*ea2-pm*pm;
 assert(std::abs(sum/N-mean)<.2);
 assert(std::abs((sq/N-(sum/N)*(sum/N))-var)/var<.05);
 assert(std::abs(pulse/N-d)<.004);
 assert(std::abs(starts/N-1/(1/p.gapP+p.width))<.0005);
 std::cout<<"PASS README C++: pulse/gap boundaries, triangle shape, full mean/variance, duty, event rate.\n";
 std::cout<<"mean="<<sum/N<<", expected="<<mean<<", duty="<<pulse/N<<"\n";
}
'''
source=BUILD/'readme_generator_check.cpp'; source.write_text(cpp+harness)
exe=BUILD/'readme_generator_check'
subprocess.run(['g++','-std=c++11','-O2','-Wall','-Wextra','-Werror','-pedantic',str(source),'-o',str(exe)],check=True)
cpp_result=subprocess.check_output([str(exe)],text=True); print(cpp_result,end='')
report={'status':'PASS','scope':'Python numerical reference + executed C++ README excerpt; NOT MATLAB execution',
        'recovery':recovery,'analytic_mean_ug':float(theory_mean),'reference_large_mean_ug':float(large.mean()),
        'analytic_std_ug':float(theory_std),'reference_large_std_ug':float(large.std()),
        'cpp_result':cpp_result.strip(),'checks':['one-axis zero isolation','quiet mean/std recovery',
        'fixed-width and signed-event fitting','log-magnitude estimates','analytic full moments',
        'stationary short-record phase','triangle normalization','ZOH window resets','all MATLAB package calls resolve',
        'six-panel summary and layout guard','no C++ source/exporter artifacts in package']}
(BUILD/'Simple_Validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
# Synthetic six-tile illustration. Different RNGs; NOT a screenshot of MATLAB plots.
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
j=1; measured=raw[:,j]; rng=np.random.default_rng(1234)
runs=[generate(m,len(raw),rng) for _ in range(30)]
a=runs[0][:,j]; _,_,on,off=fitted[j]
quietA=~detect(measured,m['b'][j],on,off)[0]; quietB=~detect(a,m['b'][j],on,off)[0]
def longest(q):
 first=np.flatnonzero(np.diff(np.r_[False,q].astype(int))==1)
 last=np.flatnonzero(np.diff(np.r_[q,False].astype(int))==-1)
 k=np.argmax(last-first+1); return np.arange(first[k],last[k]+1)
qa,qb=longest(quietA),longest(quietB); count=min(100,len(qa),len(qb))
fig,axs=plt.subplots(2,3,figsize=(15,8.5),layout='constrained'); t=np.arange(len(raw))/FS
axs[0,0].plot(t,measured,'k',lw=.5,label='Synthetic measured reference')
axs[0,0].plot(t,a,color='firebrick',lw=.5,label='Generated run 1');axs[0,0].set(title='S1: full acceleration history',xlabel='Elapsed [s]',ylabel='Error [µg]')
edges=np.linspace(min(measured.min(),a.min()),max(measured.max(),a.max()),61)
axs[0,1].hist(measured,edges,density=True,histtype='step',color='k',label='Measured')
axs[0,1].hist(a,edges,density=True,histtype='step',color='firebrick',label='Generated')
axs[0,1].set(title='S2: amplitude density',xlabel='Error [µg]',ylabel='Density [1/µg]')
axs[0,2].plot(np.arange(count)/FS,measured[qa[:count]],'k',lw=.7,label='Measured quiet')
axs[0,2].plot(np.arange(count)/FS,a[qb[:count]],color='firebrick',lw=.7,label='Generated quiet')
axs[0,2].set(title='S3: contiguous quiet segments',xlabel='Elapsed within each segment [s]',ylabel='Error [µg]')
L=400;nfft=512
f,psd=welch(measured-measured.mean(),fs=FS,window=np.hamming(L),noverlap=L//2,nfft=nfft,detrend=False)
modelPSD=np.mean([welch(x[:,j]-x[:,j].mean(),fs=FS,window=np.hamming(L),noverlap=L//2,nfft=nfft,detrend=False)[1] for x in runs],axis=0)
axs[1,0].loglog(f[1:],psd[1:],'k',label='Measured');axs[1,0].loglog(f[1:],modelPSD[1:],color='firebrick',label='Generated mean')
axs[1,0].set(title='S4: AC Welch PSD',xlabel='Frequency [Hz]',ylabel='PSD [µg²/Hz]')
refV,refP=endpoints(raw,FS,1000)
modelEnd=[endpoints(x,FS,1000) for x in runs]
for ax,k,label,unit,ref in [(axs[1,1],0,'velocity','m/s',refV),(axs[1,2],1,'position','m',refP)]:
 for x,color,title in [(ref[:,j],'k','Measured windows'),(np.concatenate([e[k][:,j] for e in modelEnd]),'firebrick','Generated windows')]:
  x=np.sort(x);ax.step(np.r_[x[0],x],np.r_[0,np.arange(1,len(x)+1)/len(x)],where='post',color=color,label=title)
 ax.set(title=f'S{5 if k==0 else 6}: terminal {label} CDF, 5 s',xlabel=f'Final {label} error [{unit}]',ylabel='Cumulative probability',ylim=(0,1))
for ax in axs.flat: ax.grid(alpha=.2);ax.legend(fontsize=8)
fig.suptitle('SYNTHETIC white background + simple pulses — Python reference, NOT hardware / MATLAB execution',fontsize=12)
fig.savefig(BUILD/'Simple_Summary_Preview.png',dpi=130);plt.close(fig)
