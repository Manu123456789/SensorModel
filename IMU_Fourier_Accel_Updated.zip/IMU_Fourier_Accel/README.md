# Accelerometer sine-wave identification and complete C++ file

This package replaces the pulse generator with a phase-preserving Fourier sum:

`error(t) = fitted_mean + sum(A[j]*sin(2*pi*f[j]*t + phase[j])) + optional_white`.

It is built for very sharp, irregular measured spikes, including events lasting
one sample. The default keeps every unique AC Fourier component. At the original
sample rate, this reconstructs the finite measured record to numerical precision.
You can then reduce `maxTones` and inspect how much spike sharpness is lost.

There is no hardware record in this delivery. Your actual coefficients are
identified when you run the package on the existing workspace table/timetable.
The C++ initializer below is a clearly labeled 32-sample synthetic example, and
the evidence preview is also synthetic. Neither contains your fitted hardware data.

## Run the MATLAB package

1. Extract the ZIP; keep `+imufourier` beside `IMU_Config.m`.
2. Open `IMU_Config.m` and set the workspace variable, XYZ column mappings,
   selected sensor axis, acquisition rate, and inclusive original row window.
   If only Y exists, set both selectedAxes and histogramAxes to `{'Y'}`.
3. Select the actual input units. Set the known TRUE physical acceleration in
   `baselineSensor_ms2`; use zero if your data is already an error channel. Do
   not subtract the observed mean to remove gravity: the error offset must stay.
4. Enter your established sensor-to-platform rotation in `R_sensor_to_PLT`.
   Its numbers should match the C++ `frame_sens2plat_T` you already use.
5. First leave `maxTones=Inf`, `ambientMode='none'`, and `phaseMode='aligned'`.
   Run `IMU_Config.m`, inspect `FitReview` and the diagnostic plots, then try a
   finite tone count if you want a shorter sine sum.

No CSV is reloaded. No time column or timetable timestamps are read. Time is
constructed from the number of rows and Fs. No rows are dropped and no hidden
resampling is performed. MATLAB R2021b plus Signal Processing Toolbox is required
for Welch/ACF diagnostics. Statistics and Machine Learning Toolbox is not needed.

For a complete first demonstration, set `useSyntheticExample=true`. That input
contains irregular one-sample spikes, some three-sample peaks, and quiet noise.

## Important controls

| Config | Meaning |
|---|---|
| maxTones=Inf | Keep all floor(Nfit/2) unique AC components; DC is stored separately |
| maxTones=512, for example | Keep at most 512 components, preserving fitted phases |
| toneSelection='energy' | Keep the largest contributions to mean-square AC power; default |
| toneSelection='lowFrequency' | Keep the first K harmonics, which can smooth spikes strongly |
| ambientMode='none' | Add no fresh noise; retained Fourier components already contain measured ambient behavior |
| ambientMode='white' | Fit a zero-mean white standard deviation from the QUIET residual after reconstruction |
| phaseMode='aligned' | Start at the first fitted sample at model activation |
| phaseMode='randomCircularShift' | One common integer circular shift per activation/run; all tones share it |
| fitFraction=1 | Fit and compare the same row window; descriptive agreement |
| fitFraction=.7 | Fit the first 70% and compare periodic prediction with the final 30% |

A short isolated spike generally occupies many Fourier bins. Keeping only a few
largest spectral peaks can produce low broad peaks and ringing. The R figure and
ToneSweep table compare waveform error, extrema, histogram, PSD and event counts
as K grows. Small total RMS error alone does not guarantee correct rare peaks.

No analysis window or zero padding is applied to the identification FFT. A Welch
window is used only for diagnostics. The mean is retained once. Positive-frequency
conjugate pairs use doubled amplitudes; the even-length Nyquist term is not doubled.
Output phases are converted for `sin`, not copied as raw cosine-phase FFT angles.

## Outputs and coefficient transfer

MATLAB returns `IMU_Results.model` plus these two transfer tables:

| Output | C++ values |
|---|---|
| Coefficients | SensorAxis0, Fs_Hz, RecordSamples, MeanError_ug, WhiteSigma_ug, NumberOfTones, PhaseMode |
| ToneCoefficients | Frequency_Hz, Amplitude_ug, Phase_rad, ordered by ToneIndex0 |

For K retained tones, the numerical model has **3*K + 2 values**: frequencies,
amplitudes, sine phases, mean, and white sigma. Fs, record length, axis selection,
phase-start mode and the host interface units are additional settings. FFTBin0
and index labels are diagnostic/copy aids, not extra numbers needed by the loop.
With Inf and a long recording, K can be large. The direct runtime costs K sine
calls per sensor tick. Coefficient storage and runtime work must both be considered;
this version prioritizes a transparent implementation, not an optimized oscillator.

Copy with full numeric precision. These commands print comma-separated values
for the THREE array initializers in the COMPLETE file below:

```matlab
axisName = 'Y';
C = IMU_Results.Coefficients;
T = IMU_Results.ToneCoefficients;
C = C(strcmp(string(C.SensorAxis),axisName),:);
T = sortrows(T(strcmp(string(T.Axis),axisName),:),'ToneIndex0');
format long g
disp(C)
fprintf('FREQUENCIES: '); fprintf('%.17g, ',T.Frequency_Hz); fprintf('\n');
fprintf('AMPLITUDES:  '); fprintf('%.17g, ',T.Amplitude_ug); fprintf('\n');
fprintf('SINE PHASES: '); fprintf('%.17g, ',T.Phase_rad); fprintf('\n');
```

The trailing comma is valid in C++ array initializers. For zero tones, use `{0.0}`
for each array; the file uses a one-element storage fallback and evaluates no tones.
There is no C++ source exporter or coefficient loader. The MAT file preserves the
model and detailed fit data for analysis. The simulation needs only the constants.

## Complete single-file C++ implementation

The following block is **the entire file**, identical to
`cpp/Accel_Fourier_Error_Sensor.cpp`. It shows everything above `error_sensor()`
and everything inside it. There is no separate generator source/header to find.
The code uses your gyro function's section order and explicitly expands the
selected-axis replacement in the final loop. All model constants and the small
persistent clock are INSIDE the function, in the same parameter area as your gyro;
only the four includes go above it. There are no external helper types or model
callbacks to place elsewhere.

The few assumed HOST names must be bound to your real simulation. `delaythta(i)`
is retained only as the gyro reference spelling for the ideal ACCEL increment at
that location. It must not be an actual gyro angle in the accelerometer model.
`accel_frame_settings` represents your existing nine matrix right-hand sides;
retain those values and the established transpose. `accel_delta_output` represents
your existing accumulator/output assignment. The full accel source was not supplied,
so the legacy white-noise box is an explicit example: retain your actual legacy
formula in that same box if it differs. These host-binding edits are unavoidable
without claiming to know unsupplied simulation code.

**All old error terms must be in the PLATFORM frame and in the same final units
before the replacement.** If an error is already folded into the apparent ideal
increment, separate it into the legacy error vector too. The example assumes
that interface is delta velocity in ft/s per tick, consistent with your intended
delta-measurement architecture. Select the actual units at the constants near the
start of the file.

| Stage in the complete file | Units / action |
|---|---|
| Mean + sine sum + optional white | Acceleration error in micro-g, on the selected SENSOR axis |
| `ug_to_host_acceleration = 9.80665e-6/0.3048` | Converts micro-g to ft/s² |
| `model_output_is_delta_velocity = true` | Multiplies by the sensor dt once, giving ft/s per update |
| Existing `frame_sens2plat_T` loop | Converts the error vector into PLATFORM coordinates once |
| Final replacement and output assignment | Adds that platform delta-velocity error to the ideal increment; no further conversion or rotation |

For SI, set the scale to `9.80665e-6`; the resulting increment is m/s. For an
instantaneous acceleration measurement interface, set the delta-velocity flag
to false and use its actual acceleration units. The name `delta_measurement`
alone does not establish the physical units; confirm the existing accumulator.

```cpp
// ============================================================
// ACCELEROMETER TONE + OPTIONAL WHITE-NOISE ERROR MODEL
//
// Same section order and sine-loop structure as your gyro file.
// Model on the selected SENSOR axis (Y = index 1 in this example):
//   error_ug(t) = fitted_mean + sum A*sin(2*pi*f*t+phase)
//                 + white_noise_sigma*N(0,1).
//
// ACCEL CHANGES:
//  1. The new sum is acceleration error in micro-g.
//  2. Convert to your measurement units; multiply by dt ONCE for delta-v.
//  3. It replaces ALL old error on that sensor axis, including bias/RW.
//  4. Keep the old noise-difference/history path for the legacy model only.
//
// The numeric initializer is SYNTHETIC. Paste your actual MATLAB values.
// All model constants and persistent variables are INSIDE error_sensor(),
// beside the corresponding gyro sections. Only these includes go above it.
// ============================================================
#include <cmath>
#include <algorithm>
#include <cstdint>
#include <stdexcept>

void error_sensor()
{
    // ========================================================
    // Local Variables -- KEEP your existing accel declarations.
    // ========================================================
    double noise[3];
    double random_walk[3];
    double random_noise[3];
    double random_walk_noise[3];
    double delta_noise[3];
    double delta_measurement[3];

    // --------------------------------------------------------
    // Sensor / Platform Frame Variables -- SAME gyro names.
    // --------------------------------------------------------
    double frame_sens2plat[3][3];
    double frame_sens2plat_T[3][3];
    double noise_sensor_frame[3];
    double noise_platform_frame[3];
    double model_platform_frame[3] = {0.0,0.0,0.0}; // ADD.

    // ========================================================
    // TEST-DERIVED TONE MODEL PARAMETERS -- SAME location as gyro.
    // Paste Coefficients + ToneCoefficients values HERE.
    // Frequency: Hz. Amplitude/mean/white sigma: micro-g.
    // Phase: radians, already converted for std::sin().
    // Full Fourier contains measured ambient noise: sigma=0 by default.
    // ========================================================
    // BEGIN_FOURIER_COEFFICIENTS
    static const int modeled_sensor_axis = 1; // SENSOR Y; X=0, Y=1, Z=2.
    static const double model_Fs_Hz = 200.0;
    static const std::uint64_t model_record_samples = 32;
    static const int number_of_tones = 16;
    static const int tone_storage = number_of_tones>0 ? number_of_tones : 1;
    static const double fitted_error_mean_ug = 1.9906250000000001;
    static const double white_noise_sigma = 0.0;
    static const double tone_frequency[tone_storage] = {
        6.25, 12.5, 18.75, 25, 31.25, 37.5, 43.75, 50, 56.25, 62.5, 68.75, 75, 81.25, 87.5, 93.75, 100
    };
    static const double tone_amplitude[tone_storage] = {
        7.004455666208095, 4.3965707239554215, 7.7623287575349034, 4.6987739424769108, 5.0777031451080523, 7.0256512327511746, 1.5099677480766884, 9.0437500000000011, 1.5099677480766884, 7.0256512327511746, 5.0777031451080523, 4.6987739424769099, 7.7623287575349034, 4.3965707239554215, 7.004455666208095, 1.6906250000000003
    };
    static const double tone_phase[tone_storage] = {
        0.87177960082789241, -1.2189585366554927, -0.90864613009703676, -3.0028879265291648, -2.9871086195313872, 1.8535695835243846, 1.1231801990116299, 0, -1.1231801990116304, -1.8535695835243846, 2.9871086195313872, 3.0028879265291648, 0.90864613009703632, 1.2189585366554923, -0.87177960082789241, -1.5707963267948966
    };
    // END_FOURIER_COEFFICIENTS

    static const double two_pi = 6.283185307179586476925286766559;
    // ADD: select your real accumulator interface. Default delta-v [ft/s].
    static const bool model_output_is_delta_velocity = true;
    static const double ug_to_host_acceleration = 9.80665e-6/0.3048;
    // For SI acceleration/increments use 9.80665e-6 instead (no /.3048).
    // For instantaneous acceleration output set the bool above to false.
    static const bool randomize_record_start = false; // MATLAB aligned default.

    // ========================================================
    // ADD: small persistent clock / activation / run-reset section.
    // No AR/filter history, pulse scheduler or extra model source file.
    // Host names here follow the supplied accel snippet/reference layout:
    //   reset_model, sensor_tick, sensor_dt_s,
    //   use_test_accel_model, test_model_condition, test_model_start_time_s.
    // Bind them to the corresponding EXISTING host variables.
    // ========================================================
    static bool model_initialized = false;
    static bool was_model_enabled = false;
    static bool have_model_tick = false;
    static std::uint64_t model_sample = 0, start_offset = 0, previous_tick = 0;
    static double cached_model_error_ug = 0.0;
    static decltype(seed) phase_seed = {}; // Only for OPTIONAL random start.

    if (reset_model || !model_initialized)
    {
        was_model_enabled = false;
        have_model_tick = false;
        model_sample = 0;
        start_offset = 0;
        phase_seed = seed; // Copy existing run RNG state; consume no legacy draw.
        if (!(model_Fs_Hz>0.0) || !std::isfinite(model_Fs_Hz) ||
            model_record_samples==0 || modeled_sensor_axis<0 || modeled_sensor_axis>2 ||
            number_of_tones<0 || !std::isfinite(fitted_error_mean_ug) ||
            !std::isfinite(white_noise_sigma) || white_noise_sigma<0.0)
            throw std::runtime_error("Invalid accelerometer Fourier parameters");
        for (int j=0; j<number_of_tones; j++)
        {
            const double bin=tone_frequency[j]*double(model_record_samples)/model_Fs_Hz;
            if (!std::isfinite(tone_frequency[j]) || tone_frequency[j]<=0.0 ||
                tone_frequency[j]>model_Fs_Hz/2.0+1e-10 ||
                std::abs(bin-std::round(bin))>1e-7 ||
                !std::isfinite(tone_amplitude[j]) || tone_amplitude[j]<0.0 ||
                !std::isfinite(tone_phase[j]))
                throw std::runtime_error("Copy frequencies, amplitudes, phases and record length consistently");
        }
        model_initialized = true;
    }
    // As in your accel snippet, clear this owned flag once. If shared, retain
    // its clearing at the established host lifecycle point instead.
    reset_model = false;
    const bool model_enabled = use_test_accel_model
                            && test_model_condition
                            && global_time >= test_model_start_time_s;

    // ========================================================
    // SENSOR -> PLATFORM TRANSFORMATION MATRIX -- KEEP all 9 lines.
    // accel_frame_settings denotes the values already in your actual file.
    // Keep your original right-hand sides; the convention is unchanged.
    // ========================================================
    frame_sens2plat[0][0] = accel_frame_settings[0][0];
    frame_sens2plat[0][1] = accel_frame_settings[0][1];
    frame_sens2plat[0][2] = accel_frame_settings[0][2];
    frame_sens2plat[1][0] = accel_frame_settings[1][0];
    frame_sens2plat[1][1] = accel_frame_settings[1][1];
    frame_sens2plat[1][2] = accel_frame_settings[1][2];
    frame_sens2plat[2][0] = accel_frame_settings[2][0];
    frame_sens2plat[2][1] = accel_frame_settings[2][1];
    frame_sens2plat[2][2] = accel_frame_settings[2][2];

    // ========================================================
    // TRANSPOSE SENSOR -> PLATFORM MATRIX -- UNCHANGED.
    // ========================================================
    for (int i=0; i<3; i++)
    {
        for (int j=0; j<3; j++)
            frame_sens2plat_T[i][j] = frame_sens2plat[j][i];
    }

    // ========================================================
    // Existing Error Vector Calculations -- KEEP your ACCEL equivalent.
    // delaythta is the gyro reference spelling used as a positional alias
    // here. Bind it to the ideal ACCEL increment, not an actual gyro angle.
    // ========================================================
    error_vector_multiplier(xyz(0,0),delaythta(0),xyz(0,0));

    // ========================================================
    // Generate RNG Values for White Noise and Random Walk -- UNCHANGED.
    // The new white term reuses random_noise[selected axis], just like gyro.
    // It adds NO draws to this legacy stream. Assume UNIT normal draws.
    // ========================================================
    size = 3;
    rn_norm_limits(&seed,&size,&random_noise[0]);
    rn_norm_limits(&seed,&size,&random_walk_noise[0]);

    // ========================================================
    // KEEP YOUR EXISTING LEGACY ACCEL NOISE CALCULATION IN THIS BOX.
    // This filled example is ordinary per-axis white noise; the actual full
    // accel formula was not supplied. Retain its real formula if different.
    // Its existing noise-state units/scales must stay unchanged.
    // We keep this running for X/Z and for clean disable transitions.
    // ========================================================
    for (int i=0; i<3; i++)
        noise_sensor_frame[i] = accel_noise_sigma[i]*random_noise[i];
    for (int i=0; i<3; i++)
    {
        noise_platform_frame[i] = 0.0;
        for (int j=0; j<3; j++)
            noise_platform_frame[i] += frame_sens2plat_T[i][j]*noise_sensor_frame[j];
        noise[i] = noise_platform_frame[i]; // Preserve LEGACY noise[] history.
    }

    // ========================================================
    // GENERATE IDENTIFIED EXPLICIT TONES -- SAME gyro sine loop.
    // ADD: local sample clock matches MATLAB t=0 at the first fitted row.
    // global_time controls activation; the fitted record repeats every N/Fs.
    // ========================================================
    if (model_enabled && !was_model_enabled)
    {
        model_sample = 0;
        start_offset = 0;
        have_model_tick = false;
        if (randomize_record_start)
        {
            // Optional common circular shift. Separate seed preserves the
            // legacy stream. Phi(Z) needs UNTRUNCATED N(0,1); otherwise bind
            // your host's uniform routine at this line instead.
            decltype(size) one=1; double z=0.0;
            rn_norm_limits(&phase_seed,&one,&z);
            if (!std::isfinite(z)) throw std::runtime_error("Invalid phase draw");
            const double u=std::min(std::nextafter(1.0,0.0),0.5*std::erfc(-z/std::sqrt(2.0)));
            start_offset=std::min(model_record_samples-1,std::uint64_t(u*double(model_record_samples)));
        }
    }
    const bool new_model_tick = model_enabled
                            && (!have_model_tick || sensor_tick!=previous_tick);
    if (model_enabled)
    {
        if (!(sensor_dt_s>0.0) || !std::isfinite(sensor_dt_s) ||
            std::abs(sensor_dt_s*model_Fs_Hz-1.0)>1e-8)
            throw std::runtime_error("Accel model must update at fitted Fs");
        if (new_model_tick && have_model_tick && sensor_tick!=previous_tick+1)
            throw std::runtime_error("Skipped/backward model tick: reset or schedule missing samples");
    }
    const std::uint64_t wrapped_sample = (model_sample+start_offset)%model_record_samples;
    double sensor_time = double(wrapped_sample)/model_Fs_Hz;
    double sensor_axis_tones = 0.0;
    if (new_model_tick)
    {
        for (int j=0; j<number_of_tones; j++)
        {
            sensor_axis_tones += tone_amplitude[j]
                              * std::sin(two_pi*tone_frequency[j]*sensor_time+tone_phase[j]);
        }
    }

    // ========================================================
    // ADD WHITE STOCHASTIC NOISE -- SAME gyro architecture.
    // WhiteSigma_ug is zero by default because full Fourier already contains
    // the measured ambient noise. No AR/ARMA path or burn-in is involved.
    // ========================================================
    double sensor_axis_white_noise = white_noise_sigma*random_noise[modeled_sensor_axis];
    if (new_model_tick)
    {
        cached_model_error_ug = fitted_error_mean_ug
                             + sensor_axis_tones + sensor_axis_white_noise;
        model_sample = (model_sample+1)%model_record_samples;
        previous_tick = sensor_tick;
        have_model_tick = true;
    }
    double sensor_axis_noise = model_enabled ? cached_model_error_ug : 0.0;

    // ========================================================
    // Build SENSOR-FRAME Noise Vector -- SAME location as gyro.
    // ACCEL CHANGE: full error includes the fitted mean/bias ONCE.
    // Convert ug -> ft/s^2; multiply by dt ONCE for delta velocity [ft/s].
    // ========================================================
    double model_error_in_host_units = sensor_axis_noise*ug_to_host_acceleration;
    if (model_output_is_delta_velocity) model_error_in_host_units *= sensor_dt_s;
    noise_sensor_frame[0] = 0.0;
    noise_sensor_frame[1] = 0.0;
    noise_sensor_frame[2] = 0.0;
    noise_sensor_frame[modeled_sensor_axis] = model_error_in_host_units;

    // ========================================================
    // Transform SENSOR-FRAME Noise -> PLATFORM FRAME -- SAME loop.
    // ========================================================
    for (int i=0; i<3; i++)
    {
        noise_platform_frame[i] = 0.0;
        for (int j=0; j<3; j++)
            noise_platform_frame[i] += frame_sens2plat_T[i][j]*noise_sensor_frame[j];
    }

    // ========================================================
    // Assign Test-Derived Platform-Frame Error -- ACCEL CHANGE.
    // Store separately from LEGACY noise[]. The new acceleration sum must
    // BYPASS noise - previous_noise, which would differentiate the spikes.
    // ========================================================
    for (int i=0; i<3; i++)
        model_platform_frame[i] = noise_platform_frame[i];

    // ========================================================
    // Existing Accelerometer Random Walk -- KEEP original calculation.
    // Keep its convolution update at the original host location as well.
    // ========================================================
    for (int i=0; i<3; i++)
        random_walk[i] = random_walk_noise[i]+random_walk_convolution[i];

    // ========================================================
    // Calculate Final Sensor Delta / Measurement -- ACCEL CHANGE.
    // Gather ALL old errors first, in PLATFORM frame and final measurement
    // units. Continue the legacy noise difference even while overridden.
    // ========================================================
    double legacy_error_platform[3];
    for (int i=0; i<3; i++)
    {
        delta_noise[i] = noise[i]-internal_data.noise[i];
        legacy_error_platform[i] = bias(i)+other_error_terms(i)
                                 + delta_noise[i]+random_walk[i];
    }
    // R=sensor->platform. Dot(column selected of R, complete platform error)
    // extracts the old complete selected SENSOR-axis error, including bias/RW.
    double old_selected_sensor_error = 0.0;
    if (model_enabled)
        for (int i=0; i<3; i++)
            old_selected_sensor_error += frame_sens2plat_T[i][modeled_sensor_axis]
                                       * legacy_error_platform[i];

    for (int i=0; i<3; i++)
    {
        if (model_enabled)
        {
            const double old_selected_platform_error =
                frame_sens2plat_T[i][modeled_sensor_axis]*old_selected_sensor_error;
            delta_measurement[i] = delaythta(i) // KEEP ideal ACCEL increment.
                                 + legacy_error_platform[i]
                                 - old_selected_platform_error
                                 + model_platform_frame[i];
        }
        else
        {
            // EXACT original sum. Model disabled -> original behavior.
            delta_measurement[i] = delaythta(i)+bias(i)+other_error_terms(i)
                                 + delta_noise[i]+random_walk[i];
        }
        // KEEP legacy history even while enabled; no stale difference on exit.
        internal_data.noise[i] = noise[i];
        // KEEP your existing output/accumulator assignment at this location.
        accel_delta_output[i] = delta_measurement[i]; // Example host name only.
    }
    was_model_enabled = model_enabled;
    return;
}
```

## Meaning of the final measurement update

With an identity matrix and sensor Y selected, the enabled branch reduces to:

`Y measurement = ideal Y increment + fitted Fourier error increment`.

It completely removes the old sensor-Y bias, noise, random walk and other error
terms. Sensor X/Z retain their existing error contributions. For a rotated frame,
removing only platform index 1 would not accomplish a sensor-Y override. The file
projects the entire old platform error onto sensor Y, subtracts that contribution,
and inserts the new Y contribution through the same established matrix.

The old noise difference and history update continue for LEGACY noise only. The
new sum is acceleration error. For a delta-velocity interface it is multiplied by
dt once, then replaces the old complete axis error. Passing this acceleration
through `noise - previous_noise` would differentiate the spike waveform. Adding
old bias/random walk after the replacement would also defeat the override.

The original two RN calls and legacy RNG seed remain intact. Just like your gyro,
`white_noise_sigma * random_noise[modeled_sensor_axis]` reuses the existing selected
normal draw; it adds no draws to the legacy stream. Only the optional circular
start uses a separate seed copy, initialized from your existing run seed without
advancing it. There is no new RNG API or required model-seed variable. Verify
that `rn_norm_limits` returns unit normals with the required scaling. The optional
random-start adapter uses Phi(Z), requiring untruncated N(0,1); use your host uniform
routine at that marked line if needed. Keep the original run initialization and
legacy state/reset policy.

Call the function once per sensor update at fitted Fs. The model caches its own
duplicate tick but does not make the entire legacy function safe for duplicate
solver calls. Reset is once per run. Re-enabling restarts the model at its selected
initial phase. Concurrent simulation instances need separate model/RNG states;
the static-local example assumes one sequential sensor instance.

## Longer simulations, bounds and randomness

The Fourier backbone repeats with period **Nfit/Fs**. It continues for arbitrarily
many cycles without MATLAB, your original dataset, a pulse catalog or runtime I/O.
A common circular shift changes where the pattern starts, preserving relative
phases and spike structure. Independently randomized tone phases can preserve
Fourier power magnitudes while destroying the irregular spike pattern and its
amplitude distribution; this package does not do that.

With aligned phases and zero added white noise, the waveform is deterministic.
The analysis evaluates one distinct model history and reports that explicitly,
instead of pretending 25 identical histories provide an uncertainty estimate.
The independent mean-plus-Gaussian comparison still uses the requested ensemble.
Choose randomCircularShift or added residual white noise only if you want those
specific sources of run variability. Complete-period delta-velocity error with
zero added noise is fixed by the measured mean; shifting phases does not create
independent whole-period velocity outcomes. Position error can depend on ordering.

Full components reproduce original sample values within numerical precision.
A truncated sum can overshoot measured extrema, ring around spikes and broaden
one-sample events. A full Fourier interpolant may also overshoot BETWEEN the
original sample times; this model is intended to be evaluated at its fitted Fs.
Optional Gaussian additions are unbounded. No silent clipping or peak renormalizing
is performed. BoundsSummary reports excursions, with a small stated roundoff
tolerance. Change rate only by explicitly preparing/identifying at the target rate.

The end-to-start join is part of the periodic model. The T4 plot shows its actual
jump; it is not secretly tapered. A different global-time phase origin or a switch
mid-cycle is a scenario choice, not an identified long-term behavior.

## Diagnostic plot families

| Family | Checks |
|---|---|
| H | Original observed XYZ histograms |
| S | Six-panel history, histogram, quiet zoom, PSD, velocity/position window CDFs |
| A | Detection overlays, thresholds, measured subrecord stability, block rate/mean, row clock |
| B | Measured/generated quiet amplitudes, Q-Q, residual ACF, consecutive quiet pairs, residual white-noise fit, actual quiet ACF |
| C | Histories, amplitude bins, Welch PSD, FFT and full ACF |
| D | Signed peak, duration, gap, onset-interval and pulse-area CDFs; gap/peak scatter |
| E | Integrated velocity/position paths and whole-record endpoints; Gaussian and constant-mean comparisons |
| G | Signed peaks, counts/occupancy, PSD ratio and integrated-power consistency |
| T | Aligned residual, largest-spike samples, retained amplitudes, tails and cycle seam |
| R | Aligned FIT-record tone-count sweep: RMSE, maximum error, extrema, PSD, histogram and event counts |
| V | Measured / aligned tones / configured ensemble: PSD, cumulative PSD power, covariance-first ACF, Allan deviation, AC RMS and amplitude distribution |
| F, multi-axis | Cross-axis checks; one common shift preserves relative axis phase, white additions are independent |

The detector is only a diagnostic tool; it does not prescribe generated counts
or pulse shapes. It uses same-sign contiguous runs beyond a robust deviation
threshold. Events touching analysis boundaries are censored for complete-event
statistics. Check A plots before judging counts. Welch settings are identical for
measured/generated data, with each record's mean removed; PSD units are ug^2/Hz.
The new V family retains a separate aligned, zero-added-noise tone-only curve
using the identified coefficients. The configured model uses its actual fitted
white sigma; no nonzero noise floor is imposed. For the full-signal C6/V3 ACF,
each realization is centered and its biased covariance is computed with divisor
N; the covariances are averaged, then normalized once at zero lag. The C6
percentile bands still describe individual normalized ACFs. Quiet masked ACF
plots retain their existing gaps-preserving estimator.

V2 and `CumulativePower.csv` use `cumtrapz(f,PSD)`; their final value equals the
`trapz` integrated Welch power in the summaries. PSDs are averaged in linear
power, never in dB. V4 and `AllanSummary.csv` use overlapping Allan variance from
the cumulative-signal second difference with N-2m pairs. For an ensemble, Allan
variances are averaged before taking the square root. This implementation needs
no Sensor Fusion Toolbox. `allanPoints` sets the logarithmic averaging-time grid;
the longest averaging times have fewer contributing differences.
`ToneValidation.csv` reports AC RMS, integrated PSD power, PSD errors, ACF error
and Allan-deviation error for the same three comparisons. Centering for these AC
diagnostics never removes the mean from the generated physical error or from
velocity/position integration.

S5/S6 compare equal-duration windows reset to zero initial error. E3/E4 compare
whole-record generated endpoints with one measured endpoint. These are open-loop
ZOH integration checks, not a full vehicle closed-loop simulation.

A full reconstruction scored against its own fitted record will naturally agree
extremely well. The coefficient-count sweep is also an aligned FIT check, even
when a held-out reference is enabled. Neither is independent validation. Generated
ranges are fixed-coefficient scenario ranges, not confidence intervals on the
sensor model. Too few tones can match total power yet miss rare sharp spikes.
A tiny shared roundoff guard nudges internal comparison-histogram edges by at
most 1024 eps at the data scale (and at most 1e-6 of a bin width). This avoids
splitting equal quantized values due to FFT roundoff; generated samples are not
clipped or changed. QuietResidualMean also exposes background offsets that a
zero-mean Gaussian addition cannot fix. Residual spikes must not be treated as ordinary Gaussian background just to fill
missing energy; review spike and quiet residual RMS and the waveform detail.

## One-record limitation and verification

This deliberately encodes one recording's behavior as a periodic disturbance.
It can support your study of what that observed IMU error does to the simulation,
but it does not establish future event rates, unseen extremes, changing conditions,
independent stochastic spikes, or true long-term sensor statistics. Repetition and
optional shifts are scenario assumptions. More cycles or shifted runs do not
create new measured evidence. A chronological held-out split is available, but
still comes from one source recording.

C++ tests compile and execute the actual function with a mock host, including
complete sensor-Y replacement, preserved X/Z under rotation, enable/disable,
legacy RNG/history, reset, and matching individual one-sample spikes. Independent
Python checks exercise even/odd records, DC/Nyquist conventions, reduced/zero tone
counts, common shifts and optional white noise against compiled C++ fixtures.
Independent estimator checks cover covariance-first ACF, overlapping Allan
variance against explicit adjacent block means, variance-before-sqrt averaging,
and cumulative linear PSD power. Results actually run are in
`evidence/Validation.json`, `Statistics_Validation.json` and `Build_Status.json`.
MATLAB/Octave was unavailable; Test_Fourier.m is supplied for local execution.
The Python preview is labeled synthetic and is not a MATLAB render or hardware fit.
Real hardware agreement and linkage to the unseen full simulation remain unverified.

```matlab
addpath('path/to/IMU_Fourier_Accel');
addpath('path/to/IMU_Fourier_Accel/tests');
Test_Fourier
```

To generate a longer MATLAB history from the fitted coefficients only:

```matlab
m = IMU_Results.model;
s = RandStream('mt19937ar','Seed',42);
longError_ug = imufourier.generate(m,10*m.recordSamples,s);
```

Each MATLAB generate call begins a fresh history; request the whole desired
history in one call. The C++ state persists sample to sample.

Reference formulas: [MathWorks fft](https://www.mathworks.com/help/matlab/ref/fft.html),
[MathWorks ifft](https://www.mathworks.com/help/matlab/ref/ifft.html), and
[MathWorks frequency-domain magnitude/phase discussion](https://www.mathworks.com/help/signal/ug/practical-introduction-to-frequency-domain-analysis.html),
and [MathWorks overlapping Allan-variance formula](https://www.mathworks.com/help/fusion/ug/inertial-sensor-noise-analysis-using-allan-variance.html).
