function T=toneSweep(x,m,info,c)
% Aligned FIT-record checks, no fresh white noise. Not a held-out score.
n=size(x,1); maxK=info.availableTones;
grid=c.sweepToneCounts; grid=grid(:)'; assert(isnumeric(grid)&&isvector(grid)&&all(grid>=0));
assert(all(isinf(grid)|grid==floor(grid)),'Sweep counts must be integers or Inf.');
grid=unique([0 min(grid,maxK) min(c.maxTones,maxK) maxK]);
names={'X','Y','Z'}; rows={}; L=max(16,min(round(c.welchWindow_s*m.Fs),floor(n/4)));
w=hamming(L); overlap=floor(L/2); nfft=max(256,2^nextpow2(L));
for j=find(m.selectedMask)
    a=x(:,j); F=info.fullFFT{j}; ranked=info.rankedBins{j};
    [P,freq]=pwelch(a-mean(a),w,overlap,nfft,m.Fs); keep=freq>0;
    edges=imufourier.histogramEdges(a,c.histogramBins); edges([1 end])=[-Inf Inf];
    href=histcounts(a,edges,'Normalization','probability');
    for K=grid
        chosen=ranked(1:K); y=m.mean_ug(j)+imufourier.fromBins(F,chosen);
        residual=a-y; S=pwelch(y-mean(y),w,overlap,nfft,m.Fs);
        psd=sqrt(mean((10*log10(max(S(keep),realmin))-10*log10(max(P(keep),realmin))).^2));
        histTV=.5*sum(abs(histcounts(y,edges,'Normalization','probability')-href));
        xx=zeros(n,3); xx(:,j)=y; only=m; only.selectedMask=false(1,3); only.selectedMask(j)=true;
        ev=imufourier.eventStats(xx,only); ev=ev{j};
        rows(end+1,:)={names{j},K,3*K+2,sqrt(mean(residual.^2)),max(abs(residual)), ...
            min(y),max(y),psd,histTV,nnz(ev.peak_ug>0),nnz(ev.peak_ug<0)}; %#ok<AGROW>
    end
end
T=cell2table(rows,'VariableNames',{'Axis','Tones','CoreCoefficients','FitRMSE_ug','FitMaxError_ug', ...
    'ReconstructedMin_ug','ReconstructedMax_ug','PSD_RMSE_dB','AmplitudeTV','PositiveEvents','NegativeEvents'});
end
