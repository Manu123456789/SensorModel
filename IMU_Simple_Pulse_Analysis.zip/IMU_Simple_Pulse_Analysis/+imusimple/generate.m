function x=generate(m,n,stream)
% White Gaussian background plus independent nonoverlapping signed pulses.
% Exact stationary phase initialization for geometric quiet gaps / fixed widths.
x=zeros(n,3);
for j=find(m.selectedMask)
    x(:,j)=m.baseline(j)+m.sigma(j)*randn(stream,n,1);
    L=m.widthSamples(j); waveform=imusimple.shape(m.shape,L); cursor=1;
    if rand(stream)<L/(m.meanGapSamples(j)+L)
        phase=1+floor(rand(stream)*L); count=min(n,L-phase+1);
        x(1:count,j)=x(1:count,j)+amplitude(m,j,stream)*waveform(phase:phase+count-1);
        cursor=count+1;
    end
    while cursor<=n
        cursor=cursor+gap(m.gapProbability(j),stream);
        if cursor>n, break; end
        count=min(L,n-cursor+1);
        x(cursor:cursor+count-1,j)=x(cursor:cursor+count-1,j)+amplitude(m,j,stream)*waveform(1:count);
        cursor=cursor+count;
    end
end
assert(all(isfinite(x(:))),'Generated amplitude overflow: inspect fitted log-amplitude spread.');
end
function G=gap(p,stream)
if p>=1, G=1; else, G=1+floor(log1p(-rand(stream))/log1p(-p)); end
end
function A=amplitude(m,j,stream)
A=exp(m.logPeakMean(j)+m.logPeakStd(j)*randn(stream));
if rand(stream)<m.negativeProbability(j), A=-A; end
end
