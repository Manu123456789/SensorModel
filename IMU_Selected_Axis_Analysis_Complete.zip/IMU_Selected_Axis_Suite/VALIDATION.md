# Validation performed for this package

## Executed checks

- The supplied 24,000-row XYZ CSV is finite, sampled at approximately 200 Hz,
  and converted from ft/s² to µg using 0.3048 and standard gravity 9.80665.
- The independent Python numerical reference was run with X, Y and Z selected
  separately. Inactive generated sensor components, quiet-factor rows and quiet
  baselines were exactly zero. The eligible training catalogs had 73, 74 and
  73 events respectively for the supplied example.
- For selected Y, the reference quiet fraction was approximately 0.943.
  The 36-second held-out suffix had 27 positive and 5 negative complete detected
  axis events. Fifty Python-model runs averaged 27.02 positive and 4.98 negative
  events. This is a synthetic workflow check, not a hardware acceptance result.
- A populated C++ **reference fixture** was built with the same selected-Y
  constants and data layout as the MATLAB exporter writes. The actual
  `Check_Exported_Model.cpp` was compiled against that fixture with strict C++11
  warnings. It exercised both the low-level generator and `IMU_error()` identity
  binding. Thirty C++ runs averaged 27.73 positive and 5.13 negative events.
- Seven ensemble-mean metrics were compared between 50 reference runs and 30
  C++ runs: mean, standard deviation, total RMS, positive/negative event counts,
  final velocity and final position. Differences were all within 1.05 estimated
  Monte Carlo standard errors. The regression bound in the test is five errors;
  that is a developer regression check, not a hardware validation threshold.
- Both C++ unit-test programs compiled with `-Wall -Wextra -Werror -pedantic`
  and address/undefined-behavior sanitizers. They passed scheduling, exact pulse
  rows, quiet covariance, no double-added noise, reset/cache/clock behavior,
  Markov/IID event selection, selected-axis zeros, and proper-rotation tests.
  Leak detection was disabled because it cannot inspect the restricted runtime;
  address and undefined-behavior instrumentation were used.
- The included preview was inspected visually. It has six plots and is labeled
  as a Python numerical reference, not MATLAB output or hardware measurements.
- Package-function references were checked for missing source files. The
  diagnostic figure helper enforces at most six tiles; the C++ comparison uses
  four. Entry scripts are short (16-line playground, 22-line hardware template).

The machine-readable numbers are in `evidence/Reference_Validation.json`.
The optional `tests/verify_reference.py` reproduces the numerical-reference and
C++-fixture checks with NumPy, SciPy, matplotlib and g++. The ordinary MATLAB
workflow does not require these Python tools.

## Not executed or established here

- MATLAB and Octave are not installed in the authoring environment. The MATLAB
  implementation and exporter were reviewed, but **were not run in MATLAB**.
  The Python reference and fixture checks do not substitute for MATLAB runtime
  testing or prove absence of MATLAB graphics/compatibility issues.
- The MATLAB-produced C++ candidate cannot be tested until the MATLAB exporter
  actually runs. The supplied procedure exercises that actual file afterward;
  the authoring-stage fixture is clearly separate from it.
- No numerical hardware record was provided. The physical cause of the pulses,
  true rail levels, operating-condition dependence, rare-event tails and actual
  quiet-noise spectrum are not established by the supplied synthetic example.
- Your actual estimator/controller, frame definitions, internal accumulator
  equations and sampling scheduler were not available. Their integration is not
  certified by the generalized adapter or open-loop error plots.
- A finite template catalog cannot demonstrate unseen tail-event probabilities.
  The generated-record ranges hold fitted parameters fixed and do not measure
  parameter uncertainty.

## First checks to run on your machine

1. Run `Run_Playground.m`; confirm all five Y figure families appear and files
   save without errors.
2. Run `addpath('tests'); Test_Selected_Axes` in MATLAB.
3. Select X, Z and then all three in the runner if you intend to use those modes.
4. Follow README section 8 to compile the MATLAB-exported C++ candidate, generate
   a trace and run `Check_CPP_Output.m` for multiple seeds.
5. Apply the real-data template and README readiness review to your hardware
   record and downstream simulation before treating coefficients as validated.
