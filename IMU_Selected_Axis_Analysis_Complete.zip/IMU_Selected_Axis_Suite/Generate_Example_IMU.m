function [ExampleIMU,Truth]=Generate_Example_IMU(fs,duration_s)
% In-memory synthetic example: quiet Gauss-Markov background plus irregular spikes.
% No hardware parameters are claimed. Returns a timetable with XYZ variables.
validateattributes(fs,{'numeric'},{'scalar','real','finite','positive'});
validateattributes(duration_s,{'numeric'},{'scalar','real','finite','>=',10});
stream=RandStream('mt19937ar','Seed',42); n=round(fs*duration_s);
sigma=[5 7 4]; C=diag(sigma)*[1 .2 .05;.2 1 -.1;.05 -.1 1]*diag(sigma);
L=chol(C,'lower'); phi=.9; initial=randn(stream,1,3)*L';
innovation=sqrt(1-phi^2)*(randn(stream,n,3)*L');
x=zeros(n,3);
for j=1:3, x(:,j)=filter(1,[1 -phi],innovation(:,j),phi*initial(j)); end
x=x+[3 -5 2]; cursor=1; catalog=zeros(0,4);
while cursor<n
    gap=max(1,round(fs*(.25+.65*exp(.45*randn(stream,1,1)))));
    width=max(3,round(fs*(.025+.125*rand(stream,1,1))));
    first=cursor+gap; last=first+width-1; if last>=n, break; end
    u=linspace(0,1,width)'; type=1+floor(3*rand(stream,1,1));
    if type==1, shape=exp(-5*u); elseif type==2, shape=1-abs(2*u-1);
    else, shape=min(1,min(8*u,8*(1-u))); end
    q=rand(stream,1,1);
    if q<.7, direction=[.18 1 -.12]; elseif q<.85, direction=[1 .12 .08]; else, direction=[-.1 .15 1]; end
    peak=350*exp(.4*randn(stream,1,1)); if rand(stream,1,1)<.22, peak=-.55*peak; end
    x(first:last,:)=x(first:last,:)+peak*shape*direction;
    catalog(end+1,:)=[first last gap peak]; %#ok<AGROW>
    cursor=last+1;
end
ExampleIMU=array2timetable(x*(1e-6*9.80665/.3048),'SampleRate',fs, ...
    'VariableNames',{'Example_X','Example_Y','Example_Z'});
Truth=struct('QuietPhi',phi,'QuietCovariance_ug2',C,'Error_ug',x,'EventCatalog',catalog);
end
