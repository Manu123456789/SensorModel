function figs=plotMatch(r)
% First realization tail bins and finite-block count checks; maximum six tiles.
figs=gobjects(0); names={'X','Y','Z'};
for j=find(r.model.selectedMask)
    f=figure('Name',['R_' names{j} '_Record_Matching'],'NumberTitle','off', ...
        'Visible',r.cfg.figureVisible,'Position',[50 50 1500 850]); figs(end+1)=f; %#ok<AGROW>
    t=tiledlayout(f,2,3,'TileSpacing','compact','Padding','compact');
    z=r.HistogramSummary(strcmp(string(r.HistogramSummary.Axis),names{j}),:);
    ax=nexttile(t); stairs(ax,z.Center_ug,z.ReferenceCount,'k','DisplayName',r.referenceLabel); hold(ax,'on');
    stairs(ax,z.Center_ug,z.Run1Count,'r','DisplayName','Generated run 1');
    set(ax,'YScale','log'); title(ax,'R1: single-run amplitude bin counts'); xlabel(ax,'Error [ug]'); ylabel(ax,'Samples / bin'); legend(ax,'show'); grid(ax,'on');
    ax=nexttile(t); plot(ax,z.Center_ug,z.Run1Count-z.ReferenceCount,'o-');
    yline(ax,0,'k:'); title(ax,'R2: single-run minus measured bins'); xlabel(ax,'Error [ug]'); ylabel(ax,'Count difference'); grid(ax,'on');
    tails=r.TailSummary(strcmp(string(r.TailSummary.Axis),names{j}),:);
    ax=nexttile(t);
    if ~isempty(tails)
        bar(ax,[tails.ReferenceSamples tails.Run1Samples]);
        set(ax,'XTick',1:height(tails),'XTickLabel',strcat(string(tails.Sign),' P',string(tails.FitPulseSamplePercentile)));
        legend(ax,r.referenceLabel,'Run 1'); grid(ax,'on');
    end
    title(ax,'R3: high-amplitude SAMPLE representation'); ylabel(ax,'Samples beyond threshold');
    ax=nexttile(t); ref=r.refEvents{j}; event=imubounded.eventStats(r.exampleGenerated,r.model); event=event{j};
    bar(ax,[nnz(ref.peak_ug>0) nnz(event.peak_ug>0);nnz(ref.peak_ug<0) nnz(event.peak_ug<0)]);
    set(ax,'XTickLabel',{'Positive','Negative'}); legend(ax,r.referenceLabel,'Run 1'); title(ax,'R4: signed complete events in run 1'); ylabel(ax,'Events'); grid(ax,'on');
    ax=nexttile(t); types=r.model.pulseTypes{j};
    scatter(ax,[types.width]/r.model.Fs,arrayfun(@(v)max(abs(v.knotValue-r.model.baseline(j))),types), ...
        15+10*[types.count],[types.sign],'filled'); colorbar(ax);
    title(ax,'R5: retained pulse types; size = count'); xlabel(ax,'Width [s]'); ylabel(ax,'Absolute peak excursion [ug]'); grid(ax,'on');
    ax=nexttile(t); histogram(ax,r.reference(:,j),r.histEdges{j},'Normalization','probability','DisplayStyle','stairs','EdgeColor','k'); hold(ax,'on');
    histogram(ax,r.exampleGenerated(:,j),r.histEdges{j},'Normalization','probability','DisplayStyle','stairs','EdgeColor','r');
    xlim(ax,[r.model.baseline(j)-2*r.model.threshold(j) r.model.baseline(j)+2*r.model.threshold(j)]);
    title(ax,'R6: quiet / threshold amplitude zoom'); xlabel(ax,'Error [ug]'); ylabel(ax,'Probability/bin'); grid(ax,'on');
    title(t,'Record-conditioned generator: exact scheduled counts only over complete fitted-length blocks');
end
end
