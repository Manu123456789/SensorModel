function stats=eventStats(x,m)
e=imusimple.detect(x,m); stats=cell(1,3);
for j=find(m.selectedMask)
    starts=e.start{j}; stops=e.stop{j}; valid=starts>1 & stops<size(x,1);
    a=starts(valid); b=stops(valid); n=numel(a);
    s=struct('start',a,'stop',b,'mask',e.mask(:,j),'width_s',(b-a+1)/m.Fs, ...
        'gap_s',NaN(n,1),'interval_s',NaN(n,1),'peak_ug',NaN(n,1),'area_ug_s',NaN(n,1));
    for k=1:n
        z=x(a(k):b(k),j)-m.baseline(j); [~,q]=max(abs(z));
        s.peak_ug(k)=z(q); s.area_ug_s(k)=sum(z)/m.Fs;
        previous=find(stops<a(k),1,'last');
        if ~isempty(previous), s.gap_s(k)=(a(k)-stops(previous)-1)/m.Fs; end
        if k>1, s.interval_s(k)=(a(k)-a(k-1))/m.Fs; end
    end
    stats{j}=s;
end
end
