function outputPath=Export_IMU_Axis_To_CPP(m,outputPath)
% Export the SAME fitted single-axis model to one C++ file using the host Gaussian RNG.
% Run after IMU_Config.m:
%   addpath('path/to/IMU_Axis_CPP_Port');
%   Export_IMU_Axis_To_CPP(IMU_Results.model,'IMU_Axis_Model.cpp');
% Or load Analysis.mat and pass PulseModel. This does not refit your data.
if nargin<2, outputPath='IMU_Axis_Model.cpp'; end
required={'Fs','selectedMask','baseline','covariance','gmPhi','templates', ...
    'gapSamples','classes','classFrequency','transitionProbability','useEventMarkov'};
for k=1:numel(required), assert(isfield(m,required{k}),['Missing model.' required{k}]); end
mask=logical(m.selectedMask(:)');
assert(numel(mask)==3 && nnz(mask)==1, ...
    'Fit ONE selected sensor axis for this compact port. Use the suite joint exporter for multiple axes.');
axis=find(mask); names={'X','Y','Z'};
validateattributes(m.Fs,{'numeric'},{'scalar','real','finite','positive'});
validateattributes(m.gmPhi,{'numeric'},{'scalar','real','finite','>=',0,'<',1});
assert(numel(m.baseline)==3 && isreal(m.baseline) && all(isfinite(m.baseline(:))));
assert(isequal(size(m.covariance),[3 3]) && isreal(m.covariance) && all(isfinite(m.covariance(:))));
variance=m.covariance(axis,axis); assert(variance>=0,'Negative quiet variance.');
sigma=sqrt(variance);
assert(iscell(m.templates) && ~isempty(m.templates)); count=numel(m.templates);
lengths=zeros(count,1); pulses=cell(count,1);
for k=1:count
    a=m.templates{k};
    assert(isnumeric(a) && isreal(a) && size(a,2)==3 && size(a,1)>0 && all(isfinite(a(:))));
    assert(all(all(a(:,~mask)==0)),'Inactive template axes must be exactly zero.');
    pulses{k}=a(:,axis); lengths(k)=size(a,1);
end
gap=m.gapSamples(:); cls=m.classes(:); signClasses=2*(axis-1)+[1 2];
assert(numel(gap)==count && isreal(gap) && all(isfinite(gap)) && all(gap>=0 & gap==floor(gap)));
assert(numel(cls)==count && all(ismember(cls,signClasses)), ...
    'The fitted event classes must belong to the selected sensor axis.');
sign=cls-signClasses(1); % MATLAB [axis+,axis-] -> C++ [0,1]
assert(numel(m.classFrequency)==6 && isequal(size(m.transitionProbability),[6 6]));
frequency=reshape(m.classFrequency(signClasses),1,2);
transition=m.transitionProbability(signClasses,signClasses);
assert(isreal(frequency) && all(isfinite(frequency)) && all(frequency>=0) && abs(sum(frequency)-1)<1e-8);
assert(isreal(transition) && all(isfinite(transition(:))) && all(transition(:)>=0) && ...
    all(abs(sum(transition,2)-1)<1e-8));
counts=accumarray(sign+1,1,[2 1]); absent=counts==0;
assert(all(frequency(absent)==0) && all(all(transition(:,absent)==0)), ...
    'Probabilities point to an empty sign class.');
assert(isscalar(m.useEventMarkov) && (m.useEventMarkov==0 || m.useEventMarkov==1));
offset=[0;cumsum(lengths(1:end-1))]; samples=vertcat(pulses{:});
burn=10*max(gap+lengths);
assert(burn<=flintmax && numel(samples)<=flintmax && all(gap<=flintmax));
if isfield(m,'burnInSamples'), assert(m.burnInSamples==burn,'Unexpected burn-in rule.'); end

lines={'// BEGIN EXPORTED AXIS MODEL'; ...
    ['// Fitted SENSOR ' names{axis} '; units ug; gaps/lengths in samples.']; ...
    '// Background: host N(0,1); events: empirical waveform replacement.'};
lines{end+1}=sprintf('static const double imu_pulse_samples[%d]={',numel(samples));
for k=1:numel(samples), lines{end+1}=sprintf('    %.17g,',samples(k)); end %#ok<AGROW>
lines{end+1}='};';
lines{end+1}=integerArray('std::size_t','imu_event_offset',offset);
lines{end+1}=integerArray('std::size_t','imu_event_length',lengths);
lines{end+1}=integerArray('std::size_t','imu_event_gap',gap);
lines{end+1}=integerArray('unsigned','imu_event_sign',sign);
lines{end+1}='static const ImuAxisParameters imu_axis_parameters={';
lines{end+1}=sprintf('    true,%d,%.17g,%.17g,%.17g,%.17g,', ...
    axis-1,m.Fs,m.baseline(axis),sigma,m.gmPhi);
lines{end+1}=sprintf('    %d,%d,imu_pulse_samples,',count,numel(samples));
lines{end+1}='    imu_event_offset,imu_event_length,imu_event_gap,imu_event_sign,';
lines{end+1}=['    {' realList(frequency) '},'];
lines{end+1}=['    {{' realList(transition(1,:)) '},{' realList(transition(2,:)) '}},'];
if m.useEventMarkov, boolean='true'; else, boolean='false'; end
lines{end+1}=sprintf('    %s,%.0f',boolean,burn);
lines{end+1}='};'; lines{end+1}='// END EXPORTED AXIS MODEL';

folder=fileparts(mfilename('fullpath'));
templatePath=fullfile(folder,'IMU_Axis_Integration_Template.cpp');
outputPath=char(outputPath);
assert(~strcmp(outputPath,templatePath) && ~strcmp(outputPath,'IMU_Axis_Integration_Template.cpp'), ...
    'Export to a NEW filename; preserve the template.');
source=fileread(templatePath);
first=strfind(source,'// BEGIN EXPORTED AXIS MODEL'); last=strfind(source,'// END EXPORTED AXIS MODEL');
assert(numel(first)==1 && numel(last)==1 && first<last,'Template markers must occur once.');
after=last+numel('// END EXPORTED AXIS MODEL');
source=[source(1:first-1) strjoin(lines,newline) source(after:end)];
fid=fopen(outputPath,'w'); assert(fid>=0,'Cannot open export path.');
cleanup=onCleanup(@()fclose(fid)); fprintf(fid,'%s',source); clear cleanup;
fprintf('Exported %s: sensor %s, %.9g Hz, %d events, %d waveform samples.\n', ...
    outputPath,names{axis},m.Fs,count,numel(samples));
fprintf('baseline=%.9g ug, stationary quiet sigma=%.9g ug, phi=%.9g.\n', ...
    m.baseline(axis),sigma,m.gmPhi);
fprintf('Bind the existing standard-normal RNG and sensor scheduler before running.\n');
end
function s=integerArray(type,name,a)
s=sprintf('static const %s %s[%d]={%s};',type,name,numel(a),sprintf('%.0f,',a));
end
function s=realList(a)
a=a(:); s=sprintf('%.17g',a(1));
if numel(a)>1, s=[s sprintf(',%.17g',a(2:end))]; end
end
