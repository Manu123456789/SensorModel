# Selected-axis IMU pulse analysis suite

This package models **one selected accelerometer axis by default**, with a
straightforward extension to two or three. It describes irregular pulses on a
quiet noise floor, preserves the pulses' contribution to the mean, and exports
a candidate C++ implementation. It does not infer the physical cause of a fault
from a histogram or certify that a model is adequate for every simulation.

The default axis is **sensor Y**. Change `cfg.selectedAxes` to `{'X'}`, `{'Z'}`,
`{'X','Y'}`, or `{'X','Y','Z'}`. Unselected SENSOR components are exactly zero
in this model's input, templates, quiet baseline, quiet noise and generated
output. Other sensor axes cannot trigger detection or influence fitting. A
selected sensor component can still contribute to all three PLATFORM components
through the frame rotation. Existing independent errors on the other sensor
axes belong in your simulator separately.

## 1. Quick start and files

For uploading the extracted source to a Git repository, see `GITHUB_SETUP.md`.
Keep the `+imupulse` directory name intact. Generated results are excluded by
the included `.gitignore`.

Requirements: MATLAB R2021b or newer, and Signal Processing Toolbox (`pwelch`,
`hamming`). The suite uses base MATLAB `fft`, `xcorr`, tables and tiled layouts.
No Statistics Toolbox, Python or C++ compiler is needed for the MATLAB workflow.
A C++11 compiler is needed only for the C++ verification stage.

1. Unzip the complete folder.
2. Open MATLAB and run `Run_Playground.m`.
3. Inspect Figure A first, then B, C, D and E. Each has at most six tiles.
4. Inspect the workspace variable `results` and the saved `output/` files.
5. For hardware, edit **`IMU_Config.m`**, set your imported table in
   `Analyze_My_Data_Template.m`, then run that script. It saves to
   `output_hardware/`, keeping the default playground output separate.

| File/folder | Purpose |
|---|---|
| `Run_Playground.m` | Short, runnable synthetic-data entry point |
| `IMU_Config.m` | Main editable config: named X/Y/Z columns, sample rate, selected axes, interval, baseline and rotation |
| `Analyze_My_Data_Template.m` | Six-line entry script: set your table, load the config, run and save |
| `Generate_Sample_IMU.m` | Optional configurable XYZ synthetic data generator |
| `+imupulse/` | Reusable preparation, fitting, generation, plotting, integration and export support |
| `data/Sample_IMU_ft_s2.csv` | 24,000 instantaneous samples, 200 Hz, 120 seconds |
| `data/Sample_Event_Truth.csv` | Synthetic generator event catalog, not detector output |
| `cpp/Export_IMU_Pulse_To_CPP.m` | Export fitted constants into one complete C++ source file |
| `cpp/IMU_Pulse_Integration_Template.cpp` | Generalized `void IMU_error()` structure with persistent state and explicit bindings |
| `cpp/Check_Exported_Model.cpp` | Generate a trace from the actual exported candidate and check the example final-loop binding |
| `Check_CPP_Output.m` | Compare that trace with the MATLAB model ensemble |
| `tests/` | MATLAB selection/units/integration checks; C++ runtime tests are in `cpp/` |
| `VALIDATION.md` | What was checked while building this deliverable, and what was not |

The entry scripts are intentionally short. Put hardware settings in
`IMU_Config.m`; `+imupulse/defaults.m` supplies algorithm defaults.
You do not need to rename your table columns or add a time column.

For example, with only sensor Y selected:

```matlab
cfg.selectedAxes = {'Y'};
cfg.columns.X = '';                 % Unselected: can remain empty
cfg.columns.Y = 'MyAccelReadout';    % Exact name in T.Properties.VariableNames
cfg.columns.Z = '';
cfg.sampleRate_Hz = 1000;            % Your actual recorded data rate
cfg.timeColumn = '';                % No timestamp column needed
```

Set the known physical baseline and input units in the same config. Column names
with spaces or punctuation work; use their exact imported MATLAB table names.
If reading Excel/CSV afresh, `readtable(...,'VariableNamingRule','preserve')`
keeps original names. The config's `sampleRate_Hz=NaN` is an intentional required
placeholder so your hardware rate is never guessed. The old positional
`cfg.axisColumns={...}` setting has been replaced by `cfg.columns.X/Y/Z`.

The MATLAB suite/exporter could not be run in the authoring environment because
MATLAB is not installed. Numerical-reference checks and C++ tests were executed;
see `VALIDATION.md` for the precise coverage and first MATLAB checks to run.

## 2. What the example represents

The CSV columns are `Time` [seconds], `ColumnX`, `ColumnY`, `ColumnZ` [ft/s²].
The playground removes `Time` before analysis and reconstructs it at 200 Hz,
exercising the same no-time-column path as your hardware workflow.
They contain a known zero true acceleration plus an error signal: quiet offset,
modestly correlated Gaussian noise, and irregular pulses. Y usually dominates;
some events mainly affect X or Z. Selecting only Y deliberately ignores the X/Z
readout, even if it contains larger excursions.

The illustrative settings are quiet biases [3, -5, 2] µg, quiet standard
deviations [5, 7, 4] µg, median pulse scale 350 µg, negative-event probability
0.22, and a 0.55 multiplier on negative-event amplitudes. Gaps are 0.25 seconds
plus a lognormal component with median 0.65 seconds. Pulse widths range from
0.025 to 0.15 seconds. Shapes include rapid-onset exponential decays, triangles
and short plateaus. The data has no rail clipping or cumulative encoding.

These choices are illustrative, not fitted hardware coefficients. The supplied
CSV was made with a Python numerical reference. The optional MATLAB generator
uses the same distribution rules, but a different random-number implementation;
the same seed need not reproduce the CSV. Set `regenerate=true` in the runner
to experiment with settings passed to `Generate_Sample_IMU`.

Do not expect generator-truth events and detector events to have identical
counts. An event can be too small on the selected axis, be cut at a boundary,
or fragment near a threshold. Several physical pulses can also merge into one
continuous threshold excursion. This suite fits the **recorded, detected error
behavior**, not an independently established physical failure mechanism.

## 3. Input preparation, units and frame conventions

Only the selected sensor columns are required in your table by default.
An unselected column may be absent, invalid, saturated or contain a different
signal; it is not read by this model. Selected columns must be numeric and
finite throughout the chosen interval. Map names explicitly with `cfg.columns.X`,
`cfg.columns.Y`, and `cfg.columns.Z`; only selected names must be supplied.
Selected axes must reference distinct columns.

**Default timing (no time column):** supply `cfg.sampleRate_Hz`. For N table rows,
the code constructs `t=cfg.startTime_s+(0:N-1)'/cfg.sampleRate_Hz`, with default
`startTime_s=0`. Row 1 is at zero, row 1001 is at one second for 1000 Hz, and the
last sample time is `(N-1)/Fs`. Integration over all N piecewise-constant samples
covers N/Fs seconds; this distinction also applies to Figure E.

Times are assigned to ORIGINAL table rows **before** `cfg.window_s` is applied.
Selecting [10 90] seconds therefore selects that part of the original recording;
it does not restart time at the first selected row. `results.input.sourceRows`
retains the corresponding original row numbers. Leave `startTime_s=0` unless
you deliberately want to assign another origin to table row 1. If the table was
already cropped before this script, it is that cropped table whose row 1 defines
the origin; provide its known start offset if needed.

**Optional timestamp mode:** set `cfg.timeColumn='YourTimeColumn'` to use numeric
seconds from an existing column instead. These timestamps determine Fs and
override `sampleRate_Hz` and `startTime_s`. They must be finite, strictly
increasing and uniformly spaced to the configured tolerance. The suite fails
on detected gaps rather than joining unrelated time periods.

With constructed time, uniform sampling is an assumption based on the rate you
provide: absent timestamps or a sample counter, the code cannot detect lost
rows or actual clock jitter. Figure A6 and saved provenance identify which
time source was used. Do not delete interior rows and then pretend the remaining
rows are still consecutive samples.

The selected sensor-frame error is

`error_ug = (measured_acceleration_ms2 - known_true_acceleration_ms2) * 1e6 / 9.80665`.

For instantaneous ft/s² data, multiply by 0.3048 to get m/s². The baseline is
the **known true input**, including the actual signed gravity projection and
true motion when relevant. It is not the mean of the anomalous signal. The
synthetic example has zero true input. For a stationary raw accelerometer, do
not assume zero unless gravity has already been removed appropriately.

`cfg.baselineSensor_ms2` always uses m/s², whatever the input mode. Only its
selected entries need be finite. For known zero-input Y, use `[NaN 0 NaN]`.
The code constructs zero model inputs for the unselected entries.

Supported `cfg.inputMode` values:

| Mode | Definition and conversion |
|---|---|
| `instantaneous_ft_s2` | Recorded acceleration, multiply by 0.3048 |
| `instantaneous_cm_s2` | Recorded acceleration, multiply by 0.01 |
| `instantaneous_ms2` | Recorded acceleration, already m/s² |
| `instantaneous_ug` | Recorded acceleration in µg, multiply by 9.80665e-6 |
| `sample_sum_cm_s2` | Logger explicitly uses C(k)=C(k-1)+a_cm_s2(k); difference and multiply by 0.01 |
| `integral_cm_s` | Logger stores cumulative velocity in cm/s; difference, multiply by 0.01 and divide by dt |

The cumulative modes align reconstructed values to the later timestamp and
lose the unidentifiable initial sample. They do not decode sliding sums,
running averages, counter wraps or resets. Select a reset-free interval and
confirm the logger's exact rule first. An integral of acceleration has velocity
units; a column labeled cm/s² is not automatically an integral.

Use one contiguous operating regime in `cfg.window_s`. The suite works at the
native sample rate; it does not silently downsample. If a different rate is
needed, apply appropriate antialias filtering/resampling and refit at that
rate. Narrow pulses can change substantially with sample rate.

Set known rail bounds in `cfg.railLimitsInput` using the original column units,
with X/Y/Z rows and lower/upper columns. Readings on a bound count as flagged.
The default rejects a selected interval with configured rail violations. With
`allowRailSamples=true`, it models the recorded clipped values, not unknown
acceleration beyond the rail. Infinite bounds disable checking; they do not
establish that the instrument was unsaturated.

The rotation convention is `platform_column = R_sensor_to_PLT * sensor_column`.
For N-by-3 row data, this is `platform = sensor * R_sensor_to_PLT'`. The code
requires a proper rotation with determinant +1. Do not add another transpose
because an older simulation happened to use one. Derive the actual direction
from the definitions of your frames. Fit in the sensor frame, then rotate
synchronized samples. Rotating three RMS magnitudes as a signed vector is not
a valid covariance transformation.

## 4. Model construction and why these techniques are used

The intended conceptual model on a selected axis is a quiet baseline plus
quiet noise and occasional shaped events. Random-event pulse signals are
studied as shot-noise/point-process models; Brémaud, Massoulié and Ridolfi [R1]
analyze their spectra for broad classes of driving point processes. That work
supports the general model family, not the claim that your accelerometer has
a particular physical failure or Poisson arrival law.

This implementation uses an **empirical event bootstrap**:

1. Use only the training prefix, 70% by default. Reserve the remaining contiguous
   suffix for comparison. At least 256 samples are required in each section.
2. Estimate an initial quiet location using the median and a robust scale
   `1.4826 * median(abs(x - median(x)))`. Scaled MAD is a normal-consistent robust
   scale estimate [R2]. It helps when occasional large pulses would inflate
   ordinary standard deviation. It is not a reliable quiet estimate when a
   high state dominates the record; inspect the detector in that case.
3. Start an event when any selected axis crosses its detection threshold.
   Keep it active until all selected axes return inside their lower release
   thresholds. Defaults are 5 robust-sigma for detection and 2 for release.
   Hysteresis reduces rapid threshold chatter. These multipliers are engineering
   defaults, not research-established universal values or formal false-alarm
   probabilities. Manual thresholds are supported per axis in µg.
4. Update the quiet mean using non-event training samples. Estimate their
   population covariance and factor it to generate quiet Gaussian samples.
   Unselected rows of the factor are forced to zero. A singular covariance
   with only one selected axis is intentional, not an error.
5. Save each complete joint event as its actual XYZ waveform minus the quiet
   baseline, together with its immediately preceding quiet gap. Exclude events
   touching record boundaries and events without an observed preceding event:
   those preceding gaps can be left-censored. At least five eligible events
   are required to run; this is a computational minimum, not sufficient evidence
   for rare-event prediction.
6. For a new realization, select an event/gap tuple empirically and generate
   fresh correlated Gaussian noise during quiet samples. **Overwrite** event
   samples with the recorded waveform plus quiet baseline. Event templates
   already contain event-time measurement noise; adding fresh Gaussian noise
   on top would double-count that component.
7. By default, events are drawn independently by class frequency and uniformly
   within class. Class is dominant normalized axis/sign: X+, X-, Y+, Y-, Z+, Z-.
   Optional first-order class transitions use observed counts smoothed toward
   the empirical class frequencies. This can retain first-order sign/axis
   tendencies, but not arbitrary burst history or slow regime dependence.
8. Discard ten times the longest observed gap-plus-event duration before keeping
   output. This is a finite burn-in heuristic shared by MATLAB and C++; it is
   not a proof of stationary initialization, especially for slowly mixing
   Markov models. Check longer burns or explicit startup behavior if relevant.

This is not sampling amplitudes uniformly between extrema, nor drawing each
sample independently from the histogram. Pairing gap and waveform retains
their observed within-event relationships. Joint templates retain simultaneous
selected-axis behavior. The bootstrap cannot create an unobserved pulse shape,
unseen tail amplitude, much longer quiet gap, or genuine new operating regime.
Long generated runs will reuse recorded event waveforms. That is a deliberate
first-model limitation, not a new physical signal synthesis result.

No overall mean is subtracted from generated histories or histograms. Quiet
baseline and total mean differ when pulses preferentially have one sign. The
pulse part, although called `noise` in the C++ binding, can have nonzero mean.
PSD/FFT/ACF remove each analyzed record's mean **for those diagnostics only**.
Mean and total RMS remain available separately in the output tables.

## 5. How to interpret the diagnostic figures

All figure names begin with A/B/C/D/E and the selected sensor axis. There are
five figures per selected axis: 6, 4, 6, 6 and 4 tiles respectively. With multiple
selected axes, one optional four-tile F figure adds cross-axis checks. No tiled
figure contains more than six plots. Figure files are saved as PNG and editable
MATLAB FIG when enabled.

The interpretations below are engineering guidance conditional on this model,
not a diagnosis of your instrument. A visually plausible plot is one check,
not independent proof of fidelity.

### Figure A — input, selection and event detection

**A1: selected error and detected events.** Gray is the recorded error after
the known physical baseline is removed. Red is the union of detected event
intervals. The dotted horizontal line is the fitted quiet baseline; the vertical
line separates training and validation. For one axis, red should cover the
excursions you intend to model. With several axes, an interval can be red on an
axis because another selected axis triggered the joint event. If red covers
nearly the entire record, a quiet-plus-brief-pulse model or its thresholds may
be inappropriate. If obvious excursions remain gray, lower the detection
threshold carefully. A clipped flat top describes the recorder limit, not the
physical peak. A sudden change near the split indicates potentially different
operating regimes, not necessarily a fitting error.

**A2: threshold zoom.** Shows the first `cfg.zoom_s` seconds, including both
positive/negative onset and release levels. Blue dashed lines start events;
green dotted lines release them. Expect a clear onset and a continuous red
event until return toward the quiet floor. Repeated short red fragments along
a single decaying pulse indicate threshold chatter or a release threshold that
is too restrictive. Very long red tails can mean the release level is too
tight relative to background variation. Raise or lower thresholds with reference
to the actual waveform and repeat the analysis; do not tune them solely to
make generated and test statistics agree. If the first window has no events,
increase `zoom_s` or inspect the saved editable figure around another event.

**A3: train/held-out amplitude histogram.** The vertical scale is logarithmic
probability per bin, so small tail occupancies are visible. The two intervals
use common bins and probabilities, not raw counts. A large quiet peak plus a
long positive tail supports a quiet-plus-positive-excursion description. A
second separated peak can indicate appreciable occupancy at another level;
it does not prove two Gaussian states or identify switching times. A narrow
pileup at a known limit suggests recorded clipping; repeated discrete levels
may also reflect quantization. The time history is needed to distinguish these.
Try several reasonable bin counts: an apparent mode that disappears immediately
with a small bin change is weak evidence. NIST discusses histograms and bimodal
mixtures as exploratory tools [R3, R4].

For this suite, a matching histogram alone is insufficient. Permuting the
record preserves its histogram and total mean but changes pulse timing and
usually its autocorrelation. A quieter validation histogram may simply reflect
fewer events in a finite suffix; compare rates and ensemble variation too.

**A4: mean by nonoverlapping time block.** Each point is the mean error over
one block (`block_s`, default 10 s); the final partial block is retained. This
is a regime/stationarity diagnostic, not a moving-average filter used to fit
the model. Some scatter is expected because pulse counts and areas vary.
A sustained trend or step can mean changing bias, pulse occupancy or true input.
Choose a stationary interval, include operating-condition dependence, or fit
separate regimes when justified. Do not claim temperature dependence without
temperature data. Compare the block duration with typical event gaps: blocks
with only one event give naturally noisy means.

**A5: joint-event start rate by block.** Counts event starts and divides by
actual block duration. It is a union-event rate shared by selected axes, not
an additional per-axis peak count. An event crossing a block boundary is
assigned by its start. Random scatter is normal; long quiet stretches followed
by many events suggest clustering or a regime change the IID tuple model may
miss. Repeated near-regular timing suggests a jittered-period model rather than
assuming memoryless arrivals. This plot does not establish that timing is
Poisson, and the implementation makes no such assumption.

**A6: sample-interval deviation.** Plots `(dt * Fs - 1) * 1e6` in ppm. In the
default no-time-column mode, intervals are constructed at the configured rate.
The plot should be essentially flat apart from arithmetic precision, and is
labeled **uniform assumed**. It is not a hardware-clock or dropped-row check.
In optional timestamp mode, Fs is estimated from the timestamps and large
interval jumps or jitter invalidate the uniform-rate assumption. The preparation
stage rejects deviations above tolerance before plotting. Do not loosen that
tolerance to hide missing samples. Neither mode establishes absolute hardware
clock accuracy without an independent time reference.

### Figure B — is the quiet background actually Gaussian and white?

These plots use training quiet samples after subtracting the quiet baseline,
not the full pulse-contaminated signal. Because the detector selects quiet
samples using thresholds, some truncation/selection effects are unavoidable.
They are checks of an approximation, not formal normality/independence tests.

**B1: quiet histogram with Gaussian density.** Histogram area is normalized to
one; the red curve has fitted quiet variance. Expect a roughly symmetric
central distribution near zero. Heavy shoulders, asymmetry or extra modes
suggest remaining small events, a changing baseline, quantization, or a
non-Gaussian quiet process. These are possibilities to investigate, not causes
established by the plot. Density height has units 1/µg and can exceed one;
it is not a bin probability. An apparently good bell shape says nothing about
temporal whiteness. If almost all quiet samples are identical, estimated
variance and Gaussian overlays are uninformative.

**B2: Gaussian Q-Q plot.** Empirical quiet quantiles are plotted against the
quantiles of the fitted Gaussian. A nearly diagonal relationship supports
the marginal approximation. Tail deviations indicate mismatched tail weight;
asymmetric bending indicates skewness. Detector truncation can bend the most
extreme quiet quantiles even when the underlying background is Gaussian.
Interpret this alongside A2, not as an independent hypothesis test. The code
uses `erfinv` and empirical interpolated percentiles, avoiding a Statistics
Toolbox dependency.

**B3: masked quiet autocorrelation.** Uses pairs at their original time offsets
and only when both samples are labeled quiet. It never concatenates separate
quiet runs. The sum of sample products at each lag is divided by the number
of eligible pairs, then normalized at zero lag. Lags with fewer than 30 pairs
are hidden; this is a display heuristic. For an approximately white quiet
background, nonzero-lag values should generally fluctuate near zero. Persistent
decay suggests correlated background; oscillation suggests a periodic component
or ringing. NIST describes autocorrelation as a way to examine time dependence
[R5]. Here the event mask and estimated mean complicate conventional white-noise
confidence limits, so none are presented as formal bounds.

If quiet correlation is material in your system's frequency band, replace the
quiet generator with a validated colored residual model before porting. Kasdin
[R8] is relevant to that extension; the present C++ export implements Gaussian
white quiet noise only. Do not claim AR/colored quiet noise is implemented merely
because an earlier gyro package had an AR filter.

**B4: adjacent quiet-sample scatter.** Plots excursion at k against k+1 only
for consecutive quiet samples in the original record. A roughly round cloud
supports weak lag-one dependence. A diagonal elongated cloud suggests positive
lag-one correlation; an anti-diagonal one suggests negative correlation.
Clusters can suggest multiple quiet states. The plot is subsampled to at most
roughly 3,000 pairs for readability; B3 uses the available pairs. A round cloud
does not prove independence or rule out higher-lag structure.

### Figure C — distribution, spectrum and full-signal correlation

The reference here is the held-out suffix. Each generated record has exactly
that sample count and duration. Do not compare its counts against all 120
seconds of the synthetic input. Each spectral comparison uses the same rate,
window, record length and frequency grid on both sides.

**C1: held-out time history.** Shows the actual selected error in the validation
interval, with its original quiet offset and pulse mean retained. Look for the
sign balance, shapes, pulse durations, gaps and clustering you care about.
Use this to interpret aggregate statistics. It is not part of parameter fitting.

**C2: one new realization.** Should have plausible behavior of the same kind,
but not pulses at the same times as C1. Pointwise RMSE or waveform correlation
between these two independent realizations is therefore not an appropriate
main validation criterion. Obvious repeated unusual shapes reveal template
reuse; more diverse training data or a justified parametric pulse model may
be needed for long simulations. A new model record can have more or fewer
events than C1 even when the model is adequate.

**C3: amplitude probabilities with ensemble range.** Black is the held-out
probability per bin. Red is the mean across new model records; shading spans
the pointwise 5th–95th percentiles across those records. Bins are defined from
the reference, but outer bins collect all model values beyond the reference
extremes; those tail masses are displayed at the outer finite bin centers.
A central mismatch points toward quiet spread, offset or occupancy errors.
A tail mismatch points toward pulse amplitudes/durations/occupancy. The saved
binned total-variation distance is `0.5 * sum(abs(p_test - p_model_mean))`.
It is bin-dependent and can conceal differences within a bin.

The band is a conditional simulation range with fitted parameters held fixed.
It is **not** a confidence interval on model parameters, not simultaneous
coverage across bins, and not proof that every future record will fall inside.
Fifty realizations make a useful first plot; substantially more help stabilize
its outer quantiles. Increasing realizations does not compensate for a short
hardware training record.

**C4: AC Welch PSD.** Each record's overall mean is removed for this diagnostic
only. A Hamming window of approximately `welchWindow_s` seconds is used, capped
at one quarter of the validation record, with 50% overlap. FFT length is a
power of two at least 256. PSD units are µg²/Hz. Black is reference; red is the
mean PSD in linear units across realizations, with pointwise simulation ranges.
Welch's overlapping-segment estimate is documented by MathWorks [R6].

The engineering purpose is to check whether model fluctuation power lands in
similar frequency regions. Excess low-frequency power can accompany long pulses,
uneven occupancy or drift. Broad high-frequency content is compatible with
sharp edges, short pulses or white noise; it does not establish a square wave.
Persistent narrow peaks suggest repeatable tones/timing that the empirical IID
model may not preserve. Compare repeated records before labeling a single PSD
wiggle a physical tone. A shorter segment gives coarser frequency discrimination;
zero padding does not restore information absent from the segment.

`PSD_LogRatio_RMSE_dB` is the RMS of `10*log10(model_mean_PSD / reference_PSD)`
over positive-frequency bins. It summarizes disagreement, but is sensitive
to band choice, estimator variability and near-zero reference power. There is
no universal acceptable dB threshold. Define a band and budget relevant to your
estimator/controller if you need an acceptance requirement. Integrated AC PSD
relates to fluctuating variance, not the signed mean or total RMS.

**C5: single-record amplitude FFT.** Black and red compare the reference and
one model record after mean removal, using a periodic Hann window, normalization
by the window sum, and correct one-sided doubling except DC/Nyquist. Units are
µg, not µg/√Hz or PSD units. MathWorks documents `fft` and one-sided spectra
[R7]. The window correction is appropriate to interpreting coherent tones;
random broadband-bin heights still depend on record length and window.

Overlapping, jagged curves are expected for different random realizations. Do
not force individual random FFT peaks to coincide. A train of sharp irregular
pulses spreads energy broadly; synthesizing many FFT sinusoids is not necessary
to reproduce it. If an isolated peak persists across independent records and
matters dynamically, test an added explicit tone or a timing mechanism. Fitting
the FFT magnitude alone would not retain pulse timing or phase relationships.

**C6: full-signal normalized autocorrelation.** Each record is centered for
this diagnostic, and a biased sample autocorrelation is normalized by its
zero-lag value. This includes pulse structure; it is different from B3's quiet
ACF. Zero lag is one for a nonconstant signal. The width of the initial decay
reflects temporal persistence; later peaks can reflect repeated timing or
oscillation. A model that matches amplitude histograms but loses this structure
is missing time dependence. `ACF_RMSE` compares reference with ensemble mean
over the plotted lag range, so its interpretation depends on `maxLag_s`.
Shading again shows pointwise conditional simulation variation, not a formal
multiple-lag hypothesis test. Undefined constant-signal ACFs are NaN, not proof
of a successful fit.

### Figure D — event statistics, including pulse area

Events are detected with the training-fitted thresholds on both reference and
generated records. Only complete events enter these statistics. For multiple
selected axes, an event is the union interval; an axis contributes an event
statistic only if its own absolute peak crosses its detection level within
that interval. Width and gaps remain joint-event quantities. This avoids
claiming that an axis had a large event merely because another axis triggered.

The model curves pool complete events from all generated records; records with
more events contribute more samples. These are descriptive CDFs, **not CDF
confidence bands** or independent samples for a naive significance test. No
events on a side/axis means insufficient evidence, not perfect matching.

**D1: signed peak CDF.** For each eligible event and axis, choose the excursion
with largest absolute magnitude and keep its sign. A sharp rise at negative
values reflects the share of negative-dominant events. A model shifted toward
larger positive values can overstate velocity increments even if its quiet
histogram matches. If an event is bipolar, this statistic records only its
dominant signed peak; inspect its waveform and area too. A CDF's maximum
observed value is not a justified physical upper bound.

**D2: event-duration CDF.** Width is number of active samples divided by Fs,
not end timestamp minus start timestamp. A one-sample event therefore has
duration 1/Fs. A model shifted to larger widths retains anomalous acceleration
longer. Stair steps near multiples of 1/Fs are normal sampling granularity.
An unexpected pileup of minimum-width events may indicate isolated digital
spikes, unresolved physical pulses or detector chatter. Check A2 before
inventing a new physical pulse population.

**D3: preceding-quiet-gap CDF.** Counts quiet samples between the previous
event and the current one. A current event without an observed predecessor has
an unknown/censored preceding gap and is excluded from this feature. Too many
short model gaps can create overly frequent bursts. Very long gaps beyond
training support cannot be generated by this bootstrap. Gaps are drawn with
their following waveform, preserving measured gap-to-current-event association.
No exponential-gap assumption is imposed.

**D4: event-start-interval CDF.** Measures time between successive complete
detected event starts in each record. This includes prior pulse duration plus
the following quiet gap and is not identical to D3. A narrow concentration
around a period suggests near-periodic timing; a broad spread suggests more
variable recurrence. Matching D3 does not guarantee matching D4 when the model
fails to reproduce dependencies between successive events. Significant mismatch
here can motivate a jittered-period, renewal-history, or condition-dependent
model rather than simply more FFT tones.

**D5: signed pulse-area CDF.** Sums event excursion above quiet baseline times
dt. Its units are µg·s; multiplying by 9.80665e-6 converts each area to its
event velocity-error contribution in m/s. Area captures amplitude AND duration
AND sign. This is often more directly relevant to an integrating IMU than
matching maximum amplitude alone. A bipolar event can have a large peak and
small net area. Thresholding truncates low tails, so include boundary/threshold
sensitivity in your interpretation. This is not the integral of the whole
record or the baseline contribution.

**D6: gap versus absolute peak scatter.** Checks whether large pulses tend to
follow longer or shorter quiet intervals. Gray/black reference points are
compared with pooled red model events (display subsampled for readability).
Pairing gaps with templates preserves relationships within training tuples;
the held-out relation can differ through sampling variability or a regime
change. A matching cloud does not prove serial independence between events.
There is no causal inference from this scatter.

### Figure E — would constant bias or mean-plus-Gaussian be enough?

Three candidates are compared: the fitted pulse model; independent Gaussian
samples matched to the **training full-signal mean and variance**; and a constant
equal to that training mean. All are integrated with zero initial error over
the validation duration. The reference is the actual held-out signal. No model
uses the held-out mean as its fitted constant, avoiding that form of leakage.

The integrator assumes piecewise-constant acceleration over each sensor sample:

`v(k+1) = v(k) + a(k)*dt`

`p(k+1) = p(k) + v(k)*dt + 0.5*a(k)*dt^2`.

Plots include the initial zero and all n interval boundaries; terminal time is
n/Fs, while the final acceleration sample timestamp is (n-1)/Fs. These are
open-loop sensor-axis error integrations with a fixed frame, no gravity/orientation
error dynamics, and no estimator corrections. They are not a complete INS,
position-navigation forecast, or your actual closed-loop simulation.

**E1: velocity error.** Red and blue curves/ranges correspond to pulse and
Gaussian ensembles; green is mean-only; black is reference. For an ideal
integrator, velocity depends on signed acceleration area. Similar terminal
velocities can coexist with very different intermediate errors. If pulse
and Gaussian ranges differ substantially, temporal correlation, event-area
variability and tails matter beyond matching instantaneous variance. A constant
mean can reproduce one record's net velocity increment if fitted to that same
record, but this experiment deliberately tests a different suffix.

**E2: position error.** Earlier acceleration errors influence position for a
longer time. In continuous form, `position_error(T)=integral((T-t)*e(t), dt)`
for zero initial conditions. Thus equal full-record means need not produce
equal position errors when event timing differs. If all models give practically
equivalent position-error behavior within your system budget, individual pulses
may add little value for that particular use. If they differ near a requirement
limit, preserving the intermittent process is justified. A visually large
difference must still be judged against engineering tolerances.

**E3: terminal velocity CDF.** Shows variation across whole generated records,
not per-sample amplitude variation. The green line has no ensemble spread
because the mean-only candidate is deterministic. The black line is one
observed held-out result, not a measured population percentile. A narrow
Gaussian CDF and broad pulse CDF warn that a same-variance Gaussian simplification
may underestimate run-to-run integrated uncertainty. Many independent hardware
records are needed to validate a tail probability.

**E4: terminal position CDF.** Same interpretation for final position. Its
tails can be especially sensitive to pulse occurrence times and duration.
This directly supports a model-choice discussion, but does not automatically
establish a flight/mission/system-level probability of exceedance. Compare
these candidates in your real estimator/controller, including rejection gates
and saturation, before deciding the simpler model is adequate.

### Optional Figure F — multi-axis and class-transition checks

This four-tile figure appears with multiple selected axes or optional class
Markov modeling. **F1/F2** compare held-out zero-lag selected-axis correlation
with the average model correlation. Joint templates and quiet covariance can
preserve simultaneous structure; mismatches can indicate changing cross-axis
coupling or incomplete event support. Correlation can be dominated by a few
large events and does not establish causality or a frame definition.

**F3** shows raw training transition counts for the six dominant axis/sign
classes. Small counts reveal weak evidence, even if a normalized probability
looks extreme. **F4** shows probabilities after smoothing toward class frequency.
Rows for never-observed previous classes are fallback distributions, not learned
transitions from those classes. With `useEventMarkov=false`, these probabilities
are computed for inspection but not used in generation. With it true, only
first-order class dependence is represented; amplitude/gap serial dependencies
and slow regime switching are still outside the model.

If the data instead dwells at two sustained levels, random-telegraph/hidden
state models are another research direction. Puglisi and Pavan [R9] use hidden
Markov methods to analyze level switching and dwell behavior in electronic
memory noise. That is methodological context, not evidence of the same physical
mechanism in your accelerometer.

## 6. Saved tables and what they do NOT mean

`Analysis.mat` contains `results` and `PulseModel`, including configuration,
training/reference samples, generated ensemble, event statistics, spectra,
integration results and review checklist. Graphics handles are excluded.

`ValidationSummary.csv` contains, per selected axis, held-out statistics, the
model ensemble mean and its pointwise 5th/95th percentile range: signed mean,
population standard deviation, total RMS, 0.1%/99.9% sample quantiles, maximum
absolute sample, positive/negative event counts and rates, positive/negative
threshold sample fractions, and final/maximum absolute integrated velocity and
position. Counts use complete events; threshold sample fractions include all
recorded samples, including boundary excursions. Each axis is counted only when
its own peak crosses its threshold inside a joint event.

`InsideModelRange` is descriptive. It is not a pass/fail hypothesis test.
Some values can lie outside a 90% pointwise model range even for an adequate
model, and the metrics are dependent. Repeated threshold tuning on the same
held-out suffix makes it development data; reserve a new independent record for
final evaluation after that tuning.

`SpectralSummary.csv` reports positive-frequency PSD log-ratio RMSE, plotted-ACF
RMSE and binned amplitude total variation. They have no universal acceptance
cutoffs. Choose tolerances based on downstream consequences, measurement
repeatability and operating requirements; do not invent a statistical confidence
level from an arbitrary small score.

`Summary_PLT.csv` reports all three platform components of the **selected-axis
contribution**: quiet baseline, held-out signed mean, AC RMS (population standard
deviation), total RMS, and one generated record's mean/AC RMS. Total RMS satisfies
`RMS² = mean² + variance`. RMS is nonnegative and is not a signed bias. The quiet
baseline is not the total pulse-contaminated mean. Other unmodeled axes' real
biases are not silently included in this table.

`Training_Event_Catalog.csv` documents eligible waveform indices, lengths,
preceding gaps, classes, peaks and signed areas. Indices are MATLAB one-based
positions in the TRAINING interval after conversion/window selection, not
original workbook row numbers. `History_sensor.csv`, `Generated_sensor.csv`,
`Generated_PLT.csv` use µg errors. `Generated_sensor_ft_s2.csv` converts generated
sensor error to ft/s²; it does not add true gravity/motion back into the signal.
`Provenance.json` records selections, rate, time source, first/last original row,
transform, synthetic label and config.
Retain the original input file and configuration when maintaining traceability.

## 7. When is the candidate good enough to port?

Exporting proves constants were written, not that a model is validated.
`Readiness.csv` deliberately records unreviewed items rather than issuing an
automatic READY label. Use the following evidence in order:

1. **Input meaning:** confirm units, baseline, axis identity, sample timing,
   rotation direction and logger rule. A synthetic demo is not hardware evidence.
2. **Detector validity:** manually inspect representative positive and negative
   events, quiet periods, tails and any rail behavior. Repeat with reasonable
   threshold variations. Conclusions that reverse under tiny changes are fragile.
3. **Sufficient event support:** examine counts by sign/class and regime, not
   just total samples. Five eligible events only lets the algorithm run. Thirty
   events is merely a review heuristic; it is not a validated adequacy threshold.
   A few negative pulses cannot establish a rare negative-tail law. Zero observed
   events of a type cannot justify declaring the physical probability zero.
4. **Background model:** B1/B2 should make a Gaussian quiet approximation
   defensible, and B3/B4 should not show material ignored dependence. If they do,
   change the quiet model and its C++ implementation together.
5. **Out-of-fit behavior:** inspect held-out signs, counts/rates, pulse areas,
   widths, gaps, amplitudes, AC PSD and ACF; explain material mismatches. Validate
   across independent runs and relevant temperature/load/vibration conditions
   rather than assuming one interval represents all operation.
6. **Downstream usefulness:** compare mean-only, Gaussian and pulse candidates
   in the actual simulator. Define tolerable differences in position/velocity
   distributions, estimator decisions, maximum excursions and requirement
   exceedances. If pulses do not change the decisions of interest materially,
   the simpler model can be sufficient for that purpose.
7. **Language/clock equivalence:** run the C++ candidate and compare its long-run
   statistics with the MATLAB ensemble using multiple seeds, identical sample
   rates and equal record durations. Verify inactive axes, reset, rotation,
   unit conversion and accumulation separately. See the procedure below.
8. **Document release scope:** identify which sensor axes, operating regime,
   bandwidth, run duration and observed amplitude/gap support were validated.
   The empirical catalog does not establish behavior outside that scope.

These criteria are engineering review criteria for this suite. The cited papers
provide foundations for model families and diagnostics, not a blanket
certification rule or universal numeric acceptance threshold. Your actual
system requirements determine whether porting is useful and adequate.

## 8. C++ export and integration into your function

Each run writes `Candidate_IMU_Model.cpp`, a full single-source scaffold with
fitted arrays. It has constants and prototypes at the top, persistent generator
state, then an example `void IMU_error()` and helper functions below it.
Unexported `cpp/IMU_Pulse_Integration_Template.cpp` deliberately refuses to run
because `fitted=false`. The exporter asserts exact zero inactive sensor baseline,
factor rows and waveform columns before producing the candidate.

In your implementation:

1. Bind the actual source sensor update rate: `sensor_dt_s=1/PulseModel.Fs` and
   `sensor_tick=0,1,2,...`. Model widths/gaps are sample counts. Do not reuse the
   constants at another rate without re-identifying/resampling the model.
2. Reset the persistent state once per independent Monte Carlo run/regime and
   provide the run seed. Reset your downstream accumulators separately. Use a
   separate state per sensor instance/thread; the example static state is for
   one instance.
3. Generate ONE joint sensor vector before your final XYZ loop, not one new
   event per component. Repeated requests at the same sensor tick return the
   cached vector. Backward ticks fail. Skipped ticks advance the generator but
   do not integrate missing physical intervals for you.
4. Supply your actual `R_sensor_to_platform` at the adapter inputs, using the
   same convention as MATLAB. Its example default is identity; the MATLAB
   configuration matrix is documented in Provenance.json, not automatically
   inserted into the C++ adapter. This is an explicit simulation binding.
5. Rotate the sampled model fluctuation and quiet baseline once. Add those
   contributions to your existing `noise[ii]` and `bias[ii]` sums respectively.
   These quantities are sampled acceleration errors in µg, not RMS parameters
   or noise densities. Insert after existing RMS-to-random-sample generation
   if that is how your function is structured.
6. Remove the older quiet-noise source and mean/quiet baseline for the SAME
   modeled process. Keep independent other errors. Do not multiply the generated
   pulse by another RMS coefficient/random draw, or add an old full-record mean
   on top. The pulse excursion already carries its nonzero mean contribution.

The final interface depends on what your internal accumulator actually consumes:

- Acceleration error in µg: `noise[ii]+bias[ii]`.
- Acceleration error in ft/s²: multiply by `1e-6*9.80665/0.3048`.
- Velocity increment error in ft/s: multiply that result by the source sample dt.

Choose one insertion point; do not inject both acceleration and its integrated
increment. If your simulation only accepts one constant bias parameter, it cannot
reproduce these time-varying pulses without changing that interface.

Do not copy the gyro's `current_noise - previous_noise` operation into an
acceleration integrator by analogy. Differencing a pulse produces edge changes;
summing such differences telescopes. That is different from summing acceleration
times dt. A current-minus-previous operation can be valid for an error already
defined on a cumulative measurement, but only with the actual units and update
equations established. This package does not invent the omitted internal update
in your simulator.

### Exercise the exported source, not only the template

After the default MATLAB run, from the package folder on a machine with g++:

```sh
g++ -std=c++11 -O2 -Wall -Wextra -Werror -pedantic cpp/Check_Exported_Model.cpp -o check_export
./check_export 7200 1234 > output/CPP_Trace.csv
```

7,200 is the held-out count for the included 24,000-sample, 70% split example.
For your own run, use `size(results.reference,1)` instead. Windows executable
names and shell invocation may differ. The checker samples the actual exported
model, checks its example `IMU_error()` binding with identity rotation, and
writes instantaneous sensor-frame error **including the quiet baseline**.

For hardware output, compile with a different included source path:

```sh
g++ -std=c++11 -O2 -DIMU_MODEL_FILE='"../output_hardware/Candidate_IMU_Model.cpp"' cpp/Check_Exported_Model.cpp -o check_export
./check_export YOUR_SAMPLE_COUNT 1234 > output_hardware/CPP_Trace.csv
```

Set `outputFolder` in `Check_CPP_Output.m` to the corresponding directory, then
run it. Four tiles per selected axis compare C++ time history, histogram, PSD
and ACF against the MATLAB model. A table compares C++ metrics to MATLAB ranges.
Use multiple independent seeds; one run is a sanity check, not equivalence proof.
The two implementations use different random generators and are not expected
to match sample-for-sample. Both use the same event probabilities, tuples,
baseline, quiet covariance, overwrite rule and source sample clock.

These tests use the example identity binding. Separately test your actual
rotation using known sensor vectors and test the real accumulator with known
constant/pulse inputs. Confirm the factors of dt, 0.3048 and 9.80665 directly.

Additional tests:

```matlab
addpath('tests');
Test_Config_And_Time
Test_Selected_Axes
```

```sh
g++ -std=c++11 -Wall -Wextra -Werror -pedantic cpp/test_imu_pulse.cpp -o test_pulse
./test_pulse
g++ -std=c++11 -Wall -Wextra -Werror -pedantic cpp/test_selected_axes.cpp -o test_axes
./test_axes
```

## 9. Evidence and further reading

The following primary research/institutional documentation was checked when
preparing this package. The algorithms and plot interpretations above are an
explicit engineering synthesis. No paper establishes that the described sensor
must follow this exact bootstrap or that a matching PSD alone validates it.

- **[R1]** P. Brémaud, L. Massoulié and A. Ridolfi (2005), *Power spectra of
  random spike fields and related processes*, Advances in Applied Probability
  37(4), 1116–1146. DOI: [10.1239/aap/1134587756](https://doi.org/10.1239/aap/1134587756).
  [Publisher abstract](https://www.cambridge.org/core/journals/advances-in-applied-probability/article/power-spectra-of-random-spike-fields-and-related-processes/4F8CEA2988AADA3B65EE31A4C16B23A9).
  General random-event/shot-noise spectral framework; not accelerometer-specific
  failure identification and not a requirement to assume Poisson events.
- **[R2]** NIST Dataplot, [Median Absolute Deviation](https://www.itl.nist.gov/div898/software/dataplot/refman2/auxillar/mad.htm).
  Robust scale and its normal-distribution scaling; does not validate our chosen
  detector multipliers.
- **[R3]** NIST/SEMATECH e-Handbook, [Histogram](https://www.itl.nist.gov/div898/handbook/eda/section3/histogra.htm).
  Exploratory distribution summaries and normalized histogram conventions.
- **[R4]** NIST/SEMATECH, [Histogram interpretation: bimodal mixture of two normals](https://www.itl.nist.gov/div898/handbook/eda/section3/histogr5.htm).
  An example of multiple population modes; not proof that your data is a normal
  mixture or that a histogram contains switching-time information.
- **[R5]** NIST/SEMATECH, [Autocorrelation Plot](https://www.itl.nist.gov/div898/handbook/eda/section3/autocopl.htm).
  Time-dependence diagnostics; our masked quiet estimator is described explicitly
  above, and formal NIST confidence limits are not asserted for it.
- **[R6]** MathWorks, [pwelch](https://www.mathworks.com/help/signal/ref/pwelch.html)
  and [xcorr](https://www.mathworks.com/help/matlab/ref/xcorr.html).
  Authoritative function definitions/scaling. Our simulation bands are distinct
  from pwelch's optional analytical PSD confidence intervals.
- **[R7]** MathWorks, [fft](https://www.mathworks.com/help/matlab/ref/fft.html).
  Discrete Fourier transforms and one-sided amplitude-spectrum convention.
- **[R8]** N. J. Kasdin (1995), *Discrete Simulation of Colored Noise and
  Stochastic Processes and 1/f^alpha Power Law Noise Generation*, Proceedings
  of the IEEE 83(5), 802–827. DOI: [10.1109/5.381848](https://doi.org/10.1109/5.381848).
  [University-hosted paper](https://umbc.edu/photonics/Menyuk/Phase-Noise/kasdin_ProcIEEE_950501n.pdf).
  Your uploaded copy was inspected. Relevant to a future colored-background
  extension; this suite does not implement that extension.
- **[R9]** F. M. Puglisi and P. Pavan (2014), *Factorial Hidden Markov Model
  analysis of Random Telegraph Noise in Resistive Random Access Memories*,
  ECTI Transactions 12(1), 24–29.
  [Paper and DOI](https://ph02.tci-thaijo.org/index.php/ECTI-EEC/article/view/170814).
  Alternative model family for sustained level switching, in a different device
  context. It does not diagnose your accelerometer.

NIST's [outlier discussion](https://www.itl.nist.gov/div898/handbook/eda/section3/eda35h.htm)
also explains why unusual observations should not simply be deleted without
establishing they are erroneous. Here the excursions are the behavior you intend
to model, so generic outlier removal would undermine that goal.

The uploaded Durbin paper concerns time-series fitting; it is not used to claim
an AR quiet model or a physical intermittent-fault model in this implementation.
No copyrighted paper PDFs are redistributed in the ZIP; references are linked.
