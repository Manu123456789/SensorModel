function Test_Fourier
% Requires MATLAB R2021b and Signal Processing Toolbox. No Statistics Toolbox.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(root);
c=testConfig; stream=RandStream('mt19937ar','Seed',7);
for n=[512 513]
    x=zeros(n,3); x(:,2)=.3+.2*randn(stream,n,1);
    x(31,2)=180; x(204,2)=-120; x(400,2)=60; % Single-sample spikes.
    [m,~]=imufourier.fit(x,200,[false true false],c);
    y=imufourier.generate(m,3*n,stream,0);
    assert(max(abs(y(:,2)-repmat(x(:,2),3,1)))<1e-9);
    assert(all(y(:,[1 3])==0,'all'));
    % Verify EXPLICIT SINE SUM, not only ifft(fft()) round-trip.
    t=(0:n-1)'/200; direct=repmat(m.mean_ug(2),n,1);
    for j=1:numel(m.toneFreq{2})
        direct=direct+m.toneAmp{2}(j)*sin(2*pi*m.toneFreq{2}(j)*t+m.tonePhase{2}(j));
    end
    assert(max(abs(direct-x(:,2)))<1e-8);
    shifted=imufourier.generate(m,n,stream,13);
    assert(max(abs(shifted(:,2)-x(mod((0:n-1)'+13,n)+1,2)))<1e-9);
end
% DC and positive/negative signed Nyquist coefficients, without factor-of-two.
n=512; k=(0:n-1)';
for amplitude=[-3 0 3]
    x=zeros(n,3); x(:,2)=2+amplitude*(-1).^k;
    [m,~]=imufourier.fit(x,200,[false true false],c);
    y=imufourier.generate(m,n,stream,0); assert(max(abs(y(:,2)-x(:,2)))<1e-10);
end
% Reduced tones expose residual spikes; optional white sigma uses QUIET only.
[T,~]=Generate_Example_IMU(200,4); d=imufourier.prepare(T,c);
c.maxTones=16; c.ambientMode='white'; [m,info]=imufourier.fit(d.y,200,d.mask,c);
q=info.residual(info.quietMask(:,2),2);
assert(abs(m.whiteSigma_ug(2)-std(q,1))<1e-10);
c.maxTones=0; c.ambientMode='none'; [offsetOnly,~]=imufourier.fit(d.y,200,d.mask,c);
[C,tones]=imufourier.coefficients(offsetOnly); assert(C.NumberOfTones==0 && height(tones)==0);
assert(isnumeric(tones.Frequency_Hz)&&isnumeric(tones.Amplitude_ug)&&isnumeric(tones.Phase_rad));
y=imufourier.generate(offsetOnly,800,stream,0); assert(all(y(:,2)==offsetOnly.mean_ug(2)));
% Workspace table units and row clock remain the same as the prior package.
c.maxTones=Inf; tt=table2timetable(T,'RowTimes',seconds((0:height(T)-1)'*7));
d2=imufourier.prepare(tt,c); assert(isequal(d.y,d2.y)&&isequal(d.t,d2.t));
c.inputMode='delta_velocity_ft_s'; Td=T; Td{:,:}=T{:,:}*9.80665e-6/.3048/200;
d3=imufourier.prepare(Td,c); assert(max(abs(d.y(:)-d3.y(:)))<1e-10);
c.inputMode='instantaneous_ug';
r=imufourier.analyze(T,c); assert(r.distinctModelRuns==1 && r.Coefficients.NumberOfTones==400);
assert(r.FitReview.FullReferenceRMSE_ug<1e-9);
r.cfg.makePlots=true; figs=imufourier.plotDiagnostics(r); assert(numel(figs)>=11); close(figs);
% Independent ACF aggregation check with unequal realization variances.
v=(0:511)'; a=sin(2*pi*3*v/512); b=8*cos(2*pi*7*v/512);
ca=xcorr(a,8,'biased'); cb=xcorr(b,8,'biased'); ca=ca(9:end); cb=cb(9:end);
expected=(ca+cb)/(ca(1)+cb(1));
actual=imufourier.normalizeACF((ca+cb)/2);
assert(max(abs(expected-actual))<1e-12);
assert(max(abs(actual-.5*(ca/ca(1)+cb/cb(1))))>.01);
% Cross-check overlapping Allan implementation against explicit block means.
w=randn(stream,1000,1); factors=[1 2 7 100]'; av=imufourier.allanVariance(w,factors);
for kk=1:numel(factors)
    mm=factors(kk); d=zeros(numel(w)-2*mm,1);
    for ii=1:numel(d), d(ii)=mean(w(ii+mm+1:ii+2*mm))-mean(w(ii+1:ii+mm)); end
    assert(abs(av(kk)-mean(d.^2)/2)<1e-11);
end
if exist('allanvar','file')==2
    [official,~]=allanvar(w,factors,200);
    assert(norm(av-official(:))/max(norm(official),realmin)<1e-7);
end
assert(max(abs(r.meanACF(:,2)-r.referenceACF(:,2)))<1e-9);
assert(max(abs(r.CumulativePower.MeasuredPower_ug2-r.CumulativePower.ToneOnlyPower_ug2))<1e-8);
assert(max(abs(r.AllanSummary.MeasuredADEV_ug-r.AllanSummary.ToneOnlyADEV_ug))<1e-8);
fprintf('PASS: full/partial Fourier; even/odd; DC/Nyquist; direct sine convention; multiple periods; common shift; ambient residual; units; row clock; diagnostic families.\n');
end
function c=testConfig
c=struct('sampleRate_Hz',200,'rowWindow',[1 Inf],'selectedAxes',{{'Y'}}, ...
    'histogramAxes',{{'X','Y','Z'}},'columns',struct('X','Example_X','Y','Example_Y','Z','Example_Z'), ...
    'inputMode','instantaneous_ug','baselineSensor_ms2',[0 0 0],'R_sensor_to_PLT',eye(3), ...
    'maxTones',Inf,'toneSelection','energy','ambientMode','none','phaseMode','aligned', ...
    'fitFraction',1,'sweepToneCounts',[8 32 128 Inf],'makeToneSweep',true, ...
    'detectSigma',5,'manualThreshold_ug',[NaN NaN NaN],'nRealizations',3,'seed',1234,'allanPoints',35, ...
    'histogramBins',60,'zoom_s',1,'quietZoom_s',.25,'maxLag_s',.5, ...
    'quietMaxLag_s',.1,'welchWindow_s',1,'block_s',1,'summaryTerminalWindow_s',1, ...
    'maxIntegrationPlotPoints',1000,'makePlots',false,'figureVisible','off', ...
    'saveResults',false,'saveFigures',false,'isSynthetic',true);
end
