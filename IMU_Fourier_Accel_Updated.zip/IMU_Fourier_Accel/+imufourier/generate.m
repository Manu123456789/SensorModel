function [x,offset]=generate(m,n,stream,offset)
% Fresh white noise is optional. The Fourier backbone repeats indefinitely.
% Repeated calls start fresh; request the desired MATLAB history in one call.
if nargin<3 || isempty(stream), stream=RandStream.getGlobalStream; end
validateattributes(n,{'numeric'},{'scalar','integer','positive'});
if nargin<4
    offset=0;
    if strcmp(m.phaseMode,'randomCircularShift'), offset=floor(rand(stream)*m.recordSamples); end
end
validateattributes(offset,{'numeric'},{'scalar','integer','>=',0,'<',m.recordSamples});
index=mod((0:n-1)'+offset,m.recordSamples)+1; x=zeros(n,3);
for j=find(m.selectedMask)
    y=imufourier.period(m,j); x(:,j)=y(index);
    if m.whiteSigma_ug(j)>0, x(:,j)=x(:,j)+m.whiteSigma_ug(j)*randn(stream,n,1); end
end
end
