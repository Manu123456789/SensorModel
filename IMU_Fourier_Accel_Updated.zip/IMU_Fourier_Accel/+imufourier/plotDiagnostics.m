function figs=plotDiagnostics(r)
% Same H/A/B/C/D/E/S families; at most six tiles. B checks the Fourier quiet background and optional white residual.
figs=[imufourier.plotSummary(r) imufourier.plotDensityPower(r) imufourier.plotWaveform(r) imufourier.plotSweep(r) imufourier.plotBackbone(r)]; m=r.model; c=r.cfg; fs=m.Fs; names={'X','Y','Z'};
fullTime=r.input.t-r.input.t(1); e=imufourier.detect(r.input.y,m);
if any(r.input.histMask)
    [f,t]=newFigure(r,'H_Observed_XYZ_Histograms',1,nnz(r.input.histMask)); figs(end+1)=f;
    for j=find(r.input.histMask)
        ax=nexttile(t); a=r.input.histValues_ft_s2(:,j); a=a(isfinite(a));
        if ~isempty(a), histogram(ax,a,c.histogramBins,'Normalization','probability'); end
        title(ax,['H: observed ' names{j}]); xlabel(ax,'Readout [ft/s^2]'); ylabel(ax,'Probability/bin'); grid(ax,'on');
    end
    title(t,'Observed XYZ distributions; visualization does not select modeled axes');
end
for j=find(m.selectedMask)
    label=names{j}; train=r.train(:,j); ref=r.reference(:,j); generated=r.exampleGenerated(:,j);
    [f,t]=newFigure(r,['A_' label '_Input_and_Detection'],2,3); figs(end+1)=f;
    marked=r.input.y(:,j); marked(~e.mask(:,j))=NaN;
    ax=nexttile(t); plot(ax,fullTime,r.input.y(:,j),'Color',[.6 .6 .6]); hold(ax,'on');
    plot(ax,fullTime,marked,'r'); yline(ax,m.baseline(j),'k:'); splitLine(ax,r);
    title(ax,'A1: measured input; red = detected events'); xlabel(ax,'Elapsed from selected row [s]'); ylabel(ax,'Error [ug]'); grid(ax,'on');
    ax=nexttile(t); keep=fullTime<=c.zoom_s;
    plot(ax,fullTime(keep),r.input.y(keep,j),'k'); hold(ax,'on'); plot(ax,fullTime(keep),marked(keep),'r','LineWidth',1.2);
    yline(ax,m.baseline(j)+m.threshold(j),'b--'); yline(ax,m.baseline(j)-m.threshold(j),'b--');
    
    
    title(ax,'A2: event-threshold zoom; red overlays measurement'); xlabel(ax,'Time [s]'); ylabel(ax,'Error [ug]'); grid(ax,'on');
    ax=nexttile(t);
    if r.hasHoldout
        a=train; b=ref; first='Fit portion'; second='Held-out portion';
    else
        q=floor(numel(train)/2); a=train(1:q); b=train(q+1:end);
        first='Measured first half'; second='Measured second half';
    end
    [~,edges]=histcounts(r.input.y(:,j),c.histogramBins);
    histogram(ax,a,edges,'Normalization','probability','DisplayStyle','stairs','DisplayName',first); hold(ax,'on');
    histogram(ax,b,edges,'Normalization','probability','DisplayStyle','stairs','DisplayName',second);
    set(ax,'YScale','log'); title(ax,'A3: measured portions, amplitude stability'); xlabel(ax,'Error [ug]'); ylabel(ax,'Probability/bin'); legend(ax,'show'); grid(ax,'on');
    [bt,mu,rate]=blockStats(r.input.y(:,j),e.start{j},fs,c.block_s);
    ax=nexttile(t); plot(ax,bt,mu,'o-'); splitLine(ax,r); title(ax,'A4: block mean'); xlabel(ax,'Elapsed [s]'); ylabel(ax,'Mean [ug]'); grid(ax,'on');
    ax=nexttile(t); plot(ax,bt,rate,'o-'); splitLine(ax,r); title(ax,'A5: event-start rate by block'); xlabel(ax,'Elapsed [s]'); ylabel(ax,'Events/s'); grid(ax,'on');
    ax=nexttile(t); plot(ax,r.input.sourceRows,fullTime); title(ax,'A6: original row / constructed elapsed time'); xlabel(ax,'Original row'); ylabel(ax,'Elapsed [s]'); grid(ax,'on');
    title(t,['Sensor ' label ': inspect detector; uniform sampling assumed']);

    [f,t]=newFigure(r,['B_' label '_Quiet_Background'],2,3); figs(end+1)=f;
    quiet=r.fitInfo.quietMask(:,j); residual=r.fitInfo.residual(:,j);
    genEvents=r.events{1}; genQuiet=~genEvents{j}.mask;
    measuredQuiet=r.reference(~r.refEvents{j}.mask,j); generatedQuiet=generated(genQuiet);
    ax=nexttile(t);
    if ~isempty(measuredQuiet), histogram(ax,measuredQuiet,40,'Normalization','pdf','DisplayStyle','stairs','DisplayName','Measured quiet'); end
    hold(ax,'on');
    if ~isempty(generatedQuiet), histogram(ax,generatedQuiet,40,'Normalization','pdf','DisplayStyle','stairs','DisplayName','Generated quiet'); end
    title(ax,'B1: quiet amplitude distributions'); xlabel(ax,'Error [ug]'); ylabel(ax,'Density'); legend(ax,'show'); grid(ax,'on');
    ax=nexttile(t); probabilities=linspace(.005,.995,99);
    qa=imufourier.percentile(measuredQuiet,100*probabilities); qb=imufourier.percentile(generatedQuiet,100*probabilities);
    plot(ax,qa,qb,'.'); hold(ax,'on'); plot(ax,qa,qa,'k--');
    title(ax,'B2: measured / generated quiet Q-Q'); xlabel(ax,'Measured quantile [ug]'); ylabel(ax,'Generated quantile [ug]'); grid(ax,'on');
    ax=nexttile(t); lag=(0:r.quietLag)'/fs;
    stem(ax,lag,imufourier.maskedACF(residual,quiet,r.quietLag),'.','DisplayName','Quiet fit residual'); hold(ax,'on');
    plot(ax,lag,[1;zeros(r.quietLag,1)],'r','DisplayName','White target if enabled');
    title(ax,'B3: quiet RESIDUAL ACF; gaps preserved'); xlabel(ax,'Lag [s]'); ylabel(ax,'Correlation'); legend(ax,'show'); grid(ax,'on');
    ax=nexttile(t); pair=find(quiet(1:end-1)&quiet(2:end)); pair=pair(1:max(1,ceil(numel(pair)/3000)):end);
    scatter(ax,train(pair),train(pair+1),5,'filled'); axis(ax,'equal');
    title(ax,'B4: measured consecutive quiet samples'); xlabel(ax,'Error k [ug]'); ylabel(ax,'Error k+1 [ug]'); grid(ax,'on');
    ax=nexttile(t); q=residual(quiet);
    if isempty(q), text(ax,.05,.5,'No quiet residual samples','Units','normalized');
    else, histogram(ax,q,40,'Normalization','pdf'); hold(ax,'on'); end
    sigma=m.whiteSigma_ug(j);
    if sigma>0
        u=linspace(-5*sigma,5*sigma,201); plot(ax,u,exp(-.5*(u/sigma).^2)/(sigma*sqrt(2*pi)),'r');
    else, text(ax,.05,.85,'No additional white noise','Units','normalized'); end
    title(ax,'B5: residual / optional added white law'); xlabel(ax,'Fit residual [ug]'); ylabel(ax,'Density'); grid(ax,'on');
    ax=nexttile(t); band(ax,lag,reshape(r.quietACF(:,j,:),r.quietLag+1,[]),'Generated quiet');
    plot(ax,lag,r.referenceQuietACF(:,j),'k','DisplayName',r.referenceLabel);
    title(ax,'B6: actual quiet ACF comparison'); xlabel(ax,'Lag [s]'); ylabel(ax,'Correlation'); legend(ax,'show'); grid(ax,'on');
    title(t,['Sensor ' label ': Fourier backbone already contains retained ambient behavior']);

    [f,t]=newFigure(r,['C_' label '_Distribution_and_Spectrum'],2,3); figs(end+1)=f;
    ax=nexttile(t); plot(ax,r.validationTime_s,ref,'k'); title(ax,['C1: ' r.referenceLabel]); xlabel(ax,'Reference-relative [s]'); ylabel(ax,'Error [ug]'); grid(ax,'on');
    ax=nexttile(t); plot(ax,r.validationTime_s,generated,'Color',[.8 .15 .15]); title(ax,'C2: one generated history'); xlabel(ax,'Elapsed [s]'); ylabel(ax,'Error [ug]'); grid(ax,'on');
    ax=nexttile(t); band(ax,r.histCenters{j}',reshape(r.histogram(:,j,:),c.histogramBins,[]),'Generated mean');
    plot(ax,r.histCenters{j},r.histReference(:,j),'k','DisplayName',r.referenceLabel);
    title(ax,'C3: amplitude probabilities, 5-95% range'); xlabel(ax,'Error [ug]'); ylabel(ax,'Probability/bin'); legend(ax,'show'); grid(ax,'on');
    ax=nexttile(t); keep=r.frequency_Hz>0;
    band(ax,r.frequency_Hz(keep),reshape(r.psd(keep,j,:),nnz(keep),[]),'Generated mean');
    plot(ax,r.frequency_Hz(keep),r.referencePSD(keep,j),'k','DisplayName',r.referenceLabel);
    set(ax,'XScale','log','YScale','log'); title(ax,'C4: AC Welch PSD, 5-95% range'); xlabel(ax,'Frequency [Hz]'); ylabel(ax,'PSD [ug^2/Hz]'); legend(ax,'show'); grid(ax,'on');
    ax=nexttile(t); [freq,a]=amplitudeFFT(ref,fs); [~,b]=amplitudeFFT(generated,fs);
    plot(ax,freq,a,'k','DisplayName',r.referenceLabel); hold(ax,'on'); plot(ax,freq,b,'Color',[.8 .15 .15],'DisplayName','Generated run 1');
    title(ax,'C5: single-record AC amplitude FFT'); xlabel(ax,'Frequency [Hz]'); ylabel(ax,'Amplitude [ug]'); legend(ax,'show'); grid(ax,'on');
    ax=nexttile(t); band(ax,(0:r.lag)'/fs,reshape(r.acf(:,j,:),r.lag+1,[]),'Covariance-averaged model ACF',r.meanACF(:,j));
    plot(ax,(0:r.lag)'/fs,r.referenceACF(:,j),'k','DisplayName',r.referenceLabel);
    title(ax,'C6: full-signal AC autocorrelation'); xlabel(ax,'Lag [s]'); ylabel(ax,'Correlation'); legend(ax,'show'); grid(ax,'on');
    title(t,['Sensor ' label ': fixed-coefficient simulation ranges, not confidence intervals']);

    [f,t]=newFigure(r,['D_' label '_Event_Statistics'],2,3); figs(end+1)=f;
    s=r.refEvents{j}; pool=poolEvents(r.events,j);
    ax=nexttile(t); eventCDF(ax,s.peak_ug,pool.peak,r.referenceLabel,'D1: signed event peak CDF','Peak [ug]');
    ax=nexttile(t); eventCDF(ax,s.width_s,pool.width,r.referenceLabel,'D2: event-duration CDF','Duration [s]');
    ax=nexttile(t); eventCDF(ax,s.gap_s,pool.gap,r.referenceLabel,'D3: preceding quiet-gap CDF','Gap [s]');
    ax=nexttile(t); eventCDF(ax,s.interval_s,pool.interval,r.referenceLabel,'D4: event-start-interval CDF','Interval [s]');
    ax=nexttile(t); eventCDF(ax,s.area_ug_s,pool.area,r.referenceLabel,'D5: signed pulse-area CDF','Area above quiet baseline [ug s]');
    ax=nexttile(t); good=isfinite(pool.gap)&isfinite(pool.peak); a=pool.gap(good); b=abs(pool.peak(good));
    take=1:max(1,ceil(numel(a)/1500)):numel(a); scatter(ax,a(take),b(take),8,[.8 .15 .15],'filled','DisplayName','Pooled generated'); hold(ax,'on');
    scatter(ax,s.gap_s,abs(s.peak_ug),22,'k','DisplayName',r.referenceLabel);
    title(ax,'D6: gap / absolute peak relationship'); xlabel(ax,'Preceding gap [s]'); ylabel(ax,'Absolute peak [ug]'); legend(ax,'show'); grid(ax,'on');
    title(t,['Sensor ' label ': same detector on measurements and generated output']);

    [f,t]=newFigure(r,['E_' label '_Integrated_Error_Comparisons'],2,2); figs(end+1)=f;
    M=numel(r.integrationTime_s);
    ax=nexttile(t); comparisons(ax,r.integrationTime_s,reshape(r.v(:,j,:),M,[]),reshape(r.gaussianV(:,j,:),M,[]),r.meanV(:,j),r.refV(:,j),r.referenceLabel);
    title(ax,'E1: velocity error, zero initial error'); xlabel(ax,'Elapsed [s]'); ylabel(ax,'Velocity error [m/s]');
    ax=nexttile(t); comparisons(ax,r.integrationTime_s,reshape(r.p(:,j,:),M,[]),reshape(r.gaussianP(:,j,:),M,[]),r.meanP(:,j),r.refP(:,j),r.referenceLabel);
    title(ax,'E2: position error, zero initial error'); xlabel(ax,'Elapsed [s]'); ylabel(ax,'Position error [m]');
    ax=nexttile(t); terminalCDF(ax,reshape(r.v(end,j,:),[],1),reshape(r.gaussianV(end,j,:),[],1),r.meanV(end,j),r.refV(end,j),r.referenceLabel);
    title(ax,'E3: whole-record terminal velocity CDF'); xlabel(ax,'Final velocity error [m/s]');
    ax=nexttile(t); terminalCDF(ax,reshape(r.p(end,j,:),[],1),reshape(r.gaussianP(end,j,:),[],1),r.meanP(end,j),r.refP(end,j),r.referenceLabel);
    title(ax,'E4: whole-record terminal position CDF'); xlabel(ax,'Final position error [m]');
    title(t,'Open-loop ZOH integration; constant mean and Gaussian comparisons use fit mean/variance');
end
if nnz(m.selectedMask)>1
    [f,t]=newFigure(r,'F_Multi_Axis_Phase_Check',2,2); figs(end+1)=f;
    quiet=all(r.fitInfo.quietMask(:,m.selectedMask),2);
    quietCorrelation=NaN(nnz(m.selectedMask));
    if nnz(quiet)>=2, quietCorrelation=corrcoef(r.train(quiet,m.selectedMask)); end
    eg=r.events{1}; qg=true(size(r.exampleGenerated,1),1);
    for jj=find(m.selectedMask), qg=qg & ~eg{jj}.mask; end
    generatedQuiet=NaN(nnz(m.selectedMask));
    if nnz(qg)>=2, generatedQuiet=corrcoef(r.exampleGenerated(qg,m.selectedMask)); end
    matrices={r.crossReference,r.crossMean,quietCorrelation,generatedQuiet};
    titles={'F1: measured full-signal correlation','F2: generated mean correlation','F3: measured quiet correlation','F4: generated quiet correlation'};
    for k=1:4
        ax=nexttile(t); imagesc(ax,matrices{k},[-1 1]); colorbar(ax); title(ax,titles{k});
        set(ax,'XTick',1:nnz(m.selectedMask),'XTickLabel',r.input.selectedAxes,'YTick',1:nnz(m.selectedMask),'YTickLabel',r.input.selectedAxes);
    end
    title(t,'Common circular shift preserves inter-axis phase; added white draws are independent');
end
end
function [f,t]=newFigure(r,name,rows,cols)
assert(rows*cols<=6); f=figure('Name',name,'NumberTitle','off','Visible',r.cfg.figureVisible,'Position',[60 60 1450 820]);
t=tiledlayout(f,rows,cols,'TileSpacing','compact','Padding','compact');
end
function splitLine(ax,r)
if r.hasHoldout, xline(ax,r.split/r.model.Fs,'b--','Fit / held-out'); end
end
function band(ax,x,Y,label,average)
K=size(Y,2); sorted=sort(Y,2); pos=1+(K-1)*[.05 .95];
lo=sorted(:,floor(pos(1)))+(pos(1)-floor(pos(1)))*(sorted(:,ceil(pos(1)))-sorted(:,floor(pos(1))));
hi=sorted(:,floor(pos(2)))+(pos(2)-floor(pos(2)))*(sorted(:,ceil(pos(2)))-sorted(:,floor(pos(2))));
for row=find(any(~isfinite(Y),2))'
    q=imufourier.percentile(Y(row,:),[5 95]); lo(row)=q(1); hi(row)=q(2);
end
x=x(:); fill(ax,[x;flipud(x)],[lo;flipud(hi)],[.8 .15 .15],'FaceAlpha',.16,'EdgeColor','none','HandleVisibility','off');
if nargin<5, average=mean(Y,2,'omitnan'); end
hold(ax,'on'); plot(ax,x,average,'Color',[.8 .15 .15],'LineWidth',1.2,'DisplayName',label);
end
function [f,a]=amplitudeFFT(x,fs)
n=numel(x); w=.5-.5*cos(2*pi*(0:n-1)'/n); z=abs(fft((x-mean(x)).*w))/sum(w);
a=z(1:floor(n/2)+1); if mod(n,2)==0, a(2:end-1)=2*a(2:end-1); else, a(2:end)=2*a(2:end); end
f=(0:floor(n/2))'*fs/n;
end
function eventCDF(ax,x,y,referenceLabel,caption,units)
drawCDF(ax,x,'k',referenceLabel); hold(ax,'on'); drawCDF(ax,y,[.8 .15 .15],'Pooled generated');
title(ax,caption); xlabel(ax,units); ylabel(ax,'Cumulative probability'); ylim(ax,[0 1]); legend(ax,'show'); grid(ax,'on');
end
function drawCDF(ax,x,color,label)
x=sort(x(isfinite(x)));
if isempty(x), plot(ax,NaN,NaN,'Color',color,'DisplayName',[label ': no complete events']);
else, stairs(ax,[x(1);x],[0;(1:numel(x))'/numel(x)],'Color',color,'LineWidth',1.2,'DisplayName',label); end
end
function p=poolEvents(events,j)
p=struct('peak',[],'width',[],'gap',[],'interval',[],'area',[]);
for k=1:numel(events)
    e=events{k}; e=e{j}; p.peak=[p.peak;e.peak_ug]; p.width=[p.width;e.width_s]; %#ok<AGROW>
    p.gap=[p.gap;e.gap_s]; p.interval=[p.interval;e.interval_s]; p.area=[p.area;e.area_ug_s]; %#ok<AGROW>
end
end
function [t,mu,rate]=blockStats(x,starts,fs,seconds)
L=max(1,round(seconds*fs)); first=(1:L:numel(x))'; t=zeros(size(first)); mu=t; rate=t;
for k=1:numel(first)
    a=first(k); b=min(a+L-1,numel(x)); t(k)=((a+b)/2-1)/fs;
    mu(k)=mean(x(a:b)); rate(k)=nnz(starts>=a&starts<=b)/((b-a+1)/fs);
end
end
function comparisons(ax,t,pulse,gaussian,constant,measured,label)
band(ax,t,pulse,'Fourier model');
plot(ax,t,mean(gaussian,2),'Color',[.1 .4 .8],'DisplayName','Mean + Gaussian (ensemble mean)');
% Gaussian interval is shown as dashed percentile curves to keep labels distinct.
sorted=sort(gaussian,2); K=size(gaussian,2); q=1+(K-1)*[.05 .95];
lo=sorted(:,floor(q(1)))+(q(1)-floor(q(1)))*(sorted(:,ceil(q(1)))-sorted(:,floor(q(1))));
hi=sorted(:,floor(q(2)))+(q(2)-floor(q(2)))*(sorted(:,ceil(q(2)))-sorted(:,floor(q(2))));
plot(ax,t,[lo hi],'--','Color',[.1 .4 .8],'HandleVisibility','off');
plot(ax,t,constant,'Color',[0 .5 0],'DisplayName','Fit mean (constant bias)');
plot(ax,t,measured,'k','LineWidth',1.3,'DisplayName',label); legend(ax,'show','Location','best'); grid(ax,'on');
end
function terminalCDF(ax,pulse,gaussian,constant,measured,label)
drawCDF(ax,pulse,[.8 .15 .15],'Fourier model'); hold(ax,'on'); drawCDF(ax,gaussian,[.1 .4 .8],'Mean + Gaussian');
xline(ax,constant,'Color',[0 .5 0],'DisplayName','Fit mean (constant bias)'); xline(ax,measured,'k--','DisplayName',[label ' endpoint']);
ylabel(ax,'Cumulative probability'); ylim(ax,[0 1]); legend(ax,'show','Location','best'); grid(ax,'on');
end
