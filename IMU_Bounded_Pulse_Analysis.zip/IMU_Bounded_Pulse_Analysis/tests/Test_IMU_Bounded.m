function Test_IMU_Bounded()
% MATLAB R2021b+ synthetic checks. No hardware qualification is claimed.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(root);
source=fileread(fullfile(root,'IMU_Config.m')); at=strfind(source,'%% RUN');
assert(numel(at)==1); eval(source(1:at-1));
cfg.makePlots=false; cfg.saveFigures=false; cfg.nRealizations=4;
cfg.sampleRate_Hz=200; cfg.baselineSensor_ms2=[0 0 0];
[T,truth]=Generate_Example_IMU(200,180);
T.Properties.VariableNames={'Channel X','Accel_Y_Custom','Sensor_Z'};
cfg.columns=struct('X','Channel X','Y','Accel_Y_Custom','Z','Sensor_Z');
cfg.rowWindow=[1000 2000]; d=imubounded.prepare(T,cfg);
assert(isequal(d.sourceRows,(1000:2000)') && d.t(1)==999/200 && d.t(end)==1999/200);
other=array2timetable(T{:,:},'SampleRate',17,'VariableNames',T.Properties.VariableNames);
d2=imubounded.prepare(other,cfg); assert(isequal(d.t,d2.t) && isequal(d.y,d2.y));
cfg.rowWindow=[1 Inf];
for axis={'X','Y','Z'}
    cfg.selectedAxes=axis; d=imubounded.prepare(T,cfg); j=find(d.mask);
    [m,info]=imubounded.fit(d.y,d.Fs,d.mask,cfg);
    assert(~isfield(m,'templates') && all(size(m.logMu)==[3 2]));
    assert(m.lower(j)==min(d.y(:,j)) && m.upper(j)==max(d.y(:,j)));
    assert(abs(m.bgMu(j)-truth.Parameters.bgMu(j))<1);
    assert(abs(m.bgSigma(j)-truth.Parameters.bgSigma(j))<1);
    assert(m.widthSamples(j,1)>m.widthSamples(j,2));
    assert(m.logMu(j,1)>m.logMu(j,2));
    x=imubounded.generate(m,50000,RandStream('mt19937ar','Seed',123));
    assert(all(all(x(:,~d.mask)==0)) && all(x(:,j)>=m.lower(j) & x(:,j)<=m.upper(j)));
    q=m.negativeProbability(j); W=[1-q q]*m.widthSamples(j,:)';
    assert(abs(m.Fs/(m.meanGapSamples(j)+W)-info.targetRate_Hz(j))<1e-10 || info.gapWasLimited(j));
end
cfg.selectedAxes={'Y'}; cfg.fitFraction=1; r=imubounded.analyze(T,cfg);
assert(~r.hasHoldout && isequal(r.train,r.reference) && height(r.Coefficients)==1);
assert(height(r.DensitySummary)==2 && height(r.PowerSummary)==1 && height(r.BoundsSummary)==1);
assert(all(r.BoundsSummary.GeneratedViolations==0));
assert(all(all(r.exampleGenerated(:,[1 3])==0)) && size(r.v,1)<=cfg.maxIntegrationPlotPoints);
cfg.fitFraction=.70; held=imubounded.analyze(T,cfg); assert(held.hasHoldout);
assert(held.model.lower(2)==min(held.train(:,2)) && held.model.upper(2)==max(held.train(:,2)));
% Zero background noise and a missing sign class must remain valid.
flat=zeros(5000,3); for first=101:400:4700, flat(first:first+19,2)=100; end
cfg.amplitudeWeight='samples'; [one,~]=imubounded.fit(flat,200,[false true false],cfg);
assert(one.negativeProbability(2)==0 && one.bgSigma(2)==0);
x=imubounded.generate(one,3000,RandStream('mt19937ar','Seed',4));
assert(all(x(:,2)>=0 & x(:,2)<=100));
% Conditional-normal law really is truncated, rather than clipped onto endpoints.
x=imubounded.boundedNormal(zeros(10000,1),1,-.3,.2,RandStream('mt19937ar','Seed',7));
assert(all(x>=-.3 & x<=.2) && ~any(x==-.3 | x==.2));
q=imubounded.boundedNormalQuantile([0 .5 1],0,1,-.3,.2);
assert(q(1)==-.3 && q(3)==.2 && q(2)>-.3 && q(2)<.2);
% Known ZOH weighting and reset windows.
x=zeros(23,3); x([1 20],2)=1; [v,p]=imubounded.windowEndpoints(x,10,10);
assert(size(v,1)==2 && abs(v(1,2)-v(2,2))<1e-15 && p(1,2)>p(2,2));
% Cumulative decoder uses the previous original row.
cfg.histogramAxes={'Y'}; cfg.rowWindow=[1000 2000]; original=imubounded.prepare(T,cfg);
accum=T; accum.Accel_Y_Custom=cumsum(T.Accel_Y_Custom*30.48); cfg.inputMode='sample_sum_cm_s2';
decoded=imubounded.prepare(accum,cfg); assert(max(abs(original.y(:,2)-decoded.y(:,2)))<1e-7);
% All previous figure families plus G, at most SIX data axes each.
r.cfg.figureVisible='off'; figures=imubounded.plotDiagnostics(r); assert(numel(figures)==8);
for k=1:numel(figures), assert(numel(findall(figures(k),'Type','axes'))<=6); end
close(figures);
fprintf('PASS: signed laws/widths, hard bounds, onset-density fit, row clock, fit modes, figures.\n');
end
