%% Random pulse events + quiet Gaussian background: identification / validation
% MATLAB R2021b; Signal Processing Toolbox (pwelch). No Statistics Toolbox.
% Run as-is for a SYNTHETIC DEMO. Set useDemo=false for your Results_sensor.
% This is a descriptive bootstrap model, not a claim about physical fault causes.
% No global mean subtraction in generation, histograms, or saved histories.
% Source pulse templates already contain event-time noise: overwrite their
% intervals rather than adding white noise twice. Quiet intervals get new noise.
% Joint XYZ templates preserve simultaneous multi-axis event structure.

%% EDIT settings
useDemo = true;                       % FALSE: use the processed Results_sensor table
nRealizations = 100;
seed = 1234;
fitFraction = 1;                      % 1=in-sample; e.g. .7=fit prefix, validate suffix
detectSigma = 5;                      % Detection thresholds in quiet-noise sigma
releaseSigma = 2;                     % End an event when ALL axes return inside this
manualThreshold_ug = [NaN NaN NaN];    % Optional positive absolute threshold per axis
useEventMarkov = true;                % Learn first-order sign/dominant-axis transitions
markovPrior = 1;                      % Total pseudo-count per row; avoids sparse traps
maxLag_s = 2;
% Use your actual matrix here if exporting platform-frame samples:
if ~exist('R_sensor_to_PLT','var'), R_sensor_to_PLT=eye(3); end

%% Input: native-rate, known-baseline-corrected SENSOR errors in micro-g
if useDemo
    rng(42); Fs=100; t=(0:1/Fs:80-1/Fs)';
    y=randn(numel(t),3)*[5 1 0;0 7 1;0 0 4]+[2 -3 1];
    cursor=100;
    while cursor<numel(t)-100
        gap=round(Fs*(.25+exp(-.25+.45*randn)));
        width=max(3,round(Fs*(.03+.15*rand)));
        cursor=cursor+gap; if cursor+width>numel(t), break; end
        u=linspace(0,1,width)';
        if rand<.5, shape=exp(-5*u); else, shape=1-abs(2*u-1); end
        amplitude=exp(log(300)+.45*randn); if rand<.2, amplitude=-.5*amplitude; end
        y(cursor:cursor+width-1,:)=y(cursor:cursor+width-1,:)+ ...
            amplitude*shape*[.2 1 -.15];
        cursor=cursor+width;
    end
    fprintf('SYNTHETIC DEMO ONLY: these are not your fitted test parameters.\n');
else
    assert(exist('Results_sensor','var')==1,'Run the accelerometer processing script first.');
    t=Results_sensor.Time_s;
    y=[Results_sensor.ErrorX_ug Results_sensor.ErrorY_ug Results_sensor.ErrorZ_ug];
    if ismember('LimitFlag',Results_sensor.Properties.VariableNames) && any(Results_sensor.LimitFlag)
        warning('Fitting observed flagged/clipped readout, not unknown acceleration beyond a rail.');
    end
end
t=double(t(:)); y=double(y); R=R_sensor_to_PLT;
assert(size(y,1)==numel(t) && size(y,2)==3 && numel(t)>=128 && ...
    isreal(y) && isreal(t) && all(isfinite(t)) && all(isfinite(y(:))) && all(diff(t)>0),'Need finite N-by-3 data and increasing times.');
dt=median(diff(t)); Fs=1/dt;
assert(all(abs(diff(t)-dt)<.01*dt+32*eps(max(abs(t)))), ...
    'Use one uniformly sampled contiguous interval. Do not join across excluded-time gaps.');
assert(isequal(size(R),[3 3]) && all(isfinite(R(:))) && norm(R*R'-eye(3),'fro')<1e-6, ...
    'R must map sensor column vectors to platform column vectors.');
validateattributes(nRealizations,{'numeric'},{'scalar','integer','>=',2});
assert(fitFraction>0 && fitFraction<=1 && detectSigma>releaseSigma && releaseSigma>0);
assert(markovPrior>0 && numel(manualThreshold_ug)==3);
if fitFraction<1
    split=floor(size(y,1)*fitFraction); train=y(1:split,:); reference=y(split+1:end,:);
    fprintf('Fit on prefix; validation uses the held-out suffix (stationarity assumed).\n');
else
    train=y; reference=y;
    fprintf('IN-SAMPLE validation: agreement is descriptive, not independent validation.\n');
end
assert(size(train,1)>=128 && size(reference,1)>=128,'Fit/validation intervals must each have >=128 samples.');

%% Fit quiet background and a catalog of COMPLETE joint XYZ pulse events
PulseModel=fitModel(train,Fs,detectSigma,releaseSigma,manualThreshold_ug,markovPrior);
PulseModel.useEventMarkov=useEventMarkov;
n=size(reference,1); tv=(0:n-1)'/Fs;
refEvents=events(reference,PulseModel);
fprintf('Fit catalog: %d complete joint events; quiet fraction %.3f.\n', ...
    numel(PulseModel.templates),mean(PulseModel.quietMask));
figure('Name','Check pulse detection before trusting the model'); tiledlayout(3,1);
trainTime=(0:size(train,1)-1)'/Fs; detected=train-PulseModel.baseline;
detected(PulseModel.quietMask,:)=NaN;
for j=1:3
    nexttile; plot(trainTime,train(:,j)-PulseModel.baseline(j),'Color',[.6 .6 .6]); hold on;
    plot(trainTime,detected(:,j),'r'); yline(PulseModel.threshold(j),'k--');
    yline(-PulseModel.threshold(j),'k--'); xlabel('Time [s]'); ylabel('Excursion [\mug]'); grid on;
end

%% Ensemble: new Gaussian background, resampled event tuples and new timing
stream=RandStream('mt19937ar','Seed',seed);
lag=min(round(maxLag_s*Fs),n-2); L=min(512,floor(n/4)); window=hamming(L);
nfft=max(256,2^nextpow2(L));
[pTest,F]=pwelch(reference-mean(reference,1),window,floor(L/2),nfft,Fs);
pAll=zeros(size(pTest,1),3,nRealizations); acAll=zeros(2*lag+1,3,nRealizations);
metricsAll=zeros(9,3,nRealizations); corrAll=zeros(3,3,nRealizations);
transitionAll=zeros(6,6,nRealizations);
bins=cell(1,3); histAll=zeros(60,3,nRealizations);
for j=1:3, [~,bins{j}]=histcounts(reference(:,j),60); bins{j}([1 end])=[-Inf Inf]; end
samples=cell(nRealizations,1);
for run=1:nRealizations
    sim=generate(PulseModel,n,stream);
    if run==1, Generated_sensor=table(tv,sim(:,1),sim(:,2),sim(:,3), ...
            'VariableNames',{'Time_s','ErrorX_ug','ErrorY_ug','ErrorZ_ug'});
        platform=sim*R'; Generated_PLT=table(tv,platform(:,1),platform(:,2),platform(:,3), ...
            'VariableNames',Generated_sensor.Properties.VariableNames);
    end
    pAll(:,:,run)=pwelch(sim-mean(sim,1),window,floor(L/2),nfft,Fs);
    for j=1:3
        acAll(:,j,run)=xcorr(sim(:,j)-mean(sim(:,j)),lag,'biased');
        histAll(:,j,run)=histcounts(sim(:,j),bins{j},'Normalization','probability')';
    end
    ev=events(sim,PulseModel); metricsAll(:,:,run)=metrics(sim,ev,PulseModel);
    corrAll(:,:,run)=corrcoef(sim); samples{run}=ev; transitionAll(:,:,run)=ev.Transitions;
end
testMetrics=metrics(reference,refEvents,PulseModel);
metricNames={'Mean_ug','Std_ug','RMS_ug','PositiveEvents','NegativeEvents','PositiveEvents_per_s', ...
    'NegativeEvents_per_s','PositiveSampleFraction','NegativeSampleFraction'};
axisNames={'X','Y','Z'}; rows=cell(27,6); k=0;
for j=1:3
    for m=1:9
        k=k+1; v=reshape(metricsAll(m,j,:),[],1);
        rows(k,:)={axisNames{j},metricNames{m},testMetrics(m,j),mean(v),pct(v,5),pct(v,95)};
    end
end
ValidationSummary=cell2table(rows,'VariableNames', ...
    {'Axis','Metric','Test','ModelMean','ModelP05','ModelP95'});
disp(ValidationSummary);

%% Plot 1: test vs ONE new realization (different event order is intended)
figure('Name','Pulse model: sensor time histories','Position',[50 50 1200 850]);
tiles=tiledlayout(3,2,'TileSpacing','compact');
for j=1:3
    nexttile; plot(tv,reference(:,j)); ylabel([axisNames{j} ' [\mug]']); xlabel('Time [s]');
    title('Test'); grid on;
    nexttile; plot(tv,Generated_sensor{:,j+1}); xlabel('Time [s]'); ylabel('[\mug]');
    title('New realization'); grid on;
end
title(tiles,'Event order changes; compare statistics, not pointwise waveform correlation');

%% Plot 2: full-signal histogram, Welch PSD, and ensemble autocorrelation
figure('Name','Pulse model: distribution PSD ACF','Position',[50 50 1400 900]);
tiles=tiledlayout(3,3,'TileSpacing','compact');
SpectralMetrics=zeros(3,3); lagTime=(-lag:lag)'/Fs;
for j=1:3
    nexttile; h=histcounts(reference(:,j),bins{j},'Normalization','probability');
    % Finite display centers; outer bins include model tails beyond test extremes.
    finiteEdges=bins{j}; finiteEdges(1)=finiteEdges(2)-(finiteEdges(3)-finiteEdges(2));
    finiteEdges(end)=finiteEdges(end-1)+(finiteEdges(end-1)-finiteEdges(end-2));
    centers=(finiteEdges(1:end-1)+finiteEdges(2:end))/2;
    plot(centers,h,'k','LineWidth',1.4); hold on;
    plot(centers,mean(histAll(:,j,:),3),'r'); grid on;
    title([axisNames{j} ': amplitude distribution']); xlabel('Error [\mug]'); ylabel('Probability/bin');
    legend('Test','Ensemble mean');
    SpectralMetrics(j,3)=.5*sum(abs(h(:)-mean(histAll(:,j,:),3)));
    nexttile; P=squeeze(pAll(:,j,:)); pm=mean(P,2);
    fillBand(F(2:end),pct(P(2:end,:),5,2),pct(P(2:end,:),95,2)); hold on;
    plot(F(2:end),pTest(2:end,j),'k',F(2:end),pm(2:end),'r');
    set(gca,'XScale','log','YScale','log'); grid on;
    xlabel('Hz'); ylabel('PSD [(\mug)^2/Hz]'); title('AC PSD: model 5-95% range');
    nexttile; raw=squeeze(acAll(:,j,:)); acMean=mean(raw,2); acMean=acMean/max(acMean(lag+1),eps);
    normalized=raw./max(raw(lag+1,:),eps);
    at=xcorr(reference(:,j)-mean(reference(:,j)),lag,'biased'); at=at/max(at(lag+1),eps);
    fillBand(lagTime,pct(normalized,5,2),pct(normalized,95,2)); hold on;
    plot(lagTime,at,'k',lagTime,acMean,'r'); grid on; xlabel('Lag [s]'); ylabel('Normalized ACF');
    title('ACF: average biased ACFs, then normalize');
    SpectralMetrics(j,1)=sqrt(mean((10*log10(max(pm(2:end),realmin))- ...
        10*log10(max(pTest(2:end,j),realmin))).^2));
    SpectralMetrics(j,2)=sqrt(mean((acMean-at).^2));
end
title(tiles,'Parameter-conditional simulation ranges; not uncertainty in the fitted parameters');
SpectralSummary=array2table(SpectralMetrics,'RowNames',axisNames, ...
    'VariableNames',{'PSD_LogRMSE_dB','ACF_RMSE','BinnedAmplitudeTV'}); disp(SpectralSummary);

%% FFT of test and ONE realization: random timing need not match bin-for-bin
figure('Name','Pulse model: single-record FFT'); tiledlayout(3,1);
w=.5-.5*cos(2*pi*(0:n-1)'/n); ff=(0:floor(n/2))'*Fs/n;
for j=1:3
    signals=[reference(:,j),Generated_sensor{:,j+1}];
    amplitude=abs(fft((signals-mean(signals,1)).*w,[],1))/sum(w);
    amplitude=amplitude(1:floor(n/2)+1,:);
    amplitude(2:ceil(n/2),:)=2*amplitude(2:ceil(n/2),:);
    nexttile; plot(ff(2:end),amplitude(2:end,:)); grid on;
    xlabel('Frequency [Hz]'); ylabel('Peak amplitude [\mug]');
    title([axisNames{j} ': single-record FFT; use ensemble PSD for statistical comparison']);
    legend('Test','One realization');
end

%% Plot 3: signed event amplitudes, widths, quiet gaps and start intervals
figure('Name','Pulse event statistics','Position',[50 50 1250 750]); tiledlayout(2,3);
for j=1:3
    nexttile; cdfLine(refEvents.Peak_ug(:,j),'k'); hold on;
    pooled=[]; for run=1:nRealizations, pooled=[pooled;samples{run}.Peak_ug(:,j)]; end %#ok<AGROW>
    cdfLine(pooled,'r'); grid on; title([axisNames{j} ': signed dominant peak per joint event']);
    xlabel('[\mug]'); ylabel('CDF'); legend('Test','Pooled model events');
end
fields={'Width_s','Gap_s','Interval_s'};
for j=1:3
    nexttile; cdfLine(refEvents.(fields{j}),'k'); hold on;
    pooled=[]; for run=1:nRealizations, pooled=[pooled;samples{run}.(fields{j})]; end %#ok<AGROW>
    cdfLine(pooled,'r'); grid on; title(fields{j},'Interpreter','none'); xlabel('Seconds'); ylabel('CDF');
end

%% Plot 4: quiet-background Gaussian and whiteness diagnostics
figure('Name','Quiet background checks','Position',[50 50 1150 850]); tiledlayout(3,2);
quiet=PulseModel.quietMask; z=train-PulseModel.baseline;
QuietACF=zeros(lag+1,3); quietLag=min(lag,size(train,1)-2);
for j=1:3
    nexttile; histogram(z(quiet,j),40,'Normalization','pdf'); hold on;
    sigma=sqrt(PulseModel.covariance(j,j)); v=linspace(-5*sigma,5*sigma,200);
    plot(v,exp(-.5*(v/max(sigma,eps)).^2)/(sqrt(2*pi)*max(sigma,eps)),'r');
    title([axisNames{j} ': quiet samples vs fitted Gaussian']); xlabel('[\mug]'); ylabel('Density'); grid on;
    % Retain original times: do NOT concatenate separated quiet intervals.
    count=xcorr(double(quiet),quietLag,'none'); r=xcorr(z(:,j).*quiet,quietLag,'none');
    r=r(quietLag+1:end)./max(count(quietLag+1:end),1); r=r/max(r(1),eps);
    QuietACF(1:quietLag+1,j)=r;
    nexttile; stem((0:quietLag)'/Fs,r,'.'); grid on; xlabel('Lag [s]'); ylabel('Masked quiet ACF');
    title('Off-zero structure challenges the white-noise assumption');
end
disp('Test cross-axis correlation:'); disp(corrcoef(reference));
disp('Mean model cross-axis correlation:'); disp(mean(corrAll,3));
disp('Observed vs fitted first-order joint-event class transitions:');
disp(PulseModel.transitionCounts); disp(PulseModel.transitionProbability);
tc=refEvents.Transitions; mc=sum(transitionAll,3);
EventTransitionComparison=struct('Test',tc./max(sum(tc,2),1), ...
    'Model',mc./max(sum(mc,2),1));
figure('Name','Joint-event sign/dominant-axis transition probabilities'); tiledlayout(1,2);
nexttile; imagesc(EventTransitionComparison.Test,[0 1]); colorbar; title('Test');
xlabel('Next class'); ylabel('Previous class');
nexttile; imagesc(EventTransitionComparison.Model,[0 1]); colorbar; title('Pooled model');
xlabel('Next class: X+, X-, Y+, Y-, Z+, Z-'); ylabel('Previous class');
fprintf(['Model ranges describe new records of equal duration. Event counts vary per run.\n' ...
    'No claim of exact spike count, parameter certainty, or white-noise validity is imposed.\n']);
% Optional: save('IMU_Pulse_Model.mat','PulseModel','ValidationSummary','SpectralSummary');
% Optional: writetable(Generated_PLT,'Generated_IMU_Error_PLT_ug.csv');

%% Local functions
function m=fitModel(x,fs,detect,release,manual,prior)
m.Fs=fs; m.baseline=median(x,1);
s=1.4826*median(abs(x-m.baseline),1); s=max(s,eps(max(1,max(abs(x),[],1))));
m.threshold=detect*s; manual=reshape(manual,1,3);
assert(all(isnan(manual) | (isfinite(manual)&manual>0)),'Manual thresholds must be positive or NaN.');
m.threshold(~isnan(manual))=manual(~isnan(manual));
m.release=min(release*s,.8*m.threshold);
[a,b,mask]=detectEvents(x,m); quiet=~mask;
assert(nnz(quiet)>=max(20,.1*size(x,1)), ...
    'Too little quiet data. Specify thresholds explicitly or choose a different interval.');
m.baseline=mean(x(quiet,:),1); m.covariance=cov(x(quiet,:),1);
[a,b,mask]=detectEvents(x,m); quiet=~mask; m.quietMask=quiet;
m.baseline=mean(x(quiet,:),1); m.covariance=cov(x(quiet,:),1);
% Complete events only; both edge events are excluded if they touch a boundary.
keep=a>1 & b<size(x,1); a=a(keep); b=b(keep);
% A first observed quiet gap may be left-censored: require a preceding event.
hasPrevious=false(size(a));
for k=1:numel(a), hasPrevious(k)=any(mask(1:a(k)-1)); end
a=a(hasPrevious); b=b(hasPrevious);
assert(numel(a)>=3,'Need at least three complete detected events; inspect thresholds / select a longer window.');
m.templates=cell(numel(a),1); m.gapSamples=zeros(numel(a),1); m.classes=zeros(numel(a),1);
for k=1:numel(a)
    m.templates{k}=x(a(k):b(k),:)-m.baseline;
    previous=find(mask(1:a(k)-1),1,'last');
    if isempty(previous), previous=0; end
    m.gapSamples(k)=a(k)-previous-1;
    scaled=abs(m.templates{k})./m.threshold; [~,idx]=max(scaled(:));
    [row,axis]=ind2sub(size(m.templates{k}),idx);
    m.classes(k)=2*(axis-1)+1+(m.templates{k}(row,axis)<0);
end
m.classFrequency=accumarray(m.classes,1,[6 1])'; m.classFrequency=m.classFrequency/sum(m.classFrequency);
m.transitionCounts=zeros(6);
for k=2:numel(a), m.transitionCounts(m.classes(k-1),m.classes(k))=m.transitionCounts(m.classes(k-1),m.classes(k))+1; end
m.transitionProbability=(m.transitionCounts+prior*m.classFrequency)./(sum(m.transitionCounts,2)+prior);
[V,D]=eig((m.covariance+m.covariance')/2); m.noiseFactor=V*diag(sqrt(max(diag(D),0)));
m.useEventMarkov=true;
end

function [a,b,mask]=detectEvents(x,m)
z=x-m.baseline; n=size(x,1); mask=false(n,1); active=false;
for k=1:n
    if ~active && any(abs(z(k,:))>=m.threshold), active=true; end
    if active && all(abs(z(k,:))<=m.release), active=false; end
    mask(k)=active;
end
a=find(diff([false;mask])==1); b=find(diff([mask;false])==-1);
end

function x=generate(m,n,stream)
cycles=m.gapSamples+cellfun(@(v)size(v,1),m.templates);
burn=10*max(cycles); total=n+burn;
x=randn(stream,total,3)*m.noiseFactor'+m.baseline;
cursor=1; previous=0;
while cursor<=total
    if previous==0 || ~m.useEventMarkov, probability=m.classFrequency;
    else, probability=m.transitionProbability(previous,:); end
    mark=find(rand(stream)<cumsum(probability),1);
    if isempty(mark), mark=find(probability>0,1,'last'); end
    pool=find(m.classes==mark); index=pool(1+floor(rand(stream)*numel(pool)));
    pulse=m.templates{index}; cursor=cursor+m.gapSamples(index);
    last=min(total,cursor+size(pulse,1)-1);
    if cursor<=total, x(cursor:last,:)=pulse(1:last-cursor+1,:)+m.baseline; end
    cursor=cursor+size(pulse,1); previous=mark;
end
x=x(burn+1:end,:);
end

function e=events(x,m)
[a,b,mask]=detectEvents(x,m); keep=a>1&b<size(x,1); a=a(keep); b=b(keep);
e.Peak_ug=zeros(numel(a),3); e.Positive=false(numel(a),3); e.Negative=e.Positive;
e.Class=zeros(numel(a),1); e.Transitions=zeros(6);
for k=1:numel(a)
    z=x(a(k):b(k),:)-m.baseline;
    for j=1:3, [~,idx]=max(abs(z(:,j))); e.Peak_ug(k,j)=z(idx,j); end
    e.Positive(k,:)=max(z,[],1)>=m.threshold; e.Negative(k,:)=min(z,[],1)<=-m.threshold;
    scaled=abs(z)./m.threshold; [~,idx]=max(scaled(:)); [row,axis]=ind2sub(size(z),idx);
    e.Class(k)=2*(axis-1)+1+(z(row,axis)<0);
    if k>1, e.Transitions(e.Class(k-1),e.Class(k))=e.Transitions(e.Class(k-1),e.Class(k))+1; end
end
e.Width_s=(b-a+1)/m.Fs; e.Start_s=(a-1)/m.Fs;
e.Gap_s=zeros(numel(a),1);
for k=1:numel(a)
    prev=find(mask(1:a(k)-1),1,'last'); if isempty(prev), e.Gap_s(k)=NaN;
    else, e.Gap_s(k)=(a(k)-prev-1)/m.Fs; end
end
e.Interval_s=diff(e.Start_s);
end

function v=metrics(x,e,m)
v=[mean(x,1); std(x,1,1); sqrt(mean(x.^2,1)); sum(e.Positive,1); sum(e.Negative,1); ...
    sum(e.Positive,1)/(size(x,1)/m.Fs);sum(e.Negative,1)/(size(x,1)/m.Fs); ...
    mean(x-m.baseline>=m.threshold,1); mean(x-m.baseline<=-m.threshold,1)];
end
function q=pct(x,p,dim)
if nargin<3, dim=1; x=x(:); end
x=sort(x,dim); count=size(x,dim); position=1+(count-1)*p/100;
idx=repmat({':'},1,ndims(x)); idx{dim}=floor(position); lo=x(idx{:});
idx{dim}=ceil(position); hi=x(idx{:}); q=lo+(hi-lo)*(position-floor(position));
end
function fillBand(x,lo,hi)
fill([x(:);flipud(x(:))],[lo(:);flipud(hi(:))],[.85 .9 1], ...
    'EdgeColor','none','HandleVisibility','off');
end
function cdfLine(x,color)
x=sort(x(isfinite(x))); if isempty(x), plot(NaN,NaN,color); else
    stairs(x,(1:numel(x))'/numel(x),color,'LineWidth',1.3); end
end
