function figs=plotDiagnostics(r)
% At most SIX tiles per figure. Separate figure families for each selected axis.
figs=gobjects(0); m=r.model; fs=m.Fs; c=r.cfg;
names={'X','Y','Z'}; train=r.train; ref=r.reference; n=size(ref,1);
time=r.validationTime_s; fullTime=r.input.t-r.input.t(1);
fullEvents=imupulse.detect(r.input.y,m);
if any(r.input.histMask)
    [f,t]=newFigure(r,'H_Observed_XYZ_Histograms',1,nnz(r.input.histMask)); figs(end+1)=f;
    for j=find(r.input.histMask)
        ax=nexttile(t); values=r.input.histValues_ft_s2(:,j); values=values(isfinite(values));
        if ~isempty(values), histogram(ax,values,c.histogramBins,'Normalization','probability'); end
        title(ax,['H: observed sensor ' names{j}]); xlabel(ax,'Acceleration [ft/s^2]'); ylabel(ax,'Probability/bin'); grid(ax,'on');
    end
    title(t,'Visualization of mapped XYZ readout; model selection is independent');
end
for j=find(m.selectedMask)
    label=names{j}; z=train(:,j)-m.baseline(j); quiet=m.quietMask;
    [f,t]=newFigure(r,['A_' label '_Input_and_Detection'],2,3); figs(end+1)=f;
    ax=nexttile(t); plot(ax,fullTime,r.input.y(:,j),'Color',[.6 .6 .6]); hold(ax,'on');
    marked=r.input.y(:,j); marked(~fullEvents.mask)=NaN;
    plot(ax,fullTime,marked,'r'); yline(ax,m.baseline(j),'k:');
    xline(ax,r.split/fs,'b--','Train / validation');
    title(ax,'A1: selected error and detected events'); xlabel(ax,'Time from window start [s]'); ylabel(ax,'Error [ug]'); grid(ax,'on');
    ax=nexttile(t); zoom=fullTime<=min(c.zoom_s,fullTime(end));
    plot(ax,fullTime(zoom),r.input.y(zoom,j),'k'); hold(ax,'on');
    plot(ax,fullTime(zoom),marked(zoom),'r','LineWidth',1.2);
    yline(ax,m.baseline(j)+m.threshold(j),'b--'); yline(ax,m.baseline(j)-m.threshold(j),'b--');
    yline(ax,m.baseline(j)+m.release(j),'Color',[0 .5 0],'LineStyle',':');
    yline(ax,m.baseline(j)-m.release(j),'Color',[0 .5 0],'LineStyle',':');
    title(ax,'A2: onset / release threshold zoom'); xlabel(ax,'Time [s]'); ylabel(ax,'Error [ug]'); grid(ax,'on');
    ax=nexttile(t); edges=linspace(min(r.input.y(:,j)),max(r.input.y(:,j))+eps,c.histogramBins+1);
    histogram(ax,train(:,j),edges,'Normalization','probability','DisplayStyle','stairs','DisplayName','Train'); hold(ax,'on');
    histogram(ax,ref(:,j),edges,'Normalization','probability','DisplayStyle','stairs','DisplayName','Held-out');
    set(ax,'YScale','log'); title(ax,'A3: level occupancy / tails'); xlabel(ax,'Error [ug]'); ylabel(ax,'Probability/bin'); legend(ax,'show'); grid(ax,'on');
    [blockTime,blockMean,blockRate]=blockStats(r.input.y,fullEvents,j,fs,c.block_s);
    ax=nexttile(t); plot(ax,blockTime,blockMean,'o-'); hold(ax,'on'); xline(ax,r.split/fs,'k--');
    title(ax,'A4: mean by nonoverlapping block'); xlabel(ax,'Time [s]'); ylabel(ax,'Mean [ug]'); grid(ax,'on');
    ax=nexttile(t); plot(ax,blockTime,blockRate,'o-'); hold(ax,'on'); xline(ax,r.split/fs,'k--');
    title(ax,'A5: joint-event start rate by block'); xlabel(ax,'Time [s]'); ylabel(ax,'Events/s'); grid(ax,'on');
    ax=nexttile(t); plot(ax,r.input.sourceRows,fullTime);
    title(ax,'A6: original row to elapsed-step mapping'); xlabel(ax,'Original row index'); ylabel(ax,'Elapsed from window start [s]'); grid(ax,'on');
    title(t,['Sensor ' label ': inspect data / detector before fitting conclusions']);

    [f,t]=newFigure(r,['B_' label '_Quiet_Background'],2,3); figs(end+1)=f;
    sigma=sqrt(max(m.covariance(j,j),0)); sigma=max(sigma,eps);
    quietZ=z(quiet); ax=nexttile(t);
    histogram(ax,quietZ,40,'Normalization','pdf'); hold(ax,'on');
    u=linspace(-5*sigma,5*sigma,201);
    plot(ax,u,exp(-.5*(u/sigma).^2)/(sqrt(2*pi)*sigma),'r','LineWidth',1.5);
    title(ax,'B1: quiet histogram / Gaussian PDF'); xlabel(ax,'Quiet excursion [ug]'); ylabel(ax,'Density [1/ug]'); grid(ax,'on');
    ax=nexttile(t); q=linspace(.005,.995,99); theoretical=sigma*sqrt(2)*erfinv(2*q-1);
    empirical=imupulse.percentile(quietZ,100*q);
    plot(ax,theoretical,empirical,'.'); hold(ax,'on'); plot(ax,theoretical,theoretical,'k--');
    title(ax,'B2: quiet Gaussian Q-Q'); xlabel(ax,'Gaussian quantile [ug]'); ylabel(ax,'Quiet sample quantile [ug]'); grid(ax,'on');
    lag=min(round(c.quietMaxLag_s*fs),size(train,1)-2);
    count=xcorr(double(quiet),lag,'none'); num=xcorr(z.*quiet,lag,'none');
    count=count(lag+1:end); covariance=num(lag+1:end)./max(count,1);
    if covariance(1)>0, rho=covariance/covariance(1); else, rho=NaN(size(covariance)); end
    rho(count<30)=NaN;
    ax=nexttile(t); stem(ax,(0:lag)'/fs,rho,'.'); hold(ax,'on'); yline(ax,0,'k:');
    plot(ax,(0:lag)'/fs,m.gmPhi.^(0:lag)','r','LineWidth',1.4);
    title(ax,'B3: quiet ACF, original time gaps retained'); xlabel(ax,'Lag [s]'); ylabel(ax,'Masked correlation'); grid(ax,'on');
    ax=nexttile(t); pair=find(quiet(1:end-1)&quiet(2:end));
    pair=pair(1:max(1,ceil(numel(pair)/3000)):end);
    scatter(ax,z(pair),z(pair+1),5,'filled'); axis(ax,'equal');
    title(ax,'B4: adjacent quiet samples only'); xlabel(ax,'Quiet excursion k [ug]'); ylabel(ax,'Quiet excursion k+1 [ug]'); grid(ax,'on');
    % Innovations are defined only on valid adjacent quiet pairs; preserve gaps.
    valid=quiet(1:end-1)&quiet(2:end);
    innovation=(z(2:end)-m.gmPhi*z(1:end-1))/(sigma*sqrt(1-m.gmPhi^2));
    ax=nexttile(t); histogram(ax,innovation(valid),40,'Normalization','pdf'); hold(ax,'on');
    u=linspace(-5,5,201); plot(ax,u,exp(-u.^2/2)/sqrt(2*pi),'r');
    title(ax,'B5: standardized quiet innovations'); xlabel(ax,'Innovation / predicted sigma'); ylabel(ax,'Density'); grid(ax,'on');
    innovation(~valid)=0; count=xcorr(double(valid),lag,'none'); num=xcorr(innovation,lag,'none');
    count=count(lag+1:end); residualACF=num(lag+1:end)./max(count,1);
    residualACF=residualACF/max(residualACF(1),eps); residualACF(count<30)=NaN;
    ax=nexttile(t); stem(ax,(0:lag)'/fs,residualACF,'.'); hold(ax,'on'); yline(ax,0,'k:');
    title(ax,'B6: innovation ACF (gaps retained)'); xlabel(ax,'Lag [s]'); ylabel(ax,'Normalized correlation'); grid(ax,'on');
    title(t,sprintf('Sensor %s: Gauss-Markov quiet background, phi=%.4g, tau=%.4g s',label,m.gmPhi,m.gmTau_s));

    [f,t]=newFigure(r,['C_' label '_Distribution_and_Spectrum'],2,3); figs(end+1)=f;
    ax=nexttile(t); plot(ax,time,ref(:,j),'k'); title(ax,'C1: held-out measured error');
    xlabel(ax,'Validation-relative time [s]'); ylabel(ax,'Error [ug]'); grid(ax,'on');
    ax=nexttile(t); plot(ax,time,r.samples(:,j,1),'Color',[.8 .15 .15]); title(ax,'C2: one NEW realization');
    xlabel(ax,'Time [s]'); ylabel(ax,'Error [ug]'); grid(ax,'on');
    ax=nexttile(t); band(ax,r.histCenters{j}',reshape(r.histogram(:,j,:),c.histogramBins,[]),[.8 .15 .15],'Model mean');
    hold(ax,'on'); plot(ax,r.histCenters{j},r.histReference(:,j),'k','DisplayName','Held-out');
    title(ax,'C3: amplitude probabilities (5-95% band)'); xlabel(ax,'Error [ug]'); ylabel(ax,'Probability/bin'); legend(ax,'show'); grid(ax,'on');
    ax=nexttile(t); keep=r.frequency_Hz>0;
    band(ax,r.frequency_Hz(keep),reshape(r.psd(keep,j,:),nnz(keep),[]),[.8 .15 .15],'Model mean');
    hold(ax,'on'); plot(ax,r.frequency_Hz(keep),r.referencePSD(keep,j),'k','DisplayName','Held-out');
    set(ax,'XScale','log','YScale','log'); title(ax,'C4: AC Welch PSD (5-95% band)');
    xlabel(ax,'Frequency [Hz]'); ylabel(ax,'PSD [ug^2/Hz]'); legend(ax,'show'); grid(ax,'on');
    ax=nexttile(t); [fHz,a]=amplitudeFFT(ref(:,j),fs); [~,b]=amplitudeFFT(r.samples(:,j,1),fs);
    plot(ax,fHz,a,'k','DisplayName','Held-out'); hold(ax,'on'); plot(ax,fHz,b,'Color',[.8 .15 .15],'DisplayName','One model run');
    title(ax,'C5: single-record AC amplitude FFT'); xlabel(ax,'Frequency [Hz]'); ylabel(ax,'Amplitude [ug]'); legend(ax,'show'); grid(ax,'on');
    ax=nexttile(t); band(ax,(0:r.lag)'/fs,reshape(r.acf(:,j,:),r.lag+1,[]),[.8 .15 .15],'Model mean');
    hold(ax,'on'); plot(ax,(0:r.lag)'/fs,r.referenceACF(:,j),'k','DisplayName','Held-out');
    title(ax,'C6: full-signal AC autocorrelation'); xlabel(ax,'Lag [s]'); ylabel(ax,'Normalized ACF'); legend(ax,'show'); grid(ax,'on');
    title(t,['Sensor ' label ': conditional simulation ranges, not parameter confidence intervals']);

    [f,t]=newFigure(r,['D_' label '_Event_Statistics'],2,3); figs(end+1)=f;
    ev=r.refEvents; eligible=isfinite(ev.peak_ug(:,j)); pool=pooledEvents(r.events,j);
    ax=nexttile(t); empiricalCDF(ax,ev.peak_ug(:,j),pool.peak,'D1: signed event peak CDF','Peak excursion [ug]');
    ax=nexttile(t); empiricalCDF(ax,ev.width_s(eligible),pool.width,'D2: event duration CDF','Duration [s]');
    ax=nexttile(t); empiricalCDF(ax,ev.gap_s(eligible),pool.gap,'D3: preceding quiet gap CDF','Gap [s]');
    ax=nexttile(t); empiricalCDF(ax,ev.interval_s(eligible),pool.interval,'D4: event-start interval CDF','Interval [s]');
    ax=nexttile(t); empiricalCDF(ax,ev.area_ug_s(:,j),pool.area,'D5: signed pulse area CDF','Area above quiet baseline [ug s]');
    ax=nexttile(t); show=isfinite(pool.gap)&isfinite(pool.peak);
    x=pool.gap(show); y=abs(pool.peak(show)); take=1:max(1,ceil(numel(x)/1500)):numel(x);
    scatter(ax,x(take),y(take),8,[.8 .15 .15],'filled','DisplayName','Pooled model'); hold(ax,'on');
    scatter(ax,ev.gap_s(eligible),abs(ev.peak_ug(eligible,j)),22,'k','DisplayName','Held-out');
    title(ax,'D6: gap / absolute peak relationship'); xlabel(ax,'Preceding quiet gap [s]'); ylabel(ax,'Absolute peak [ug]'); legend(ax,'show'); grid(ax,'on');
    title(t,['Sensor ' label ': complete detected events; model CDFs pool runs, no CDF confidence claim']);

    [f,t]=newFigure(r,['E_' label '_Why_Pulses_Matter'],2,2); figs(end+1)=f;
    ax=nexttile(t); comparisonBand(ax,r.integrationTime_s,reshape(r.v(:,j,:),n+1,[]), ...
        reshape(r.gaussianV(:,j,:),n+1,[]),r.meanV(:,j),r.refV(:,j));
    title(ax,'E1: velocity error, zero initial error'); xlabel(ax,'Elapsed integration time [s]'); ylabel(ax,'Velocity error [m/s]');
    ax=nexttile(t); comparisonBand(ax,r.integrationTime_s,reshape(r.p(:,j,:),n+1,[]), ...
        reshape(r.gaussianP(:,j,:),n+1,[]),r.meanP(:,j),r.refP(:,j));
    title(ax,'E2: position error, zero initial error'); xlabel(ax,'Elapsed integration time [s]'); ylabel(ax,'Position error [m]');
    ax=nexttile(t); terminalCDF(ax,reshape(r.v(end,j,:),[],1),reshape(r.gaussianV(end,j,:),[],1), ...
        r.meanV(end,j),r.refV(end,j)); title(ax,'E3: terminal velocity distribution'); xlabel(ax,'Final velocity error [m/s]');
    ax=nexttile(t); terminalCDF(ax,reshape(r.p(end,j,:),[],1),reshape(r.gaussianP(end,j,:),[],1), ...
        r.meanP(end,j),r.refP(end,j)); title(ax,'E4: terminal position distribution'); xlabel(ax,'Final position error [m]');
    title(t,['Sensor ' label ': open-loop ZOH integration; not your full navigation/control system']);
end
if nnz(m.selectedMask)>1 || c.useEventMarkov
    [f,t]=newFigure(r,'F_Selected_Axes_and_Transitions',2,2); figs(end+1)=f;
    ax=nexttile(t); imagesc(ax,r.crossReference,[-1 1]); colorbar(ax); title(ax,'F1: held-out selected-axis correlation');
    set(ax,'XTick',1:nnz(m.selectedMask),'XTickLabel',r.input.selectedAxes,'YTick',1:nnz(m.selectedMask),'YTickLabel',r.input.selectedAxes);
    ax=nexttile(t); imagesc(ax,r.crossMean,[-1 1]); colorbar(ax); title(ax,'F2: ensemble mean selected-axis correlation');
    set(ax,'XTick',1:nnz(m.selectedMask),'XTickLabel',r.input.selectedAxes,'YTick',1:nnz(m.selectedMask),'YTickLabel',r.input.selectedAxes);
    ax=nexttile(t); imagesc(ax,m.transitionCounts); colorbar(ax); title(ax,'F3: training class transition COUNTS');
    xlabel(ax,'Next class 1..6'); ylabel(ax,'Previous class 1..6');
    ax=nexttile(t); imagesc(ax,m.transitionProbability,[0 1]); colorbar(ax); title(ax,'F4: smoothed class transition probabilities');
    xlabel(ax,'Next: X+,X-,Y+,Y-,Z+,Z-'); ylabel(ax,'Previous class');
    title(t,'Joint selected-axis model: inactive class rows are fallback distributions, not observations');
end
end
function [f,t]=newFigure(r,name,rows,cols)
assert(rows*cols<=6); f=figure('Name',name,'NumberTitle','off', ...
    'Visible',r.cfg.figureVisible,'Position',[70 70 1400 800]);
t=tiledlayout(f,rows,cols,'TileSpacing','compact','Padding','compact');
end
function band(ax,x,Y,color,label)
% Pointwise conditional central 90% range, interpolation across ordered runs.
sorted=sort(Y,2); K=size(Y,2); q=1+(K-1)*[.05 .95];
low=sorted(:,floor(q(1)))*(ceil(q(1))-q(1))+sorted(:,ceil(q(1)))*(q(1)-floor(q(1)));
high=sorted(:,floor(q(2)))*(ceil(q(2))-q(2))+sorted(:,ceil(q(2)))*(q(2)-floor(q(2)));
if floor(q(1))==ceil(q(1)), low=sorted(:,q(1)); end
if floor(q(2))==ceil(q(2)), high=sorted(:,q(2)); end
x=x(:); fill(ax,[x;flipud(x)],[low;flipud(high)],color,'FaceAlpha',.16,'EdgeColor','none','HandleVisibility','off');
hold(ax,'on'); plot(ax,x,mean(Y,2),'Color',color,'LineWidth',1.2,'DisplayName',label);
end
function [f,a]=amplitudeFFT(x,fs)
n=numel(x); window=.5-.5*cos(2*pi*(0:n-1)'/n);
z=abs(fft((x-mean(x)).*window))/sum(window); a=z(1:floor(n/2)+1);
if mod(n,2)==0, a(2:end-1)=2*a(2:end-1); else, a(2:end)=2*a(2:end); end
f=(0:floor(n/2))'*fs/n;
end
function empiricalCDF(ax,x,y,caption,xLabel)
drawCDF(ax,x,'k','Held-out'); hold(ax,'on'); drawCDF(ax,y,[.8 .15 .15],'Pooled model');
title(ax,caption); xlabel(ax,xLabel); ylabel(ax,'Cumulative probability'); ylim(ax,[0 1]); legend(ax,'show'); grid(ax,'on');
end
function drawCDF(ax,x,color,label)
x=sort(x(isfinite(x)));
if isempty(x), plot(ax,NaN,NaN,'Color',color,'DisplayName',[label ': no events']);
else, stairs(ax,[x(1);x],[0;(1:numel(x))'/numel(x)],'Color',color,'LineWidth',1.2,'DisplayName',label); end
end
function pool=pooledEvents(events,j)
pool=struct('peak',[],'width',[],'gap',[],'interval',[],'area',[]);
for k=1:numel(events)
    e=events{k}; valid=isfinite(e.peak_ug(:,j));
    pool.peak=[pool.peak;e.peak_ug(valid,j)]; pool.width=[pool.width;e.width_s(valid)]; %#ok<AGROW>
    pool.gap=[pool.gap;e.gap_s(valid)]; pool.interval=[pool.interval;e.interval_s(valid)]; %#ok<AGROW>
    pool.area=[pool.area;e.area_ug_s(valid,j)]; %#ok<AGROW>
end
end
function [t,mu,rate]=blockStats(x,e,j,fs,secondsPerBlock)
step=max(1,round(secondsPerBlock*fs)); first=(1:step:size(x,1))';
t=zeros(size(first)); mu=t; rate=t;
for k=1:numel(first)
    a=first(k); b=min(a+step-1,size(x,1)); t(k)=((a+b)/2-1)/fs;
    mu(k)=mean(x(a:b,j)); rate(k)=nnz(e.start>=a&e.start<=b)/((b-a+1)/fs);
end
end
function comparisonBand(ax,t,pulse,gaussian,constant,reference)
band(ax,t,pulse,[.8 .15 .15],'Pulse model');
band(ax,t,gaussian,[.1 .4 .8],'Mean + Gaussian');
plot(ax,t,constant,'Color',[0 .5 0],'LineWidth',1.5,'DisplayName','Training mean only');
plot(ax,t,reference,'k','LineWidth',1.4,'DisplayName','Held-out'); legend(ax,'show','Location','best'); grid(ax,'on');
end
function terminalCDF(ax,pulse,gaussian,constant,reference)
drawCDF(ax,pulse,[.8 .15 .15],'Pulse model'); hold(ax,'on');
drawCDF(ax,gaussian,[.1 .4 .8],'Mean + Gaussian');
xline(ax,constant,'Color',[0 .5 0],'LineWidth',1.4,'DisplayName','Training mean only');
xline(ax,reference,'k--','LineWidth',1.4,'DisplayName','Held-out');
ylabel(ax,'Cumulative probability'); legend(ax,'show','Location','best'); grid(ax,'on'); ylim(ax,[0 1]);
end
