function x=generate(m,n,stream)
% Separate signed laws/widths. COMPLETE output stays within measured fit bounds.
x=zeros(n,3);
for j=find(m.selectedMask)
    lo=m.lower(j); hi=m.upper(j);
    x(:,j)=imubounded.boundedNormal(repmat(m.bgMu(j),n,1),m.bgSigma(j),lo,hi,stream);
    q=m.negativeProbability(j); meanWidth=[1-q q]*m.widthSamples(j,:)'; cursor=1;
    if rand(stream)<meanWidth/(m.meanGapSamples(j)+meanWidth)
        signIndex=1+(rand(stream)<q*m.widthSamples(j,2)/meanWidth);
        L=m.widthSamples(j,signIndex); phase=1+floor(rand(stream)*L);
        count=min(n,L-phase+1); w=imubounded.shape(m.shape,L);
        center=m.bgMu(j)+imubounded.boundedAmplitude(m,j,signIndex,stream)*w(phase:phase+count-1);
        x(1:count,j)=imubounded.boundedNormal(center,m.bgSigma(j),lo,hi,stream); cursor=count+1;
    end
    while cursor<=n
        if m.gapProbability(j)>=1, G=1;
        else, G=1+floor(log1p(-rand(stream))/log1p(-m.gapProbability(j))); end
        cursor=cursor+G; if cursor>n, break; end
        signIndex=1+(rand(stream)<q); L=m.widthSamples(j,signIndex);
        w=imubounded.shape(m.shape,L); count=min(L,n-cursor+1);
        center=m.bgMu(j)+imubounded.boundedAmplitude(m,j,signIndex,stream)*w(1:count);
        x(cursor:cursor+count-1,j)=imubounded.boundedNormal(center,m.bgSigma(j),lo,hi,stream);
        cursor=cursor+count;
    end
    assert(all(isfinite(x(:,j))) && all(x(:,j)>=lo & x(:,j)<=hi),'Bounded output violated its support.');
end
end
