function summary=compareCpp(r,T)
% Statistical comparison, not sample-for-sample RNG identity. Four tiles / axis.
x=T{:,{'ErrorX_ug','ErrorY_ug','ErrorZ_ug'}}; n=size(r.reference,1);
assert(size(x,1)==n && all(isfinite(x(:))),'Use exactly the held-out sample count.');
assert(all(all(x(:,~r.model.selectedMask)==0)),'Inactive C++ sensor axes must be exactly zero.');
expected=(0:n-1)'/r.model.Fs;
assert(all(abs(T.Time_s-expected)<1e-8/r.model.Fs+1e-12),'C++ timestamps/sample rate do not match.');
[values,names]=imupulse.metrics(x,r.model); labels={'X','Y','Z'}; rows={};
for j=find(r.model.selectedMask)
    for k=1:numel(names)
        v=reshape(r.metricValues(k,j,:),[],1); range=imupulse.percentile(v,[5 95]);
        rows(end+1,:)={labels{j},names{k},values(k,j),mean(v),range(1),range(2)}; %#ok<AGROW>
    end
    if ~r.cfg.makePlots, continue; end
    f=figure('Name',['CPP_Check_' labels{j}],'Visible',r.cfg.figureVisible); t=tiledlayout(f,2,2);
    nexttile(t); plot(expected,x(:,j)); title('C++ new realization'); xlabel('Time [s]'); ylabel('Error [ug]'); grid on;
    nexttile(t); counts=histcounts(x(:,j),r.histEdges{j},'Normalization','probability');
    plot(r.histCenters{j},counts); hold on;
    plot(r.histCenters{j},mean(r.histogram(:,j,:),3),'r');
    title('C++ vs MATLAB ensemble histogram'); xlabel('Error [ug]'); ylabel('Probability/bin'); grid on;
    [p,freq]=pwelch(x(:,j)-mean(x(:,j)),r.welch.window,r.welch.overlap,r.welch.nfft,r.model.Fs);
    nexttile(t); keep=freq>0; loglog(freq(keep),p(keep)); hold on;
    model=mean(r.psd(:,j,:),3); loglog(freq(keep),model(keep),'r');
    title('C++ vs MATLAB ensemble AC PSD'); xlabel('Frequency [Hz]'); ylabel('PSD [ug^2/Hz]'); grid on;
    z=x(:,j)-mean(x(:,j)); a=xcorr(z,r.lag,'biased'); a=a(r.lag+1:end); a=a/max(a(1),eps);
    nexttile(t); plot((0:r.lag)'/r.model.Fs,a); hold on;
    plot((0:r.lag)'/r.model.Fs,mean(r.acf(:,j,:),3),'r');
    title('C++ vs MATLAB ensemble ACF'); xlabel('Lag [s]'); ylabel('Normalized ACF'); grid on;
    title(t,'Different random streams: compare multiple seeds / equal durations, not individual samples');
end
summary=cell2table(rows,'VariableNames',{'Axis','Metric','CPP','MATLAB_ModelMean','MATLAB_P05','MATLAB_P95'});
end
