function [model,summary,details] = identify_imu_switch_model(time_s,error_sensor_ug,options)
% Identify a two-level switching readout from baseline-corrected SENSOR XYZ.
% MATLAB R2021b; no additional toolboxes. No overall mean is removed.
% Fits are descriptive: two clusters alone do not establish a sensor fault.
% Exported levels include the offset; do not add the old mean bias again.
if nargin<3, options=struct; end
defaults = struct('ConfirmSamples',1,'MinSeparationSigma',4, ...
    'MinSeparation_ug',0,'MinCompleteRuns',2,'TimeToleranceFraction',0.01, ...
    'ManualLevels_ug',nan(3,2),'OutputDirectory','','MakePlots',true,'Seed',1234);
fields=fieldnames(defaults);
for k=1:numel(fields)
    if ~isfield(options,fields{k}), options.(fields{k})=defaults.(fields{k}); end
end
validateattributes(options.ConfirmSamples,{'numeric'},{'scalar','integer','positive','finite'});
validateattributes(options.MinCompleteRuns,{'numeric'},{'scalar','integer','positive','finite'});
validateattributes(options.MinSeparationSigma,{'numeric'},{'scalar','real','finite','nonnegative'});
validateattributes(options.MinSeparation_ug,{'numeric'},{'scalar','real','finite','nonnegative'});
assert(isequal(size(options.ManualLevels_ug),[3 2]),'ManualLevels_ug must be 3x2.');
t=double(time_s(:)); y=double(error_sensor_ug);
assert(size(y,1)==numel(t) && size(y,2)==3 && numel(t)>=8 && ...
    isreal(t) && isreal(y) && all(isfinite(t)) && all(isfinite(y(:))) && all(diff(t)>0), ...
    'Need finite, increasing times and an N-by-3 sensor-error matrix (at least 8 rows).');
t=t-t(1); dt=median(diff(t));
assert(all(abs(diff(t)-dt)<=options.TimeToleranceFraction*dt+32*eps(max(t))), ...
    ['Fit one contiguous, uniformly sampled interval. Do not compress gaps caused ' ...
     'by exclusions or join separate test segments.']);
fs=1/dt; n=numel(t); names={'X','Y','Z'};
empty=struct('switching',false,'low_ug',0,'high_ug',0,'low_s',0,'high_s',0, ...
    'phase_s',0,'initial_high',false,'initial_remaining_s',0, ...
    'low_dwells_s',[],'high_dwells_s',[]);
model=repmat(empty,1,3); inferred=zeros(n,3); periodic=zeros(n,3); empirical=zeros(n,3);
stateAll=false(n,3); rows=cell(3,16); runTables=cell(1,3);
stream=RandStream('mt19937ar','Seed',options.Seed);
for axis=1:3
    x=y(:,axis); manual=options.ManualLevels_ug(axis,:);
    if all(isnan(manual))
        lo=min(x); hi=max(x);
        for k=1:100
            high=x>(lo+hi)/2;
            if ~any(high) || all(high), break; end
            levels=[median(x(~high)),median(x(high))];
            if max(abs(levels-[lo hi]))<=1e-10*max(1,max(abs(x)))
                lo=levels(1); hi=levels(2); break;
            end
            lo=levels(1); hi=levels(2);
        end
    else
        assert(all(isfinite(manual)) && manual(2)>manual(1), ...
            'Manual levels must be [low high] or [NaN NaN] for each axis.');
        lo=manual(1); hi=manual(2);
    end
    high=x>(lo+hi)/2;
    if any(high) && ~all(high)
        sigmaLow=1.4826*median(abs(x(~high)-median(x(~high))));
        sigmaHigh=1.4826*median(abs(x(high)-median(x(high))));
        separation=(hi-lo)/max([sigmaLow sigmaHigh eps(max(1,max(abs(x))))]);
    else
        separation=0;
    end
    if hi-lo<=options.MinSeparation_ug || ...
            (all(isnan(manual)) && separation<options.MinSeparationSigma)
        % Do not force a two-state fit on an axis that lacks level separation.
        p=empty; p.low_ug=median(x); p.high_ug=p.low_ug;
        model(axis)=p; inferred(:,axis)=p.low_ug; periodic(:,axis)=p.low_ug;
        empirical(:,axis)=p.low_ug; runTables{axis}=table;
        rows(axis,:)={names{axis},'constant',p.low_ug,p.high_ug,NaN,NaN,NaN,NaN, ...
            NaN,NaN,0,0,separation,sqrt(mean((x-p.low_ug).^2)),NaN,NaN};
        continue;
    end
    % Hysteresis, with optional consecutive-sample confirmation to suppress chatter.
    state=false(n,1); state(1)=x(1)>(lo+hi)/2;
    lowThreshold=lo+0.35*(hi-lo); highThreshold=lo+0.65*(hi-lo); count=0;
    for k=2:n
        state(k)=state(k-1);
        cross=(~state(k) && x(k)>=highThreshold) || (state(k) && x(k)<=lowThreshold);
        if cross, count=count+1; else, count=0; end
        if count>=options.ConfirmSamples
            first=k-count+1; state(first:k)=~state(k-1); count=0;
        end
    end
    if ~any(state) || all(state)
        error('Axis %s has no resolved transitions. Check levels / ConfirmSamples.',names{axis});
    end
    % Refit plateau levels after classification; retain the nonzero low level.
    lo=median(x(~state)); hi=median(x(state));
    assert(hi>lo,'Classified high level must exceed low level.');
    starts=[1; find(diff(state)~=0)+1];
    runState=state(starts); startTimes=t(starts);
    duration=diff([startTimes;t(end)+dt]); complete=true(size(starts));
    complete([1 end])=false; % Both record-edge runs are censored, not full dwells.
    lowDwells=duration(complete & ~runState); highDwells=duration(complete & runState);
    assert(numel(lowDwells)>=options.MinCompleteRuns && ...
        numel(highDwells)>=options.MinCompleteRuns, ...
        ['Axis ' names{axis} ': need at least ' num2str(options.MinCompleteRuns) ...
        ' complete high AND low runs. Select a longer contiguous test interval.']);
    low_s=median(lowDwells); high_s=median(highDwells); period=low_s+high_s;
    firstRise=startTimes(find(runState & starts>1,1));
    phase=mod(-firstRise,period);
    p=struct('switching',true,'low_ug',lo,'high_ug',hi,'low_s',low_s, ...
        'high_s',high_s,'phase_s',phase,'initial_high',state(1), ...
        'initial_remaining_s',startTimes(2),'low_dwells_s',lowDwells, ...
        'high_dwells_s',highDwells);
    model(axis)=p; stateAll(:,axis)=state;
    inferred(:,axis)=lo+(hi-lo)*double(state);
    cyclePhase=mod(t+phase,period); edgeTolerance=32*eps(max(1,max(abs(t+phase))));
    cyclePhase(period-cyclePhase<=edgeTolerance)=0;
    cyclePhase(abs(cyclePhase-high_s)<=edgeTolerance)=high_s;
    periodic(:,axis)=lo+(hi-lo)*double(cyclePhase<high_s);
    % Preview the empirical alternating-renewal model (different RNG from C++).
    on=state(1); next=p.initial_remaining_s;
    for k=1:n
        while t(k)>=next-32*eps(max(1,abs(next)))
            on=~on;
            if on, pool=highDwells; else, pool=lowDwells; end
            next=next+pool(1+floor(rand(stream)*numel(pool)));
        end
        empirical(k,axis)=lo+(hi-lo)*double(on);
    end
    runTables{axis}=table(startTimes,runState,duration,complete, ...
        'VariableNames',{'Start_s','High','Duration_s','Complete'});
    rows(axis,:)={names{axis},'switching',lo,hi,low_s,high_s,1/period,high_s/period, ...
        std(lowDwells)/mean(lowDwells),std(highDwells)/mean(highDwells), ...
        numel(lowDwells),numel(highDwells),separation, ...
        sqrt(mean((x-inferred(:,axis)).^2)), ...
        sqrt(mean((x-periodic(:,axis)).^2)),mean(state)};
end
summary=cell2table(rows,'VariableNames',{'Axis','Type','Low_ug','High_ug', ...
    'MedianLow_s','MedianHigh_s','NominalFrequency_Hz','NominalDuty', ...
    'LowDwellCV','HighDwellCV','CompleteLowRuns','CompleteHighRuns', ...
    'LevelSeparationSigma','PlateauResidualRMS_ug','PeriodicRMSE_ug','ObservedHighFraction'});
details=struct('Time_s',t,'Fs_Hz',fs,'InputSensor_ug',y,'InferredState',stateAll, ...
    'Classified_ug',inferred,'Periodic_ug',periodic,'EmpiricalPreview_ug',empirical, ...
    'Residual_ug',y-inferred,'Runs',{runTables});
if ~isempty(options.OutputDirectory)
    if ~isfolder(options.OutputDirectory), mkdir(options.OutputDirectory); end
    localWriteHeader(fullfile(options.OutputDirectory,'imu_switch_params.h'),model);
    writetable(summary,fullfile(options.OutputDirectory,'imu_switch_summary.csv'));
    save(fullfile(options.OutputDirectory,'imu_switch_fit.mat'),'model','summary','details','options');
end
if options.MakePlots
    figure('Name','Two-state IMU model: time, distribution, FFT','Position',[50 50 1350 900]);
    tiles=tiledlayout(3,3,'TileSpacing','compact','Padding','compact');
    for axis=1:3
        ax=nexttile(tiles,3*axis-2);
        plot(ax,t,y(:,axis),'Color',[.7 .7 .7]); hold(ax,'on');
        stairs(ax,t,inferred(:,axis),'k'); plot(ax,t,periodic(:,axis),'r--');
        title(ax,['Sensor ' names{axis} ': test / classified / periodic']);
        xlabel(ax,'Elapsed time [s]'); ylabel(ax,'Error [\mug]'); grid(ax,'on');
        legend(ax,'Test','Classified levels','Periodic model','Location','best');
        ax=nexttile(tiles,3*axis-1);
        [~,edges]=histcounts([y(:,axis);periodic(:,axis);empirical(:,axis)],50);
        histogram(ax,y(:,axis),edges,'Normalization','probability'); hold(ax,'on');
        histogram(ax,periodic(:,axis),edges,'Normalization','probability','DisplayStyle','stairs');
        histogram(ax,empirical(:,axis),edges,'Normalization','probability','DisplayStyle','stairs');
        xlabel(ax,'Error [\mug]'); ylabel(ax,'Fraction of samples'); grid(ax,'on');
        legend(ax,'Test','Periodic','Empirical preview','Location','best');
        ax=nexttile(tiles,3*axis);
        w=0.5-0.5*cos(2*pi*(0:n-1)'/n); % Periodic Hann, no toolbox
        signals=[y(:,axis),periodic(:,axis),empirical(:,axis)];
        % DC is removed ONLY for this spectrum display, never for model levels.
        amplitude=abs(fft((signals-mean(signals,1)).*w,[],1))/sum(w);
        amplitude=amplitude(1:floor(n/2)+1,:);
        amplitude(2:ceil(n/2),:)=2*amplitude(2:ceil(n/2),:);
        f=(0:floor(n/2))'*fs/n;
        plot(ax,f(2:end),amplitude(2:end,:)); grid(ax,'on');
        xlabel(ax,'Frequency [Hz]'); ylabel(ax,'FFT peak amplitude [\mug]');
        legend(ax,'Test','Periodic','Empirical preview','Location','best');
    end
    title(tiles,'Two-state approximation: inspect timing, level occupancy and spectral agreement');
end
end

function localWriteHeader(path,model)
fid=fopen(path,'w'); assert(fid>=0,'Cannot write parameter header.');
cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
fprintf(fid,'// Generated from YOUR selected SENSOR-frame data. Levels [ug], time [s].\n');
fprintf(fid,'#ifndef IMU_SWITCH_PARAMS_H\n#define IMU_SWITCH_PARAMS_H\n');
fprintf(fid,'#include "imu_switch_model.hpp"\nnamespace imu_switch_fitted {\n');
for axis=1:3
    localArray(fid,sprintf('low_%d',axis),model(axis).low_dwells_s);
    localArray(fid,sprintf('high_%d',axis),model(axis).high_dwells_s);
end
fprintf(fid,'static const imu_switch::AxisParams axes[3] = {\n');
for axis=1:3
    p=model(axis);
    fprintf(fid,['  {%s, %.17g, %.17g, %.17g, %.17g, %.17g, %s, %.17g, ' ...
        'low_%d, %d, high_%d, %d}%s\n'], ...
        localBool(p.switching),p.low_ug,p.high_ug,p.low_s,p.high_s,p.phase_s, ...
        localBool(p.initial_high),p.initial_remaining_s,axis,numel(p.low_dwells_s), ...
        axis,numel(p.high_dwells_s),localComma(axis<3));
end
fprintf(fid,'};\n} // namespace imu_switch_fitted\n#endif\n');
end
function localArray(fid,name,values)
fprintf(fid,'static const double %s[] = {',name);
if isempty(values), fprintf(fid,'1.0'); else
    fprintf(fid,'%.17g',values(1)); fprintf(fid,', %.17g',values(2:end));
end
fprintf(fid,'};\n');
end
function s=localBool(value)
if value, s='true'; else, s='false'; end
end
function s=localComma(value)
if value, s=','; else, s=''; end
end
