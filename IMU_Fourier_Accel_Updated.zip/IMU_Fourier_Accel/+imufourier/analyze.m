function r=analyze(T,c)
assert(exist('pwelch','file')==2,'Signal Processing Toolbox is required.');
assert(isscalar(c.maxTones) && isreal(c.maxTones) && c.maxTones>=0 && ...
    (c.maxTones==Inf || (isfinite(c.maxTones)&&c.maxTones==floor(c.maxTones))));
assert(ismember(c.toneSelection,{'energy','lowFrequency'}));
assert(ismember(c.ambientMode,{'none','white'}));
assert(ismember(c.phaseMode,{'aligned','randomCircularShift'}));
validateattributes(c.fitFraction,{'numeric'},{'scalar','real','finite','>',0,'<=',1});
validateattributes(c.nRealizations,{'numeric'},{'scalar','integer','>=',1});
validateattributes(c.seed,{'numeric'},{'scalar','integer','>=',0,'<',2^32});
validateattributes(c.maxIntegrationPlotPoints,{'numeric'},{'scalar','integer','>=',2});
validateattributes(c.allanPoints,{'numeric'},{'scalar','integer','>=',2});
validateattributes(c.histogramBins,{'numeric'},{'scalar','integer','>=',10});
assert(isfinite(c.detectSigma) && c.detectSigma>0);
assert(isequal(size(c.manualThreshold_ug),[1 3]) && ...
    all(isnan(c.manualThreshold_ug) | (isfinite(c.manualThreshold_ug)&c.manualThreshold_ug>0)));
settings=[c.zoom_s c.quietZoom_s c.maxLag_s c.quietMaxLag_s c.welchWindow_s c.block_s c.summaryTerminalWindow_s];
assert(all(isfinite(settings)&settings>0));
d=imufourier.prepare(T,c); holdout=c.fitFraction<1; cut=floor(size(d.y,1)*c.fitFraction);
if holdout
    train=d.y(1:cut,:); ref=d.y(cut+1:end,:);
    referenceLabel='Measured (held-out)'; referenceMode='First portion fits; final portion checks';
else
    train=d.y; ref=d.y; referenceLabel='Measured (fit/reference)';
    referenceMode='Same record fits and checks: descriptive agreement, not independent validation';
end
assert(size(train,1)>=256 && size(ref,1)>=256,'Need >=256 samples in each fit/reference portion.');
[m,fitInfo]=imufourier.fit(train,d.Fs,d.mask,c); n=size(ref,1); K=c.nRealizations;
if strcmp(c.phaseMode,'aligned') && all(m.whiteSigma_ug==0), K=1; end
r=struct('cfg',c,'input',d,'train',train,'reference',ref,'model',m,'fitInfo',fitInfo, ...
    'split',cut,'hasHoldout',holdout,'referenceLabel',referenceLabel,'referenceMode',referenceMode);
[r.Coefficients,r.ToneCoefficients]=imufourier.coefficients(m);
r.distinctModelRuns=K; r.phaseOffsets=zeros(K,1); r.validationTime_s=(0:n-1)'/m.Fs;
r.generatedMin=Inf(1,3); r.generatedMax=-Inf(1,3); r.boundViolations=zeros(1,3);
L=max(16,min(round(c.welchWindow_s*m.Fs),floor(n/4)));
r.welch=struct('window',hamming(L),'overlap',floor(L/2),'nfft',max(256,2^nextpow2(L)));
[r.referencePSD,r.frequency_Hz]=pwelch(ref-mean(ref,1),r.welch.window,r.welch.overlap,r.welch.nfft,m.Fs);
r.lag=min(round(c.maxLag_s*m.Fs),n-2);
r.quietLag=min(round(c.quietMaxLag_s*m.Fs),min(size(train,1),n)-2);
r.psd=zeros(numel(r.frequency_Hz),3,K); r.acf=NaN(r.lag+1,3,K); r.acfCovariance=zeros(r.lag+1,3,K);
r.quietACF=NaN(r.quietLag+1,3,K); r.referenceACF=NaN(r.lag+1,3);
r.referenceQuietACF=NaN(r.quietLag+1,3);
r.histogram=NaN(c.histogramBins,3,K); r.histReference=NaN(c.histogramBins,3);
r.histEdges=cell(1,3); r.histCenters=cell(1,3);
for j=find(d.mask)
    edges=imufourier.histogramEdges(ref(:,j),c.histogramBins); counts=histcounts(ref(:,j),edges);
    r.histCenters{j}=(edges(1:end-1)+edges(2:end))/2; edges([1 end])=[-Inf Inf]; r.histEdges{j}=edges;
    r.histReference(:,j)=counts(:)/n; r.referenceACF(:,j)=acf(ref(:,j),r.lag);
end
% Add the aligned tone-only baseline using the SAME coefficients, with white off.
toneModel=m; toneModel.whiteSigma_ug(:)=0;
r.toneOnly=imufourier.generate(toneModel,n,[],0);
r.tonePSD=pwelch(r.toneOnly-mean(r.toneOnly,1),r.welch.window,r.welch.overlap,r.welch.nfft,m.Fs);
r.toneACF=NaN(r.lag+1,3);
maxM=floor((n-2)/2); r.allanM=unique(round(logspace(0,log10(maxM),c.allanPoints)))';
r.allanM=r.allanM(r.allanM>=1 & r.allanM<(n-1)/2); r.allanTau_s=r.allanM/m.Fs;
r.referenceAllanVariance=imufourier.allanVariance(ref,r.allanM);
r.toneAllanVariance=imufourier.allanVariance(r.toneOnly,r.allanM);
r.allanVariance=zeros(numel(r.allanM),3,K);
for j=find(d.mask), r.toneACF(:,j)=acf(r.toneOnly(:,j),r.lag); end
[r.referenceMetrics,r.metricNames,refV,refP,r.refEvents]=imufourier.metrics(ref,m);
r.metricValues=NaN(numel(r.metricNames),3,K); r.events=cell(K,1);
for j=find(d.mask), r.referenceQuietACF(:,j)=imufourier.maskedACF(ref(:,j),~r.refEvents{j}.mask,r.quietLag); end
index=unique(round(linspace(1,n+1,min(n+1,c.maxIntegrationPlotPoints))))';
r.integrationTime_s=(index-1)/m.Fs; r.refV=refV(index,:); r.refP=refP(index,:);
r.v=zeros(numel(index),3,K); r.p=r.v;
r.gaussianV=zeros(numel(index),3,c.nRealizations); r.gaussianP=r.gaussianV;
meanFit=mean(train,1); stdFit=std(train,1,1);
[meanV,meanP]=imufourier.integrate(repmat(meanFit,n,1),m.Fs);
r.meanV=meanV(index,:); r.meanP=meanP(index,:);
clear refV refP meanV meanP;
windowL=min(n,max(1,round(c.summaryTerminalWindow_s*m.Fs))); W=floor(n/windowL);
[testV,testP]=imufourier.windowEndpoints(ref,m.Fs,windowL);
r.summary=struct('window_s',windowL/m.Fs,'windowSamples',windowL,'windowsPerRecord',W, ...
    'discardedSamplesPerRecord',n-W*windowL,'testV',testV,'testP',testP, ...
    'modelV',zeros(W*K,3),'modelP',zeros(W*K,3));
r.crossReference=corrcoef(ref(:,d.mask)); r.crossMean=zeros(nnz(d.mask));
stream=RandStream('mt19937ar','Seed',c.seed);
gaussianStream=RandStream('mt19937ar','Seed',mod(c.seed+98765,2^32));
for k=1:K
    [x,r.phaseOffsets(k)]=imufourier.generate(m,n,stream);
    r.generatedMin=min(r.generatedMin,min(x,[],1)); r.generatedMax=max(r.generatedMax,max(x,[],1));
    for j=find(m.selectedMask)
        tolerance=100*eps(max(1,max(abs(train(:,j)))));
        outside=x(:,j)<m.lower(j)-tolerance | x(:,j)>m.upper(j)+tolerance;
        r.boundViolations(j)=r.boundViolations(j)+nnz(outside);
    end
    if k==1, r.exampleGenerated=x; end
    [r.metricValues(:,:,k),~,v,p,r.events{k}]=imufourier.metrics(x,m);
    eventRecord=r.events{k};
    r.v(:,:,k)=v(index,:); r.p(:,:,k)=p(index,:);
    r.psd(:,:,k)=pwelch(x-mean(x,1),r.welch.window,r.welch.overlap,r.welch.nfft,m.Fs);
    for j=find(d.mask)
        [r.acf(:,j,k),r.acfCovariance(:,j,k)]=acf(x(:,j),r.lag);
        r.quietACF(:,j,k)=imufourier.maskedACF(x(:,j),~eventRecord{j}.mask,r.quietLag);
        r.histogram(:,j,k)=histcounts(x(:,j),r.histEdges{j},'Normalization','probability')';
    end
    rows=(k-1)*W+(1:W);
    [r.summary.modelV(rows,:),r.summary.modelP(rows,:)]=imufourier.windowEndpoints(x,m.Fs,windowL);
    r.allanVariance(:,:,k)=imufourier.allanVariance(x,r.allanM);
    r.crossMean=r.crossMean+corrcoef(x(:,d.mask))/K;
end
% The preferred ensemble estimator: mean BIASED COVARIANCE first, then normalize once.
r.meanACF=imufourier.normalizeACF(mean(r.acfCovariance,3));
% Preserve the requested Gaussian-comparison ensemble even if the Fourier
% model has only one distinct deterministic history.
for k=1:c.nRealizations
    gaussian=meanFit+randn(gaussianStream,n,3).*stdFit; gaussian(:,~d.mask)=0;
    [v,p]=imufourier.integrate(gaussian,m.Fs);
    r.gaussianV(:,:,k)=v(index,:); r.gaussianP(:,:,k)=p(index,:);
end
labels={'X','Y','Z'}; rows={}; scores={}; detection={};
for j=find(d.mask)
    for q=1:numel(r.metricNames)
        values=reshape(r.metricValues(q,j,:),[],1); range=imufourier.percentile(values,[5 95]);
        observed=r.referenceMetrics(q,j);
        rows(end+1,:)={labels{j},r.metricNames{q},observed,mean(values),range(1),range(2), ...
            observed>=range(1)&&observed<=range(2)}; %#ok<AGROW>
    end
    keep=r.frequency_Hz>0; average=mean(r.psd(:,j,:),3);
    psdError=sqrt(mean((10*log10(max(average(keep),realmin))-10*log10(max(r.referencePSD(keep,j),realmin))).^2));
    acfError=sqrt(mean((r.meanACF(:,j)-r.referenceACF(:,j)).^2));
    tv=.5*sum(abs(mean(r.histogram(:,j,:),3)-r.histReference(:,j)));
    scores(end+1,:)={labels{j},psdError,acfError,tv}; %#ok<AGROW>
    s=fitInfo.events{j}; detection(end+1,:)={labels{j},nnz(fitInfo.quietMask(:,j)), ...
        numel(s.peak_ug),nnz(s.peak_ug>0),nnz(s.peak_ug<0),m.threshold(j),m.release(j)}; %#ok<AGROW>
end
r.ValidationSummary=cell2table(rows,'VariableNames',{'Axis','Metric','MeasuredReference','ModelMean','ModelP05','ModelP95','InsideModelRange'});
r.SpectralSummary=cell2table(scores,'VariableNames',{'Axis','PSD_LogRatio_RMSE_dB','ACF_RMSE','BinnedAmplitudeTV'});
r.DetectionSummary=cell2table(detection,'VariableNames',{'Axis','QuietFitSamples','CompleteFitEvents','PositiveFitEvents','NegativeFitEvents','Onset_ug','Release_ug'});
r.TerminalWindows=terminalTable(r);
[r.CumulativePower,r.AllanSummary,r.ToneValidation]=imufourier.backboneSummaries(r);
[r.DensitySummary,r.PowerSummary,r.BoundsSummary,r.FitReview]=imufourier.extraSummaries(r);
[r.TailSummary,r.HistogramSummary]=imufourier.tailSummaries(r);
if c.makeToneSweep, r.ToneSweep=imufourier.toneSweep(train,m,fitInfo,c);
else, r.ToneSweep=table; end
r.Generated_sensor=array2table([r.validationTime_s r.exampleGenerated], ...
    'VariableNames',{'Elapsed_s','ErrorX_ug','ErrorY_ug','ErrorZ_ug'});
r.Generated_PLT=array2table([r.validationTime_s r.exampleGenerated*c.R_sensor_to_PLT'], ...
    'VariableNames',r.Generated_sensor.Properties.VariableNames);
fprintf('%s\n',referenceMode); fprintf('Selected axes: %s. Unselected SENSOR contributions are zero.\n',strjoin(d.selectedAxes,','));
disp(r.Coefficients); disp(r.DetectionSummary); disp(r.SpectralSummary); disp(r.ValidationSummary);
disp(r.DensitySummary); disp(r.PowerSummary); disp(r.BoundsSummary); disp(r.FitReview);
disp(r.TailSummary); disp(r.ToneValidation);
fprintf('Model period %.9g s; distinct model histories evaluated: %d (requested %d).\n',m.period_s,K,c.nRealizations);
if K==1, fprintf('Aligned Fourier with zero added noise is deterministic; ensemble bands collapse.\n'); end
if c.makePlots, r.figures=imufourier.plotDiagnostics(r); else, r.figures=gobjects(0); end
end
function [a,covariance]=acf(x,lag)
x=x-mean(x); z=xcorr(x,lag,'biased'); covariance=z(lag+1:end);
a=imufourier.normalizeACF(covariance);
end
function T=terminalTable(r)
s=r.summary; rows={}; labels={'X','Y','Z'};
for j=find(r.model.selectedMask)
    for k=1:2
        if k==1, name='Velocity'; unit='m/s'; a=s.testV(:,j); b=s.modelV(:,j);
        else, name='Position'; unit='m'; a=s.testP(:,j); b=s.modelP(:,j); end
        qa=imufourier.percentile(a,[5 50 95]); qb=imufourier.percentile(b,[5 50 95]);
        rows(end+1,:)={labels{j},name,unit,s.window_s,numel(a),numel(b),s.discardedSamplesPerRecord, ...
            qa(1),qa(2),qa(3),qb(1),qb(2),qb(3)}; %#ok<AGROW>
    end
end
T=cell2table(rows,'VariableNames',{'Axis','Quantity','Unit','Window_s','MeasuredWindows','GeneratedWindows', ...
    'DiscardedSamplesPerRecord','MeasuredP05','MeasuredP50','MeasuredP95','GeneratedP05','GeneratedP50','GeneratedP95'});
end
