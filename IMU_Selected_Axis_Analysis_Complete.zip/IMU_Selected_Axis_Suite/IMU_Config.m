function cfg=IMU_Config()
% EDIT THIS FILE for your imported table. No time column is required.
cfg=imupulse.defaults();

%% 1. Select sensor axes and assign their EXACT table variable names
cfg.selectedAxes={'Y'};              % {'X'}, {'Y'}, {'Z'}, or e.g. {'X','Z'}
cfg.columns.X='';                     % Example: 'Accel_X_ft_s2'
cfg.columns.Y='Your_Y_Column';        % EDIT to your actual column name
cfg.columns.Z='';                     % Unselected axis names can stay empty

%% 2. Acquisition timing (one uniformly sampled row per sensor update)
cfg.sampleRate_Hz=NaN;                % EDIT: your recorded rate, e.g. 1000
cfg.startTime_s=0;                    % ORIGINAL row 1 time; normally leave at 0
cfg.timeColumn='';                   % Leave empty: t=(0:height(T)-1)'/Fs + start
% OPTIONAL timestamp mode: cfg.timeColumn='RecordedTime_s'; numeric seconds.
% With a real time column, its timestamps determine Fs; sampleRate_Hz is ignored.

%% 3. Input units, interval and known true acceleration
cfg.inputMode='instantaneous_ft_s2';
cfg.window_s=[-Inf Inf];              % Entire record, or e.g. [10 90] seconds
cfg.baselineSensor_ms2=[NaN NaN NaN]; % EDIT selected entries, including gravity
% Example ONLY for known zero-input / gravity-compensated Y:
% cfg.baselineSensor_ms2=[NaN 0 NaN];
cfg.R_sensor_to_PLT=eye(3);           % platform_column = R * sensor_column

%% 4. Model and diagnostic options
cfg.fitFraction=.70; cfg.nRealizations=50; cfg.isSynthetic=false;
% Optional detection thresholds [ug] in X/Y/Z order:
% cfg.manualThreshold_ug=[NaN 40 NaN]; cfg.detectSigma=5; cfg.releaseSigma=2;
% Optional ORIGINAL input bounds: rows X/Y/Z, columns lower/upper:
% cfg.railLimitsInput=[-Inf Inf;-0.05 0.05;-Inf Inf];
% cfg.allowRailSamples=true; % Explicitly model the recorded clipped readout
end
