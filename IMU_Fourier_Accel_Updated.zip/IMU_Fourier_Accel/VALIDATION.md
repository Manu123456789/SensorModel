# Validation record

Executed build checks:

```bash
g++ -std=c++11 -O2 -Wall -Wextra -Werror -Wno-unused-function tests/test_integrated_host.cpp -o /tmp/imu_fourier_host
/tmp/imu_fourier_host
python3 tests/verify_reference.py
python3 tests/verify_statistics.py
```

The first test compiles the exact delivered `error_sensor()` function against a
mock host. It checks individual reconstructed spike samples, multiple periods,
enable-time and condition gating, run resets, full selected-axis replacement,
preserved sensor X/Z under rotation, unchanged legacy RNG draws and seed sequence,
and unchanged legacy noise history. It also checks that adding a large sensor-Y
legacy bias has no effect on the enabled result.

The Python test replaces only the coefficient constants in temporary copies of
the actual C++ source and compiles them. Fixtures cover odd/even full reconstruction,
reduced Fourier sets, offset-only output, a common circular start shift, and added
white noise. A separate NumPy sine evaluation covers positive/negative Nyquist
terms, DC, odd/even records, and an irregular one-sample-spike reconstruction sweep.
Evidence/Validation.json records numerical results. Temporary fixture arrays are
test-only; the production implementation never reads a data file.

The statistics reference checks ensemble averaging of biased covariance before
normalization, overlapping Allan variance against explicit adjacent block means,
constant-offset invariance, variance averaging before square root, and cumulative
linear PSD power with a final value equal to the trapezoidal power integral.
`evidence/Statistics_Validation.json` records those Python results. These checks
validate the estimator formulas independently; they do not execute MATLAB.

AddressSanitizer and UndefinedBehaviorSanitizer were also used on the exact
mock-host integration test. Leak checking is disabled because this execution
environment does not support LeakSanitizer's required /proc inspection. Check
evidence/Build_Status.json for actual status rather than treating this document
as proof of execution.

MATLAB/Octave execution is NOT claimed. Run `Test_Fourier` from the tests folder
with the package root on the path in MATLAB R2021b and Signal Processing Toolbox.
It exercises actual MATLAB fitting/generation, explicit sine-vs-FFT conventions,
periods/shifts, DC/Nyquist/odd lengths, quiet residual noise fitting, units and
row timing, empty tone tables, covariance-first ensemble ACF, overlapping Allan
variance, cumulative power, and construction of every plot family including V.
If `allanvar` is installed, it also cross-checks the base-MATLAB implementation
against that function. Sensor Fusion Toolbox is not required by the package.

For hardware review, first verify units, physical-baseline subtraction, sample
rate, and A detection overlays. With full components, ambientMode=none and aligned
phases, check the aligned point error in FitReview before reducing maxTones.
Check peak heights and durations, the run-1 histogram, quiet behavior, PSD and
integrated errors as you reduce K; do not accept a sharp-spike model solely on
global RMS or captured energy. Examine the circular join and repeated cycles.

The default fit/check uses the same source record and therefore demonstrates
descriptive reconstruction, not independent predictive accuracy. An exact full
fit should not be presented as proof of a general stochastic sensor model.
Unseen hardware data, actual host RNG semantics, real measurement units and the
full production simulation linkage were not provided and remain unverified.
