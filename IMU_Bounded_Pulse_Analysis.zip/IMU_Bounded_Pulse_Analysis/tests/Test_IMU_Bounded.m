function Test_IMU_Bounded()
% Supplied MATLAB R2021b+ integration tests. Run in MATLAB; no hardware qualification.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(root);
source=fileread(fullfile(root,'IMU_Config.m')); at=strfind(source,'%% RUN');
assert(numel(at)==1); eval(source(1:at-1));
cfg.makePlots=false; cfg.saveFigures=false; cfg.nRealizations=4;
cfg.sampleRate_Hz=200; cfg.baselineSensor_ms2=[0 0 0];
[T,~]=Generate_Example_IMU(200,180);
T.Properties.VariableNames={'Channel X','Accel_Y_Custom','Sensor_Z'};
cfg.columns=struct('X','Channel X','Y','Accel_Y_Custom','Z','Sensor_Z');
cfg.rowWindow=[1000 2000]; d=imubounded.prepare(T,cfg);
assert(isequal(d.sourceRows,(1000:2000)') && d.t(1)==999/200 && d.t(end)==1999/200);
other=array2timetable(T{:,:},'SampleRate',17,'VariableNames',T.Properties.VariableNames);
d2=imubounded.prepare(other,cfg); assert(isequal(d.t,d2.t) && isequal(d.y,d2.y));
cfg.rowWindow=[1 Inf];
for axis={'X','Y','Z'}
    cfg.selectedAxes=axis; d=imubounded.prepare(T,cfg); j=find(d.mask);
    [m,info]=imubounded.fit(d.y,d.Fs,d.mask,cfg);
    assert(~isfield(m,'gapProbability') && ~isfield(m,'logMu'));
    assert(m.lower(j)==min(d.y(:,j)) && m.upper(j)==max(d.y(:,j)));
    [x,ledger]=imubounded.generate(m,2*m.blockSamples+37,RandStream('mt19937ar','Seed',123));
    assert(all(all(x(:,~d.mask)==0)) && all(x(:,j)>=m.lower(j)&x(:,j)<=m.upper(j)));
    for k=1:2
        rows=(k-1)*m.blockSamples+(1:m.blockSamples);
        events=imubounded.eventStats(x(rows,:),m); e=events{j};
        assert(isequal([nnz(e.peak_ug>0) nnz(e.peak_ug<0)],info.signCounts(j,:)));
        plan=ledger{j}{k}; types=m.pulseTypes{j};
        assert(sum(plan.gaps)+sum([types(plan.order).width])==m.blockSamples);
    end
    assert(numel(ledger{j})==3);
end
cfg.selectedAxes={'Y'}; cfg.fitFraction=1; r=imubounded.analyze(T,cfg);
assert(~r.hasHoldout && isequal(r.train,r.reference) && height(r.Coefficients)==1);
assert(height(r.DensitySummary)==2 && height(r.PowerSummary)==1 && height(r.BoundsSummary)==1);
assert(all(r.BoundsSummary.GeneratedViolations==0) && all(r.BlockSummary.ExactlyOneCompleteBlock));
assert(all(all(r.exampleGenerated(:,[1 3])==0)) && size(r.v,1)<=cfg.maxIntegrationPlotPoints);
assert(height(r.PulseKnots)==r.Coefficients.TotalKnotCount);
cfg.fitFraction=.70; held=imubounded.analyze(T,cfg); assert(held.hasHoldout);
assert(held.model.lower(2)==min(held.train(:,2)) && held.model.upper(2)==max(held.train(:,2)));
assert(held.BlockSummary.CompleteGeneratedBlocks==0);
% Exact coefficient limit preserves pulse samples and occupied time.
cfg.maxPulseTypesPerSign=100000; cfg.maxKnotsPerPulse=100000; cfg.knotTolerance_ug=0;
d=imubounded.prepare(T,cfg); [m,info]=imubounded.fit(d.y,d.Fs,d.mask,cfg);
x=imubounded.generate(m,m.blockSamples,RandStream('mt19937ar','Seed',2));
e=imubounded.detect(x,m);
assert(isequal(sort(x(e.mask(:,2),2)),sort(d.y(~info.quietMask(:,2),2))));
% Missing sign class, constant quiet, width-one spikes and boundary fragments.
flat=zeros(5000,3); flat(1:3,2)=20; flat(end-4:end,2)=60;
for first=101:400:4700, flat(first,2)=100; end
[one,info]=imubounded.fit(flat,200,[false true false],cfg);
assert(info.signCounts(2,2)==0 && one.bgSigma(2)==0 && info.boundaryEvents(2)==2);
x=imubounded.generate(one,10000,RandStream('mt19937ar','Seed',4));
assert(all(x(:,2)>=0 & x(:,2)<=100));
% Conditional noise is not clipped to endpoints.
x=imubounded.boundedNormal(zeros(10000,1),1,-.3,.2,RandStream('mt19937ar','Seed',7));
assert(all(x>-.3 & x<.2));
% Topology preservation overrides a small knot budget when required.
[~,~,x]=imubounded.compressPulse([30;20;-20;25;-25;25;30],0,10,4,3,100);
assert(all(abs(x)>4));
% ZOH integration and row-based cumulative decoding.
x=zeros(23,3); x([1 20],2)=1; [v,p]=imubounded.windowEndpoints(x,10,10);
assert(size(v,1)==2 && abs(v(1,2)-v(2,2))<1e-15 && p(1,2)>p(2,2));
cfg.histogramAxes={'Y'}; cfg.rowWindow=[1000 2000]; original=imubounded.prepare(T,cfg);
accum=T; accum.Accel_Y_Custom=cumsum(T.Accel_Y_Custom*30.48); cfg.inputMode='sample_sum_cm_s2';
decoded=imubounded.prepare(accum,cfg); assert(max(abs(original.y(:,2)-decoded.y(:,2)))<1e-7);
% Same diagnostics plus R, maximum six data axes per figure.
r.cfg.figureVisible='off'; figures=imubounded.plotDiagnostics(r); assert(numel(figures)==9);
for k=1:numel(figures), assert(numel(findall(figures(k),'Type','axes'))<=6); end
close(figures);
fprintf('PASS: full-block counts, compressed pulses, bounds, row clock, fit modes, nine figure families.\n');
end
