function Test_IMU_Simple()
% MATLAB R2021b+ and Signal Processing Toolbox. Synthetic regression checks.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(root);
source=fileread(fullfile(root,'IMU_Config.m')); at=strfind(source,'%% RUN');
assert(numel(at)==1); eval(source(1:at-1));
cfg.makePlots=false; cfg.saveFigures=false; cfg.nRealizations=4;
cfg.sampleRate_Hz=200; cfg.baselineSensor_ms2=[0 0 0];
[T,truth]=Generate_Example_IMU(200,180);
T.Properties.VariableNames={'Channel X','Accel_Y_Custom','Sensor_Z'};
cfg.columns=struct('X','Channel X','Y','Accel_Y_Custom','Z','Sensor_Z');
cfg.rowWindow=[1000 2000]; d=imusimple.prepare(T,cfg);
assert(isequal(d.sourceRows,(1000:2000)') && size(d.y,1)==1001);
assert(d.t(1)==999/200 && d.t(end)==1999/200);
% Acquisition metadata is deliberately inconsistent. Configured Fs controls time.
other=array2timetable(T{:,:},'SampleRate',17,'VariableNames',T.Properties.VariableNames);
d2=imusimple.prepare(other,cfg); assert(isequal(d.t,d2.t) && isequal(d.y,d2.y));
cfg.rowWindow=[1 Inf];
for axis={'X','Y','Z'}
    cfg.selectedAxes=axis; d=imusimple.prepare(T,cfg);
    [m,info]=imusimple.fit(d.y,d.Fs,d.mask,cfg); j=find(d.mask);
    assert(~isfield(m,'templates') && nnz(info.quietMask(:,j))>100);
    assert(abs(m.baseline(j)-truth.Parameters.baseline(j))<1);
    assert(abs(m.sigma(j)-truth.Parameters.sigma(j))<.5);
    assert(abs(m.negativeProbability(j)-truth.Parameters.negativeProbability(j))<.15);
    assert(abs(m.widthSamples(j)-truth.Parameters.widthSamples(j))<=1);
    x=imusimple.generate(m,10000,RandStream('mt19937ar','Seed',1));
    assert(all(all(x(:,~d.mask)==0)));
    assert(height(imusimple.coefficients(m))==1);
end
cfg.selectedAxes={'Y'}; cfg.fitFraction=1; r=imusimple.analyze(T,cfg);
assert(~r.hasHoldout && isequal(r.train,r.reference) && height(r.Coefficients)==1);
assert(all(all(r.exampleGenerated(:,[1 3])==0)));
assert(size(r.v,1)<=cfg.maxIntegrationPlotPoints && r.integrationTime_s(end)==size(r.reference,1)/cfg.sampleRate_Hz);
cfg.fitFraction=.70; held=imusimple.analyze(T,cfg);
assert(held.hasHoldout && size(held.train,1)==floor(height(T)*.7));
assert(size(held.reference,1)==height(T)-size(held.train,1));
% Choosing fewer visualization axes permits a table containing only that channel.
cfg.histogramAxes={'Y'}; d=imusimple.prepare(T(:,{'Accel_Y_Custom'}),cfg); assert(nnz(d.mask)==1);
% Known integration and per-window reset; early pulse has greater position area.
x=zeros(23,3); x([1 20],2)=1; [v,p]=imusimple.windowEndpoints(x,10,10);
assert(size(v,1)==2 && abs(v(1,2)-v(2,2))<1e-15 && p(1,2)>p(2,2));
assert(abs(v(1,2)-9.80665e-7)<1e-15 && abs(p(1,2)-.95*9.80665e-7)<1e-15);
assert(isequal(imusimple.shape('triangle',4),[.5;1;1;.5]));
% Cumulative decoding retains the requested original-row labels, using prior row.
cfg.rowWindow=[1000 2000]; original=imusimple.prepare(T,cfg);
accum=T; accum.Accel_Y_Custom=cumsum(T.Accel_Y_Custom*30.48);
cfg.inputMode='sample_sum_cm_s2'; decoded=imusimple.prepare(accum,cfg);
assert(isequal(original.sourceRows,decoded.sourceRows) && max(abs(original.y(:,2)-decoded.y(:,2)))<1e-7);
% Same figure families with no more than six data axes per tiled figure.
r.cfg.figureVisible='off'; figures=imusimple.plotDiagnostics(r);
assert(numel(figures)==7); % S,H,A,B,C,D,E for one axis
for k=1:numel(figures), assert(numel(findall(figures(k),'Type','axes'))<=6); end
close(figures);
fprintf('PASS: row window, metadata-independent clock, coefficients, axes, fit modes, integration, figures.\n');
end
