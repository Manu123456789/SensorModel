function [mu,sigma,exitflag]=fitBoundedLog(a,weight,cap)
% Weighted upper-truncated lognormal MLE, with log-location <= log(cap).
z=log(a(:)); weight=weight(:)/sum(weight); avg=sum(weight.*z);
variance=sum(weight.*(z-avg).^2); top=log(cap);
if variance<1e-14, mu=min(top,avg); sigma=0; exitflag=1; return; end
start=[min(top,avg) log(max(sqrt(variance),2e-6))];
options=optimset('Display','off','MaxIter',400,'TolX',1e-8,'TolFun',1e-8);
[theta,~,exitflag]=fminsearch(@cost,start,options);
mu=min(top,theta(1)); sigma=min(10,max(1e-6,exp(theta(2))));
    function value=cost(t)
        s=exp(t(2)); center=t(1);
        if ~isfinite(s) || ~isfinite(center) || center>top || s<1e-6 || s>10
            value=1e100; return;
        end
        Z=.5*erfc(-(top-center)/(s*sqrt(2)));
        value=log(s)+.5*(variance+(avg-center)^2)/s^2+log(max(Z,realmin));
    end
end
