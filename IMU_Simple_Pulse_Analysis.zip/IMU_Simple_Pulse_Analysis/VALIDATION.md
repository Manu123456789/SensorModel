# Verification status — simple coefficient model

This revision replaces recorded waveform catalogs and correlated backgrounds
with white noise plus fixed-shape, fixed-duration, randomly timed signed pulses.
It has no C++ source exporter. C++ instructions are a manually usable README
example, tested separately from your unseen host simulation.

## Executed checks

`tests/verify_reference.py` independently implements the specified numerical
model with NumPy, fits a synthetic 180-second 200-Hz record, and checks:

- selected X/Y/Z separately, with exact zeros on unselected sensor components;
- recovery of quiet offset/variance, fixed pulse width, log-magnitude statistics
  and sign probability under the example's assumed model;
- complete-event detection and positive complete-gap estimates;
- analytical full mean/std versus a one-million-sample realization;
- random stationary phase initialization over many short realizations;
- the normalized triangle definition, including short pulse supports;
- ZOH integration and reset-window endpoint weighting;
- resolution of every `imusimple` function call;
- summary six-tile count and detailed figure layout guard;
- absence of a waveform-export workflow and C++ source files in the deliverable.

It extracts the ACTUAL C++ generator block from README.md and compiles it with
C++11, `-Wall -Wextra -Werror -pedantic`. The executable checks exact quiet/pulse
boundaries and triangle values, then uses one million samples to check model
mean, variance, duty and event-start rate. The same extracted C++ also passed address/undefined-behavior instrumentation
with leak detection disabled. This verifies that the printed manual
implementation represents the intended model; it does not run your own RNG or
sensor error accumulator.

For the numerical reference's selected Y fit, quiet mean/std were about
-5.0605 / 5.0224 micro-g, with a fixed width of 16 samples and 158 complete detected
events. Its analytical full mean/std were about 9.8780 / 101.4053 micro-g; a new
one-million-sample numerical run gave 10.1506 / 101.5465 micro-g. These are
SYNTHETIC developer examples, not your hardware coefficients.

The compiled README C++ example had a separate known synthetic parameter set.
Its measured full mean was about 5.4562 micro-g versus an analytical 5.4154,
with nominal duty reproduced within the regression tolerance. Machine-readable
results are in `evidence/Simple_Validation.json`.

`evidence/Simple_Summary_Preview.png` is a six-panel Python reference illustration.
It is not a screenshot of MATLAB graphics and is not a fit to hardware data.
Its labels explicitly identify its synthetic/numerical origin.

## Supplied MATLAB tests — NOT executed here

MATLAB and Octave are not installed in the authoring environment. The MATLAB
implementation, plotting and saving path were reviewed but could not be executed.
The independent Python checks do not establish MATLAB syntax/runtime compatibility.

Run on your MATLAB R2021b+ installation:

```matlab
addpath('tests');
Test_IMU_Simple
```

The supplied MATLAB test covers:

- exact inclusive original-row windows and `t=(row-1)/Fs`;
- timetable metadata at a deliberately different rate having no clock effect;
- custom mapped channel names and restricted visualization columns;
- single-axis coefficient fits, exact inactive-axis zeros and no template catalog;
- full-record versus held-out reference modes and their sizes;
- display storage cap while integration preserves the full terminal horizon;
- pulse shape, ZOH weighting and window resets;
- cumulative-input decoding on requested original rows using the previous row;
- hidden graphics smoke checks for S,H,A,B,C,D,E, each with <=6 data axes.

For an ordinary visual check, set `cfg.useSyntheticExample=true` in IMU_Config.m
and run it. This exercises the whole MATLAB pipeline without hardware data.

Optional developer reference check (needs Python3/NumPy/SciPy/matplotlib/g++):

```sh
python3 tests/verify_reference.py /tmp/imu_simple_checks
```

## What remains a hardware/model judgment

Your raw test data and actual plots are not bundled or numerically validated
here. A lognormal magnitude law, independent signs, geometric gaps, fixed width,
ideal shape, white background and independence across selected axes are all
simplifying assumptions. The example is generated under those assumptions;
passing it is not evidence that the real sensor must follow them.

Detection can censor small events, trim pulse support or merge/fragment events.
Threshold-derived estimates are intentionally simple and approximate. Retain
all the diagnostics to see those limitations. Full-record fitting (the default)
is explicitly an in-sample comparison. Use the optional held-out mode and/or
separate measured runs for stronger validation.

PSD/amplitude agreement alone does not establish correct integrated errors.
Neither pointwise generated ranges nor CDF windows constitute a formal
qualification test. Your host's RNG, scheduling, unit conversion, frame rotation
and acceleration/delta-velocity insertion point require validation in that sim.
