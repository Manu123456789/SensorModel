function f=boundedNormalPDF(x,mu,sigma,lo,hi)
f=zeros(size(x));
if sigma==0, return; end
Z=.5*erfc(-(hi-mu)/(sigma*sqrt(2)))-.5*erfc(-(lo-mu)/(sigma*sqrt(2)));
inside=x>=lo & x<=hi; z=(x(inside)-mu)/sigma;
f(inside)=exp(-.5*z.^2)/(sigma*sqrt(2*pi)*Z);
end
