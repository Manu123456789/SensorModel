# Port the fitted accelerometer pulse model into your existing C++ error function

This port follows the structure of your attached `model_c_tones_white_noise(1).cpp`:
file constants and types, function prototypes, a main `void IMU_error()`, and helpers
below it. Use `error_sensor()` as the name instead if that is your application's
function name. The source is an integration scaffold; the host bindings must be
connected to your actual simulation, whose complete interfaces were not supplied.

The model is your existing fitted **quiet Gauss-Markov background plus empirical
spike events**. This is not a new identification method and does not replace the
MATLAB analysis suite. The supplied exporter translates ONE selected SENSOR axis
from `IMU_Results.model` into a complete single C++ file. No raw dataset, MATLAB
installation, CSV parser, or model header is needed at C++ runtime.

## 1. What changes compared with the tone example

Your tone example produces `sum(A*sin(...)) + sigma*Gaussian`. This model instead
uses persistent quiet state and an event scheduler:

```text
quiet[k] = phi*quiet[k-1] + sigma_quiet*sqrt(1-phi^2)*w[k]

excursion[k] = quiet[k]                 when not in an event
excursion[k] = stored_pulse[row]        during an event

sensor_error[k] = quiet_baseline + excursion[k]
```

Here `w[k]` is an independent, zero-mean, unit-variance Gaussian sample from YOUR
existing normal RNG. `sigma_quiet` is the stationary quiet standard deviation,
not the innovation standard deviation. The square-root factor gives the fitted
stationary variance: `phi^2*sigma_quiet^2 + (1-phi^2)*sigma_quiet^2`.

A fitted first-order model uses one previous quiet-state value, not an AR(p)
coefficient/history array. Even though the full output has spikes and asymmetric
tails, its quiet background can still be Gaussian. Neither its pulses nor the
complete process are made Gaussian by using a Gaussian background driver.

**Important implementation detail from the MATLAB code:** event templates are
measured waveform segments after subtracting the quiet baseline. They already
contain the measured within-event texture. During an event the waveform REPLACES
the quiet output. Fresh Gaussian noise is not added on top. The latent quiet
state still advances during the event, so it resumes at the correct sensor time.
This preserves the current MATLAB generator's behavior.

## 2. Exactly what comes out of MATLAB

Run your existing `IMU_Config.m` analysis on your real record, with exactly one
selected axis. For sensor Y / physical sensor axis 2:

```matlab
cfg.selectedAxes = {'Y'};
```

Use the fitted result, not the config settings or one generated trace:

```matlab
m = IMU_Results.model;
```

The following is exported automatically. `j` is the MATLAB selected-axis index:
X=1, Y=2, Z=3.

| MATLAB source | Exported C++ field/data | Units and purpose |
|---|---|---|
| `m.selectedMask` | `sensor_axis` | Zero-based C++ index: X=0, Y=1, Z=2 |
| `m.Fs` | `Fs` | Hz; required runtime sensor update rate |
| `m.baseline(j)` | `quiet_baseline_ug` | Signed quiet offset, micro-g |
| `sqrt(m.covariance(j,j))` | `quiet_sigma_ug` | Quiet stationary standard deviation, micro-g |
| `m.gmPhi` | `phi` | Dimensionless one-sample correlation factor |
| `m.templates{k}(:,j)` | `imu_pulse_samples` | Measured pulse deviations, micro-g, stacked in event order |
| Template row counts | `imu_event_length` | Duration of each event, in samples |
| Cumulative template lengths | `imu_event_offset` | Zero-based index of each waveform's first sample |
| `m.gapSamples(k)` | `imu_event_gap` | Quiet samples immediately BEFORE that same event |
| `m.classes` | `imu_event_sign` | Selected-axis positive/negative event classes, mapped to 0/1 |
| Selected-axis entries of `m.classFrequency` | `sign_probability` | Probability of selecting each event-sign class |
| Selected-axis block of `m.transitionProbability` | `transition` | Optional next-sign probabilities given previous sign |
| `m.useEventMarkov` | `use_markov` | Preserves whether your fitted generator uses sign transitions |
| `m.burnInSamples` / existing burn rule | `burn_in_samples` | Discarded pre-run samples for event-scheduler warm-up |

For this scalar port, `sqrt(covariance(j,j))` replaces the three-column
`noiseFactor(j,:)` multiplication. Both have the same Gaussian marginal variance
for ONE selected axis. Sample-by-sample Gaussian draws need not be identical.
A joint multi-axis fit requires the original covariance-factor implementation;
this exporter deliberately rejects multiple selected axes.

This is more than a handful of coefficients. Your identified pulse model is an
empirical catalog: the stored waveform and its preceding gap stay paired. Keeping
only a mean, RMS, minimum and maximum would discard identified pulse shapes,
widths and timing. A smaller parametric catalog would be a different model and
would need validation against the same diagnostics.

### Export command

Place this port folder on the MATLAB path and keep the template beside the
exporter:

```matlab
portRoot = 'C:\YourFolder\IMU_Axis_CPP_Port';  % EDIT this path
addpath(portRoot);
Export_IMU_Axis_To_CPP(IMU_Results.model, ...
    fullfile(portRoot,'IMU_Axis_Model.cpp'));
```

Alternatively, from the existing saved analysis:

```matlab
loaded = load(fullfile(cfg.outputFolder,'Analysis.mat'),'PulseModel');
Export_IMU_Axis_To_CPP(loaded.PulseModel, ...
    fullfile(portRoot,'IMU_Axis_Model.cpp'));
```

The generated `IMU_Axis_Model.cpp` contains all constants, runtime helpers and the
example `IMU_error()` binding. Copy its implementation into your simulation's
existing `.cpp`, merging includes/types/prototypes as appropriate. Do not compile
the template AND generated implementation as duplicate functions. Do not overwrite
the template with the exporter output.

No hardware record or numerical fitted model was supplied in this turn. Therefore
this package cannot contain your actual calibrated numbers. The template has
`fitted=false` and refuses to run until the exporter supplies a fitted model.
The numerical fixture in `tests/run_checks.py` is synthetic test data only.

## 3. Which parts of your tone code to remove or replace

For the particular modeled source and selected SENSOR axis:

| Old block | Action |
|---|---|
| `number_of_tones`, frequency/amplitude/phase arrays and `two_pi` | Remove from this accelerometer model |
| `sensor_time` and the sine-wave summation | Replace with the pulse scheduler |
| `white_noise_sigma * random_noise[1]` for this same source | Replace with the fitted persistent quiet-state calculation |
| Original sensor-to-platform rotation | Retain its physical convention, after checking it matches the MATLAB rotation |
| Other sensors' independent error sources | Retain as separate existing components |
| Other physical bias, delay, misalignment and scale-factor terms | Retain if they are not already represented by the fitted error model |
| Existing Gaussian generator routine | Reuse through the small normal-draw adapter below |
| Existing random-walk term | Assess separately; it is not automatically the same as this stationary background |

Remove only duplicate contributions for this modeled source. The presence of an
existing Gaussian RNG does not mean the correctly scaled/persistent background is
already present. The RNG supplies unit samples; the fitted model supplies their
scaling and correlation. Conversely, adding the old white-noise sample AND the
new fitted background for the same physical noise would double count it.

The pulse excursion can have a positive mean even after subtracting the QUIET
baseline. Do not subtract its full-signal mean, and do not add the full training
mean again. Add `m.baseline(j)` once. The example splits the baseline into `bias[]`
and the changing excursion into `noise[]` only for convenient bookkeeping.
The complete added acceleration is their sum.

## 4. Bridge to your existing `rn_norm_limits` routine

The supplied runtime takes a function pointer, `ImuNormalDraw`, whose callback
returns ONE fresh `N(0,1)` sample each time it is invoked. It does not implement a
second Gaussian generator. A conceptual bridge using your existing function is:

```cpp
// Put this helper below IMU_error(), with a prototype above it.
// 'seed' and rn_norm_limits are YOUR existing host objects/function.
// Use your host's declared integer/seed types if they differ from this example.
static double normal_from_my_sim(void*)
{
    int size = 3;
    double random_noise[3];
    rn_norm_limits(&seed, &size, &random_noise[0]);
    return random_noise[imu_axis_parameters.sensor_axis];
}
```

Bind it in the example inputs:

```cpp
imu_input.normal_draw = normal_from_my_sim;
imu_input.normal_context = nullptr;
```

If your RNG state lives in an object rather than globals, put its address in
`normal_context` and use that object inside the callback. This avoids assuming
what type your `seed` actually has.

**Check the generator's distribution.** The callback contract is untruncated,
zero-mean, unit-variance Gaussian draws with appropriate independence. The name
`rn_norm_limits` alone does not establish that contract. If it truncates, clips,
rescales or correlates the samples, the MATLAB Gaussian assumption will not be
reproduced exactly. Inspect its existing documentation/implementation and a quiet
trace. Do not multiply by the old RMS inside the bridge: the new model applies
the fitted sigma itself.

The callback is called once for stationary initialization, once per burn-in
sample, then once per NEW sensor tick. It is called during pulse intervals too,
while the quiet latent state advances. Repeated requests for the SAME tick use
the cached sample without new calls. The conceptual bridge above draws a fresh
three-element vector on each callback and uses one component; that is valid but
may use more host draws than the old implementation.

Do not implement the bridge by returning one fixed `random_noise[1]` repeatedly.
Initialization and burn-in require fresh independent samples on every callback.
If the old vector draw existed solely to feed the replaced source, replace that
call with this callback route. If other modeled sources still use it, retain
their necessary draws separately.

RNG algorithm reuse and RNG STATE reuse are separate decisions. Reusing a global
seed means this model's added calls, especially burn-in, advance the shared stream
and can change unrelated sources' realizations. If your host supports separate
seed state, use its same normal-generator routine with a dedicated model stream
for reproducible component isolation. This does not require a different RNG
algorithm. The callback/context interface supports either arrangement.

### Why an event RNG also appears

Gaussian samples drive the quiet amplitudes. The scheduler additionally needs
uniform random choices of event sign and catalog entry. A file-local
`std::mt19937` supplies those choices only; no second Gaussian noise is added.
It is seeded once per run through `event_seed`. If your sim requires its own
uniform-event RNG, replace those two event-selection draws with equivalent
independent host uniform choices, keeping the probability and pairing rules.
Do not apply a uniform CDF transform to clipped Gaussian values and assume the
result is uniform.

## 5. One selected sensor axis, then frame rotation

For physical sensor axis 2 / sensor Y, C++ uses index 1. Before rotation:

```cpp
model_noise_sensor_ug[0] = 0.0;
model_noise_sensor_ug[1] = sample.excursion_ug;
model_noise_sensor_ug[2] = 0.0;
```

The exported baseline is placed on that same sensor axis. The adapter does this
using `p.sensor_axis`, so selecting X/Y/Z in MATLAB sets the corresponding index
automatically. Changing the index without refitting would instead apply the
old axis's fitted behavior to a different physical axis.

One anomalous SENSOR axis can contribute to several PLATFORM components:

```text
model_platform = R_sensor_to_platform * model_sensor
```

Use the same numerical `R` as `cfg.R_sensor_to_PLT`. Your attached source uses
`frame_sens2plat_T`; its variable name is not enough to determine its physical
meaning. If `frame_sens2plat_T` is the actual sensor-to-platform map and equals
MATLAB's configured `R`, bind that matrix here. If `frame_sens2plat` itself is
already that map, use it without another transpose. A unit vector on sensor Y
should map to column Y of `R`; this is a useful direct check.

For comparison with MATLAB, first log the model-only SENSOR vector before adding
other components. Its unselected components must be exactly zero. After rotation
that zero pattern is generally no longer expected. Do not force the final
platform output to `[0,model,0]` unless the frames are aligned that way.

## 6. Where it enters your final measurement loop

Generate ONE scalar model sample just BEFORE the final XYZ loop, then build and
rotate the sensor vector once. Do not call the scheduler three times inside the
axis loop; that would advance three model samples for one sensor update.

The included `IMU_error()` shows the following sequence:

```cpp
// Once per sensor update, before the axis loop:
ImuAxisSample sample;
if (!imu_axis_sample(p, model_state, sensor_tick,
                     normal_from_my_sim, nullptr, sample)) {
    return; // Bind this failure to your host's actual error handling.
}

// Build selected-axis vector and rotate it here, as in the supplied source.

for (int ii = 0; ii < 3; ++ii) {
    noise[ii] = other_noise_terms[ii] + model_noise_platform_ft_s2[ii];
    bias[ii]  = other_bias_terms[ii]  + model_bias_platform_ft_s2[ii];
    // Add the appropriate acceleration or velocity-increment quantity below.
}
```

This snippet assumes the persistent state has already been reset and all terms
in those sums are sampled PLATFORM-frame acceleration errors in ft/s^2. It is
not suitable if `noise[]` is an RMS parameter that a later routine multiplies by
a Gaussian draw; in that case add the model AFTER that multiplication instead.
The complete template contains the reset, validation and rotation code omitted
from this compact excerpt.

### Acceleration-error interface

If your sim expects instantaneous acceleration error, add the modeled sample
in the required units. The adapter's default acceleration unit is ft/s^2:

```cpp
const double ug_to_ft_s2 = 1e-6 * 9.80665 / 0.3048;
accel_error_ft_s2[ii] += model_total_platform_ug[ii] * ug_to_ft_s2;
```

Do not multiply by `dt` at this interface if the sim performs the integration
later. For m/s^2 use `1e-6*9.80665`; for micro-g no conversion is necessary.

### Velocity-increment / internal accumulator interface

If the receiving internal accumulator expects an increment in velocity:

```cpp
const double model_delta_v_ft_s =
    model_total_platform_ug[ii] * (1e-6 * 9.80665 / 0.3048) * sensor_dt_s;

// Conceptual only: retained terms must already have compatible delta-v units.
delta_measurement[ii] = existing_delta_measurement_terms[ii]
                      + model_delta_v_ft_s;
```

If `delta_measurement[]` instead means an acceleration sample, that increment
formula is the wrong interface. Your omitted internal update determines which
case applies. The template exposes BOTH alternatives for inspection; connect only
one. Double injection would double the new model's contribution.

### Why your attached `delta_noise = current - previous` needs care

Your tone file has:

```cpp
delta_noise[ii] = noise[ii] - internal_data.noise[ii];
```

Applying that directly to the new instantaneous acceleration error produces
changes in acceleration, including large transition-edge pulses, rather than the
fitted acceleration waveform. Summing those differences telescopes to an
endpoint difference. It does not generally produce `integral(accel_error dt)`.

Keep unrelated existing differenced/cumulative-measurement error paths where
they belong. For this new source, inject acceleration before integration, or
inject the correctly scaled velocity increment into a delta-v accumulator. Do
not route this new acceleration through the old differencing line just because
its variable is also named `noise`.

Differencing can be correct when the modeled quantity itself is an error on an
already cumulative measurement. This fitted MATLAB model, however, represents
instantaneous acceleration error after the configured input decoding. If a host
requires differencing a cumulative error, first form that cumulative error with
the correct integral and persistent state. The incomplete template does not
establish your host's actual interface, so the adapter keeps this choice explicit.

## 7. Scheduler, resets and sample rate

The runtime picks a sign class using its fitted frequency or optional transition
row, chooses a template within that class, outputs its paired quiet gap, then
outputs its waveform. The next tuple is selected after the event completes.
With Markov transitions off and empirical class frequencies, every catalog
event has equal probability; template/gap pairing is preserved. The catalog
supports observed shapes and timing only, not unseen extreme events.

`static ImuAxisState model_state` persists inside the function. Reset it ONCE per
Monte Carlo run/regime with a new desired event seed and a properly initialized
host Gaussian stream. Resetting only the event seed cannot reproduce a run if
the host Gaussian stream has not also been reset.

The reset starts the latent quiet process with stationary variance. It also
runs the same discarded event warm-up as MATLAB (`10*max(gap+length)`). This is
a practical finite warm-up rule, not a proof of event-process stationarity. It
reduces dependence on starting every run at the beginning of a new quiet gap.
No tones or time-dependent phases are used.

After reset, supply sensor ticks `0,1,2,...` at EXACTLY the fitted `m.Fs`:

```cpp
imu_input.sensor_dt_s = 1.0 / imu_axis_parameters.Fs;
imu_input.sensor_tick = sensor_update_count;
```

The same tick returns the cached output. Backward ticks, skipped ticks or a
nonzero first tick are rejected, so state does not silently advance incorrectly.
A general dynamics solver callback may occur several times per sensor period;
use the discrete sensor tick, not an arbitrary solver-call counter.

Do not change only `dt` if you want a different update rate. `phi`, catalog
sample lengths and gaps all depend on the fitted sample rate. Reprocess/refit
at the intended rate or explicitly resample and revalidate the complete model.
The existing per-sample sigma already applies at that rate; do not multiply by
an old `sqrt(Fs)` or `1/sqrt(dt)` noise-density scaling again.

For multiple simulated IMU instances, one function-local static state is shared
by all calls. Move state into each instance's persistent internal data if the
host simulates more than one sensor concurrently. Threaded calls also require
per-instance RNG/state management. One process-local static is appropriate only
for the single-instance function structure illustrated here.

## 8. Run a C++ trace through your existing MATLAB checker

The included `Trace_IMU_Axis_Model.cpp` is an OFFLINE executable for statistical
comparison. It supplies a C++ standard-normal test source; your actual sim uses
its host callback. It outputs model-only SENSOR micro-g, including the quiet
baseline, with the same column names the existing checker expects.

After MATLAB has exported `IMU_Axis_Model.cpp` into this folder:

```sh
g++ -std=c++11 -O2 -Wall -Wextra -Werror -pedantic Trace_IMU_Axis_Model.cpp -o trace_imu
./trace_imu SAMPLE_COUNT 1234 > CPP_Trace.csv
```

Replace SAMPLE_COUNT with `size(IMU_Results.reference,1)`, expressed as an integer.
Place the resulting `CPP_Trace.csv` in the analysis suite's `cfg.outputFolder`,
then use the existing suite command:

```matlab
CPP_Comparison = Check_CPP_Output(cfg);
```

Alternatively, compare directly without moving the file:

```matlab
Tcpp = readtable(fullfile(portRoot,'CPP_Trace.csv'));
CPP_Comparison = imupulse.compareCpp(IMU_Results,Tcpp);
```

Run multiple seeds and compare equal-duration ensembles. MATLAB and C++ use
different random streams/distribution implementations, so their samples and
individual spike times are not expected to coincide, even for the same numeric
seed. The desired comparison is statistical: quiet variance/correlation,
amplitude probabilities, PSD, ACF, signed counts/rates, pulse areas/gaps, and
integrated velocity/position errors. C++ should reproduce the MATLAB MODEL;
that alone does not resolve a mismatch between the model and hardware.

Then log the equivalent model-only signal from your ACTUAL simulation to check
its host RNG, call rate, rotation and insertion point. A successful offline trace
does not establish that an unseen accumulator has the correct units.

The previous dataset discussion identified C4's low-lying held-out PSD and the
B6 quiet-innovation correlation as remaining checks. Porting should preserve
the identified model; it should not silently tune away those discrepancies.

## 9. What was verified for this port

Executed C++ checks are summarized in `Port_Validation.json`:

- C++11 compilation with strict warnings;
- exact scheduled gaps/waveform samples, including no extra background during events;
- latent background evolution through events and stationary initialization;
- stationary quiet variance and lag-one correlation on 300,000 samples;
- host normal-callback use, cached-tick behavior and clock rejection;
- finite/invalid parameter checks and warm-up phase handling;
- optional sign-transition behavior;
- exact inactive SENSOR zeros, rotation, unit conversion and retained unrelated errors;
- reproducibility for identical test seeds and variation for different seeds;
- CSV trace layout compatible with the existing MATLAB comparison function.

These tests use a populated SYNTHETIC export-layout fixture. MATLAB/Octave are
not installed here, so the new MATLAB exporter was reviewed but NOT executed.
It has an optional `tests/Test_Export_IMU_Axis.m` for your MATLAB installation.
Your actual exported coefficients, host RNG distribution and integrated sim
still require execution and comparison. No claim is made that synthetic test
numbers are your hardware calibration.

Optional developer checks (build output stays outside this folder):

```sh
python3 tests/run_checks.py /tmp/imu_axis_port_checks
```

Files supplied:

- `IMU_Axis_Integration_Template.cpp`: complete single-file runtime and example host bindings.
- `Export_IMU_Axis_To_CPP.m`: exporter for the existing fitted model struct.
- `Trace_IMU_Axis_Model.cpp`: offline trace executable.
- `tests/`: C++/exporter checks with clearly synthetic fixtures.
- `Port_Validation.json`: executed-check evidence.
- `README.md`: this implementation guide.

How code looks:
void IMU_error()
{
    // Remember background state and pulse position between calls.
    static ImuAxisState state;

    const ImuAxisParameters& p = imu_axis_parameters;

    // Reset ONCE at the beginning of each simulation run.
    if (imu_input.reset_model || !state.initialized)
    {
        if (!imu_axis_reset(
                p, state,
                imu_input.event_seed,
                imu_input.normal_draw,
                imu_input.normal_context))
            return;

        imu_input.reset_model = false;
    }

    // Generate ONE selected-axis sample per sensor update.
    ImuAxisSample sample;

    if (!imu_axis_sample(
            p, state,
            imu_input.sensor_tick,
            imu_input.normal_draw,
            imu_input.normal_context,
            sample))
        return;

    // Populate only the selected SENSOR axis.
    double model_noise_sensor_ug[3] = {};
    double model_bias_sensor_ug[3]  = {};

    model_noise_sensor_ug[p.sensor_axis] = sample.excursion_ug;
    model_bias_sensor_ug[p.sensor_axis]  = sample.quiet_baseline_ug;

    double noise[3];
    double bias[3];

    const double ug_to_ft_s2 = 1e-6 * 9.80665 / 0.3048;

    // Transform into the platform frame and combine errors.
    for (int ii = 0; ii < 3; ++ii)
    {
        double model_noise = 0.0;
        double model_bias  = 0.0;

        for (int jj = 0; jj < 3; ++jj)
        {
            const double r =
                imu_input.R_sensor_to_platform[ii][jj];

            model_noise += r * model_noise_sensor_ug[jj];
            model_bias  += r * model_bias_sensor_ug[jj];
        }

        noise[ii] = imu_input.other_noise_ft_s2[ii]
                  + model_noise * ug_to_ft_s2;

        bias[ii] = imu_input.other_bias_ft_s2[ii]
                 + model_bias * ug_to_ft_s2;

        // Instantaneous acceleration-error output:
        imu_output.acceleration_error_ft_s2[ii] =
            noise[ii] + bias[ii];

        // Alternative: velocity-increment output:
        imu_output.delta_velocity_error_ft_s[ii] =
            (noise[ii] + bias[ii]) * imu_input.sensor_dt_s;
    }
}