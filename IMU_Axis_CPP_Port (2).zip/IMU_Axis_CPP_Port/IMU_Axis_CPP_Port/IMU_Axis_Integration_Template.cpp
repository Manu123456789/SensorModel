// Single selected SENSOR axis: fitted Gauss-Markov quiet background + event catalog.
// Export with Export_IMU_Axis_To_CPP.m. Keep types, constants, prototypes, IMU_error,
// and helpers in ONE .cpp. No Gaussian RNG is implemented here: use the sim's.
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <random>

typedef double (*ImuNormalDraw)(void*); // Independent, untruncated N(0,1) samples.
struct ImuAxisParameters {
    bool fitted;
    int sensor_axis;                         // X=0, Y=1, Z=2
    double Fs, quiet_baseline_ug, quiet_sigma_ug, phi;
    std::size_t event_count, sample_count;
    const double* pulse_ug;                   // Baseline-subtracted measured samples
    const std::size_t *offset, *length, *gap;  // ROW offsets and sample counts
    const unsigned* sign;                    // Positive class=0, negative class=1
    double sign_probability[2], transition[2][2];
    bool use_markov;
    std::size_t burn_in_samples;
};
struct ImuAxisState {
    bool initialized=false, have_event=false, have_cache=false, cached_is_pulse=false;
    double quiet_ug=0, cached_excursion_ug=0;
    std::size_t event=0, gap_remaining=0, pulse_row=0;
    unsigned previous_sign=2;
    std::uint64_t cached_tick=0;
    std::mt19937 event_rng;                   // Event choices only, NOT Gaussian noise
};
struct ImuAxisSample {
    double excursion_ug=0, quiet_baseline_ug=0;
    bool is_pulse=false;
};

// BEGIN EXPORTED AXIS MODEL
// Placeholder only: the exporter replaces this block with YOUR fitted data.
static const double imu_pulse_samples[1]={0};
static const std::size_t imu_event_offset[1]={0}, imu_event_length[1]={1}, imu_event_gap[1]={1};
static const unsigned imu_event_sign[1]={0};
static const ImuAxisParameters imu_axis_parameters={
    false,1,200,0,0,0,1,1,imu_pulse_samples,
    imu_event_offset,imu_event_length,imu_event_gap,imu_event_sign,
    {1,0},{{1,0},{1,0}},false,0
};
// END EXPORTED AXIS MODEL

// Function prototypes.
static bool imu_axis_validate(const ImuAxisParameters&);
static bool imu_axis_reset(const ImuAxisParameters&,ImuAxisState&,std::uint32_t,ImuNormalDraw,void*);
static bool imu_axis_step(const ImuAxisParameters&,ImuAxisState&,ImuNormalDraw,void*);
static bool imu_axis_sample(const ImuAxisParameters&,ImuAxisState&,std::uint64_t,
                            ImuNormalDraw,void*,ImuAxisSample&);
static bool imu_axis_rotation_valid(const double (&)[3][3]);

// EXAMPLE BINDINGS: replace these with your sim's existing variables.
// The example compiles, but fitted=false prevents running uncalibrated data.
struct ImuHostInputs {
    bool reset_model=true;
    std::uint32_t event_seed=1234;
    std::uint64_t sensor_tick=0;              // 0,1,2,... at the fitted Fs
    double sensor_dt_s=0;                    // Must be 1/Fs
    ImuNormalDraw normal_draw=nullptr;        // Bridge to existing rn_norm_limits
    void* normal_context=nullptr;            // Optional host RNG state
    bool include_quiet_baseline=true;        // false only if SAME baseline already added
    double R_sensor_to_platform[3][3]={{1,0,0},{0,1,0},{0,0,1}};
    double other_noise_ft_s2[3]={0,0,0};      // Sampled PLATFORM errors, not RMS settings
    double other_bias_ft_s2[3]={0,0,0};       // Exclude duplicate fitted bias
};
enum class ImuPortStatus { Ok,NotFitted,BadParameters,BadDt,BadRotation,BadClockOrRng };
struct ImuHostOutputs {
    ImuPortStatus status=ImuPortStatus::NotFitted;
    double acceleration_error_ft_s2[3]={0,0,0};
    double delta_velocity_error_ft_s[3]={0,0,0};
    double model_only_sensor_ug[3]={0,0,0};
    double model_only_platform_ft_s2[3]={0,0,0};
    bool model_is_pulse=false;
};
static ImuHostInputs imu_input;
static ImuHostOutputs imu_output;

void IMU_error()
{
    static ImuAxisState model_state;           // Must persist across sensor updates
    const ImuAxisParameters& p=imu_axis_parameters;
    double model_noise_sensor_ug[3]={0,0,0}, model_bias_sensor_ug[3]={0,0,0};
    double model_noise_platform_ft_s2[3]={0,0,0}, model_bias_platform_ft_s2[3]={0,0,0};
    double noise[3], bias[3];
    imu_output=ImuHostOutputs();

    // ... existing delay, scale-factor, misalignment calculations ...
    if (!p.fitted) return;
    if (!std::isfinite(imu_input.sensor_dt_s) || imu_input.sensor_dt_s<=0 ||
        std::abs(imu_input.sensor_dt_s-1/p.Fs)>1e-8/p.Fs) {
        imu_output.status=ImuPortStatus::BadDt; return;
    }
    if (!imu_axis_rotation_valid(imu_input.R_sensor_to_platform)) {
        imu_output.status=ImuPortStatus::BadRotation; return;
    }
    if (imu_input.reset_model || !model_state.initialized) {
        if (!imu_axis_reset(p,model_state,imu_input.event_seed,
                            imu_input.normal_draw,imu_input.normal_context)) {
            imu_output.status=ImuPortStatus::BadParameters; return;
        }
        imu_input.reset_model=false;
    }

    // NEW: generate ONCE per sensor XYZ update, OUTSIDE the final axis loop.
    ImuAxisSample sample;
    if (!imu_axis_sample(p,model_state,imu_input.sensor_tick,
                         imu_input.normal_draw,imu_input.normal_context,sample)) {
        imu_output.status=ImuPortStatus::BadClockOrRng; return;
    }
    model_noise_sensor_ug[p.sensor_axis]=sample.excursion_ug;
    if (imu_input.include_quiet_baseline)
        model_bias_sensor_ug[p.sensor_axis]=sample.quiet_baseline_ug;
    imu_output.model_is_pulse=sample.is_pulse;

    // Same convention as MATLAB cfg.R_sensor_to_PLT: platform = R * sensor.
    // If your legacy code uses frame_sens2plat_T, use it here ONLY if it equals R.
    const double ug_to_ft_s2=1e-6*9.80665/0.3048;
    for (int ii=0;ii<3;++ii) {
        imu_output.model_only_sensor_ug[ii]=model_noise_sensor_ug[ii]+model_bias_sensor_ug[ii];
        for (int jj=0;jj<3;++jj) {
            const double r=imu_input.R_sensor_to_platform[ii][jj];
            model_noise_platform_ft_s2[ii]+=r*model_noise_sensor_ug[jj]*ug_to_ft_s2;
            model_bias_platform_ft_s2[ii]+=r*model_bias_sensor_ug[jj]*ug_to_ft_s2;
        }
        imu_output.model_only_platform_ft_s2[ii]=
            model_noise_platform_ft_s2[ii]+model_bias_platform_ft_s2[ii];
    }

    // YOUR FINAL LOOP. Bind the 'other' arrays to retained existing terms.
    // noise[]/bias[] HERE are INSTANTANEOUS acceleration errors in ft/s^2.
    for (int ii=0;ii<3;++ii) {
        noise[ii]=imu_input.other_noise_ft_s2[ii]+model_noise_platform_ft_s2[ii];
        bias[ii]=imu_input.other_bias_ft_s2[ii]+model_bias_platform_ft_s2[ii];
        imu_output.acceleration_error_ft_s2[ii]=noise[ii]+bias[ii];
        imu_output.delta_velocity_error_ft_s[ii]=
            (noise[ii]+bias[ii])*imu_input.sensor_dt_s;

        // Connect ONE output above to the matching host interface.
        // Acceleration interface: add acceleration_error_ft_s2[ii].
        // Delta-velocity interface: add delta_velocity_error_ft_s[ii].
        // Do NOT use current-minus-previous on this instantaneous accel model.
        // Keep unrelated legacy differenced-error terms in their existing path.
    }
    imu_output.status=ImuPortStatus::Ok;
}

// Helpers remain in the same .cpp, below your main function.
static bool imu_axis_validate(const ImuAxisParameters& p)
{
    if (!p.fitted || p.sensor_axis<0 || p.sensor_axis>2 || !std::isfinite(p.Fs) || p.Fs<=0 ||
        !std::isfinite(p.quiet_baseline_ug) || !std::isfinite(p.quiet_sigma_ug) || p.quiet_sigma_ug<0 ||
        !std::isfinite(p.phi) || p.phi<0 || p.phi>=1 || p.event_count==0 || p.sample_count==0 ||
        !p.pulse_ug || !p.offset || !p.length || !p.gap || !p.sign) return false;
    std::size_t counts[2]={0,0};
    for (std::size_t k=0;k<p.event_count;++k) {
        if (p.sign[k]>1 || p.length[k]==0 || p.offset[k]>=p.sample_count ||
            p.length[k]>p.sample_count-p.offset[k] ||
            p.gap[k]>std::numeric_limits<std::size_t>::max()-p.length[k]) return false;
        ++counts[p.sign[k]];
    }
    for (std::size_t k=0;k<p.sample_count;++k) if (!std::isfinite(p.pulse_ug[k])) return false;
    double sum=0;
    for (int i=0;i<2;++i) {
        const double prob=p.sign_probability[i];
        if (!std::isfinite(prob) || prob<0 || (prob>0 && counts[i]==0)) return false;
        sum+=prob; double row=0;
        for (int j=0;j<2;++j) {
            const double q=p.transition[i][j];
            if (!std::isfinite(q) || q<0 || (q>0 && counts[j]==0)) return false;
            row+=q;
        }
        if (std::abs(row-1)>1e-8) return false;
    }
    return std::abs(sum-1)<=1e-8;
}
static bool imu_axis_step(const ImuAxisParameters& p,ImuAxisState& s,
                          ImuNormalDraw normal,void* context)
{
    // Advance latent quiet state even during pulses. Consume one host normal.
    const double w=normal(context);
    if (!std::isfinite(w)) return false;
    s.quiet_ug=p.phi*s.quiet_ug+p.quiet_sigma_ug*std::sqrt(1-p.phi*p.phi)*w;
    if (!std::isfinite(s.quiet_ug)) return false;
    if (!s.have_event) {
        const double* probability=(p.use_markov && s.previous_sign<2) ?
            p.transition[s.previous_sign] : p.sign_probability;
        const double u=std::generate_canonical<double,53>(s.event_rng);
        const unsigned sign=(probability[1]<=0 || (probability[0]>0 && u<probability[0])) ? 0u : 1u;
        std::size_t count=0;
        for (std::size_t k=0;k<p.event_count;++k) if (p.sign[k]==sign) ++count;
        if (!count) return false;
        std::uniform_int_distribution<std::size_t> choose(0,count-1);
        const std::size_t pick=choose(s.event_rng); std::size_t seen=0;
        for (std::size_t k=0;k<p.event_count;++k) if (p.sign[k]==sign && seen++==pick) {
            s.event=k; break;
        }
        s.gap_remaining=p.gap[s.event]; s.pulse_row=0; s.have_event=true;
    }
    s.cached_is_pulse=(s.gap_remaining==0);
    if (s.gap_remaining) {
        s.cached_excursion_ug=s.quiet_ug; --s.gap_remaining;
    } else {
        s.cached_excursion_ug=p.pulse_ug[p.offset[s.event]+s.pulse_row];
        // Pulse replaces quiet output: templates already contain measured texture.
        if (++s.pulse_row==p.length[s.event]) {
            s.previous_sign=p.sign[s.event]; s.have_event=false;
        }
    }
    return true;
}
static bool imu_axis_reset(const ImuAxisParameters& p,ImuAxisState& s,std::uint32_t seed,
                           ImuNormalDraw normal,void* context)
{
    s=ImuAxisState();
    if (!imu_axis_validate(p) || !normal) return false;
    s.event_rng.seed(seed);
    const double w=normal(context); if (!std::isfinite(w)) return false;
    s.quiet_ug=p.quiet_sigma_ug*w;       // Stationary initialization, not a zero ramp
    for (std::size_t k=0;k<p.burn_in_samples;++k)
        if (!imu_axis_step(p,s,normal,context)) return false;
    s.initialized=true; return true;
}
static bool imu_axis_sample(const ImuAxisParameters& p,ImuAxisState& s,std::uint64_t tick,
                            ImuNormalDraw normal,void* context,ImuAxisSample& out)
{
    out=ImuAxisSample();
    if (!s.initialized || !normal) return false;
    if (s.have_cache && tick==s.cached_tick) { /* Return cache without drawing RNG. */ }
    else {
        if ((!s.have_cache && tick!=0) || (s.have_cache &&
            (s.cached_tick==std::numeric_limits<std::uint64_t>::max() || tick!=s.cached_tick+1))) return false;
        if (!imu_axis_step(p,s,normal,context)) { s.initialized=false; return false; }
        s.cached_tick=tick; s.have_cache=true;
    }
    out.excursion_ug=s.cached_excursion_ug; out.quiet_baseline_ug=p.quiet_baseline_ug;
    out.is_pulse=s.cached_is_pulse; return true;
}
static bool imu_axis_rotation_valid(const double (&R)[3][3])
{
    for (int i=0;i<3;++i) for (int j=0;j<3;++j) {
        double dot=0;
        for (int k=0;k<3;++k) {
            if (!std::isfinite(R[i][k]) || !std::isfinite(R[j][k])) return false;
            dot+=R[i][k]*R[j][k];
        }
        if (std::abs(dot-(i==j ? 1.0 : 0.0))>1e-6) return false;
    }
    const double det=R[0][0]*(R[1][1]*R[2][2]-R[1][2]*R[2][1])-
        R[0][1]*(R[1][0]*R[2][2]-R[1][2]*R[2][0])+
        R[0][2]*(R[1][0]*R[2][1]-R[1][1]*R[2][0]);
    return std::abs(det-1)<1e-6;
}
