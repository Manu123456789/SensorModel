"""NumPy/SciPy numerical reference plus actual C++ function fixtures.
Not MATLAB execution or hardware validation. Run from any working directory.
"""
import json
import subprocess
import tempfile
from pathlib import Path
import numpy as np
from scipy import signal
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "evidence"


def identify(x, fs, count=None):
    n = len(x); mean = x.mean(); F = np.fft.fft(x-mean)
    bins = np.arange(1, n//2+1)
    power = 2*np.abs(F[bins]/n)**2
    if n % 2 == 0:
        power[-1] = (F[n//2].real/n)**2
    rank = bins[np.argsort(-power, kind="stable")]
    if count is not None:
        bins = np.sort(rank[:count])
    C = F[bins]/n; amplitude = 2*np.abs(C); phase = np.angle(C)+np.pi/2
    if n % 2 == 0:
        nyq = bins == n//2; amplitude[nyq] = np.abs(C[nyq].real)
        phase[nyq] = np.where(C[nyq].real < 0, -np.pi/2, np.pi/2)
    phase = (phase+np.pi)%(2*np.pi)-np.pi
    return dict(n=n, fs=fs, mean=mean, bins=bins, f=bins*fs/n, a=amplitude, phase=phase, rank=rank, F=F)


def direct(p, offset=0):
    index=(np.arange(p["n"])+offset)%p["n"]
    y=np.full(p["n"],p["mean"])
    # Same sine convention as C++; bounded temporary memory.
    for start in range(0,len(p["f"]),64):
        sl=slice(start,start+64)
        y += (np.sin(2*np.pi*index[:,None]/p["fs"]*p["f"][sl]+p["phase"][sl])*p["a"][sl]).sum(axis=1)
    return y


def coeff_box(p, sigma=0.):
    values=lambda v:", ".join(format(float(x),".17g") for x in v) if len(v) else "0.0"
    return f"""// BEGIN_FOURIER_COEFFICIENTS
static const int modeled_sensor_axis=1;
static const double model_Fs_Hz={p['fs']:.17g};
static const std::uint64_t model_record_samples={p['n']};
static const int number_of_tones={len(p['f'])};
static const int tone_storage=number_of_tones>0?number_of_tones:1;
static const double fitted_error_mean_ug={p['mean']:.17g};
static const double white_noise_sigma={sigma:.17g};
static const double tone_frequency[tone_storage]={{{values(p['f'])}}};
static const double tone_amplitude[tone_storage]={{{values(p['a'])}}};
static const double tone_phase[tone_storage]={{{values(p['phase'])}}};
// END_FOURIER_COEFFICIENTS"""


def cpp_fixture(p, expected, sigma=0., shifted=False):
    # Replace ONLY the values a user would paste; execute the real function body.
    source=(ROOT/"cpp/Accel_Fourier_Error_Sensor.cpp").read_text()
    lo=source.index("// BEGIN_FOURIER_COEFFICIENTS"); hi=source.index("// END_FOURIER_COEFFICIENTS",lo)+len("// END_FOURIER_COEFFICIENTS")
    source=source[:lo]+coeff_box(p,sigma)+source[hi:]
    if shifted:
        source=source.replace("randomize_record_start = false", "randomize_record_start = true")
    host=(ROOT/"tests/test_integrated_host.cpp").read_text().split('#include "../cpp/Accel_Fourier_Error_Sensor.cpp"')[0]
    host += "\n#include <iomanip>\n"+source
    host += "\nstatic const double expected_record[]={"+", ".join(format(float(v),".17g") for v in expected)+"};\n"
    host += f"""\nstatic const double fixture_Fs={p['fs']:.17g};
static const std::uint64_t fixture_N={p['n']};
static const double fixture_sigma={sigma:.17g};
static const bool fixture_shifted={'true' if shifted else 'false'};
static const double fixture_scale=9.80665e-6/0.3048;
"""
    host += r'''
int main() {
    for(int i=0;i<3;++i)for(int j=0;j<3;++j)accel_frame_settings[i][j]=(i==j?1.:0.);
    seed=119; reset_model=true; use_test_accel_model=true;
    test_model_condition=true; test_model_start_time_s=0.; sensor_dt_s=1./fixture_Fs;
    const int count=fixture_sigma>0.?5000:3*int(fixture_N);
    std::vector<double> output;
    for(int k=0;k<count;++k) {
        sensor_tick=k;global_time=k*sensor_dt_s;error_sensor();
        output.push_back((accel_delta_output[1]-ideal_values[1])/(fixture_scale*sensor_dt_s));
    }
    double best=1e100,variance=0.,residualMean=0.;int bestShift=0;
    for(std::uint64_t shift=0;shift<(fixture_shifted?fixture_N:1);++shift) {
        double square=0.,mean=0.,maximum=0.;
        for(int k=0;k<count;++k) {
            const double e=output[k]-expected_record[(k+shift)%fixture_N];
            square+=e*e;mean+=e;maximum=std::max(maximum,std::abs(e));
        }
        if(square<best) {best=square;bestShift=int(shift);variance=square/count;residualMean=mean/count;}
    }
    const double rmse=std::sqrt(variance);
    if(fixture_sigma==0.) assert(rmse<2e-7);
    else {assert(std::abs(rmse/fixture_sigma-1.)<.06);assert(std::abs(residualMean)<.06);}
    std::cout<<std::setprecision(12)<<"{\"rmse_ug\":"<<rmse<<",\"shift_samples\":"<<bestShift<<"}\n";
}
'''
    with tempfile.TemporaryDirectory(prefix="imu_fourier_fixture_") as td:
        td=Path(td); cpp=td/"fixture.cpp"; exe=td/"fixture"; cpp.write_text(host)
        subprocess.run(["g++","-std=c++11","-O2","-Wno-unused-function",str(cpp),"-o",str(exe)],check=True,capture_output=True,text=True)
        result=subprocess.run([str(exe)],check=True,capture_output=True,text=True)
    return json.loads(result.stdout)


def main():
    OUT.mkdir(exist_ok=True); rng=np.random.default_rng(37); results={}; numeric=[]
    for n in [17,18,511,512]:
        x=.3+.2*rng.normal(size=n); x[n//3]=180.; x[2*n//3]=-120.
        if n%2==0:x+=-.7*(-1.)**np.arange(n)
        p=identify(x,200.); y=direct(p)
        error=float(np.max(np.abs(y-x))); assert error<1e-9
        assert np.max(np.abs(direct(p,7)-x[(np.arange(n)+7)%n]))<1e-9
        numeric.append(dict(samples=n,tones=len(p['f']),max_sine_error_ug=error))
        if n in [17,18]: results[f"cpp_full_{n}"]=cpp_fixture(p,x)
    for amplitude in [-3.,0.,3.]:
        x=2.+amplitude*(-1.)**np.arange(32);p=identify(x,200.)
        assert np.max(np.abs(direct(p)-x))<1e-11
    results['dc_signed_nyquist']='PASS'
    x=.3+.2*rng.normal(size=128);x[29]=180.;x[81]=-120.
    partial=identify(x,200.,8); expected=direct(partial)
    results['cpp_reduced']=cpp_fixture(partial,expected)
    results['cpp_common_shift']=cpp_fixture(partial,expected,shifted=True)
    results['cpp_optional_white']=cpp_fixture(partial,expected,sigma=.75)
    empty=identify(x,200.,0); results['cpp_offset_only']=cpp_fixture(empty,np.full(128,x.mean()))

    # A deliberately spiky measured-like synthetic fixture for numerical sweeps.
    fs=200.;n=2048;test=.3+.5*rng.normal(size=n);starts=[];cursor=25
    while cursor<n-10:
        height=rng.uniform(30,200)*(1 if rng.random()>.3 else -.7)
        if rng.random()<.12:test[cursor:cursor+3]=height*np.array([.25,1.,.25])
        else:test[cursor]=height
        starts.append(cursor);cursor+=int(rng.integers(7,90))
    full=identify(test,fs);yfull=direct(full);assert np.max(np.abs(yfull-test))<1e-9
    counts=[8,32,128,512,1024]; sweep=[]; histories=[]
    for K in counts:
        p=identify(test,fs,K);y=direct(p);histories.append(y)
        sweep.append(dict(tones=K,rmse_ug=float(np.sqrt(np.mean((y-test)**2))),max_error_ug=float(np.max(np.abs(y-test))),
                          min_ug=float(y.min()),max_ug=float(y.max())))
    assert all(sweep[i]['rmse_ug']>=sweep[i+1]['rmse_ug']-1e-10 for i in range(len(sweep)-1))
    results['explicit_sine_even_odd']=numeric
    results['spiky_synthetic_sweep']=sweep
    results['matlab_execution']='NOT RUN: MATLAB/Octave unavailable; Test_Fourier.m supplied'
    results['hardware_and_real_host']='NOT RUN: measured hardware record/full simulation source not supplied'
    (OUT/'Validation.json').write_text(json.dumps(results,indent=2))

    fig,ax=plt.subplots(2,3,figsize=(14,7.6),constrained_layout=True);t=np.arange(n)/fs;partial=histories[2]
    ax[0,0].plot(t,test,color='black',lw=.6,label='Synthetic measurement');ax[0,0].plot(t,partial,color='#b52d38',lw=.6,label='K=128')
    ax[0,0].set(title='Irregular one-sample spikes',xlabel='Time [s]',ylabel='Error [µg]');ax[0,0].legend(fontsize=8)
    peak=int(np.argmax(np.abs(test)));ind=np.arange(max(0,peak-8),min(n,peak+9))
    ax[0,1].plot(ind,test[ind],'ko-',label='Measured');ax[0,1].plot(ind,partial[ind],'o-',color='#b52d38',label='K=128')
    ax[0,1].plot(ind,yfull[ind],'+--',color='#277b75',label='All 1024')
    ax[0,1].set(title='Sharpness versus number of tones',xlabel='Sample',ylabel='Error [µg]');ax[0,1].legend(fontsize=8)
    ax[0,2].semilogy(counts,[max(v['rmse_ug'],1e-14) for v in sweep],'o-',color='#b52d38')
    ax[0,2].set(title='Aligned reconstruction error',xlabel='Number of tones K',ylabel='RMSE [µg]')
    edges=np.linspace(test.min()-.1,test.max()+.1,61)
    for y,col,label in [(test,'black','Measured'),(partial,'#b52d38','K=128'),(yfull,'#277b75','All tones')]:
        ax[1,0].hist(y,bins=edges,density=True,histtype='step',color=col,label=label)
        f,P=signal.welch(y-y.mean(),fs,nperseg=256);ax[1,1].loglog(f[1:],P[1:],color=col,label=label)
    ax[1,0].set(yscale='log',title='Amplitude histogram',xlabel='Error [µg]',ylabel='Density')
    ax[1,1].set(title='Welch PSD',xlabel='Frequency [Hz]',ylabel='µg²/Hz');ax[1,1].legend(fontsize=8)
    join=np.r_[np.arange(n-10,n),np.arange(10)];clock=np.arange(-10,10)/fs
    ax[1,2].plot(clock,test[join],'ko-',label='Measured circular join');ax[1,2].plot(clock,yfull[join],'+--',color='#277b75',label='Full Fourier')
    ax[1,2].axvline(0,color='gray',ls=':');ax[1,2].set(title='Period boundary (not smoothed)',xlabel='Time from restart [s]',ylabel='Error [µg]')
    for a in ax.flat:a.grid(alpha=.2)
    fig.suptitle('SYNTHETIC NUMERICAL PREVIEW · Python reference · not MATLAB or hardware validation',fontsize=13)
    fig.savefig(OUT/'Fourier_Synthetic_Preview.png',dpi=140)
    print(json.dumps(results,indent=2))


if __name__=='__main__':main()
