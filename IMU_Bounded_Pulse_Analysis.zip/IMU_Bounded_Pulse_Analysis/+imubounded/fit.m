function [m,info]=fit(x,fs,selected,c)
% Record-conditioned pulse generator. Counts are fixed over one fitted horizon.
m=struct('Fs',fs,'selectedMask',selected,'mode','recordMatched', ...
    'baseline',zeros(1,3),'threshold',Inf(1,3),'release',Inf(1,3), ...
    'bgMu',zeros(1,3),'bgSigma',zeros(1,3),'lower',zeros(1,3),'upper',zeros(1,3), ...
    'quietLower',zeros(1,3),'quietUpper',zeros(1,3), ...
    'releaseLower',zeros(1,3),'releaseUpper',zeros(1,3),'blockSamples',size(x,1), ...
    'pulseTypes',{cell(1,3)},'gapQuantiles',{cell(1,3)});
m.baseline(selected)=median(x(:,selected),1);
robust=1.4826*median(abs(x-m.baseline),1); robust=max(robust,eps(max(1,max(abs(x),[],1))));
m.threshold(selected)=c.detectSigma*robust(selected);
manual=selected & ~isnan(c.manualThreshold_ug); m.threshold(manual)=c.manualThreshold_ug(manual);
m.release(selected)=min(c.releaseSigma*robust(selected),.8*m.threshold(selected));
for iteration=1:10
    e=imubounded.detect(x,m); updated=m.baseline;
    for j=find(selected)
        quiet=~e.mask(:,j); assert(nnz(quiet)>=max(30,.1*size(x,1)),'Too little quiet data; inspect detection.');
        updated(j)=mean(x(quiet,j));
    end
    change=max(abs(updated(selected)-m.baseline(selected))./robust(selected)); m.baseline=updated;
    if change<1e-6, break; end
end
e=imubounded.detect(x,m);
info=struct('quietMask',~e.mask,'events',{imubounded.eventStats(x,m)}, ...
    'signCounts',zeros(3,2),'boundaryEvents',zeros(1,3),'fitExitFlags',zeros(1,3), ...
    'sourceActiveSamples',zeros(3,2),'modelActiveSamples',zeros(3,2), ...
    'compressionTV',zeros(1,3),'maxKnotError_ug',zeros(1,3), ...
    'knotLimitEvents',zeros(1,3),'types',{cell(1,3)});
for j=find(selected)
    quiet=~e.mask(:,j); assert(nnz(quiet)>=max(30,.1*size(x,1)),'Too few final quiet samples.');
    m.lower(j)=min(x(:,j)); m.upper(j)=max(x(:,j));
    assert(m.lower(j)<m.upper(j),'A flat channel cannot identify a pulse model.');
    margin=max(eps(abs(m.baseline(j))+m.threshold(j)),m.threshold(j)*1e-12);
    m.quietLower(j)=max(m.lower(j),m.baseline(j)-m.threshold(j)+margin);
    m.quietUpper(j)=min(m.upper(j),m.baseline(j)+m.threshold(j)-margin);
    releaseMargin=max(eps(abs(m.baseline(j))+m.release(j)),m.release(j)*1e-12);
    m.releaseLower(j)=max(m.lower(j),m.baseline(j)-m.release(j)+releaseMargin);
    m.releaseUpper(j)=min(m.upper(j),m.baseline(j)+m.release(j)-releaseMargin);
    [m.bgMu(j),m.bgSigma(j),info.fitExitFlags(j)]=imubounded.fitBoundedNormal( ...
        x(quiet,j),m.quietLower(j),m.quietUpper(j));
    a=e.start{j}; b=e.stop{j}; n=numel(a);
    assert(n>=c.minEvents,'Too few detected segments: inspect thresholds or extend row window.');
    info.boundaryEvents(j)=nnz(a==1 | b==size(x,1));
    peaks=zeros(n,1); widths=b-a+1; areas=zeros(n,1);
    for k=1:n
        z=x(a(k):b(k),j)-m.baseline(j); [~,p]=max(abs(z)); peaks(k)=z(p); areas(k)=sum(z);
    end
    [~,minRow]=min(x(:,j)); [~,maxRow]=max(x(:,j));
    extremeEvents=find((a<=minRow & b>=minRow) | (a<=maxRow & b>=maxRow));
    groups={};
    for signIndex=1:2
        ids=find((1+(peaks<0))==signIndex); info.signCounts(j,signIndex)=numel(ids);
        info.sourceActiveSamples(j,signIndex)=sum(widths(ids));
        [~,order]=sort(abs(peaks(ids))); ids=ids(order);
        protected=min(c.protectedTailEvents,numel(ids));
        reserved=unique([ids(end-protected+1:end); intersect(ids,extremeEvents)],'stable');
        rest=setdiff(ids,reserved,'stable');
        budget=max(1,c.maxPulseTypesPerSign-numel(reserved));
        if ~isempty(rest)
            boundaries=round(linspace(0,numel(rest),min(budget,numel(rest))+1));
            for k=1:numel(boundaries)-1, groups{end+1}=rest(boundaries(k)+1:boundaries(k+1)); end %#ok<AGROW>
        end
        for k=1:numel(reserved), groups{end+1}=reserved(k); end %#ok<AGROW>
    end
    types=struct('count',{},'width',{},'knotRow',{},'knotValue',{},'sign',{},'sourceEvent',{});
    reconstructed=[]; original=[];
    for k=1:numel(groups)
        ids=groups{k};
        features=[abs(peaks(ids)) widths(ids) abs(areas(ids))]; center=mean(features,1);
        scale=max(center,1e-12); score=sum(((features-center)./scale).^2,2);
        [~,which]=min(score); chosen=ids(which); values=x(a(chosen):b(chosen),j);
        [kr,kv,y,error,limited]=imubounded.compressPulse(values,m.baseline(j), ...
            m.threshold(j),m.release(j),c.maxKnotsPerPulse,c.knotTolerance_ug);
        types(k)=struct('count',numel(ids),'width',numel(values),'knotRow',kr, ...
            'knotValue',kv,'sign',sign(peaks(chosen)),'sourceEvent',chosen);
        s=1+(types(k).sign<0); info.modelActiveSamples(j,s)=info.modelActiveSamples(j,s)+numel(ids)*numel(y);
        info.maxKnotError_ug(j)=max(info.maxKnotError_ug(j),error);
        info.knotLimitEvents(j)=info.knotLimitEvents(j)+limited;
        reconstructed=[reconstructed;repmat(y,numel(ids),1)]; %#ok<AGROW>
        for event=ids(:)', original=[original;x(a(event):b(event),j)]; end %#ok<AGROW>
    end
    active=sum([types.count].*[types.width]);
    assert(size(x,1)-active>=n+1, ...
        'Compressed pulse widths leave too little quiet time. Increase maxPulseTypesPerSign.');
    m.pulseTypes{j}=types;
    gaps=[a(1)-1; a(2:end)-b(1:end-1)-1; size(x,1)-b(end)];
    m.gapQuantiles{j}=imubounded.percentile(max(gaps-1,0),linspace(0,100,c.gapQuantileCount))';
    edges=linspace(m.lower(j),m.upper(j),c.histogramBins+1); edges([1 end])=[-Inf Inf];
    originalP=histcounts(original,edges,'Normalization','probability');
    modelP=histcounts(reconstructed,edges,'Normalization','probability');
    info.compressionTV(j)=.5*sum(abs(originalP-modelP)); info.types{j}=types;
    if info.compressionTV(j)>c.compressionTVWarning || info.knotLimitEvents(j)>0
        warning('IMU:Compression','Axis %d pulse compression TV %.3g; knot-limited types %d. Increase type/knot budgets and inspect FitReview.', ...
            j,info.compressionTV(j),info.knotLimitEvents(j));
    end
end
end
