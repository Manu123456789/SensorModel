# Fit-derived pulse model in your existing IMU function

Your function can keep its current layout. The runtime uses plain functions and
one persistent local state structure. It has no heap allocation, parameter-file
loader, extra runtime header, or new shared-memory definitions.

## Export a single C++ file

1. Fit `PulseModel` with `IMU_Pulse_Noise_Validation.m`. Set `useDemo=false` in that
   script when fitting your actual sensor data. Inspect the validation plots.
2. Keep `Export_IMU_Pulse_To_CPP.m` and `IMU_Pulse_Integration_Template.cpp` together.
3. In MATLAB, call:

```matlab
Export_IMU_Pulse_To_CPP(PulseModel,'IMU_Pulse_Integration.cpp');
```

The result is ONE `.cpp` containing your fitted constants, helper prototypes,
`void IMU_error()`, and all helper implementations. Copy the marked additions to
your real function, or adapt the example bindings in the generated file. The
unexported template deliberately refuses to run; its zero arrays are not a model.
The exporter was reviewed but could not be executed here without MATLAB/Octave.

## Where each part goes

| Location in your current file | Additions |
|---|---|
| Includes / constants / declarations | Helper types, generated MATLAB constants, helper prototypes |
| Near start of `void IMU_error()` | `static ImuPulseState`, local model XYZ vectors, reset/clock checks |
| Immediately before your final XYZ loop | One joint XYZ sample, then one sensor-to-platform transform |
| Inside the existing XYZ loop | Add transformed model fluctuation to `noise[ii]`, model quiet offset to `bias[ii]` |
| Below the function | File-local helper implementations |

The `ImuExampleInputs` and `ImuExampleOutputs` structures are explicit adapter
bindings so the example compiles. Replace them with your existing variables;
they do not require changes to your simulator's shared-memory layout. Existing
`noise`/`bias` arrays need not be declared again if they already exist.

This assumes `noise[ii]` and `bias[ii]` hold current sampled acceleration errors
in micro-g. If `noise[ii]` is actually an RMS/noise-density PARAMETER used by an
RNG later, add the model's sampled fluctuation after that RNG instead. Never
use a signed generated pulse as a standard-deviation input or multiply it by
another random number / RMS value.

The essential insertion looks like this (error handling omitted here only):

```cpp
// Before the ii loop, once per SENSOR update:
imu_pulse_sample(parameters, pulse_state, sensor_tick, model_sensor_ug);
// Rotate the complete XYZ vector once; same matrix convention as MATLAB.

for (int ii=0; ii<3; ++ii) {
    noise[ii] = other_noise[ii] + model_fluctuation_platform_ug[ii];
    bias[ii]  = other_bias[ii]  + model_quiet_baseline_platform_ug[ii];
    // Continue your existing internal update with the appropriate units.
}
```

Do not call the generator three times inside that loop. Each generated sample
already contains all three axes; separate calls would destroy their event timing.

## Units, frame, and the accumulator

The inputs to this fitted model have already been converted from ft/s^2 into
sensor-frame acceleration error in micro-g by MATLAB. The generated fluctuations
and quiet baseline are both in micro-g. `R_sensor_to_platform` maps a SENSOR
column vector to a PLATFORM column vector, as in the processing script. Rotate
exactly once. If your legacy matrix actually maps the reverse direction, supply
its transpose at the binding point; the gyro variable's name alone is insufficient.

If `noise[ii]`/`bias[ii]` are micro-g acceleration-error inputs, use the displayed
addition directly. Your existing velocity/position integration then integrates
the changed acceleration. Do not additionally accumulate an acceleration error
just because the sensor routine is called repeatedly.

If the internal update consumes velocity increments in ft/s, the corresponding
quantity for one held sensor interval is:

```cpp
delta_velocity_error_ft_s[ii] = (noise[ii]+bias[ii])
                           * 1e-6 * 9.80665 / 0.3048 * sensor_dt_s;
```

For a cumulative velocity-error state, add THAT increment once per update. If the
simulation already integrates acceleration elsewhere, inject acceleration there
instead; do not inject both quantities. The scaffold calculates both output
forms but does not invent your omitted internal update. For a cumulative
position-error state, acceleration cannot be summed into it directly either.

Do not copy the gyro `current_noise - previous_noise` treatment automatically.
Differencing the acceleration produces pulses at changes and its accumulated sum
telescopes; it is not integration of acceleration into velocity. It can be correct
for a model defined on an already cumulative measurement with suitable units.
Your actual final update is needed to choose that interpretation definitively.

## Avoid counting the same error twice

- This replaces the old background-white-noise term for THIS same measured source.
  Keep independent sensor error sources, but remove the duplicated old RMS term.
- `baseline_ug` is the fitted QUIET baseline, added through `bias[ii]`. Pulse
  template deviations retain their nonzero average, even though they are routed
  through a variable named `noise`. Do not center them to zero.
- Remove the old overall mean bias for this same fitted process; that overall
  mean includes pulse occupancy and would count the pulse mean twice.
- Set `inject_quiet_baseline=false` only if the exact same quiet baseline is
  already supplied elsewhere, with the correct frame and units. This does not
  justify retaining a duplicate overall pulse-process mean.
- During a pulse the recorded joint template replaces the quiet Gaussian noise.
  It already contains event-time noise, so the code does not add it a second time.

## Clock, reset, and random numbers

- Supply `sensor_tick = 0,1,2,...` on the update clock at the exported `Fs`.
  `sensor_dt_s` must match `1/Fs`; there is no extra RMS or sample-rate scaling.
  Identify at the intended IMU update rate before export. Do not change `Fs` alone
  after export: the widths and gaps are measured in samples.
- Set `reset_model=true` once per new Monte Carlo run/regime, with the run seed.
  Reset both the pulse model and your existing accumulator through your usual
  simulation initialization. Initial quiet/event phase is randomized by the same
  burn-in length used by the MATLAB generator.
- Repeated reads of the same tick return the cached XYZ sample. A backward clock
  is rejected unless reset. Skipped ticks advance the generator, but the helper
  does not perform missing physical integration; integrate each sensor interval
  if accumulated trajectory error is required.
- Each sensor/simulation instance needs its own `ImuPulseState`. The local static
  example is for one instance; use instance-owned storage for parallel runs.
- The implementation has separate event and Gaussian RNG streams. Box-Muller
  produces zero-mean, unit-standard-deviation Gaussian input; the exported factor
  applies the quiet covariance. MATLAB and C++ use different RNGs, so expect
  matching distributions, not identical samples for the same integer seed.

The model preserves empirical template shape/width/sign/amplitude/gap tuples and
optional first-order event-class transitions. It does not extrapolate unseen
rare events or guarantee the exact same event count in every simulated record.

## Verification

The C++ tests exercise joint sample timing, positive/negative class transitions,
Gaussian covariance, replacement of noise during events, reset/seed behavior,
cached reads and skipped ticks, frame checks, and unit conversion:

```sh
g++ -std=c++11 -Wall -Wextra -Werror -pedantic test_imu_pulse.cpp -o test_imu_pulse
./test_imu_pulse
```

The test includes the scaffold for access to its file-local helpers; compile the
test file alone. The MATLAB exporter is a separate offline step. Real model
coefficients still have to come from your fitted `PulseModel`.
