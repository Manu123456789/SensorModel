function Test_Selected_Axes()
% Run from MATLAB: addpath('tests'); Test_Selected_Axes
% Meaningful selection, time, unit, integration and end-to-end smoke checks.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(root);
T=readtable(fullfile(root,'data','Sample_IMU_ft_s2.csv'));
c=imupulse.defaults(); c.makePlots=false; c.saveFigures=false; c.nRealizations=4;
for selected={'X','Y','Z'}
    c.selectedAxes=selected; d=imupulse.prepare(T,c); inactive=~d.mask;
    assert(all(all(d.y(:,inactive)==0)));
    corrupt=T; unselected=find(inactive);
    for j=unselected, corrupt.(c.axisColumns{j})=1e12*ones(height(T),1); end
    d2=imupulse.prepare(corrupt,c); assert(isequal(d.y,d2.y));
    m=imupulse.fit(d.y(1:16800,:),d.Fs,d.mask,c);
    s=RandStream('mt19937ar','Seed',1); x=imupulse.generate(m,3000,s);
    assert(all(all(x(:,inactive)==0)) && all(m.baseline(inactive)==0));
    assert(all(all(m.noiseFactor(inactive,:)==0)));
    % A table only needs the selected column, plus time.
    only=T(:,[{'Time'} c.axisColumns(d.mask)]);
    d3=imupulse.prepare(only,c); assert(isequal(d.y,d3.y));
end
c.selectedAxes={'X','Y','Z'}; d=imupulse.prepare(T,c); assert(all(d.mask));
% The cumulative sum decoder must recover later instantaneous samples.
accum=T; accum{:,2:4}=cumsum(T{:,2:4}*30.48,1);
c.inputMode='sample_sum_cm_s2'; dc=imupulse.prepare(accum,c);
assert(max(abs(dc.y(:)-reshape(d.y(2:end,:),[],1)))<1e-7);
% Constant 1 ug integrated for 1 second: velocity=g*1e-6, position=0.5*g*1e-6.
[v,p,t]=imupulse.integrate(ones(100,1),100);
assert(abs(v(end)-9.80665e-6)<1e-15 && abs(p(end)-.5*9.80665e-6)<1e-15 && t(end)==1);
% Equal mean/area can still produce different position errors through timing.
early=[ones(10,1);zeros(90,1)]; late=flipud(early);
[ve,pe]=imupulse.integrate(early,100); [vl,pl]=imupulse.integrate(late,100);
assert(abs(ve(end)-vl(end))<1e-15 && pe(end)>pl(end));
% Bad timestamps must fail instead of silently joining time gaps.
c.inputMode='instantaneous_ft_s2'; bad=T; bad.Time(1000:end)=bad.Time(1000:end)+.01;
failed=false; try, imupulse.prepare(bad,c); catch, failed=true; end; assert(failed);
c.selectedAxes={'Y'}; r=imupulse.analyze(T,c);
assert(all(all(r.Generated_sensor{:, [2 4]}==0)) && numel(r.model.templates)>=5);
fprintf('PASS: selected axes, omitted columns, exact zeros, units, clock, integrator, analysis.\n');
end
