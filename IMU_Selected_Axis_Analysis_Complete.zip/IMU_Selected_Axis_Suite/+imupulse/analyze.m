function r=analyze(T,c)
% Complete analysis. ALL user settings are supplied by main script IMU_Config.m.
assert(nargin==2,'Run IMU_Config.m to supply your workspace input and all settings.');
assert(exist('pwelch','file')==2,'Signal Processing Toolbox required (pwelch).');
validateattributes(c.nRealizations,{'numeric'},{'scalar','integer','>=',2});
assert(c.fitFraction>0 && c.fitFraction<1,'Use a separate validation suffix: 0<fitFraction<1.');
assert(c.detectSigma>c.releaseSigma && c.releaseSigma>0 && c.markovPrior>0);
validateattributes(c.histogramBins,{'numeric'},{'scalar','integer','>=',10});
assert(c.maxLag_s>0 && c.quietMaxLag_s>0 && c.welchWindow_s>0 && c.block_s>0 && c.zoom_s>0);
validateattributes(c.gmPhiMax,{'numeric'},{'scalar','real','finite','>=',0,'<',1});
assert(isscalar(c.gmPhiOverride) && (isnan(c.gmPhiOverride) || ...
    (isfinite(c.gmPhiOverride) && c.gmPhiOverride>=0 && c.gmPhiOverride<=c.gmPhiMax)));
d=imupulse.prepare(T,c); cut=floor(size(d.y,1)*c.fitFraction);
train=d.y(1:cut,:); ref=d.y(cut+1:end,:); n=size(ref,1); K=c.nRealizations;
assert(cut>=256 && n>=256,'Need >=256 samples in both training and validation.');
m=imupulse.fit(train,d.Fs,d.mask,c);
r=struct('cfg',c,'input',d,'model',m,'train',train,'reference',ref,'split',cut);
r.validationTime_s=(0:n-1)'/d.Fs;
r.trainEvents=imupulse.eventStats(train,m); r.refEvents=imupulse.eventStats(ref,m);
L=min(round(c.welchWindow_s*d.Fs),floor(n/4)); L=max(16,L);
window=hamming(L); nfft=max(256,2^nextpow2(L)); overlap=floor(L/2);
r.welch=struct('window',window,'overlap',overlap,'nfft',nfft,'L',L);
[r.referencePSD,r.frequency_Hz]=pwelch(ref-mean(ref,1),window,overlap,nfft,d.Fs);
r.lag=min(round(c.maxLag_s*d.Fs),n-2);
r.referenceACF=NaN(r.lag+1,3);
r.psd=zeros(size(r.referencePSD,1),3,K); r.acf=NaN(r.lag+1,3,K);
r.histogram=NaN(c.histogramBins,3,K); r.histEdges=cell(1,3);
r.histReference=NaN(c.histogramBins,3); r.histCenters=cell(1,3);
for j=find(d.mask)
    [counts,edges]=histcounts(ref(:,j),c.histogramBins);
    r.histCenters{j}=(edges(1:end-1)+edges(2:end))/2;
    edges([1 end])=[-Inf Inf]; r.histEdges{j}=edges;
    r.histReference(:,j)=counts(:)/n;
    r.referenceACF(:,j)=acf(ref(:,j),r.lag);
end
r.samples=zeros(n,3,K); r.events=cell(K,1);
[r.referenceMetrics,r.metricNames]=imupulse.metrics(ref,m);
r.metricValues=NaN(numel(r.metricNames),3,K);
r.v=zeros(n+1,3,K); r.p=r.v; r.gaussianV=r.v; r.gaussianP=r.v;
r.gaussianMean=mean(train,1); r.gaussianSigma=std(train,1,1);
stream=RandStream('mt19937ar','Seed',c.seed);
gaussianStream=RandStream('mt19937ar','Seed',mod(c.seed+98765,2^32));
r.crossReference=corrcoef(ref(:,d.mask)); r.crossMean=zeros(nnz(d.mask));
for k=1:K
    x=imupulse.generate(m,n,stream); r.samples(:,:,k)=x;
    r.events{k}=imupulse.eventStats(x,m);
    r.metricValues(:,:,k)=imupulse.metrics(x,m);
    r.psd(:,:,k)=pwelch(x-mean(x,1),window,overlap,nfft,d.Fs);
    for j=find(d.mask)
        r.acf(:,j,k)=acf(x(:,j),r.lag);
        r.histogram(:,j,k)=histcounts(x(:,j),r.histEdges{j},'Normalization','probability')';
    end
    [r.v(:,:,k),r.p(:,:,k),r.integrationTime_s]=imupulse.integrate(x,d.Fs);
    gaussian=randn(gaussianStream,n,3).*r.gaussianSigma+r.gaussianMean;
    gaussian(:,~d.mask)=0;
    [r.gaussianV(:,:,k),r.gaussianP(:,:,k)]=imupulse.integrate(gaussian,d.Fs);
    r.crossMean=r.crossMean+corrcoef(x(:,d.mask))/K;
end
[r.refV,r.refP]=imupulse.integrate(ref,d.Fs);
[r.meanV,r.meanP]=imupulse.integrate(repmat(r.gaussianMean,n,1),d.Fs);
axisNames={'X','Y','Z'}; rows={}; score={};
for j=find(d.mask)
    for k=1:numel(r.metricNames)
        v=reshape(r.metricValues(k,j,:),[],1); range=imupulse.percentile(v,[5 95]);
        observed=r.referenceMetrics(k,j);
        rows(end+1,:)={axisNames{j},r.metricNames{k},observed,mean(v),range(1),range(2), ...
            observed>=range(1)&&observed<=range(2)}; %#ok<AGROW>
    end
    meanPSD=mean(r.psd(:,j,:),3); keep=r.frequency_Hz>0;
    psdError=sqrt(mean((10*log10(max(meanPSD(keep),realmin)./ ...
        max(r.referencePSD(keep,j),realmin))).^2));
    acfError=sqrt(mean((mean(r.acf(:,j,:),3)-r.referenceACF(:,j)).^2));
    tv=.5*sum(abs(mean(r.histogram(:,j,:),3)-r.histReference(:,j)));
    score(end+1,:)={axisNames{j},psdError,acfError,tv}; %#ok<AGROW>
end
r.ValidationSummary=cell2table(rows,'VariableNames', ...
    {'Axis','Metric','HeldOut','ModelMean','ModelP05','ModelP95','InsideModelRange'});
r.SpectralSummary=cell2table(score,'VariableNames', ...
    {'Axis','PSD_LogRatio_RMSE_dB','ACF_RMSE','BinnedAmplitudeTV'});
r.GaussMarkovSummary=table(m.gmPhiRaw,m.gmPhi,m.gmTau_s,m.gmPairCount, ...
    'VariableNames',{'RawSharedPhi','FittedSharedPhi','RelaxationTime_s','ConsecutiveQuietPairs'});
r.HistogramSummary=table(d.histogramAxes',sum(isfinite(d.histValues_ft_s2(:,d.histMask)),1)', ...
    'VariableNames',{'SensorAxis','FiniteVisualizationSamples'});
r.Generated_sensor=array2table([r.validationTime_s r.samples(:,:,1)], ...
    'VariableNames',{'Time_s','ErrorX_ug','ErrorY_ug','ErrorZ_ug'});
r.Generated_PLT=array2table([r.validationTime_s r.samples(:,:,1)*c.R_sensor_to_PLT'], ...
    'VariableNames',r.Generated_sensor.Properties.VariableNames);
r.History_sensor=array2table([d.t d.y],'VariableNames',r.Generated_sensor.Properties.VariableNames);
r.Summary_PLT=platformSummary(ref,r.samples(:,:,1),m,c.R_sensor_to_PLT);
r.Readiness=checklist(r);
fprintf('Selected sensor axes: %s; Fs=%.9g Hz; eligible training events=%d.\n', ...
    strjoin(d.selectedAxes,','),d.Fs,numel(m.templates));
fprintf('Other sensor axes are EXACTLY ZERO in this model contribution.\n');
disp(r.ValidationSummary); disp(r.SpectralSummary); disp(r.GaussMarkovSummary); disp(r.Summary_PLT); disp(r.Readiness);
if c.makePlots, r.figures=imupulse.plotDiagnostics(r); else, r.figures=gobjects(0); end
end
function a=acf(x,lag)
x=x-mean(x); z=xcorr(x,lag,'biased'); z=z(lag+1:end);
if z(1)>eps(max(1,max(abs(x))))^2, a=z/z(1); else, a=NaN(size(z)); end
end
function t=platformSummary(ref,generated,m,R)
x=ref*R'; y=generated*R'; quiet=m.baseline*R';
t=table({'X';'Y';'Z'},quiet',mean(x,1)',std(x,1,1)',sqrt(mean(x.^2,1))', ...
    mean(y,1)',std(y,1,1)', ...
    'VariableNames',{'PlatformAxis','QuietBaseline_ug','HeldOutMean_ug', ...
    'HeldOutAC_RMS_ug','HeldOutTotalRMS_ug','GeneratedMean_ug','GeneratedAC_RMS_ug'});
end
function t=checklist(r)
count=numel(r.model.templates);
if r.cfg.isSynthetic, dataStatus='SYNTHETIC: not hardware validation'; else, dataStatus='Hardware label: verify provenance'; end
if count<30, eventStatus='REVIEW: fewer than 30 eligible events'; else, eventStatus='Inspect sign counts and tail coverage; 30 is only a heuristic'; end
if any(r.input.rail), railStatus='REVIEW: observed clipped readout only'; else, railStatus='No configured rail exceeded; unknown rails remain unknown'; end
t=table({'Input provenance';'Event evidence';'Clipping';'Detector labeling'; ...
    'Quiet Gaussian / first-order Gauss-Markov assumption';'Stationarity / regime coverage'; ...
    'Held-out diagnostics';'C++ statistical equivalence';'System-level consequences';'Release decision'}, ...
    {dataStatus;eventStatus;railStatus;'MANUAL REVIEW REQUIRED: Figure A'; ...
    'MANUAL REVIEW REQUIRED: Figure B';'MANUAL REVIEW REQUIRED: A4/A5 and other test runs'; ...
    'MANUAL REVIEW REQUIRED: C/D/E and summary tables'; ...
    'NOT YET CHECKED: run exported model, then Check_CPP_Output.m'; ...
    'NOT YET CHECKED: run your actual estimator/controller'; ...
    'CANDIDATE ONLY: no automatic approval'},'VariableNames',{'Check','Status'});
end
