function [m,info]=fit(x,fs,selected,c)
% Seven scalar parameters per axis. NO empirical waveform catalog is retained.
m=struct('Fs',fs,'selectedMask',selected,'shape',c.pulseShape,'baseline',zeros(1,3), ...
    'sigma',zeros(1,3),'threshold',Inf(1,3),'release',Inf(1,3), ...
    'meanGapSamples',NaN(1,3),'gapProbability',NaN(1,3),'logPeakMean',NaN(1,3), ...
    'logPeakStd',NaN(1,3),'negativeProbability',NaN(1,3),'widthSamples',zeros(1,3));
m.baseline(selected)=median(x(:,selected),1);
robust=1.4826*median(abs(x-m.baseline),1); robust=max(robust,eps(max(1,max(abs(x),[],1))));
m.threshold(selected)=c.detectSigma*robust(selected);
manual=selected & ~isnan(c.manualThreshold_ug); m.threshold(manual)=c.manualThreshold_ug(manual);
m.release(selected)=min(c.releaseSigma*robust(selected),.8*m.threshold(selected));
for iteration=1:10
    e=imusimple.detect(x,m); updated=m.baseline;
    for j=find(selected)
        quiet=~e.mask(:,j); assert(nnz(quiet)>=max(30,.1*size(x,1)),'Too few quiet samples; inspect detection.');
        updated(j)=mean(x(quiet,j));
    end
    change=max(abs(updated(selected)-m.baseline(selected))./robust(selected)); m.baseline=updated;
    if change<1e-6, break; end
end
e=imusimple.detect(x,m); info=struct('quietMask',~e.mask,'events',{imusimple.eventStats(x,m)});
for j=find(selected)
    quiet=info.quietMask(:,j); assert(nnz(quiet)>=max(30,.1*size(x,1)),'Too few final quiet samples.');
    m.sigma(j)=std(x(quiet,j),1); s=info.events{j};
    assert(numel(s.peak_ug)>=c.minEvents,'Too few complete events: inspect thresholds or use a longer row window.');
    gaps=s.gap_s(isfinite(s.gap_s))*fs;
    assert(numel(gaps)>=2 && all(gaps>=1),'Need at least two complete positive quiet gaps.');
    m.meanGapSamples(j)=mean(gaps); m.gapProbability(j)=1/m.meanGapSamples(j);
    logPeak=log(abs(s.peak_ug));
    m.logPeakMean(j)=mean(logPeak); m.logPeakStd(j)=std(logPeak,1);
    m.negativeProbability(j)=mean(s.peak_ug<0);
    m.widthSamples(j)=max(1,round(mean(s.width_s)*fs));
end
end
