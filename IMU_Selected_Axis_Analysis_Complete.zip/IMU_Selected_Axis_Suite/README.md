# Workspace IMU analysis: Gauss-Markov background and irregular spikes

Run **IMU_Config.m** after your sensor data has already been imported into the
MATLAB workspace. This is now the single main script and the single place to
change every user setting. It reads the existing timetable directly; it does
not reimport your large source file. A MATLAB table is also accepted.

Requirements: MATLAB R2021b+ and Signal Processing Toolbox for Welch PSD
estimation. No Statistics Toolbox is needed. The implementation was reviewed,
but MATLAB/Octave were not available for execution in the authoring environment.
See VALIDATION.md for the executed numerical-reference and C++ checks.

## 1. Set up your real data in one script

Edit these lines near the top of IMU_Config.m:

```matlab
cfg.workspaceVariable = 'MyImportedIMUTimetable';
cfg.columns.X = 'Actual_X_Channel';
cfg.columns.Y = 'Actual_Y_Channel';
cfg.columns.Z = 'Actual_Z_Channel';
cfg.selectedAxes = {'Y'};             % Fit/generate only this SENSOR axis
cfg.histogramAxes = {'X','Y','Z'};     % Display all XYZ distributions
cfg.sampleRate_Hz = 1000;             % Your actual acquisition rate
cfg.window_s = [0 120];               % Original-record elapsed seconds
```

Also set the input units, known physical baseline for the modeled axes, frame
rotation, and output folder in this same script. Run IMU_Config.m as a script;
do not call it as a configuration function. The result is IMU_Results and the
configuration remains in cfg. No clear command removes your imported workspace
data. MATLAB uses copy-on-write for the input assignment; the script does not
modify your timetable.

**Visualization and model selection are independent.** The default overview
shows X, Y and Z histograms of observed acceleration in ft/s². Those plots are
for inspection, not an input to identification. Detection, quiet fitting, pulse
catalogs and generated errors use only selectedAxes. Unmodeled SENSOR components
are exactly zero. To model X and Z, set selectedAxes={'X','Z'}. To visualize
only Y, set histogramAxes={'Y'}; only mapped channels in the union of those two
selections need exist. Map each read axis to a distinct channel. Names with
spaces/punctuation are supported using their exact MATLAB timetable names.

All settings are in the main script: acquisition rate, interval, physical
baseline, units, rails, selected/model axes, visualization axes, Gauss-Markov
fit options, event thresholds, event-class transitions, realization count,
plots, output folder, file generation and the synthetic example switch.
There is no defaults file to edit.

### Optional in-memory example

Set cfg.useSyntheticExample=true in the SAME script. Generate_Example_IMU.m
creates an example timetable in memory and configures its known zero-input
baseline and channel names. It does not read a data file. Example settings
demoSampleRate_Hz and demoDuration_s are also in the main script. Example output
is written to output_example; the real-data path uses cfg.outputFolder.
The example is synthetic, not an identified hardware model.

| File | Purpose |
|---|---|
| IMU_Config.m | Main editable settings AND execution script |
| Generate_Example_IMU.m | Optional in-memory timetable example |
| +imupulse/ | Preparation, fitting, generation, diagnostics, output functions |
| cpp/Export_IMU_Pulse_To_CPP.m | Write one C++ candidate with fitted constants |
| cpp/IMU_Pulse_Integration_Template.cpp | Persistent Gauss-Markov/event runtime and final-loop adapter |
| cpp/Check_Exported_Model.cpp | Produce a trace from an exported candidate |
| Check_CPP_Output.m | Call Check_CPP_Output(cfg) after producing that trace |
| tests/Test_IMU_Suite.m | MATLAB timetable/selection/row-step/fit regression checks |
| tests/verify_gm_reference.py | Optional numerical-reference and actual C++ fixture checks |
| VALIDATION.md | Verification coverage and limitations |
| GITHUB_SETUP.md | Source-control setup |

## 2. Row index and acquisition rate define ALL analysis steps

For original table row k, the derived elapsed step is (k-1)/Fs, where Fs is
cfg.sampleRate_Hz. Row 1 is at zero; at 1000 Hz, row 1001 is at one second.
The code does not inspect the timetable's row labels or use its metadata to
estimate the acquisition rate. That rule is unconditional: there is no alternate
clock mode, time-source option, or automatic rate inference.

The selected interval is interpreted on the original recording BEFORE values
are extracted. For [10 90] seconds at 1000 Hz, the instantaneous readout interval
is rows 10001 through 90001 inclusive. The code extracts only the mapped channels
and requested rows, rather than copying every channel of the large input.
IMU_Results.input.sourceRows preserves original row identities. If you already
cropped your workspace dataset, its first row is the origin for this analysis.

The last of N samples is at (N-1)/Fs; integrating N held constant samples spans
N/Fs seconds. All times in plots and output histories are derived quantities.
Uniform contiguous sampling is assumed from the acquisition rate: do not delete
interior rows while treating the remainder as consecutive sensor updates.

The default window is [0 120] seconds to limit a first analysis on a very large
record. Change it explicitly for your intended operating regime. At least
512 reconstructed samples must remain, with >=256 training and validation
samples each. The ensemble stores generated histories and integrated errors;
memory scales with validation sample count times nRealizations. Reduce the
interval or ensemble count for a first pass; importing the source again is not
required.

## 3. Units, physical baseline, histograms and frame mapping

The modeled error on selected axes is
error_ug=(measured_ms2-known_true_ms2)*1e6/9.80665.
For instantaneous ft/s², the conversion to m/s² is multiplication by 0.3048.
The known true input includes actual gravity projection and true motion. Do
not replace that baseline with the mean of the anomalous signal. Supply finite
baselineSensor_ms2 entries only for MODELED axes; unmodeled entries may be NaN.

The overview histograms show OBSERVED acceleration converted to ft/s², without
subtracting a fitted mean or requiring a physical baseline for unused axes.
Thus a gravity-sensitive axis can be centered near a gravity projection; that
is not automatically bias. Nonfinite visualization-only samples are omitted
per axis and counted in HistogramSummary. Nonfinite modeled samples cause an
error instead of silently compressing the acquisition sequence. Visualization-only
channels cannot trigger event detection, affect fit parameters or contribute to
the modeled platform error.

Supported inputMode settings:

| Mode | Meaning |
|---|---|
| instantaneous_ft_s2 | Acceleration; multiply by 0.3048 for m/s² |
| instantaneous_cm_s2 | Acceleration; multiply by 0.01 |
| instantaneous_ms2 | Acceleration already in m/s² |
| instantaneous_ug | Acceleration in µg; multiply by 9.80665e-6 |
| sample_sum_cm_s2 | Logger explicitly uses C(k)=C(k-1)+a_cm_s2(k); difference then multiply by 0.01 |
| integral_cm_s | Logger stores velocity in cm/s; difference, multiply by 0.01, divide by 1/Fs |

Cumulative decoding requires an observed preceding sample. It aligns to the
later original row and keeps only whole intervals within window_s, so the
first unidentifiable sample is not invented. These modes do not decode resets,
running averages, wraps or sliding sums. Confirm the logger rule and select a
reset-free interval first.

Configure known rail bounds in ORIGINAL channel units using railLimitsInput,
X/Y/Z rows and lower/upper columns. Bounds on selected model axes are checked.
With allowRailSamples=false, a rail violation stops the fit. With it true, the
model describes recorded clipping, not unobserved acceleration beyond the rail.
Infinite bounds disable checking, not establish absence of clipping.

The sample rate is native and fixed. To simulate at another sensor rate,
resample with a justified antialias strategy and refit; do not change the
runtime clock while keeping event sample counts or Gauss-Markov coefficients.

The column-vector rotation is platform=R_sensor_to_PLT*sensor. For N-by-3 row
histories, multiply by R_sensor_to_PLT'. Fit in the sensor frame, then rotate
synchronized generated errors. A single sensor-axis contribution can affect all
three platform axes after rotation. Other independent sensor errors must be
added separately. Rotate samples/covariance, not three RMS magnitudes as a
signed vector.

## 4. Model construction and why these techniques are used

The intended conceptual model on a selected axis is a quiet baseline plus
quiet noise and occasional shaped events. Random-event pulse signals are
studied as shot-noise/point-process models; Brémaud, Massoulié and Ridolfi [R1]
analyze their spectra for broad classes of driving point processes. That work
supports the general model family, not the claim that your accelerometer has
a particular physical failure or Poisson arrival law.

The complete model is **hybrid**, not wholly Gaussian. A stationary Gaussian
process has Gaussian marginal distributions; it cannot by itself reproduce
a separate asymmetric spike population. We use a first-order Gauss-Markov
(OU/AR(1)) quiet background plus empirical random events. The discrete quiet
recursion is

```
q[k] = phi*q[k-1] + sqrt(1-phi^2)*L*w[k]
w[k] ~ N(0,I),  L*L' = C_quiet,  0 <= phi < 1
tau = -1/(Fs*log(phi))   when phi > 0
```

The stationary quiet covariance is C_quiet, and its lag-l covariance is
phi^l*C_quiet. This follows by substituting the recursion into the covariance
equation; the innovation covariance is (1-phi²)*C_quiet. It is a sampled
first-order mean-reverting Gaussian model; see [R10] for related sensor modeling.
The white limiting case is phi=0. NoiseFactor in MATLAB/C++ factors STATIONARY
covariance, not innovation covariance. Both runtimes apply the square-root
innovation scaling once and initialize the latent state with that stationary
covariance.

Only consecutive quiet training pairs are used in the lag-one regression.
Each selected channel is scaled by its quiet standard deviation before pooling
the regression. One shared phi is used for multiple selected axes so that the
full quiet cross-covariance remains positive semidefinite under this simple
transition. Different axes are therefore assumed to have a common quiet
relaxation time. Inspect each axis's B3 and B6 before accepting that assumption.

The fitted coefficient is clipped to [0,gmPhiMax] for a stable, nonoscillatory
relaxation. gmPhiOverride optionally supplies a chosen coefficient in that
range. RawSharedPhi and FittedSharedPhi are both saved. Negative raw correlation,
a cap-limited estimate, multiple ACF decay scales or oscillations are evidence
against this simple quiet model, not evidence that clipping solved the physics.
Constant quiet signals have no informative correlation estimate and use zero.
At least 30 consecutive quiet pairs are required; this is a computational
minimum, not an adequacy guarantee.

The event-plus-background identification is:

1. Use only the training prefix, 70% by default. Reserve the remaining contiguous
   suffix for comparison. At least 256 samples are required in each section.
2. Estimate an initial quiet location using the median and a robust scale
   `1.4826 * median(abs(x - median(x)))`. Scaled MAD is a normal-consistent robust
   scale estimate [R2]. It helps when occasional large pulses would inflate
   ordinary standard deviation. It is not a reliable quiet estimate when a
   high state dominates the record; inspect the detector in that case.
3. Start an event when any selected axis crosses its detection threshold.
   Keep it active until all selected axes return inside their lower release
   thresholds. Defaults are 5 robust-sigma for detection and 2 for release.
   Hysteresis reduces rapid threshold chatter. These multipliers are engineering
   defaults, not research-established universal values or formal false-alarm
   probabilities. Manual thresholds are supported per axis in µg.
4. Update the quiet mean using non-event training samples. Estimate their
   population covariance and fit the quiet Gauss-Markov transition from adjacent pairs.
   Unselected rows of the factor are forced to zero. A singular covariance
   with only one selected axis is intentional, not an error.
5. Save each complete joint event as its actual XYZ waveform minus the quiet
   baseline, together with its immediately preceding quiet gap. Exclude events
   touching record boundaries and events without an observed preceding event:
   those preceding gaps can be left-censored. At least five eligible events
   are required to run; this is a computational minimum, not sufficient evidence
   for rare-event prediction.
6. For a new realization, select an event/gap tuple empirically and generate
   a fresh stationary Gauss-Markov latent background across all samples. **Overwrite** event
   samples with the recorded waveform plus quiet baseline. Event templates
   already contain event-time measurement noise; adding fresh Gaussian noise
   on top would double-count that component.
7. By default, events are drawn independently by class frequency and uniformly
   within class. Class is dominant normalized axis/sign: X+, X-, Y+, Y-, Z+, Z-.
   Optional first-order class transitions use observed counts smoothed toward
   the empirical class frequencies. This can retain first-order sign/axis
   tendencies, but not arbitrary burst history or slow regime dependence.

The latent background continues through event intervals but is not added to the
observed event templates. This avoids double-counting their recorded background
noise. The first quiet sample after a pulse comes from the continuing latent
process; event/quiet boundary coupling is approximate and should be checked.

8. Discard ten times the longest observed gap-plus-event duration before keeping
   output. This is a finite burn-in heuristic shared by MATLAB and C++; it is
   not a proof of stationary EVENT initialization, especially for slowly mixing
   Markov models. Check longer burns or explicit startup behavior if relevant.

This is not sampling amplitudes uniformly between extrema, nor drawing each
sample independently from the histogram. Pairing gap and waveform retains
their observed within-event relationships. Joint templates retain simultaneous
selected-axis behavior. The bootstrap cannot create an unobserved pulse shape,
unseen tail amplitude, much longer quiet gap, or genuine new operating regime.
Long generated runs will reuse recorded event waveforms. That is a deliberate
first-model limitation, not a new physical signal synthesis result.

No overall mean is subtracted from generated histories or histograms. Quiet
baseline and total mean differ when pulses preferentially have one sign. The
pulse part, although called `noise` in the C++ binding, can have nonzero mean.
PSD/FFT/ACF remove each analyzed record's mean **for those diagnostics only**.
Mean and total RMS remain available separately in the output tables.

## 5. How to interpret the diagnostic figures

The H overview contains one histogram per visualization axis (three by default).
Each selected MODEL axis has A/B/C/D/E figures with 6, 6, 6, 6 and 4 tiles. With multiple
selected axes, one optional four-tile F figure adds cross-axis checks. No tiled
figure contains more than six plots. Figure files are saved as PNG and editable
MATLAB FIG when enabled.

The interpretations below are engineering guidance conditional on this model,
not a diagnosis of your instrument. A visually plausible plot is one check,
not independent proof of fidelity.

### Figure H — observed XYZ distributions (visualization only)

Each tile summarizes one mapped sensor's acceleration over the chosen interval.
The horizontal unit is ft/s², the vertical quantity is probability per bin; each
axis uses its own finite range. A central peak represents commonly occupied
levels. A long positive tail suggests infrequent high readouts; a separate
peak suggests another appreciably occupied level. Neither establishes a
physical fault or reveals dwell durations. Known rail pileups may reflect
clipping; gravity/motion can shift centers. Repeat with reasonable bin counts
and inspect the selected-axis time plots before interpreting apparent modes.
HistogramSummary records finite visualization sample counts. These H plots
do not determine which channels get modeled; selectedAxes alone does that.

### Figure A — input, selection and event detection

**A1: selected error and detected events.** Gray is the recorded error after
the known physical baseline is removed. Red is the union of detected event
intervals. The dotted horizontal line is the fitted quiet baseline; the vertical
line separates training and validation. For one axis, red should cover the
excursions you intend to model. With several axes, an interval can be red on an
axis because another selected axis triggered the joint event. If red covers
nearly the entire record, a quiet-plus-brief-pulse model or its thresholds may
be inappropriate. If obvious excursions remain gray, lower the detection
threshold carefully. A clipped flat top describes the recorder limit, not the
physical peak. A sudden change near the split indicates potentially different
operating regimes, not necessarily a fitting error.

**A2: threshold zoom.** Shows the first `cfg.zoom_s` seconds, including both
positive/negative onset and release levels. Blue dashed lines start events;
green dotted lines release them. Expect a clear onset and a continuous red
event until return toward the quiet floor. Repeated short red fragments along
a single decaying pulse indicate threshold chatter or a release threshold that
is too restrictive. Very long red tails can mean the release level is too
tight relative to background variation. Raise or lower thresholds with reference
to the actual waveform and repeat the analysis; do not tune them solely to
make generated and test statistics agree. If the first window has no events,
increase `zoom_s` or inspect the saved editable figure around another event.

**A3: train/held-out amplitude histogram.** The vertical scale is logarithmic
probability per bin, so small tail occupancies are visible. The two intervals
use common bins and probabilities, not raw counts. A large quiet peak plus a
long positive tail supports a quiet-plus-positive-excursion description. A
second separated peak can indicate appreciable occupancy at another level;
it does not prove two Gaussian states or identify switching times. A narrow
pileup at a known limit suggests recorded clipping; repeated discrete levels
may also reflect quantization. The time history is needed to distinguish these.
Try several reasonable bin counts: an apparent mode that disappears immediately
with a small bin change is weak evidence. NIST discusses histograms and bimodal
mixtures as exploratory tools [R3, R4].

For this suite, a matching histogram alone is insufficient. Permuting the
record preserves its histogram and total mean but changes pulse timing and
usually its autocorrelation. A quieter validation histogram may simply reflect
fewer events in a finite suffix; compare rates and ensemble variation too.

**A4: mean by nonoverlapping time block.** Each point is the mean error over
one block (`block_s`, default 10 s); the final partial block is retained. This
is a regime/stationarity diagnostic, not a moving-average filter used to fit
the model. Some scatter is expected because pulse counts and areas vary.
A sustained trend or step can mean changing bias, pulse occupancy or true input.
Choose a stationary interval, include operating-condition dependence, or fit
separate regimes when justified. Do not claim temperature dependence without
temperature data. Compare the block duration with typical event gaps: blocks
with only one event give naturally noisy means.

**A5: joint-event start rate by block.** Counts event starts and divides by
actual block duration. It is a union-event rate shared by selected axes, not
an additional per-axis peak count. An event crossing a block boundary is
assigned by its start. Random scatter is normal; long quiet stretches followed
by many events suggest clustering or a regime change the IID tuple model may
miss. Repeated near-regular timing suggests a jittered-period model rather than
assuming memoryless arrivals. This plot does not establish that timing is
Poisson, and the implementation makes no such assumption.

**A6: original row to elapsed-step mapping.** The horizontal axis shows
original row number; the vertical axis shows elapsed seconds from the selected
window's start. Its slope is exactly 1/Fs. A later window retains its original
row identities rather than relabeling the source recording. This is a mapping
check under the configured acquisition rate, not a measurement of clock jitter.

### Figure B — Gaussian marginal / Gauss-Markov temporal checks

These plots use training quiet samples after subtracting the quiet baseline,
not the full pulse-contaminated signal. Because the detector selects quiet
samples using thresholds, some truncation/selection effects are unavoidable.
They are checks of an approximation, not formal normality/independence tests.

**B1: quiet histogram with Gaussian density.** Histogram area is normalized to
one; the red curve has fitted quiet variance. Expect a roughly symmetric
central distribution near zero. Heavy shoulders, asymmetry or extra modes
suggest remaining small events, a changing baseline, quantization, or a
non-Gaussian quiet process. These are possibilities to investigate, not causes
established by the plot. Density height has units 1/µg and can exceed one;
it is not a bin probability. An apparently good bell shape says nothing about
temporal whiteness. If almost all quiet samples are identical, estimated
variance and Gaussian overlays are uninformative.

**B2: Gaussian Q-Q plot.** Empirical quiet quantiles are plotted against the
quantiles of the fitted Gaussian. A nearly diagonal relationship supports
the marginal approximation. Tail deviations indicate mismatched tail weight;
asymmetric bending indicates skewness. Detector truncation can bend the most
extreme quiet quantiles even when the underlying background is Gaussian.
Interpret this alongside A2, not as an independent hypothesis test. The code
uses `erfinv` and empirical interpolated percentiles, avoiding a Statistics
Toolbox dependency.

**B3: masked quiet autocorrelation and fitted exponential.** Pairs retain
their original row separation, and both endpoints must be quiet. Products are
divided by eligible-pair counts and normalized at zero lag; lags with fewer
than 30 pairs are hidden. The red line is phi^lag. Positive persistence is
expected for the fitted Gauss-Markov model, rather than treating every off-zero
correlation as a failure. A slow mismatch, second decay scale, negative lobe
or oscillation suggests the first-order model is inadequate. Threshold-based
quiet selection can distort empirical correlations, especially near event
tails; these are descriptive checks, not formal confidence bounds [R5].

**B4: adjacent quiet-sample scatter.** Plots successive quiet excursions,
using only adjacent original samples. Positive phi should give an elongated
diagonal Gaussian cloud. A round cloud is consistent with a small phi;
anti-diagonal structure cannot be represented by the imposed positive OU
relaxation. Multiple clouds suggest extra states/regimes. Display subsampling
limits crowding; no serial independence is inferred just from a round cloud.

**B5: standardized Gauss-Markov innovations.** For adjacent quiet samples,
the displayed residual is
(z[k]-phi*z[k-1])/(sigma_quiet*sqrt(1-phi²)).
A roughly zero-centered, unit-variance Gaussian distribution supports the
innovation approximation. Heavy tails, skewness, multiple modes or the wrong
spread indicate unmodeled behavior or imperfect event separation. The red curve
is N(0,1). Quiet selection can truncate tails, so do not interpret visual
agreement as a formal normality test. Near-zero quiet variance gives an
uninformative standardized diagnostic.

**B6: innovation autocorrelation.** Keeps the original gaps and uses only
eligible pairs of innovations. Unlike the quiet process itself, the driving
innovations should have little remaining serial dependence. Persistent
nonzero-lag structure indicates that the first-order transition did not explain
the background's memory. A matching B1 histogram with a mismatching B6 ACF is
not sufficient validation. Kasdin [R8] is relevant if a higher-order colored
background is needed; that extension would require changing both runtimes.

### Figure C — distribution, spectrum and full-signal correlation

The reference here is the held-out suffix. Each generated record has exactly
that sample count and duration. Do not compare its counts against all 120
seconds of the synthetic input. Each spectral comparison uses the same rate,
window, record length and frequency grid on both sides.

**C1: held-out time history.** Shows the actual selected error in the validation
interval, with its original quiet offset and pulse mean retained. Look for the
sign balance, shapes, pulse durations, gaps and clustering you care about.
Use this to interpret aggregate statistics. It is not part of parameter fitting.

**C2: one new realization.** Should have plausible behavior of the same kind,
but not pulses at the same times as C1. Pointwise RMSE or waveform correlation
between these two independent realizations is therefore not an appropriate
main validation criterion. Obvious repeated unusual shapes reveal template
reuse; more diverse training data or a justified parametric pulse model may
be needed for long simulations. A new model record can have more or fewer
events than C1 even when the model is adequate.

**C3: amplitude probabilities with ensemble range.** Black is the held-out
probability per bin. Red is the mean across new model records; shading spans
the pointwise 5th–95th percentiles across those records. Bins are defined from
the reference, but outer bins collect all model values beyond the reference
extremes; those tail masses are displayed at the outer finite bin centers.
A central mismatch points toward quiet spread, offset or occupancy errors.
A tail mismatch points toward pulse amplitudes/durations/occupancy. The saved
binned total-variation distance is `0.5 * sum(abs(p_test - p_model_mean))`.
It is bin-dependent and can conceal differences within a bin.

The band is a conditional simulation range with fitted parameters held fixed.
It is **not** a confidence interval on model parameters, not simultaneous
coverage across bins, and not proof that every future record will fall inside.
Fifty realizations make a useful first plot; substantially more help stabilize
its outer quantiles. Increasing realizations does not compensate for a short
hardware training record.

**C4: AC Welch PSD.** Each record's overall mean is removed for this diagnostic
only. A Hamming window of approximately `welchWindow_s` seconds is used, capped
at one quarter of the validation record, with 50% overlap. FFT length is a
power of two at least 256. PSD units are µg²/Hz. Black is reference; red is the
mean PSD in linear units across realizations, with pointwise simulation ranges.
Welch's overlapping-segment estimate is documented by MathWorks [R6].

The engineering purpose is to check whether model fluctuation power lands in
similar frequency regions. Excess low-frequency power can accompany long pulses,
uneven occupancy or drift. Broad high-frequency content is compatible with
sharp edges, short pulses or white noise; it does not establish a square wave.
Persistent narrow peaks suggest repeatable tones/timing that the empirical IID
model may not preserve. Compare repeated records before labeling a single PSD
wiggle a physical tone. A shorter segment gives coarser frequency discrimination;
zero padding does not restore information absent from the segment.

`PSD_LogRatio_RMSE_dB` is the RMS of `10*log10(model_mean_PSD / reference_PSD)`
over positive-frequency bins. It summarizes disagreement, but is sensitive
to band choice, estimator variability and near-zero reference power. There is
no universal acceptable dB threshold. Define a band and budget relevant to your
estimator/controller if you need an acceptance requirement. Integrated AC PSD
relates to fluctuating variance, not the signed mean or total RMS.

**C5: single-record amplitude FFT.** Black and red compare the reference and
one model record after mean removal, using a periodic Hann window, normalization
by the window sum, and correct one-sided doubling except DC/Nyquist. Units are
µg, not µg/√Hz or PSD units. MathWorks documents `fft` and one-sided spectra
[R7]. The window correction is appropriate to interpreting coherent tones;
random broadband-bin heights still depend on record length and window.

Overlapping, jagged curves are expected for different random realizations. Do
not force individual random FFT peaks to coincide. A train of sharp irregular
pulses spreads energy broadly; synthesizing many FFT sinusoids is not necessary
to reproduce it. If an isolated peak persists across independent records and
matters dynamically, test an added explicit tone or a timing mechanism. Fitting
the FFT magnitude alone would not retain pulse timing or phase relationships.

**C6: full-signal normalized autocorrelation.** Each record is centered for
this diagnostic, and a biased sample autocorrelation is normalized by its
zero-lag value. This includes pulse structure; it is different from B3's quiet
ACF. Zero lag is one for a nonconstant signal. The width of the initial decay
reflects temporal persistence; later peaks can reflect repeated timing or
oscillation. A model that matches amplitude histograms but loses this structure
is missing time dependence. `ACF_RMSE` compares reference with ensemble mean
over the plotted lag range, so its interpretation depends on `maxLag_s`.
Shading again shows pointwise conditional simulation variation, not a formal
multiple-lag hypothesis test. Undefined constant-signal ACFs are NaN, not proof
of a successful fit.

### Figure D — event statistics, including pulse area

Events are detected with the training-fitted thresholds on both reference and
generated records. Only complete events enter these statistics. For multiple
selected axes, an event is the union interval; an axis contributes an event
statistic only if its own absolute peak crosses its detection level within
that interval. Width and gaps remain joint-event quantities. This avoids
claiming that an axis had a large event merely because another axis triggered.

The model curves pool complete events from all generated records; records with
more events contribute more samples. These are descriptive CDFs, **not CDF
confidence bands** or independent samples for a naive significance test. No
events on a side/axis means insufficient evidence, not perfect matching.

**D1: signed peak CDF.** For each eligible event and axis, choose the excursion
with largest absolute magnitude and keep its sign. A sharp rise at negative
values reflects the share of negative-dominant events. A model shifted toward
larger positive values can overstate velocity increments even if its quiet
histogram matches. If an event is bipolar, this statistic records only its
dominant signed peak; inspect its waveform and area too. A CDF's maximum
observed value is not a justified physical upper bound.

**D2: event-duration CDF.** Width is number of active samples divided by Fs,
not end sample instant minus start sample instant. A one-sample event therefore has
duration 1/Fs. A model shifted to larger widths retains anomalous acceleration
longer. Stair steps near multiples of 1/Fs are normal sampling granularity.
An unexpected pileup of minimum-width events may indicate isolated digital
spikes, unresolved physical pulses or detector chatter. Check A2 before
inventing a new physical pulse population.

**D3: preceding-quiet-gap CDF.** Counts quiet samples between the previous
event and the current one. A current event without an observed predecessor has
an unknown/censored preceding gap and is excluded from this feature. Too many
short model gaps can create overly frequent bursts. Very long gaps beyond
training support cannot be generated by this bootstrap. Gaps are drawn with
their following waveform, preserving measured gap-to-current-event association.
No exponential-gap assumption is imposed.

**D4: event-start-interval CDF.** Measures time between successive complete
detected event starts in each record. This includes prior pulse duration plus
the following quiet gap and is not identical to D3. A narrow concentration
around a period suggests near-periodic timing; a broad spread suggests more
variable recurrence. Matching D3 does not guarantee matching D4 when the model
fails to reproduce dependencies between successive events. Significant mismatch
here can motivate a jittered-period, renewal-history, or condition-dependent
model rather than simply more FFT tones.

**D5: signed pulse-area CDF.** Sums event excursion above quiet baseline times
dt. Its units are µg·s; multiplying by 9.80665e-6 converts each area to its
event velocity-error contribution in m/s. Area captures amplitude AND duration
AND sign. This is often more directly relevant to an integrating IMU than
matching maximum amplitude alone. A bipolar event can have a large peak and
small net area. Thresholding truncates low tails, so include boundary/threshold
sensitivity in your interpretation. This is not the integral of the whole
record or the baseline contribution.

**D6: gap versus absolute peak scatter.** Checks whether large pulses tend to
follow longer or shorter quiet intervals. Gray/black reference points are
compared with pooled red model events (display subsampled for readability).
Pairing gaps with templates preserves relationships within training tuples;
the held-out relation can differ through sampling variability or a regime
change. A matching cloud does not prove serial independence between events.
There is no causal inference from this scatter.

### Figure E — would constant bias or mean-plus-Gaussian be enough?

Three candidates are compared: the fitted pulse model; independent Gaussian
samples matched to the **training full-signal mean and variance**; and a constant
equal to that training mean. All are integrated with zero initial error over
the validation duration. The reference is the actual held-out signal. No model
uses the held-out mean as its fitted constant, avoiding that form of leakage.

The integrator assumes piecewise-constant acceleration over each sensor sample:

`v(k+1) = v(k) + a(k)*dt`

`p(k+1) = p(k) + v(k)*dt + 0.5*a(k)*dt^2`.

Plots include the initial zero and all n interval boundaries; terminal time is
n/Fs, while the final acceleration sample sample instant is (n-1)/Fs. These are
open-loop sensor-axis error integrations with a fixed frame, no gravity/orientation
error dynamics, and no estimator corrections. They are not a complete INS,
position-navigation forecast, or your actual closed-loop simulation.

**E1: velocity error.** Red and blue curves/ranges correspond to pulse and
Gaussian ensembles; green is mean-only; black is reference. For an ideal
integrator, velocity depends on signed acceleration area. Similar terminal
velocities can coexist with very different intermediate errors. If pulse
and Gaussian ranges differ substantially, temporal correlation, event-area
variability and tails matter beyond matching instantaneous variance. A constant
mean can reproduce one record's net velocity increment if fitted to that same
record, but this experiment deliberately tests a different suffix.

**E2: position error.** Earlier acceleration errors influence position for a
longer time. In continuous form, `position_error(T)=integral((T-t)*e(t), dt)`
for zero initial conditions. Thus equal full-record means need not produce
equal position errors when event timing differs. If all models give practically
equivalent position-error behavior within your system budget, individual pulses
may add little value for that particular use. If they differ near a requirement
limit, preserving the intermittent process is justified. A visually large
difference must still be judged against engineering tolerances.

**E3: terminal velocity CDF.** Shows variation across whole generated records,
not per-sample amplitude variation. The green line has no ensemble spread
because the mean-only candidate is deterministic. The black line is one
observed held-out result, not a measured population percentile. A narrow
Gaussian CDF and broad pulse CDF warn that a same-variance Gaussian simplification
may underestimate run-to-run integrated uncertainty. Many independent hardware
records are needed to validate a tail probability.

**E4: terminal position CDF.** Same interpretation for final position. Its
tails can be especially sensitive to pulse occurrence times and duration.
This directly supports a model-choice discussion, but does not automatically
establish a flight/mission/system-level probability of exceedance. Compare
these candidates in your real estimator/controller, including rejection gates
and saturation, before deciding the simpler model is adequate.

### Optional Figure F — multi-axis and class-transition checks

This four-tile figure appears with multiple selected axes or optional class
Markov modeling. **F1/F2** compare held-out zero-lag selected-axis correlation
with the average model correlation. Joint templates and quiet covariance can
preserve simultaneous structure; mismatches can indicate changing cross-axis
coupling or incomplete event support. Correlation can be dominated by a few
large events and does not establish causality or a frame definition.

**F3** shows raw training transition counts for the six dominant axis/sign
classes. Small counts reveal weak evidence, even if a normalized probability
looks extreme. **F4** shows probabilities after smoothing toward class frequency.
Rows for never-observed previous classes are fallback distributions, not learned
transitions from those classes. With `useEventMarkov=false`, these probabilities
are computed for inspection but not used in generation. With it true, only
first-order class dependence is represented; amplitude/gap serial dependencies
and slow regime switching are still outside the model.

If the data instead dwells at two sustained levels, random-telegraph/hidden
state models are another research direction. Puglisi and Pavan [R9] use hidden
Markov methods to analyze level switching and dwell behavior in electronic
memory noise. That is methodological context, not evidence of the same physical
mechanism in your accelerometer.

## 6. Saved tables and what they do NOT mean

`Analysis.mat` contains `results` and `PulseModel`, including configuration,
training/reference samples, generated ensemble, event statistics, spectra,
integration results and review checklist. Graphics handles are excluded.

`GaussMarkovSummary.csv` records the unconstrained pooled lag-one coefficient,
the fitted/overridden coefficient, its relaxation time and the adjacent quiet
pair count. Compare raw and fitted coefficients to spot clipping at a model
constraint. `HistogramSummary.csv` records the finite observation count for
each visualization axis. Actual histogram inputs are preserved in
results.input.histValues_ft_s2. These visualization channels are separate from
results.input.y, whose unmodeled axes are zero.

All output choices are in IMU_Config.m: saveResults controls file output;
exportCpp controls candidate source generation; saveFigures controls PNG/FIG
files. Large per-sample history CSV files are off unless writeHistoryCSVs=true.
The analysis MAT file still contains the histories and ensemble for review.

`ValidationSummary.csv` contains, per selected axis, held-out statistics, the
model ensemble mean and its pointwise 5th/95th percentile range: signed mean,
population standard deviation, total RMS, 0.1%/99.9% sample quantiles, maximum
absolute sample, positive/negative event counts and rates, positive/negative
threshold sample fractions, and final/maximum absolute integrated velocity and
position. Counts use complete events; threshold sample fractions include all
recorded samples, including boundary excursions. Each axis is counted only when
its own peak crosses its threshold inside a joint event.

`InsideModelRange` is descriptive. It is not a pass/fail hypothesis test.
Some values can lie outside a 90% pointwise model range even for an adequate
model, and the metrics are dependent. Repeated threshold tuning on the same
held-out suffix makes it development data; reserve a new independent record for
final evaluation after that tuning.

`SpectralSummary.csv` reports positive-frequency PSD log-ratio RMSE, plotted-ACF
RMSE and binned amplitude total variation. They have no universal acceptance
cutoffs. Choose tolerances based on downstream consequences, measurement
repeatability and operating requirements; do not invent a statistical confidence
level from an arbitrary small score.

`Summary_PLT.csv` reports all three platform components of the **selected-axis
contribution**: quiet baseline, held-out signed mean, AC RMS (population standard
deviation), total RMS, and one generated record's mean/AC RMS. Total RMS satisfies
`RMS² = mean² + variance`. RMS is nonnegative and is not a signed bias. The quiet
baseline is not the total pulse-contaminated mean. Other unmodeled axes' real
biases are not silently included in this table.

`Training_Event_Catalog.csv` documents eligible waveform indices, lengths,
preceding gaps, classes, peaks and signed areas. Indices are MATLAB one-based
positions in the TRAINING interval after conversion/window selection, not
original source rows. When writeHistoryCSVs=true, `History_sensor.csv`, `Generated_sensor.csv`,
`Generated_PLT.csv` use µg errors. When writeHistoryCSVs=true, `Generated_sensor_ft_s2.csv` converts generated
sensor error to ft/s²; it does not add true gravity/motion back into the signal.
`Provenance.json` records selections, acquisition rate, the row-clock rule, first/last original row,
transform, synthetic label and config.
Retain the original input file and configuration when maintaining traceability.

## 7. When is the candidate good enough to port?

Exporting proves constants were written, not that a model is validated.
`Readiness.csv` deliberately records unreviewed items rather than issuing an
automatic READY label. Use the following evidence in order:

1. **Input meaning:** confirm units, baseline, axis identity, sample timing,
   rotation direction and logger rule. A synthetic demo is not hardware evidence.
2. **Detector validity:** manually inspect representative positive and negative
   events, quiet periods, tails and any rail behavior. Repeat with reasonable
   threshold variations. Conclusions that reverse under tiny changes are fragile.
3. **Sufficient event support:** examine counts by sign/class and regime, not
   just total samples. Five eligible events only lets the algorithm run. Thirty
   events is merely a review heuristic; it is not a validated adequacy threshold.
   A few negative pulses cannot establish a rare negative-tail law. Zero observed
   events of a type cannot justify declaring the physical probability zero.
4. **Background model:** B1/B2 should make a Gaussian quiet approximation
   defensible, B3 should support the fitted exponential, and B6 should not show material residual dependence. If they do,
   change the quiet model and its C++ implementation together.
5. **Out-of-fit behavior:** inspect held-out signs, counts/rates, pulse areas,
   widths, gaps, amplitudes, AC PSD and ACF; explain material mismatches. Validate
   across independent runs and relevant temperature/load/vibration conditions
   rather than assuming one interval represents all operation.
6. **Downstream usefulness:** compare mean-only, Gaussian and pulse candidates
   in the actual simulator. Define tolerable differences in position/velocity
   distributions, estimator decisions, maximum excursions and requirement
   exceedances. If pulses do not change the decisions of interest materially,
   the simpler model can be sufficient for that purpose.
7. **Language/clock equivalence:** run the C++ candidate and compare its long-run
   statistics with the MATLAB ensemble using multiple seeds, identical sample
   rates and equal record durations. Verify inactive axes, reset, rotation,
   unit conversion and accumulation separately. See the procedure below.
8. **Document release scope:** identify which sensor axes, operating regime,
   bandwidth, run duration and observed amplitude/gap support were validated.
   The empirical catalog does not establish behavior outside that scope.

These criteria are engineering review criteria for this suite. The cited papers
provide foundations for model families and diagnostics, not a blanket
certification rule or universal numeric acceptance threshold. Your actual
system requirements determine whether porting is useful and adequate.

## 8. C++ export and integration into your function

Each run writes `Candidate_IMU_Model.cpp`, a full single-source scaffold with
fitted arrays. It has constants and prototypes at the top, persistent generator
state, then an example `void IMU_error()` and helper functions below it.
Unexported `cpp/IMU_Pulse_Integration_Template.cpp` deliberately refuses to run
because `fitted=false`. The exporter asserts exact zero inactive sensor baseline,
factor rows and waveform columns before producing the candidate.

In your implementation:

1. Bind the actual source sensor update rate: `sensor_dt_s=1/PulseModel.Fs` and
   `sensor_tick=0,1,2,...`. Model widths/gaps are sample counts. Do not reuse the
   constants at another rate without re-identifying/resampling the model.
2. Reset the persistent state once per independent Monte Carlo run/regime and
   provide the run seed. Reset your downstream accumulators separately. Use a
   separate state per sensor instance/thread; the example static state is for
   one instance.
3. Generate ONE joint sensor vector before your final XYZ loop, not one new
   event per component. Repeated requests at the same sensor tick return the
   cached vector. Backward ticks fail. Skipped ticks advance the generator but
   do not integrate missing physical intervals for you.
4. Supply your actual `R_sensor_to_platform` at the adapter inputs, using the
   same convention as MATLAB. Its example default is identity; the MATLAB
   configuration matrix is documented in Provenance.json, not automatically
   inserted into the C++ adapter. This is an explicit simulation binding.
5. Rotate the sampled model fluctuation and quiet baseline once. Add those
   contributions to your existing `noise[ii]` and `bias[ii]` sums respectively.
   These quantities are sampled acceleration errors in µg, not RMS parameters
   or noise densities. Insert after existing RMS-to-random-sample generation
   if that is how your function is structured.
6. Remove the older quiet-noise source and mean/quiet baseline for the SAME
   modeled process. Keep independent other errors. Do not multiply the generated
   pulse by another RMS coefficient/random draw, or add an old full-record mean
   on top. The pulse excursion already carries its nonzero mean contribution.

The final interface depends on what your internal accumulator actually consumes:

- Acceleration error in µg: `noise[ii]+bias[ii]`.
- Acceleration error in ft/s²: multiply by `1e-6*9.80665/0.3048`.
- Velocity increment error in ft/s: multiply that result by the source sample dt.

Choose one insertion point; do not inject both acceleration and its integrated
increment. If your simulation only accepts one constant bias parameter, it cannot
reproduce these time-varying pulses without changing that interface.

Do not copy the gyro's `current_noise - previous_noise` operation into an
acceleration integrator by analogy. Differencing a pulse produces edge changes;
summing such differences telescopes. That is different from summing acceleration
times dt. A current-minus-previous operation can be valid for an error already
defined on a cumulative measurement, but only with the actual units and update
equations established. This package does not invent the omitted internal update
in your simulator.

### Exercise the exported source, not only the template

After a hardware run, from the package folder with g++:

```sh
g++ -std=c++11 -O2 -Wall -Wextra -Werror -pedantic cpp/Check_Exported_Model.cpp -o check_export
./check_export YOUR_VALIDATION_SAMPLE_COUNT 1234 > output_hardware/CPP_Trace.csv
```

Use size(IMU_Results.reference,1) for the count. For the in-memory example, include
the source from output_example with a compiler override:

```sh
g++ -std=c++11 -O2 -DIMU_MODEL_FILE='"../output_example/Candidate_IMU_Model.cpp"' cpp/Check_Exported_Model.cpp -o check_export
./check_export YOUR_VALIDATION_SAMPLE_COUNT 1234 > output_example/CPP_Trace.csv
```

After generating a trace in cfg.outputFolder, call in MATLAB:

```matlab
CPP_Comparison = Check_CPP_Output(cfg);
```

Four plots per selected axis compare a C++ trace with MATLAB ensemble histograms,
PSD and ACF. Repeat with multiple independent seeds and equal durations. Different
RNGs mean individual sample histories need not match. The shared mathematical
model includes stationary quiet covariance, phi, the continuous latent update,
empirical event/gap tuples and their output-overwrite rule.

These tests use the example identity binding. Separately test your actual
rotation using known sensor vectors and test the real accumulator with known
constant/pulse inputs. Confirm the factors of dt, 0.3048 and 9.80665 directly.

Additional tests:

```matlab
addpath('tests');
Test_IMU_Suite
```

```sh
g++ -std=c++11 -Wall -Wextra -Werror -pedantic cpp/test_imu_pulse.cpp -o test_pulse
./test_pulse
g++ -std=c++11 -Wall -Wextra -Werror -pedantic cpp/test_selected_axes.cpp -o test_axes
./test_axes
g++ -std=c++11 -Wall -Wextra -Werror -pedantic cpp/test_gauss_markov.cpp -o test_gm
./test_gm
```

## 9. Evidence and further reading

The following primary research/institutional documentation was checked when
preparing this package. The algorithms and plot interpretations above are an
explicit engineering synthesis. No paper establishes that the described sensor
must follow this exact bootstrap or that a matching PSD alone validates it.

- **[R1]** P. Brémaud, L. Massoulié and A. Ridolfi (2005), *Power spectra of
  random spike fields and related processes*, Advances in Applied Probability
  37(4), 1116–1146. DOI: [10.1239/aap/1134587756](https://doi.org/10.1239/aap/1134587756).
  [Publisher abstract](https://www.cambridge.org/core/journals/advances-in-applied-probability/article/power-spectra-of-random-spike-fields-and-related-processes/4F8CEA2988AADA3B65EE31A4C16B23A9).
  General random-event/shot-noise spectral framework; not accelerometer-specific
  failure identification and not a requirement to assume Poisson events.
- **[R2]** NIST Dataplot, [Median Absolute Deviation](https://www.itl.nist.gov/div898/software/dataplot/refman2/auxillar/mad.htm).
  Robust scale and its normal-distribution scaling; does not validate our chosen
  detector multipliers.
- **[R3]** NIST/SEMATECH e-Handbook, [Histogram](https://www.itl.nist.gov/div898/handbook/eda/section3/histogra.htm).
  Exploratory distribution summaries and normalized histogram conventions.
- **[R4]** NIST/SEMATECH, [Histogram interpretation: bimodal mixture of two normals](https://www.itl.nist.gov/div898/handbook/eda/section3/histogr5.htm).
  An example of multiple population modes; not proof that your data is a normal
  mixture or that a histogram contains switching-time information.
- **[R5]** NIST/SEMATECH, [Autocorrelation Plot](https://www.itl.nist.gov/div898/handbook/eda/section3/autocopl.htm).
  Time-dependence diagnostics; our masked quiet estimator is described explicitly
  above, and formal NIST confidence limits are not asserted for it.
- **[R6]** MathWorks, [pwelch](https://www.mathworks.com/help/signal/ref/pwelch.html)
  and [xcorr](https://www.mathworks.com/help/matlab/ref/xcorr.html).
  Authoritative function definitions/scaling. Our simulation bands are distinct
  from pwelch's optional analytical PSD confidence intervals.
- **[R7]** MathWorks, [fft](https://www.mathworks.com/help/matlab/ref/fft.html).
  Discrete Fourier transforms and one-sided amplitude-spectrum convention.
- **[R8]** N. J. Kasdin (1995), *Discrete Simulation of Colored Noise and
  Stochastic Processes and 1/f^alpha Power Law Noise Generation*, Proceedings
  of the IEEE 83(5), 802–827. DOI: [10.1109/5.381848](https://doi.org/10.1109/5.381848).
  [University-hosted paper](https://umbc.edu/photonics/Menyuk/Phase-Noise/kasdin_ProcIEEE_950501n.pdf).
  Your uploaded copy was inspected. Relevant to a future colored-background
  extension; this suite does not implement that extension.
- **[R9]** F. M. Puglisi and P. Pavan (2014), *Factorial Hidden Markov Model
  analysis of Random Telegraph Noise in Resistive Random Access Memories*,
  ECTI Transactions 12(1), 24–29.
  [Paper and DOI](https://ph02.tci-thaijo.org/index.php/ECTI-EEC/article/view/170814).
  Alternative model family for sustained level switching, in a different device
  context. It does not diagnose your accelerometer.

NIST's [outlier discussion](https://www.itl.nist.gov/div898/handbook/eda/section3/eda35h.htm)
also explains why unusual observations should not simply be deleted without
establishing they are erroneous. Here the excursions are the behavior you intend
to model, so generic outlier removal would undermine that goal.

The uploaded Durbin paper concerns time-series fitting; it is not used to claim
an AR quiet model or a physical intermittent-fault model in this implementation.
No copyrighted paper PDFs are redistributed in the ZIP; references are linked.

- **[R10]** MathWorks, [Design Fusion Filter for Custom Sensors](https://www.mathworks.com/help/fusion/ug/design-fusion-filter-for-custom-sensors.html).
  Related use of a first-order Gauss-Markov sensor state. That example uses an
  Euler approximation to the continuous mean-reverting equation; this suite uses
  an explicit stationary discrete recursion and exponential correlation relation.
  This reference is conceptual; this suite uses its own scalar-transition/covariance
  implementation and does not require the navigation/fusion tools used in that
  example. Its newer example availability does not change this suite's R2021b target.
- MathWorks, [array2timetable](https://www.mathworks.com/help/matlab/ref/array2timetable.html),
  supports construction of the optional synthetic timetable in memory.

- **[R11]** A. G. Quinchia et al. (2013), *A Comparison between Different Error
  Modeling of MEMS Applied to GPS/INS Integrated Systems*, Sensors 13(8), 9549–9588.
  [Open-access paper](https://pmc.ncbi.nlm.nih.gov/articles/PMC3812568/),
  DOI: 10.3390/s130809549. Compares inertial stochastic-error model families and
  cautions that a first-order Gauss-Markov assumption need not fit actual MEMS
  behavior. This is a reason to inspect quiet ACF/innovation diagnostics, not
  evidence that it already fits your sensor or captures the separate spike population.

## 10. Dataset review conversation: observations and interpretation

This appendix records the questions, observations and explanations discussed
after Manu ran the analysis on his dataset. It is a readable record of that
conversation, with the observations separated from their interpretation. The
original guide above is retained; this appendix changes documentation only.

**Evidence boundary:** the plot observations below were reported by Manu. The
assistant checked the plotting/model code but did not independently inspect the
actual hardware samples or the resulting figures during this discussion. Terms
such as "good match" describe the reported visual assessment, not a numerical
acceptance test or a completed qualification of the model.

### 10.1. Timing clarification from the preceding discussion

**Question:** Are we generating time from row number and the known sampling
rate, rather than looking up time values in the input? Can the requested window
be specified as rows 1000 through 2000?

**Explanation:** The clock is constructed from the original sample row k as
`t(k) = (k - 1) / Fs`. Row 1 therefore corresponds to zero seconds, and adjacent
samples are separated by `1/Fs`. The input's time values are not used.

However, in the version discussed, `cfg.window_s` still accepts SECONDS rather
than row bounds. To select original rows 1000 through 2000 for an instantaneous
input using that existing setting, write:

```matlab
cfg.window_s = ([1000 2000] - 1) / cfg.sampleRate_Hz;
```

At 1000 Hz this selects 0.999 through 1.999 seconds, inclusive: 1001 samples
whose first-to-last timestamps span one second. Entering `[1000 2000]` directly
into `window_s` would instead request 1000 through 2000 seconds. This appendix
does not implement a new row-window setting. Cumulative-input decoding has the
additional interval/boundary handling described earlier in this guide.

### 10.2. Input and Detection: red spikes and an apparently missing background

**Reported observation/question:** The Input and Detection figure looked like
a collection of red spikes. The smaller noise near the horizontal axis was not
visible. Was this figure intended to show just the spikes or compare them with
test data? The figure was referred to as "A7" during the question.

**Explanation:** The relevant tile is **A1: selected error and detected events**
inside the Input and Detection figure. MATLAB's overall figure number can
differ from this tile label. Figure A itself contains only A1 through A6.

A1 first plots the COMPLETE measured signal in gray, including the background.
It then redraws the samples classified as events in red. The background has not
been deleted, but the large spikes set the vertical range, making the quiet
fluctuations look nearly flat. This is a detection display on measured data,
not a measured-versus-generated comparison.

The goal is for red to identify the excursions you consider pulse events while
ordinary background samples remain unmarked. The summary figure's **S3 quiet
background close-up** shows contiguous quiet test and generated segments on a
scale determined by those smaller fluctuations. S1 provides the full measured
versus generated history comparison. A1 by itself does not establish whether
the generated background is correct.

### 10.3. A2 threshold zoom: red directly on black

**Reported observation/question:** A2 showed red on top of black. Should that
happen?

**Explanation:** Yes. Black is the measured signal. Red redraws the SAME measured
samples where the detector's event mask is active. Exact overlap is expected;
red is a classification overlay, not a separate simulation trace.

The onset and release thresholds define a hysteresis detector: an excursion
starts an event at the onset threshold, and a return inside the lower release
threshold ends it. Inspect whether the red portions cover the physical events
you mean to model. If nearly everything is red, the detector may be too
sensitive, the baseline may be inappropriate, or this pulse/quiet separation
may not describe the record well. If visible excursions are missed, inspect
the threshold settings. Red-on-black alignment is not a model-accuracy test.

### 10.4. A3: what training and held-out data actually mean

**Reported observation/question:** The training and held-out histograms matched,
but the meaning of those labels was unclear. What does "held out" mean?

**Explanation:** Both are portions of the measured record within the selected
analysis window. They are not labels for measured versus generated data.

| Term | Default portion | What the code does with it |
|---|---|---|
| Training / fit data | First 70% | Fits the quiet baseline, background statistics, event waveforms and event timing |
| Held-out / test data | Remaining 30% | Checks the fitted model on measurements not used to estimate those quantities |
| Generated data | New model realizations | Simulates new histories using the fitted quantities |

"Held out" means set aside during fitting. For 10,000 selected samples with
`cfg.fitFraction = 0.70`, samples 1 through 7000 fit the model; samples 7001
through 10000 form the held-out check. The training-fitted detector is applied
to the held-out portion too, without refitting its thresholds there.

The reason for separating them is to ask whether the model describes later
measurements, rather than merely reproducing the samples used to construct it.
A held-out suffix is not automatically an independent experimental run:
neighboring samples may remain correlated, and both portions can share the
same operating conditions. Additional runs provide stronger evidence of
generalization. Repeatedly adjusting the model after inspecting this suffix
also makes a fresh validation record valuable for the final check.

**A3 compares measured data with measured data.** Its histogram agreement is
encouraging because it suggests similar amplitude occupancy in the fit and
test portions. It does not establish generated-model accuracy or matching
time dependence. The same histogram can result from differently ordered
samples. If synthetic-example mode is active, both measured/reference portions
come from the synthetic example instead of hardware.

The older comparison label "Training mean only" means a constant equal to the
mean of the entire fit signal, INCLUDING its pulses. Its clearer label is
"Fit-data mean (constant bias)". That mean differs from the quiet baseline when
pulses preferentially have one sign. It is not RMS or the ensemble mean of the
generated realizations.

### 10.5. What a quiet histogram represents

**Question:** What is the "quiet histogram"?

**Explanation:** Quiet samples are those classified as OUTSIDE detected pulse
events. Quiet does not mean exactly zero, nor does it mean samples known with
certainty to contain no other physical effects. The classification depends on
the detector and the supplied physical-baseline correction.

B1 uses quiet samples from the FIT portion, subtracts the fitted quiet baseline,
and plots their amplitude density. Its question is: after separating the
spikes, is a Gaussian marginal distribution a reasonable description of the
remaining background? The fitted Gaussian curve provides a visual reference.

Thus B1 is a background-assumption check, not a full-signal histogram and not
an independent held-out validation. A biased detector can affect which samples
enter it; the A plots should be reviewed before relying on the B plots.

### 10.6. B3: fast correlation decay followed by slight oscillation

**Reported observation:** Over a displayed lag range of approximately 0 to
0.25 seconds, the quiet autocorrelation decayed substantially in a short time
and then appeared to oscillate slightly.

**Interpretation:** Fast decay suggests short statistical memory in the quiet
background. Samples separated by more than the decay time have relatively
little linear correlation. This concerns separation in TIME, not whether two
samples occupy the same frequency bin.

Small fluctuations around zero at longer lags can occur in a finite record.
They do not automatically mean the model is wrong. However, a clear, repeatable
oscillation could indicate remaining tonal or oscillatory behavior that this
first-order positive-correlation Gauss-Markov model cannot reproduce. Its
theoretical normalized correlation is `phi^lag` for sample lag, giving a smooth
positive decay for `0 < phi < 1`.

B3 preserves the original time gaps when forming quiet-pair correlations; it
does not concatenate quiet samples across events. It has no formal significance
bounds in this version, so the reported oscillations cannot be declared
statistically insignificant from their appearance alone. Stronger evidence
would come from repeatability, amplitude relative to estimation variation and
the innovation check in B6.

**Follow-up:** B6 asks whether correlation remains after the fitted first-order
prediction has been removed. Apart from the normalized zero-lag value, its
correlation should be small if the model has adequately captured the quiet
linear dependence. An oscillatory structure persisting there suggests more
background dynamics remain to be modeled. Generic complete-record confidence
formulas should not be assumed valid without accounting for the masking and
fitted parameters.

### 10.7. B4: a single round cloud

**Reported observation/question:** B4 showed one approximately round cloud. Is
that good?

**Interpretation:** B4 plots a quiet sample against the immediately following
quiet sample, using only pairs that are both classified as quiet. A round cloud
on its equal-axis scale is consistent with weak adjacent-sample correlation.
An elongated diagonal cloud would suggest more persistence. One cloud also
shows no obvious separate quiet levels in this particular projection.

This is encouraging if it agrees with B3 and the fitted correlation factor.
If B4 is round, B3 loses correlation nearly immediately and `gmPhi` is close
to zero, white Gaussian background noise may be adequate at the sampling rate
used. The current Gauss-Markov model includes that limiting case.

A round cloud alone does not prove independence, normality or absence of
higher-lag dependence. It is one visual check alongside B1/B2/B3/B5/B6.

### 10.8. B1 and B5: symmetric Gaussian-looking distributions

**Reported observation/question:** B1 and B5 looked normally distributed with
no obvious skewness. Is that good?

**Interpretation:** Yes, these observations support the Gaussian assumptions,
but the panels test different quantities.

- **B1** tests the quiet background AMPLITUDES after subtracting the quiet
  baseline. A Gaussian-looking shape supports the marginal amplitude model.
- **B5** tests the standardized INNOVATIONS: the part of each quiet sample not
  explained by predicting it from the preceding quiet sample. For the scalar
  selected axis, the calculation is
  `innovation = (z(k+1) - phi*z(k)) / (sigma*sqrt(1 - phi^2))`.
  A suitable Gaussian innovation model should resemble the plotted normal
  reference with mean zero and variance one.

For B5, agreement in center, width and tails matters, not just symmetry. A
symmetric distribution can still have the wrong variance or non-Gaussian tails.
B2's Gaussian Q-Q plot helps inspect departures, especially in the tails.
B6 checks temporal correlation left in the innovations. A bell-shaped
histogram alone does not establish whiteness.

These B diagnostics use fit data. They support the chosen background structure
on that portion; they do not by themselves show that the later measured
background has the same statistics.

### 10.9. C3: is held-out the actual test comparison?

**Reported observation/question:** C3 seemed useful for showing model goodness.
Is its held-out curve the comparison to the actual test measurements?

**Explanation:** Yes. Unlike A3, C3 compares the held-out MEASURED amplitude
distribution with distributions from newly GENERATED records. The measured
curve uses the test portion set aside from fitting. The model curve is the
ensemble mean, and the shaded region spans pointwise 5th to 95th percentiles
across generated histogram probabilities.

Agreement supports the full-signal amplitude distribution: how often the
model visits common values and excursions. It does not show that individual
spikes occur at the same timestamps, which is not the aim of independent
stochastic realizations. It also does not establish pulse ordering or temporal
correlation. C6 and the D plots address complementary aspects.

### 10.10. C4: measured PSD near the lower edge of the generated range

**Reported observation/question:** The held-out Welch PSD lay toward the lower
extreme of the generated cloud. What does that mean?

**Interpretation:** The cloud is the pointwise 5th-to-95th percentile range of
Welch PSD estimates across generated records, with the fitted model held fixed.
It describes finite-realization variation. It is not a parameter-confidence
interval, a simultaneous band for the whole spectrum, or an automatic model
acceptance boundary.

If the measured PSD is consistently near the lower edge over a broad range,
the model MAY be generating more fluctuation power than that particular test
segment contains. This is a reason to investigate, not an automatic failure:
one measured realization can lie below the model mean, and frequency bins are
not independent trials.

Possible contributors include stronger modeled background variance, more
frequent or more energetic pulses, different pulse durations/shapes, or a
change in operating behavior between the fit and held-out portions. The
frequency pattern helps narrow the question:

| Pattern | What to investigate |
|---|---|
| Model PSD broadly above measured PSD | Overall fluctuation variance, background strength, pulse energy and event rate |
| Mismatch mainly at low frequencies | Background persistence, pulse timing/gaps, slow drift or regime changes |
| Localized spectral mismatch | Pulse shape/width or remaining frequency-specific structure |

Compare the held-out standard deviation against the model range in
`ValidationSummary`, and inspect C6, event counts/rates and A4/A5. If the mean
generated PSD stays systematically high across additional measured segments,
that is stronger evidence of a mismatch than one low-lying curve alone.

**Important distinction:** C4 removes each analyzed record's own mean. A
constant mean-offset difference by itself cannot explain a PSD discrepancy
there. Signed means still matter in the time histories and integrated-error
plots. Any eventual adjustment should follow identification of the cause rather
than scaling the complete signal solely to make the PSD overlay look better.

### 10.11. D1 through D6: all reported to match well

**Reported observation/question:** All six D plots matched the held-out data
well throughout. Is that a good sign?

**Interpretation:** Yes. This is useful supporting evidence for the detected
pulse model, subject to the event sample counts and the accuracy of detection.
Each plot checks a different aspect:

| Tile | Quantity compared | Why the agreement matters |
|---|---|---|
| D1 | Signed event peak | Supports positive/negative amplitude behavior |
| D2 | Event duration | Supports time spent within individual events |
| D3 | Preceding quiet gap | Supports spacing between detected events |
| D4 | Event-start interval | Supports recurrence timing including event duration |
| D5 | Signed pulse area above quiet baseline | Supports pulse contributions to integrated velocity error |
| D6 | Preceding gap versus absolute peak | Supports the displayed relationship between event spacing and size |

D5 is especially relevant for acceleration-error injection: the time integral
of acceleration contributes to velocity error. Position error also depends on
WHEN that acceleration occurs within the integration interval.

The generated event CDFs pool complete detected events over model runs; they
are descriptive distributions, not confidence bounds. A visually close CDF
with only a small number of measured events is weaker evidence than one based
on many representative events. D6 is a scatter comparison, so assess the
observed relationship and occupied range rather than expecting individual
points to coincide.

**Remaining check:** similar peak, width or gap distributions can coexist
with different numbers of events. Check positive/negative event counts and
rates in `ValidationSummary` as well. The D plots do not establish every
longer-term clustering or ordering relationship, and a good pulse match does
not independently validate the quiet background.

### 10.12. Interpretation retained from this dataset discussion

The reported observations are encouraging for the empirical pulse
representation and the Gaussian quiet-background assumption. Agreement of
fit and held-out amplitude histograms supports similar amplitude behavior over
those two portions. Gaussian-looking quiet amplitudes and innovations support
the background assumptions. Agreement across D1-D6 supports several important
event statistics, particularly pulse area and timing.

The two main unresolved items from this conversation are:

1. **B6:** check for unexplained temporal correlation in the quiet innovations,
   especially in light of the small oscillation reported in B3.
2. **C4:** determine whether generated fluctuation power is systematically high
   relative to the held-out measurements or whether the placement reflects
   finite-record variation.

The report did not include numerical amplitudes for the B3 oscillation, fitted
`gmPhi`, innovation-correlation values, PSD-error metrics or event counts.
Consequently this discussion records a qualitative assessment and the next
checks, not a numerical pass/fail conclusion or confirmation that the C++ model
is ready for release.

### 10.13. Documentation supporting this conversation

The primary documentation consulted for the discussion was:

- MathWorks, [Validating Models After Estimation](https://www.mathworks.com/help/ident/ug/validating-models-after-estimation.html),
  for the distinction between data used to estimate a model and data used to
  validate it.
- MathWorks, [What Is Residual Analysis?](https://www.mathworks.com/help/ident/ug/what-is-residual-analysis.html),
  for assessing unexplained time dependence using residual autocorrelation.
  This suite's masked innovation calculation is described above; it does not
  directly implement the documentation's full residual-testing workflow or
  its confidence-interval calculations.

These references support the diagnostic principles. They do not independently
verify the reported dataset observations. Section 9 contains the broader
research and function references for the modeling approach.
