// Synthetic generator/integration tests. No actual test-derived coefficients here.
#include "imu_switch_model.hpp"
#include <cassert>
#include <iostream>
#include <limits>

static const double low[] = {0.3,0.5,0.7};
static const double high[] = {0.1,0.2,0.4};
static const imu_switch::AxisParams params[3] = {
    {true, 10,1010,0.8,0.2,0.7,false,0.3,low,3,high,3},
    {true, -500,-100,0.6,0.4,0.1,true,0.25,low,3,high,3},
    {false,25,25,0,0,0,false,0,nullptr,0,nullptr,0}
};
static bool near(double a,double b,double tol=1e-10) { return std::abs(a-b)<tol; }
int main() {
    using imu_switch::Model; using imu_switch::Timing;
    Model p(params,Timing::Periodic); assert(p.valid());
    double y[3];
    assert(p.sample(0,y) && y[0]==10 && y[1]==-100 && y[2]==25);
    assert(p.sample(0.299,y) && y[0]==10);
    assert(p.sample(0.3,y) && y[0]==1010);
    assert(p.sample(0.301,y) && y[0]==1010);
    assert(p.sample(0.499,y) && y[0]==1010);
    assert(p.sample(0.5,y) && y[0]==10);
    assert(p.sample(0.501,y) && y[0]==10);
    assert(p.sample(0.501,y)); // duplicate call does not advance anything
    assert(!p.sample(0.1,y));  // backward clock must require reset
    p.reset(); assert(p.sample(0,y) && y[0]==10);
    assert(!p.sample(-1,y));
    assert(!p.sample(std::numeric_limits<double>::quiet_NaN(),y));

    // Time-averaged two-level signal has low+(high-low)*duty, without centering.
    p.reset(); double total=0;
    for (int k=0;k<10000;++k) { assert(p.sample((k+0.5)*0.001,y)); total+=y[0]; }
    assert(near(total/10000,210,1e-8));

    // Every empirical sample is one of the fitted levels; initial partial dwell
    // is kept separate from full dwell pools. Sampling cadence does not affect RNG.
    Model dense(params,Timing::EmpiricalDwells,987),sparse(params,Timing::EmpiricalDwells,987);
    assert(dense.valid() && sparse.valid());
    for (int k=0;k<=2000;++k) {
        double a[3],b[3]; assert(dense.sample(k*0.01,a));
        assert((a[0]==10 || a[0]==1010) && (a[1]==-500 || a[1]==-100) && a[2]==25);
        if (k%10==0) {
            assert(sparse.sample(k*0.01,b));
            for (int j=0;j<3;++j) assert(a[j]==b[j]);
        }
    }
    dense.reset(987); assert(dense.sample(0,y) && y[0]==10 && y[1]==-100);
    assert(dense.sample(0.299,y) && y[0]==10);
    assert(dense.sample(0.3,y) && y[0]==1010);
    Model otherSeed(params,Timing::EmpiricalDwells,988);
    dense.reset(987); int differences=0;
    for (int k=0;k<2000;++k) {
        double a[3],b[3]; assert(dense.sample(k*.01,a)); assert(otherSeed.sample(k*.01,b));
        if (a[0]!=b[0] || a[1]!=b[1]) ++differences;
    }
    assert(differences>0);

    // Physical unit conversion and rotation, not differencing of acceleration.
    p.reset(); const double R[3][3]={{0,-1,0},{1,0,0},{0,0,1}};
    double platform[3],dv[3];
    assert(imu_switch::acceleration_step(p,0,0.01,R,platform,dv));
    assert(platform[0]==100 && platform[1]==10 && platform[2]==25);
    assert(near(dv[0],100e-6*9.80665/0.3048*0.01));
    assert(!imu_switch::acceleration_step(p,0,0,R,platform,dv));

    // Invalid active parameters must fail clearly, even before any sampling.
    imu_switch::AxisParams invalid[3]={params[0],params[1],params[2]};
    invalid[0].high_s=0; Model bad(invalid,Timing::Periodic); assert(!bad.valid());
    invalid[0]=params[0]; invalid[0].high_count=0;
    Model noDwells(invalid,Timing::EmpiricalDwells); assert(!noDwells.valid());
    // Full telemetry differencing telescopes; it is NOT the acceleration integral.
    const double q[]={0,100,100,0}; double differencesSum=0,accelIntegral=0,previous=0;
    for(double value:q) { differencesSum+=value-previous; accelIntegral+=value*0.01; previous=value; }
    assert(differencesSum==0 && near(accelIntegral,2));
    std::cout << "PASS: periodic/empirical timing, levels, resets, RNG cadence, units, rotation and integration\n";
}
