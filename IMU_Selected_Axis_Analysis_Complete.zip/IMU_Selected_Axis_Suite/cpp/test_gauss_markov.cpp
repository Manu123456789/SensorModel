#include "IMU_Pulse_Integration_Template.cpp"
#include <cassert>
#include <iostream>
int main()
{
    static const double rows[2][3]={{0,100,0},{0,50,0}};
    static const std::size_t offset[1]={0},length[1]={2},gap[1]={2};
    static const unsigned cls[1]={2};
    ImuPulseParameters p=imu_pulse_parameters;
    p.fitted=true; p.Fs=200; p.event_count=1; p.sample_count=2;
    p.samples_ug=rows; p.offset=offset; p.length=length; p.gap=gap; p.event_class=cls;
    for (int j=0;j<6;++j) {
        p.class_probability[j]=0;
        for (int k=0;k<6;++k) p.transition_probability[j][k]=(k==2?1:0);
    }
    p.class_probability[2]=1; p.gm_phi=.5; p.burn_in_samples=0;
    ImuPulseState s={}; assert(imu_pulse_reset(p,s,1));
    s.gm_state_ug[1]=8;
    for (std::uint64_t tick=0;tick<8;++tick) {
        double x[3]; assert(imu_pulse_sample(p,s,tick,x));
        const double expected=8*std::pow(.5,static_cast<double>(tick+1));
        assert(std::abs(s.gm_state_ug[1]-expected)<1e-12);
        if (tick%4<2) assert(std::abs(x[1]-expected)<1e-12);
        else assert(x[1]==(tick%4==2?100:50)); // recorded pulse, no extra background
        assert(x[0]==0 && x[2]==0);
    }
    // Long quiet run: stationary variance and lag-one correlation.
    static const std::size_t longGap[1]={10000000}; p.gap=longGap;
    p.gm_phi=.9; p.noise_factor[1][1]=2; p.burn_in_samples=1000;
    assert(imu_pulse_reset(p,s,123));
    const int n=300000; double sum=0,sq=0,cross=0,previous=0;
    for (int k=0;k<n;++k) {
        double x[3]; assert(imu_pulse_sample(p,s,static_cast<std::uint64_t>(k),x));
        assert(!s.cached_is_pulse && x[0]==0 && x[2]==0);
        sum+=x[1]; sq+=x[1]*x[1]; if (k>0) cross+=x[1]*previous; previous=x[1];
    }
    const double mean=sum/n, variance=sq/n-mean*mean;
    const double rho=(cross/(n-1)-mean*mean)/variance;
    assert(std::abs(mean)<.06 && std::abs(variance-4)<.12 && std::abs(rho-.9)<.006);
    p.gm_phi=1; assert(!imu_pulse_validate(p)); p.gm_phi=-.1; assert(!imu_pulse_validate(p));
    std::cout<<"PASS: persistent GM state through events, no double noise, variance="<<variance<<", lag1="<<rho<<"\n";
}
