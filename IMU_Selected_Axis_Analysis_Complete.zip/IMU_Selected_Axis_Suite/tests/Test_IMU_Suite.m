function Test_IMU_Suite()
% Run in MATLAB: addpath('tests'); Test_IMU_Suite
root=fileparts(fileparts(mfilename('fullpath'))); addpath(root);
% Reuse the ACTUAL main configuration up to its RUN boundary, without loading data.
source=fileread(fullfile(root,'IMU_Config.m')); boundary=strfind(source,'%% RUN');
assert(numel(boundary)==1); eval(source(1:boundary-1));
cfg.makePlots=false; cfg.saveFigures=false; cfg.nRealizations=4;
cfg.sampleRate_Hz=200; cfg.window_s=[0 Inf]; cfg.baselineSensor_ms2=[0 0 0];
[T,truth]=Generate_Example_IMU(200,120);
T.Properties.VariableNames={'My X acceleration','Y_custom','Readout_Z'};
cfg.columns=struct('X','My X acceleration','Y','Y_custom','Z','Readout_Z');
d=imupulse.prepare(T,cfg);
assert(d.Fs==200 && isequal(d.t,(0:height(T)-1)'/200));
assert(all(d.histMask) && all(all(d.y(:,[1 3])==0)));
assert(all(all(isfinite(d.histValues_ft_s2))));
% Histograms may change on other axes; the selected model input must not change.
corrupt=T; corrupt{:,{'My X acceleration','Readout_Z'}}=1e8*ones(height(T),2);
d2=imupulse.prepare(corrupt,cfg); assert(isequal(d.y,d2.y));
% Row labels play no role: deliberately create metadata at a DIFFERENT rate.
other=array2timetable(T{:,:},'SampleRate',17,'VariableNames',T.Properties.VariableNames);
d3=imupulse.prepare(other,cfg); assert(isequal(d.t,d3.t) && isequal(d.y,d3.y));
cfg.window_s=[1 4]; window=imupulse.prepare(T,cfg);
assert(isequal(window.sourceRows,(201:801)') && window.t(1)==1 && window.t(end)==4);
cfg.window_s=[0 Inf];
for axis={'X','Y','Z'}
    cfg.selectedAxes=axis; d=imupulse.prepare(T,cfg);
    m=imupulse.fit(d.y(1:16800,:),200,d.mask,cfg);
    assert(m.gmPhi>=0 && m.gmPhi<1 && abs(m.gmPhi-truth.QuietPhi)<.15);
    x=imupulse.generate(m,5000,RandStream('mt19937ar','Seed',1));
    assert(all(all(x(:,~d.mask)==0)));
end
cfg.selectedAxes={'X','Y','Z'}; d=imupulse.prepare(T,cfg); assert(all(d.mask));
% Unused mapped columns can be omitted when their visualization is disabled.
cfg.selectedAxes={'Y'}; cfg.histogramAxes={'Y'}; only=T(:,{'Y_custom'});
small=imupulse.prepare(only,cfg); assert(all(all(small.y(:,[1 3])==0)));
% Full analysis smoke check (separate train / validation).
cfg.histogramAxes={'X','Y','Z'}; r=imupulse.analyze(T,cfg);
assert(all(all(r.Generated_sensor{:, [2 4]}==0)) && height(r.HistogramSummary)==3);
assert(r.model.gmPairCount>=30 && isfield(r,'GaussMarkovSummary'));
assert(r.summary.windowsPerRecord==floor(size(r.reference,1)/r.summary.windowSamples));
assert(size(r.summary.modelV,1)==r.summary.windowsPerRecord*cfg.nRealizations);
assert(all(all(r.summary.modelV(:,[1 3])==0)) && height(r.SummaryTerminal)==2);
% Window resets and ZOH position weighting: an early pulse travels farther.
fake=struct('model',struct('Fs',10,'selectedMask',[false true false]), ...
    'reference',zeros(23,3),'samples',zeros(23,3,2), ...
    'cfg',struct('summaryTerminalWindow_s',1));
fake.reference([1 20],2)=1; fake.samples(:,:,1)=fake.reference;
fake.samples(:,:,2)=fake.reference;
s=imupulse.summaryData(fake);
assert(s.windowsPerRecord==2 && s.discardedSamplesPerRecord==3);
assert(abs(s.testV(1,2)-s.testV(2,2))<1e-15 && s.testP(1,2)>s.testP(2,2));
assert(isequal(s.modelV,[s.testV;s.testV]) && isequal(s.modelP,[s.testP;s.testP]));
assert(abs(s.testV(1,2)-9.80665e-7)<1e-15);
assert(abs(s.testP(1,2)-.95*9.80665e-7)<1e-15);
fake.cfg.summaryTerminalWindow_s=100; s=imupulse.summaryData(fake);
assert(s.windowsPerRecord==1 && s.windowSamples==23);
% Summary graphics smoke check: six data axes and usable background segment.
r.cfg.figureVisible='off'; figures=imupulse.plotSummary(r);
assert(numel(figures)==1 && numel(findall(figures,'Type','axes'))==6); close(figures);
% Constant acceleration and event timing have known integration consequences.
[v,p]=imupulse.integrate(ones(100,1),100);
assert(abs(v(end)-9.80665e-6)<1e-15 && abs(p(end)-.5*9.80665e-6)<1e-15);
% Decoder retains later original rows and the known acquisition rate.
cfg.histogramAxes={'Y'}; cfg.inputMode='sample_sum_cm_s2';
accum=only; accum.Y_custom=cumsum(only.Y_custom*30.48);
dec=imupulse.prepare(accum,cfg); cfg.inputMode='instantaneous_ft_s2';
instant=imupulse.prepare(only,cfg);
assert(isequal(dec.sourceRows,(2:height(T))'));
assert(max(abs(dec.y(:,2)-instant.y(2:end,2)))<1e-7);
fprintf('PASS: workspace-style timetable, mapped XYZ histograms, selected models, row clock, GM fit, units.\n');
end
