// Compile the ACTUAL filled error_sensor() example against a mock host.
// No hardware simulation or unseen host implementation is claimed here.
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <vector>

static std::uint32_t seed=0;
static int size=3;
static bool reset_model=true,use_test_accel_model=false,test_model_condition=true;
static double global_time=0.,sensor_dt_s=.005,test_model_start_time_s=.1;
static std::uint64_t sensor_tick=0;
static double accel_frame_settings[3][3];
static double accel_noise_sigma[3]={.0001,.0003,.0002};
static double random_walk_convolution[3]={.001,.002,-.003};
static double accel_delta_output[3];
static struct {double noise[3];} internal_data;
static double ideal_values[3]={.2,.3,-.4},bias_values[3]={.002,-.003,.004};
static double other_values[3]={-.001,.005,.002};
static int legacy_draws=0;
static double delaythta(int i) {return ideal_values[i];}
static double bias(int i) {return bias_values[i];}
static double other_error_terms(int i) {return other_values[i];}
static double xyz(int,int) {return 0.;}
static void error_vector_multiplier(double,double,double) {}
static double host_uniform(std::uint32_t& s) {
    s=1664525u*s+1013904223u;
    return (double(s)+.5)/4294967296.;
}
static void rn_norm_limits(std::uint32_t* rng_seed,int* n,double* output) {
    if(rng_seed==&seed) legacy_draws+=*n;
    for(int i=0;i<*n;++i) {
        const double a=host_uniform(*rng_seed),b=host_uniform(*rng_seed);
        output[i]=std::sqrt(-2.*std::log(a))*std::cos(6.283185307179586*b);
    }
}

// This includes the exact error_sensor() body, including its local constants.
#include "../cpp/Accel_Fourier_Error_Sensor.cpp"

// Independent expectations for the synthetic initializer, not production globals.
static const std::uint64_t expected_record_samples=32;
static const double expected_ug_to_host=9.80665e-6/0.3048;

struct Row {double output[3],history[3];std::uint32_t legacySeed;};
static std::vector<Row> run(bool enabled,double addedSensorY) {
    seed=119; reset_model=true;
    use_test_accel_model=enabled; legacy_draws=0;
    for(int i=0;i<3;++i) {
        internal_data.noise[i]=0.;
        // R_sensor_to_platform[i][1] == accel_frame_settings[1][i].
        bias_values[i]=(.002-.003*i)+accel_frame_settings[1][i]*addedSensorY;
    }
    std::vector<Row> records;
    const int n=2*int(expected_record_samples)+100;
    for(int k=0;k<n;++k) {
        sensor_tick=k; global_time=k*sensor_dt_s;
        test_model_condition=k<20+2*int(expected_record_samples) || k>=40+2*int(expected_record_samples);
        for(int i=0;i<3;++i) random_walk_convolution[i]=.001*(i+1)+k*1e-7;
        error_sensor();
        assert(!reset_model);
        Row row; row.legacySeed=seed;
        for(int i=0;i<3;++i) {row.output[i]=accel_delta_output[i];row.history[i]=internal_data.noise[i];}
        records.push_back(row);
    }
    assert(legacy_draws==6*n);
    return records;
}
int main() {
    // Proper nonidentity rotation, stored in the pre-transpose convention.
    const double a=.37,b=.62;
    const double R[3][3]={{std::cos(a),-std::sin(a)*std::cos(b),std::sin(a)*std::sin(b)},
                         {std::sin(a),std::cos(a)*std::cos(b),-std::cos(a)*std::sin(b)},
                         {0.,std::sin(b),std::cos(b)}};
    for(int i=0;i<3;++i) for(int j=0;j<3;++j) accel_frame_settings[i][j]=R[j][i];
    const auto legacy=run(false,0.); const auto model=run(true,0.);
    const auto changedBias=run(true,100.); const auto repeated=run(true,0.);
    int positive[2]={},negative[2]={}; bool event=false;
    for(std::size_t k=0;k<legacy.size();++k) {
        const bool enabled=k>=20 && (k<20+2*expected_record_samples||k>=40+2*expected_record_samples);
        assert(legacy[k].legacySeed==model[k].legacySeed);
        for(int i=0;i<3;++i) {
            assert(legacy[k].history[i]==model[k].history[i]);
            assert(model[k].output[i]==repeated[k].output[i]);
            if(enabled) assert(std::abs(model[k].output[i]-changedBias[k].output[i])<1e-11);
            else assert(legacy[k].output[i]==model[k].output[i]);
        }
        double sensorLegacy[3]={},sensorModel[3]={};
        for(int j=0;j<3;++j) for(int i=0;i<3;++i) {
            sensorLegacy[j]+=R[i][j]*(legacy[k].output[i]-ideal_values[i]);
            sensorModel[j]+=R[i][j]*(model[k].output[i]-ideal_values[i]);
        }
        assert(std::abs(sensorLegacy[0]-sensorModel[0])<1e-11);
        assert(std::abs(sensorLegacy[2]-sensorModel[2])<1e-11);
        if(enabled) {
            const double ug=sensorModel[1]/(expected_ug_to_host*sensor_dt_s);
            const std::uint64_t restart=k<20+2*expected_record_samples ? 20 : 40+2*expected_record_samples;
            const int point=int((k-restart)%expected_record_samples);
            double expected=.3;
            if(point==5) expected=80.;
            if(point==19) expected=-45.;
            if(point==25) expected=20.;
            assert(std::abs(ug-expected)<2e-7);
            if(k<20+2*expected_record_samples) {
                const int block=int((k-20)/expected_record_samples);
                const bool pulse=ug>10.||ug<-8.;
                if(pulse&&!event) {if(ug>0)++positive[block];else++negative[block];}
                event=pulse;
            }
        }
    }
    for(int k=0;k<2;++k) {assert(positive[k]==2);assert(negative[k]==1);}
    std::cout<<"PASS: exact integrated error_sensor() body; legacy RNG/history unchanged; sensor X/Z preserved under rotation; full Y replacement; time/condition gating; run reset; full sample-by-sample Fourier spikes; two periods.\n";
}
