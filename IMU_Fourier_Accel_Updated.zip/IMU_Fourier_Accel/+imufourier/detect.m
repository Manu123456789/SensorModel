function e=detect(x,m)
% One reproducible definition for both measured and generated events.
% Crossing the onset threshold starts a pulse. Falling below it ends one.
% A direct sign reversal starts a new event even without a quiet sample.
e=struct('mask',false(size(x)),'start',{cell(1,3)},'stop',{cell(1,3)});
for j=find(m.selectedMask)
    z=x(:,j)-m.baseline(j); cls=zeros(size(z));
    cls(z>=m.threshold(j))=1; cls(z<=-m.threshold(j))=-1;
    e.mask(:,j)=cls~=0;
    e.start{j}=find(cls~=0 & cls~=[0;cls(1:end-1)]);
    e.stop{j}=find(cls~=0 & cls~=[cls(2:end);0]);
end
end
