function Test_Export_IMU_Axis()
% Optional MATLAB check: synthetic models only; no hardware calibration.
% Run: addpath('tests'); Test_Export_IMU_Axis
root=fileparts(fileparts(mfilename('fullpath'))); addpath(root);
folder=tempname; mkdir(folder); cleanup=onCleanup(@()rmdir(folder,'s')); %#ok<NASGU>
for axis=1:3
    m=struct('Fs',100,'selectedMask',false(1,3),'baseline',zeros(1,3), ...
        'covariance',zeros(3),'gmPhi',.9,'templates',{{}}, ...
        'gapSamples',[2;3],'classes',2*(axis-1)+[1;2], ...
        'classFrequency',zeros(1,6),'transitionProbability',zeros(6), ...
        'useEventMarkov',false,'burnInSamples',50);
    m.selectedMask(axis)=true; m.baseline(axis)=3; m.covariance(axis,axis)=4;
    a=zeros(2,3); a(:,axis)=[100;200]; b=zeros(1,3); b(axis)=-50;
    m.templates={a;b}; classes=2*(axis-1)+[1 2];
    m.classFrequency(classes)=[.5 .5]; m.transitionProbability(:,classes)=repmat([.5 .5],6,1);
    path=fullfile(folder,sprintf('axis%d.cpp',axis)); Export_IMU_Axis_To_CPP(m,path);
    text=fileread(path);
    tokens=regexp(text,'imu_axis_parameters=\{\s*true,(\d),([^,]+),([^,]+),([^,]+),([^,]+),','tokens','once');
    assert(numel(tokens)==5 && str2double(tokens{1})==axis-1);
    assert(str2double(tokens{2})==100 && str2double(tokens{3})==3 && str2double(tokens{4})==2);
    assert(abs(str2double(tokens{5})-.9)<1e-15);
    assert(contains(text,'imu_event_sign[2]={0,1,};'));
    assert(contains(text,'imu_event_offset[2]={0,2,};'));
    assert(contains(text,'imu_event_length[2]={2,1,};'));
    assert(contains(text,'imu_event_gap[2]={2,3,};'));
end
invalid=m; invalid.selectedMask=[true true false]; caught=false;
try, Export_IMU_Axis_To_CPP(invalid,fullfile(folder,'invalid.cpp')); catch, caught=true; end
assert(caught,'Joint multi-axis fits must not silently become a scalar model.');
fprintf('PASS: selected X/Y/Z export, sigma/baseline/phi, class/row indexing, multi-axis rejection.\n');
end
