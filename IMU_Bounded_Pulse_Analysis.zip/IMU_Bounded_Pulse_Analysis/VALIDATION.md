# Verification — record-matched revision 3

The MATLAB source targets R2021b+ with Signal Processing Toolbox. MATLAB/Octave
were unavailable in this environment, so MATLAB execution and hardware fitting
are NOT claimed. The hardware data and plots described by the user were not
available for numerical inspection. The included images are prominently labeled
SYNTHETIC and were generated with an independent Python reference.

## Executed checks

`tests/verify_reference.py` fits a 60,000-sample, 200-Hz synthetic challenge with
mixed pulse shapes/widths, asymmetric signs, non-geometric spacing and rare sharp
positive/negative extremes. It compares the new record-conditioned generator
against an independent implementation of revision 2's bounded lognormal/geometric
model. This is one synthetic benchmark, not an expected hardware performance gain.

Across 24 new complete-block realizations:

- Exactly 134 positive and 46 negative detected complete events in every run.
- Both observed pulse extrema retained; no output bound violations.
- The rare positive tail above 800 ug appears in every run (one sample/run).
  The prior generator missed it in 22/24 runs and had 157–207 total events/run.
- Ensemble mean binned amplitude TV: approximately .00405 new versus .00663 old.
- Ensemble mean Welch PSD log-ratio RMSE: approximately .77 dB versus 3.88 dB old.
  PSD agreement is reported, not guaranteed by an amplitude/count fit.

Additional checks cover one type per observed event with all sample rows retained
(exact pulse-sample histogram), missing negative class, zero quiet variance,
width-one pulses, censored boundary segments, sign-changing pulse topology,
a mandatory extreme in a biphasic event, two full blocks plus a partial block,
fresh stochastic order/gaps/quiet noise, and no clipping atoms in quiet draws.
The first sample of each quiet slot is release-conditioned so a measured pulse's
scheduled end is not extended by a random quiet value above the release level.

The EXACT C++ implementation extracted from README.md is compiled with:

```text
g++ -std=c++11 -O2 -Wall -Wextra -Werror -pedantic
```

Its synthetic coefficients exercise 12 complete blocks, exact redetected signed
counts, extrema, bounds, reset/continuation, width-one pulses and rejection of
invalid parameters. An AddressSanitizer/UndefinedBehaviorSanitizer run also passes
with leak detection disabled in this environment. The runtime sample streams
need not be identical to MATLAB/Python because RNG algorithms/draw order differ.

Static checks confirm all package calls resolve, MATLAB primary function names
match their filenames, the S/G/R figures have six tiles, README fences balance,
and the package contains no C++ exporter or generated C++ source.
Both exported scientific preview figures were visually inspected.

Machine-readable results: `evidence/RecordMatch_Validation.json`.
Reproduce the independent checks from the package root with:

```text
python3 tests/verify_reference.py /absolute/path/to/scratch-build
```

Dependencies for those OPTIONAL verification checks are NumPy, SciPy, matplotlib
and g++. They are not runtime dependencies of the MATLAB package or C++ model.

## Supplied MATLAB checks — not executed here

Run `Test_IMU_Bounded` after adding the package and tests folders to your path.
The test covers custom channel names, one selected axis at a time, original-row
clock despite conflicting timetable sample metadata, bounded output, complete
block signed counts and length, partial continuation, full-record versus held-out
reference modes, the four coefficient tables, exact pulse-sample limit, missing
sign/noiseless background, boundary segments, topology, conditional noise, ZOH
integration, cumulative-input decoding, and all nine single-axis figure families
with no more than six data axes per figure.

## Interpretation limits

Fixed counts and template multiplicities deliberately condition on one record;
this can be useful for reproducing a disturbance scenario, but it understates
natural count/area variability and does not validate unseen sensor behavior.
Whole-block terminal velocity variance and low-frequency PSD can be affected by
the artificial block constraint. Coefficient compression may still change
individual amplitude bins or signed occupancy; inspect R, FitReview and the
histogram/tail tables. More types/knots can improve pulse fidelity at the cost
of more constants. These tests do not qualify the model, host integration or
estimator/controller against the user's sensor.
