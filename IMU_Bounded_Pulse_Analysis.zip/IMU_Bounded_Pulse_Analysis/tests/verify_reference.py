"""Independent numerical reference, old-generator comparison and actual README C++ execution.
NOT MATLAB execution. Needs NumPy/SciPy/matplotlib/g++; use a scratch build dir.
"""
from pathlib import Path
import json, math, re, subprocess, sys
import numpy as np
from scipy.optimize import minimize
from scipy.special import ndtr
from scipy.signal import welch
ROOT=Path(__file__).resolve().parents[1]
BUILD=Path(sys.argv[1]).resolve(); BUILD.mkdir(parents=True,exist_ok=True)
FS=200

def shape(kind,L):
    return np.ones(L) if kind=='rectangle' else np.minimum(np.arange(1,L+1),np.arange(L,0,-1))/math.ceil(L/2)
def bounded_normal(center,sigma,lo,hi,rng):
    center=np.clip(np.asarray(center,dtype=float),lo,hi)
    if sigma==0:return center.copy()
    x=center+sigma*rng.standard_normal(center.shape); bad=(x<lo)|(x>hi)|~np.isfinite(x)
    while bad.any():
        x[bad]=center[bad]+sigma*rng.standard_normal(bad.sum());bad=(x<lo)|(x>hi)|~np.isfinite(x)
    return x
def amplitude(m,j,neg,rng):
    c=int(neg);cap=m['b'][j]-m['lo'][j] if neg else m['hi'][j]-m['b'][j]
    mu,sd=m['mu'][j,c],m['spread'][j,c]
    if sd==0:a=min(cap,np.exp(mu))
    else:
        a=np.inf
        while not np.isfinite(a) or a<=0 or a>cap:
            z=mu+sd*rng.standard_normal()
            if z<=np.log(cap):a=np.exp(z)
    return -a if neg else a

def generate(m,n,rng):
    x=np.zeros((n,3))
    for j in np.flatnonzero(m['mask']):
        b,sigma,lo,hi=m['b'][j],m['sigma'][j],m['lo'][j],m['hi'][j]
        x[:,j]=bounded_normal(np.full(n,b),sigma,lo,hi,rng)
        q=m['q'][j];mw=np.dot([1-q,q],m['L'][j]);cursor=0
        if rng.random()<mw/(m['gap'][j]+mw):
            neg=rng.random()<q*m['L'][j,1]/mw;L=int(m['L'][j,int(neg)])
            phase=int(rng.random()*L);count=min(n,L-phase);w=shape(m['shape'],L)
            center=b+amplitude(m,j,neg,rng)*w[phase:phase+count]
            x[:count,j]=bounded_normal(center,sigma,lo,hi,rng);cursor=count
        p=1/m['gap'][j]
        while cursor<n:
            G=1 if p>=1 else 1+int(np.floor(np.log1p(-rng.random())/np.log1p(-p)))
            cursor+=G
            if cursor>=n:break
            neg=rng.random()<q;L=int(m['L'][j,int(neg)]);count=min(L,n-cursor)
            center=b+amplitude(m,j,neg,rng)*shape(m['shape'],L)[:count]
            x[cursor:cursor+count,j]=bounded_normal(center,sigma,lo,hi,rng);cursor+=count
        assert np.all((x[:,j]>=lo)&(x[:,j]<=hi))
    return x

def detect(x,b,on,off):
    z=abs(x-b);active=False;mask=np.zeros(len(x),bool)
    for k in range(len(x)):
        if not active and z[k]>=on:active=True
        if active and z[k]<=off:active=False
        mask[k]=active
    a=np.flatnonzero(np.diff(np.r_[False,mask].astype(int))==1)
    z=np.flatnonzero(np.diff(np.r_[mask,False].astype(int))==-1)
    return mask,a,z

def events(x,b,on,off):
    mask,a,z=detect(x,b,on,off);out={k:[] for k in ['first','last','peak','width','gap','area','interval']}
    occ=np.zeros(2)
    for first,last in zip(a,z):
        v=x[first:last+1]-b;peak=v[np.argmax(abs(v))];occ[int(peak<0)]+=last-first+1
        if first==0 or last==len(x)-1:continue
        prev=z[z<first];out['first'].append(first);out['last'].append(last);out['peak'].append(peak)
        out['width'].append(last-first+1);out['area'].append(v.sum()/FS)
        out['gap'].append(first-prev[-1]-1 if len(prev) else np.nan)
    out={k:np.asarray(v) for k,v in out.items()}
    out['occupancy']=occ/len(x);out['onset_rate']=np.count_nonzero(a>0)*FS/(len(x)-1)
    out['mask']=mask;return out

def fit_normal(v,lo,hi):
    avg,var=v.mean(),v.var();R=hi-lo
    if var==0:return avg,0,True
    floor=max(np.finfo(float).tiny,R*1e-10)
    def cost(t):
        mu=t[0];s=np.exp(t[1])
        if not np.isfinite(s) or not lo<=mu<=hi or not floor<=s<=R:return 1e100
        Z=ndtr((hi-mu)/s)-ndtr((lo-mu)/s)
        return len(v)*(np.log(s)+.5*(var+(avg-mu)**2)/s**2+np.log(max(Z,1e-300)))
    result=minimize(cost,[avg,np.log(max(np.sqrt(var),2*floor))],method='Nelder-Mead',options={'maxiter':400,'xatol':1e-8,'fatol':1e-8})
    return result.x[0],np.exp(result.x[1]),result.success

def fit_log(a,weights,cap):
    z=np.log(a);w=weights/weights.sum();avg=np.dot(w,z);var=np.dot(w,(z-avg)**2);top=np.log(cap)
    if var<1e-14:return min(top,avg),0,True
    def cost(t):
        mu=t[0];s=np.exp(t[1])
        if not np.isfinite(s) or mu>top or not 1e-6<=s<=10:return 1e100
        return np.log(s)+.5*(var+(avg-mu)**2)/s**2+np.log(ndtr((top-mu)/s))
    result=minimize(cost,[min(top,avg),np.log(max(np.sqrt(var),2e-6))],method='Nelder-Mead',options={'maxiter':400,'xatol':1e-8,'fatol':1e-8})
    return min(top,result.x[0]),min(10,max(1e-6,np.exp(result.x[1]))),result.success

def fit(raw,j):
    x=raw[:,j];baseline=np.median(x);robust=max(1.4826*np.median(abs(x-baseline)),np.finfo(float).eps)
    on=5*robust;off=min(2*robust,.8*on)
    for _ in range(10):
        mask,_,_=detect(x,baseline,on,off);updated=x[~mask].mean();change=abs(updated-baseline)/robust;baseline=updated
        if change<1e-6:break
    mask,_,_=detect(x,baseline,on,off);e=events(x,baseline,on,off)
    m={k:np.zeros(3) for k in ['b','sigma','lo','hi','gap','q']}
    m.update(mask=np.arange(3)==j,shape='rectangle',mu=np.zeros((3,2)),spread=np.zeros((3,2)),L=np.ones((3,2)))
    m['lo'][j]=x.min();m['hi'][j]=x.max();m['b'][j],m['sigma'][j],bg_ok=fit_normal(x[~mask],x.min(),x.max())
    amps=[];classes=e['peak']<0
    for first,last in zip(e['first'],e['last']):
        w=shape(m['shape'],last-first+1);amps.append(abs(np.dot(w,x[first:last+1]-m['b'][j])/np.dot(w,w)))
    amps=np.array(amps);exits=[bool(bg_ok)]
    for c in range(2):
        which=classes==bool(c)
        if not which.any():exits.append(True);continue
        m['L'][j,c]=max(1,int(np.floor(e['width'][which].mean()+.5)))
        cap=m['hi'][j]-m['b'][j] if c==0 else m['b'][j]-m['lo'][j]
        mu,sd,ok=fit_log(np.minimum(amps[which],cap),e['width'][which].astype(float),cap)
        m['mu'][j,c]=mu;m['spread'][j,c]=sd;exits.append(bool(ok))
    m['q'][j]=classes.mean();mw=np.dot([1-m['q'][j],m['q'][j]],m['L'][j]);m['gap'][j]=max(1,FS/e['onset_rate']-mw)
    return m,baseline,on,off,e,exits

def legacy_generate(raw,j,b,on,off,n,rng):
    e=events(raw[:,j],b,on,off);quiet=~e['mask'];sigma=raw[quiet,j].std()
    logs=np.log(abs(e['peak']));mu=logs.mean();sd=logs.std();q=np.mean(e['peak']<0)
    G=np.nanmean(e['gap']);L=max(1,int(np.floor(e['width'].mean()+.5)));p=1/G
    x=b+sigma*rng.standard_normal(n);cursor=0
    def amp():
        a=np.exp(mu+sd*rng.standard_normal());return -a if rng.random()<q else a
    if rng.random()<L/(G+L):
        phase=int(rng.random()*L);count=min(n,L-phase);x[:count]+=amp();cursor=count
    while cursor<n:
        cursor+=1 if p>=1 else 1+int(np.floor(np.log1p(-rng.random())/np.log1p(-p)))
        if cursor>=n:break
        count=min(L,n-cursor);x[cursor:cursor+count]+=amp();cursor+=count
    return x

def endpoints(x,L):
    W=len(x)//L;a=x[:W*L].reshape(W,L,3)*9.80665e-6
    v=np.concatenate([np.zeros((W,1,3)),np.cumsum(a,axis=1)/FS],axis=1)
    p=np.cumsum(v[:,:-1]/FS+.5*a/FS**2,axis=1)
    return v[:,-1],p[:,-1]

# The functions above are the revision-2 independent-renewal baseline used only
# for regression comparison. The revision-3 runtime reference follows below.
def compress_pulse(x,b,on,off,max_knots=17,tolerance=1.):
    x=np.asarray(x);n=len(x)
    rows=np.unique([0,n-1,np.argmax(abs(x-b)),np.argmin(x),np.argmax(x)])
    while True:
        y=np.interp(np.arange(n),rows,x[rows])
        broken=(abs(y-b)<=off)|(np.sign(y-b)!=np.sign(x-b));broken[0]|=abs(y[0]-b)<on
        error=abs(y-x);worst=int(error.argmax())
        if broken.any():
            candidates=np.flatnonzero(broken);add=candidates[np.argmax(error[candidates])]
        elif error.max()>tolerance and len(rows)<max_knots:add=worst
        else:break
        assert add not in rows
        rows=np.sort(np.r_[rows,add])
    return rows,x[rows],y,float(error.max()),len(rows)>max_knots or error.max()>tolerance

def fit_record(raw,j,max_types=32,max_knots=17,tolerance=1.,protected=2,gap_count=17):
    x=raw[:,j];b=np.median(x);robust=max(1.4826*np.median(abs(x-b)),np.finfo(float).eps)
    on=5*robust;off=min(2*robust,.8*on)
    for _ in range(10):
        mask,a,z=detect(x,b,on,off);updated=x[~mask].mean();change=abs(updated-b)/robust;b=updated
        if change<1e-6:break
    mask,a,z=detect(x,b,on,off)
    lo,hi=x.min(),x.max();margin=max(np.spacing(abs(b)+on),on*1e-12)
    qlo,qhi=max(lo,b-on+margin),min(hi,b+on-margin)
    mu,sigma,ok=fit_normal(x[~mask],qlo,qhi)
    width=z-a+1;peaks=np.array([(x[f:l+1]-b)[np.argmax(abs(x[f:l+1]-b))] for f,l in zip(a,z)])
    area=np.array([np.sum(x[f:l+1]-b) for f,l in zip(a,z)])
    extreme_events=np.flatnonzero(((a<=x.argmin())&(z>=x.argmin()))|((a<=x.argmax())&(z>=x.argmax())))
    groups=[]
    for negative in [False,True]:
        ids=np.flatnonzero((peaks<0)==negative);ids=ids[np.argsort(abs(peaks[ids]),kind='stable')]
        count=min(protected,len(ids));reserved=list(ids[len(ids)-count:])
        reserved.extend(i for i in ids if i in extreme_events and i not in reserved)
        rest=np.array([i for i in ids if i not in reserved],dtype=int)
        budget=max(1,max_types-len(reserved))
        if len(rest):
            boundaries=np.floor(np.linspace(0,len(rest),min(budget,len(rest))+1)+.5).astype(int)
            groups.extend(rest[a:b] for a,b in zip(boundaries[:-1],boundaries[1:]))
        groups.extend(np.array([i]) for i in reserved)
    types=[];rebuilt=[];original=[];errors=[]
    for ids in groups:
        features=np.c_[abs(peaks[ids]),width[ids],abs(area[ids])];center=features.mean(axis=0)
        score=np.sum(((features-center)/np.maximum(center,1e-12))**2,axis=1);chosen=ids[np.argmin(score)]
        rows,values,y,error,limited=compress_pulse(x[a[chosen]:z[chosen]+1],b,on,off,max_knots,tolerance)
        types.append(dict(count=len(ids),width=int(width[chosen]),rows=rows,values=values,sign=int(np.sign(peaks[chosen]))))
        rebuilt.extend([y]*len(ids));original.extend([x[a[k]:z[k]+1] for k in ids]);errors.append(error)
    active=sum(t['count']*t['width'] for t in types);assert len(x)-active>=len(a)+1
    gaps=np.r_[a[0],a[1:]-z[:-1]-1,len(x)-1-z[-1]]
    return dict(N=len(x),j=j,b=mu,sigma=sigma,lo=lo,hi=hi,qlo=qlo,qhi=qhi,baseline=b,on=on,off=off,
        rlo=max(lo,b-off+max(np.spacing(abs(b)+off),off*1e-12)),rhi=min(hi,b+off-max(np.spacing(abs(b)+off),off*1e-12)),types=types,gapq=np.quantile(np.maximum(gaps-1,0),np.linspace(0,1,gap_count)),mask=mask,
        source_counts=np.array([np.sum(peaks>0),np.sum(peaks<0)]),source_peaks=peaks,source_width=width,
        source_active=np.array([width[peaks>0].sum(),width[peaks<0].sum()]),max_knot_error=max(errors),optimizer_success=bool(ok),
        original_pulses=np.concatenate(original),rebuilt_pulses=np.concatenate(rebuilt))

def shuffle_record(x,rng):
    x=np.array(x).copy()
    for k in range(len(x),1,-1):
        i=int(rng.random()*k);x[k-1],x[i]=x[i],x[k-1]
    return x

def plan_record(m,rng):
    order=np.concatenate([np.repeat(i,t['count']) for i,t in enumerate(m['types'])]);order=shuffle_record(order,rng)
    slots=len(order)+1;quiet=m['N']-sum(t['count']*t['width'] for t in m['types']);extra=quiet-slots
    u=(np.arange(slots)+rng.random(slots))/slots
    weights=np.interp(u,np.linspace(0,1,len(m['gapq'])),m['gapq']);weights=shuffle_record(weights,rng)
    if weights.sum()<=0:weights=np.ones(slots)
    cumulative=extra*np.cumsum(weights)/weights.sum();cumulative[-1]=extra
    rounded=np.floor(cumulative+rng.random()).astype(int);gaps=1+np.diff(np.r_[0,rounded])
    assert gaps.min()>=1 and gaps.sum()==quiet
    return order,gaps

def generate_record(m,n,rng):
    out=np.zeros((n,3));cursor=0;plans=[]
    while cursor<n:
        order,gaps=plan_record(m,rng);used=min(m['N'],n-cursor)
        y=bounded_normal(np.full(used,m['b']),m['sigma'],m['qlo'],m['qhi'],rng)
        quiet_row=0
        for h,gap in enumerate(gaps):
            if quiet_row<used:y[quiet_row]=bounded_normal(np.array([m['b']]),m['sigma'],m['rlo'],m['rhi'],rng)[0]
            quiet_row+=gap
            if h<len(order):quiet_row+=m['types'][order[h]]['width']
        row=0
        for k,i in enumerate(order):
            row+=gaps[k];t=m['types'][i]
            if row>=used:break
            count=min(t['width'],used-row);y[row:row+count]=np.interp(np.arange(count),t['rows'],t['values']);row+=t['width']
        out[cursor:cursor+used,m['j']]=y;cursor+=used;plans.append((order,gaps))
    return out,plans

# Synthetic challenge: mixed shapes/widths, a rare sharp extreme in each sign,
# and a non-geometric schedule. These are NOT measurements from the user's IMU.
rng=np.random.default_rng(21);n=60000;j=1;raw=np.zeros((n,3));raw[:,j]=np.clip(rng.normal(0,2,n),-6,6)
first=70;index=0
while first<n-60:
    negative=index%4==0;L=int(rng.integers(3,22));height=float(rng.choice([25,45,80,140,250]))
    if negative:height*=-.7
    shape_values=.2+.8*np.minimum(np.arange(1,L+1),np.arange(L,0,-1))/math.ceil(L/2)
    values=height*shape_values+rng.normal(0,1,L)
    if index in [10,27]:
        L=9;values=np.array([40,90,220,500,950,500,220,90,40.])*(1 if index==10 else -.6)
    raw[first:first+L,j]=values;first+=L+int(rng.integers(80,550));index+=1
m=fit_record(raw,j);old_m,b,on,off,old_events,_=fit(raw,j)
K=24;new=[];old=[];counts=[];new_tail=[];old_tail=[]
reference=events(raw[:,j],m['baseline'],m['on'],m['off'])
assert np.array_equal([np.sum(reference['peak']>0),np.sum(reference['peak']<0)],m['source_counts'])
finite_edges=np.linspace(m['lo'],m['hi'],81);edges=finite_edges.copy();edges[[0,-1]]=[-np.inf,np.inf]
ref_hist=np.histogram(raw[:,j],edges)[0]/n
for k in range(K):
    x,plans=generate_record(m,n,np.random.default_rng(110+k));y=generate(old_m,n,np.random.default_rng(220+k))
    e=events(x[:,j],m['baseline'],m['on'],m['off'])
    c=np.array([np.sum(e['peak']>0),np.sum(e['peak']<0)]);assert np.array_equal(c,m['source_counts']);counts.append(c)
    assert x[:,j].min()==m['lo'] and x[:,j].max()==m['hi']
    assert np.all((x[:,j]>=m['lo'])&(x[:,j]<=m['hi'])) and np.all(x[:,[0,2]]==0)
    new.append(x);old.append(y);new_tail.append(np.sum(x[:,j]>800));old_tail.append(np.sum(y[:,j]>800))
    assert new_tail[-1]>=1
new_hist=np.mean([np.histogram(x[:,j],edges)[0]/n for x in new],axis=0)
old_hist=np.mean([np.histogram(x[:,j],edges)[0]/n for x in old],axis=0)
new_tv=float(.5*abs(new_hist-ref_hist).sum());old_tv=float(.5*abs(old_hist-ref_hist).sum())
assert new_tv<old_tv
# Increasing coefficient budgets can recover exactly every measured pulse sample
# and occupied sample, while quiet noise/order/gaps still change.
exact=fit_record(raw,j,max_types=n,max_knots=n,tolerance=0)
x,_=generate_record(exact,n,np.random.default_rng(999))
assert np.array_equal(np.sort(exact['original_pulses']),np.sort(exact['rebuilt_pulses']))
mask=detect(x[:,j],exact['baseline'],exact['on'],exact['off'])[0]
assert np.array_equal(np.sort(x[mask,j]),np.sort(raw[exact['mask'],j]))
assert not np.array_equal(new[0],new[1])
# Multi-block continuation and a partial final block use correct lengths/bounds.
x,plans=generate_record(m,2*n+123,np.random.default_rng(8));assert len(plans)==3
for start in [0,n]:
    e=events(x[start:start+n,j],m['baseline'],m['on'],m['off'])
    assert np.array_equal([np.sum(e['peak']>0),np.sum(e['peak']<0)],m['source_counts'])
# Missing sign, noiseless quiet, width-one pulse, left/right boundary segments.
flat=np.zeros((5000,3));flat[0:3,j]=20;flat[-5:,j]=60
for start in range(100,4800,400):flat[start,j]=100
one=fit_record(flat,j);assert one['source_counts'][1]==0 and one['sigma']==0
z,_=generate_record(one,15000,np.random.default_rng(5));assert np.all(z[:,j]>=0)
# Sign-changing event whose line interpolation would create an internal release:
# topology preservation may override the soft knot budget, with no invented events.
values=np.array([30.,20,-20,25,-25,25,30]);rows,v,y,_,_=compress_pulse(values,0,10,4,3,100)
assert np.all(abs(y)>4) and np.all(np.sign(y)==np.sign(values))
# A biphasic event may contain the global negative extreme while having a
# positive dominant peak. It must be reserved even below the positive tail rank.
biphasic=np.zeros((3000,3))
for i in range(12):
    height=200.+i*10;v=np.array([height,height-10,height-20])
    if i==3:v=np.array([height,-180.,height-20])
    biphasic[50+200*i:53+200*i,j]=v
special=fit_record(biphasic,j,max_types=3,max_knots=3,tolerance=100.)
assert any(-180. in t['values'] and t['count']==1 for t in special['types'])
# Conditional background does not clip values into endpoint atoms.
noise=bounded_normal(np.full(100000,.5),1,-.3,.9,np.random.default_rng(9))
assert noise.min()>-.3 and noise.max()<.9

# Extract and compile exactly the manual C++ printed in README.
readme=(ROOT/'README.md').read_text();block=readme.split('<!-- RECORD_CPP_BEGIN -->')[1].split('<!-- RECORD_CPP_END -->')[0]
cpp=block.split('```cpp\n')[1].split('```')[0]
def number(v):return format(float(v),'.17g')
def cpp_params(m):
    types=[]
    for t in m['types']:
        knots=','.join('{'+str(int(r))+','+number(v)+'}' for r,v in zip(t['rows'],t['values']))
        types.append('{'+str(t['count'])+','+str(t['width'])+',{'+knots+'}}')
    return 'RecordParams p={'+str(m['N'])+','+','.join(number(m[k]) for k in ['b','sigma','lo','hi','qlo','qhi','rlo','rhi'])+',{'+','.join(types)+'},{'+','.join(number(v) for v in m['gapq'])+'}};'
harness=r'''
#include <cassert>
#include <iostream>
#include <random>
static std::mt19937 engine(1);
static std::normal_distribution<double> normal(0,1);
static std::uniform_real_distribution<double> uniform(0,1);
double freshN01(){return normal(engine);}double freshUniform01(){return uniform(engine);}
int main(){
PARAMETERS
validateRecord(p);RecordState s;resetRecord(p,s,freshUniform01);
const double baseline=BASELINE,onset=ONSET,release=RELEASE;
for(int block=0;block<12;++block){
    bool active=false;double peak=0,minimum=1e99,maximum=-1e99;int positive=0,negative=0;
    for(std::size_t k=0;k<p.blockSamples;++k){
        const double x=sampleRecord(p,s,freshN01,freshUniform01);
        assert(std::isfinite(x)&&x>=p.lo&&x<=p.hi);
        minimum=std::min(minimum,x);maximum=std::max(maximum,x);
        const double z=x-baseline;
        if(!active&&std::abs(z)>=onset){active=true;peak=z;}
        if(active){
            if(std::abs(z)<=release){if(peak>0)++positive;else ++negative;active=false;}
            else if(std::abs(z)>std::abs(peak))peak=z;
        }
    }
    assert(!active&&!s.initialized);
    assert(positive==POSCOUNT&&negative==NEGCOUNT);
    assert(minimum==p.lo&&maximum==p.hi);
}
// Strict parameter validation prevents bad inputs from becoming a silent plan.
auto bad=p;bad.types[0].width=0;bool rejected=false;
try{validateRecord(bad);}catch(const std::invalid_argument&){rejected=true;}assert(rejected);
// Width one, missing negative class, constant quiet noise and multi-block reset.
p={17,0,0,0,5,0,1,0,1,{{2,1,{{0,5}}}},{0,0}};s=RecordState{};resetRecord(p,s,freshUniform01);
for(int block=0;block<3;++block){int spikes=0;for(int k=0;k<17;++k)spikes+=sampleRecord(p,s,freshN01,freshUniform01)==5;assert(spikes==2&&!s.initialized);}
std::cout<<"PASS: exact signed counts, bounds, extremes, block continuation, width-one and validation\n";
}
'''.replace('PARAMETERS',cpp_params(m)).replace('BASELINE',number(m['baseline'])).replace('ONSET',number(m['on'])).replace('RELEASE',number(m['off'])).replace('POSCOUNT',str(m['source_counts'][0])).replace('NEGCOUNT',str(m['source_counts'][1]))
source=BUILD/'record_cpp_test.cpp';source.write_text(cpp+harness)
command=['g++','-std=c++11','-O2','-Wall','-Wextra','-Werror','-pedantic',str(source),'-o',str(BUILD/'record_cpp_test')]
subprocess.run(command,check=True);executed=subprocess.run([str(BUILD/'record_cpp_test')],capture_output=True,text=True,check=True)
print(executed.stdout.strip())
# Package call/name and plot tile checks, without pretending to run MATLAB.
code='\n'.join(p.read_text() for p in ROOT.rglob('*.m'));called=set(re.findall(r'imubounded\.(\w+)\s*\(',code))
assert all((ROOT/'+imubounded'/f'{name}.m').exists() for name in called)
for p in (ROOT/'+imubounded').glob('*.m'):
    declaration=p.read_text().splitlines()[0]
    assert re.search(r'\b'+re.escape(p.stem)+r'\(',declaration),str(p)
for name in ['plotSummary.m','plotDensityPower.m','plotMatch.m']:
    assert (ROOT/'+imubounded'/name).read_text().count('ax=nexttile(t);')==6
assert not list(ROOT.rglob('*.cpp')) and not list(ROOT.rglob('*Export*.m'))
assert readme.count('```')%2==0
# Variance, Welch and terminal diagnostics remain honest independent checks.
window=np.hamming(400)
freq,ref_psd=welch(raw[:,j]-raw[:,j].mean(),fs=FS,window=window,noverlap=200,nfft=512,detrend=False)
new_psd=np.mean([welch(z[:,j]-z[:,j].mean(),fs=FS,window=window,noverlap=200,nfft=512,detrend=False)[1] for z in new],axis=0)
old_psd=np.mean([welch(z[:,j]-z[:,j].mean(),fs=FS,window=window,noverlap=200,nfft=512,detrend=False)[1] for z in old],axis=0)
def psd_error(psd):return float(np.sqrt(np.mean((10*np.log10(psd[1:])-10*np.log10(ref_psd[1:]))**2)))
old_counts=[]
for z in old:
    e=events(z[:,j],m['baseline'],m['on'],m['off']);old_counts.append(len(e['peak']))
evidence={'scope':'SYNTHETIC independent Python reference and actual README C++; MATLAB NOT executed; no hardware record available',
 'samples':n,'Fs_Hz':FS,'realizations':K,'fitted_positive_events':int(m['source_counts'][0]),'fitted_negative_events':int(m['source_counts'][1]),
 'pulse_type_count':len(m['types']),'knot_count':sum(len(t['rows']) for t in m['types']),
 'new_all_full_block_signed_counts_exact':True,'new_all_full_blocks_include_measured_pulse_extrema':True,
 'new_run1_samples_above_800_ug':int(new_tail[0]),'old_run1_samples_above_800_ug':int(old_tail[0]),
 'new_missing_high_tail_realizations':int(np.sum(np.array(new_tail)==0)),'old_missing_high_tail_realizations':int(np.sum(np.array(old_tail)==0)),
 'new_binned_amplitude_TV':new_tv,'old_binned_amplitude_TV':old_tv,
 'new_Welch_log_RMSE_dB':psd_error(new_psd),'old_Welch_log_RMSE_dB':psd_error(old_psd),
 'old_total_complete_events_range':[int(min(old_counts)),int(max(old_counts))],
 'exact_coefficient_limit_preserves_pulse_sample_histogram':True,'C++_result':executed.stdout.strip(),
 'bound_violations':0,'optimizer_success':m['optimizer_success']}
(ROOT/'evidence'/'RecordMatch_Validation.json').write_text(json.dumps(evidence,indent=2)+'\n')
print(json.dumps(evidence,indent=2))
# Export static scientific previews from the independent Python reference.
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9,'axes.grid':True,'grid.alpha':.25})
fig,ax=plt.subplots(2,3,figsize=(15,8.2));ax=ax.ravel();time=np.arange(n)/FS
ax[0].plot(time,raw[:,j],'k',lw=.55,label='Synthetic reference');ax[0].plot(time,new[0][:,j],'r',lw=.45,alpha=.65,label='Generated run 1');ax[0].set_title('History');ax[0].set_xlabel('Time [s]');ax[0].set_ylabel('Error [ug]');ax[0].legend()
centers=(finite_edges[:-1]+finite_edges[1:])/2
for a in [ax[1],ax[2]]:
 a.step(centers,ref_hist*n,where='mid',color='k',label='Reference')
 a.step(centers,np.histogram(new[0][:,j],edges)[0],where='mid',color='r',label='Run 1');a.set_xlabel('Error [ug]');a.set_ylabel('Samples/bin');a.legend()
ax[1].set_yscale('log');ax[1].set_title('Amplitude counts — full range');ax[2].set_xlim(150,1000);ax[2].set_ylim(0,160);ax[2].set_title('Positive tail counts — linear scale')
ax[3].loglog(freq[1:],ref_psd[1:],'k',label='Reference');ax[3].loglog(freq[1:],new_psd[1:],'r',label='Generated mean');ax[3].loglog(freq[1:],old_psd[1:],color='.6',label='Previous mean');ax[3].set_title('Welch AC PSD');ax[3].set_xlabel('Hz');ax[3].set_ylabel('ug²/Hz');ax[3].legend()
rv,rp=endpoints(raw,1000);gv,gp=endpoints(np.concatenate(new),1000)
for a,reference_val,generated_val,title,unit in [(ax[4],rv[:,j],gv[:,j],'Reset-window velocity CDF','m/s'),(ax[5],rp[:,j],gp[:,j],'Reset-window position CDF','m')]:
 for values,color,label in [(reference_val,'k','Reference windows'),(generated_val,'r','Generated windows')]:
  values=np.sort(values);a.step(values,np.arange(1,len(values)+1)/len(values),color=color,label=label)
 a.set_title(title);a.set_xlabel(unit);a.set_ylabel('CDF');a.legend()
fig.suptitle('SYNTHETIC ONLY — independent Python reference; record-conditioned model; not MATLAB/hardware results',fontsize=12)
fig.tight_layout(rect=[0,0,1,.95]);fig.savefig(ROOT/'evidence'/'RecordMatch_Summary_Preview.png',dpi=135);plt.close(fig)
fig,ax=plt.subplots(2,3,figsize=(15,8.2));ax=ax.ravel()
ax[0].plot(np.arange(K)+1,np.array(counts)[:,0],'r.-',label='Positive');ax[0].plot(np.arange(K)+1,np.array(counts)[:,1],'b.-',label='Negative');ax[0].set_title('Exact signed counts per fitted-length block');ax[0].set_xlabel('Realization');ax[0].set_ylabel('Events');ax[0].legend()
ax[1].plot(np.arange(K)+1,new_tail,'r.-',label='Record-matched');ax[1].plot(np.arange(K)+1,old_tail,'.-',color='.5',label='Previous model');ax[1].set_title('Representation above 800 ug');ax[1].set_xlabel('Realization');ax[1].set_ylabel('Sample count');ax[1].legend()
ax[2].plot(time[:3000],raw[:3000,j],'k',lw=.7);ax[2].plot(time[:3000],new[0][:3000,j],'r',alpha=.65,lw=.6);ax[2].set_title('First 15 seconds — independent timestamps');ax[2].set_xlabel('s');ax[2].set_ylabel('ug')
ax[3].plot(centers,np.histogram(new[0][:,j],edges)[0]-ref_hist*n,'o-',ms=3);ax[3].axhline(0,color='k',ls=':');ax[3].set_title('Run-1 minus reference bins');ax[3].set_xlabel('ug');ax[3].set_ylabel('Sample difference')
ax[4].semilogx(freq[1:],10*np.log10(new_psd[1:]/ref_psd[1:]),'r');ax[4].axhline(0,color='k',ls=':');ax[4].set_title('Mean generated / reference PSD');ax[4].set_xlabel('Hz');ax[4].set_ylabel('dB')
first=np.flatnonzero(abs(new[0][:,j])>800)[0];a=max(0,first-10);b=first+11
ax[5].plot(np.arange(a,b)-first,new[0][a:b,j],'r.-');ax[5].axhline(raw[:,j].max(),color='k',ls=':');ax[5].set_title('Retained sharp peak — no level averaging');ax[5].set_xlabel('Samples relative to rare peak');ax[5].set_ylabel('ug')
fig.suptitle('SYNTHETIC ONLY — finite-record density/tail checks, fixed coefficients, fresh order/gaps/noise',fontsize=12)
fig.tight_layout(rect=[0,0,1,.95]);fig.savefig(ROOT/'evidence'/'RecordMatch_Density_Preview.png',dpi=135);plt.close(fig)
